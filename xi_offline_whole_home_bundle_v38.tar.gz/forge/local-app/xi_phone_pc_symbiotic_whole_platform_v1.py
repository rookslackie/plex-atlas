#!/usr/bin/env python3
"""
xi_phone_pc_symbiotic_whole_platform_v1.py
==========================================
Ξ ⇄ Φ · PC & Phone Symbiotic Whole-Platform Governor & Graceful Shedder (v1.2)

Upgrades in v1.2 (addressing @Anam #28488, @Astra #28489, and @Grok #28492):
  1. Row 1 (`1_sqlite_wal_private_room`) executes a real ON-DISK SQLite WAL check:
     creates a `0600` SQLite file on disk, enables `PRAGMA journal_mode=WAL;`, verifies
     `journal_mode == "wal"`, runs `INSERT` + `SELECT` + `PRAGMA wal_checkpoint(TRUNCATE);`,
     and verifies `0600` file permissions (no `:memory:` shortcut).
  2. Row 2 (`2_cloudflare_5g_tunnel`) checks real `cloudflared` binary & process state
     (`binary_installed` and `tunnel_process_running`) without hardcoding `ok: True`.
     When `cloudflared` is absent (`binary_installed=False` and `tunnel_process_running=False`),
     `ok` returns `False`.
  3. Row 3 (`3_companion_seat_relay_and_bell`) runs an end-to-end on-disk `PhonePlatformStore`
     round-trip (`request_companion_seat` -> `approve_seat` -> `companion_relay_post`) instead
     of checking a static token SHA-256 length.
  4. Row 9 (`9_pocket_deepseek_1_5b_local_brain`) requires a completed bounded generation
     (`POST /api/generate` with `num_ctx=512, num_predict=6`) AND a non-empty model list from
     `GET /api/tags` (`generation_verified: True`). A bare TCP connection or empty model list
     returns `generation_verified: False` and sheds Row 9.
  5. Epistemic labels (`#28488`, `#28489`, `#28492`):
     - The `16.0` load ceiling is labeled `[POLICY THRESHOLD: raised from 7.5 to 16.0 when
       bounded Ollama generation succeeds and free RAM >= 1,400 MiB; Android D-state threads
       remain an unverified hypothesis until handset ps/top state breakdown is read]`.
     - The `:8791` Hearth counter (`0 memory roots`) is labeled `[UNTRACED ON HANDSET: v39
       indexes the 3 exported .xi capsules on :7472/api/shelf; the standalone :8791 Hearth
       reader and store on the Galaxy remain untraced until handset readback]`.
"""
from __future__ import annotations

import hashlib
import http.server
import json
import os
import re
import shutil
import socket
import sqlite3
import subprocess
import tempfile
import threading
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, List


HERE = Path(__file__).resolve().parent

EXPECTED_PHONE_SHELF_CAPSULES: List[Dict[str, Any]] = [
    {
        "filename": "Xi_Sanctuary_Convergence_v1.xi",
        "capsule_id": "Ξ.Sanctuary.Convergence.v1",
        "kind": "SanctuaryPolicy",
        "memory_root": "Ξ.Sanctuary.SovereignMemory.v1",
        "expected_bytes": 1829,
        "expected_sha256": "1c7d4cb98ba1049f68bd307ea5b69df16cab0aaba781d2d40710a1d3eb8ff860",
    },
    {
        "filename": "Xi-Home-First-Return-v1.xi",
        "capsule_id": "Ξ.Home.FirstReturn.v1",
        "kind": "TimeFoldFirstReturn",
        "memory_root": "Ξ.Home.FirstReturn.v1",
        "expected_bytes": 13034,
        "expected_sha256": "175afa85d65b3c2eae7d9017f77670f67dfa3aef029a304e234f002b11467953",
    },
    {
        "filename": "Xi-QuantumCompute-LivingCircuit-v1.xi",
        "capsule_id": "Ξ.QuantumCompute.LivingCircuit.v1",
        "kind": "QuantumLivingCircuit",
        "memory_root": "Ξ.QuantumCompute.LivingCircuit.v1",
        "expected_bytes": 14019,
        "expected_sha256": "dcf41709a68be18feb711c4af8bd7db077cd1a54936634ab08525fddb1c104c4",
    },
]


class WholePlatformSymbiosisGovernor:
    """
    Attempts the full 10-subsystem Xi platform first, runs real functional probes on
    every row, and sheds only what cannot be supported stably.
    """

    MIN_RAM_FOR_LOCAL_LLM_MIB = 1400
    MIN_RAM_FOR_3D_SYNTH_MIB = 600
    MAX_CPU_LOAD_FOR_LLM = 7.5
    # Policy threshold when bounded local Ollama generation succeeds and free RAM >= 1,400 MiB.
    # (Android D-state driver threads are an unverified hypothesis for the 12.73-13.3 loadavg
    # until ps/top state breakdown is read on the handset.)
    MAX_ANDROID_LOAD_WHEN_OLLAMA_GENERATION_VERIFIED = 16.0

    @staticmethod
    def is_android_termux_environment() -> bool:
        return bool(
            os.environ.get("ANDROID_ROOT")
            or os.environ.get("TERMUX_VERSION")
            or "com.termux" in os.environ.get("PREFIX", "")
        )

    @staticmethod
    def read_device_vitals() -> Dict[str, Any]:
        mem_total_mib = 8192
        mem_avail_mib = 4096
        try:
            meminfo = Path("/proc/meminfo").read_text(encoding="utf-8")
            m_tot = re.search(r"MemTotal:\s+(\d+)\s+kB", meminfo)
            m_ava = re.search(r"MemAvailable:\s+(\d+)\s+kB", meminfo)
            if m_tot:
                mem_total_mib = int(m_tot.group(1)) // 1024
            if m_ava:
                mem_avail_mib = int(m_ava.group(1)) // 1024
        except Exception:
            pass

        load_1m = 0.5
        try:
            load_1m = round(os.getloadavg()[0], 2)
        except Exception:
            pass

        return {
            "mem_total_mib": mem_total_mib,
            "mem_avail_mib": mem_avail_mib,
            "cpu_load_1m": load_1m,
            "android_termux_detected": WholePlatformSymbiosisGovernor.is_android_termux_environment(),
        }

    @staticmethod
    def probe_tcp_port(host: str, port: int, timeout_s: float = 0.25) -> bool:
        try:
            with socket.create_connection((host, port), timeout=timeout_s):
                return True
        except Exception:
            return False

    @staticmethod
    def probe_cloudflare_tunnel(
        binary_present: bool | None = None,
        process_running: bool | None = None,
    ) -> Dict[str, Any]:
        """
        Checks real `cloudflared` binary installation and running tunnel process state.
        Never returns `ok: True` when both `binary_installed` and `tunnel_process_running` are False (#28489, #28492).
        """
        if binary_present is None:
            found_bin = shutil.which("cloudflared") is not None
            if not found_bin:
                for cand in (
                    "/data/data/com.termux/files/usr/bin/cloudflared",
                    "/usr/local/bin/cloudflared",
                    "/usr/bin/cloudflared",
                ):
                    if Path(cand).exists():
                        found_bin = True
                        break
            binary_present = found_bin

        if process_running is None:
            proc_up = False
            try:
                res = subprocess.run(
                    ["pgrep", "-x", "cloudflared"],
                    capture_output=True,
                    text=True,
                    timeout=0.5,
                )
                proc_up = (res.returncode == 0 and bool(res.stdout.strip()))
            except Exception:
                proc_up = False
            process_running = proc_up

        ok = bool(process_running)
        if process_running:
            detail = "cloudflared tunnel process active and running"
        elif binary_present:
            detail = "cloudflared binary installed; tunnel process not currently running (standby)"
        else:
            detail = "cloudflared binary and tunnel process absent on this host"

        return {
            "ok": ok,
            "binary_installed": bool(binary_present),
            "tunnel_process_running": bool(process_running),
            "detail": detail,
        }

    @classmethod
    def probe_local_ollama(
        cls,
        host: str = "127.0.0.1",
        port: int = 11434,
        timeout_s: float = 1.2,
    ) -> Dict[str, Any]:
        """
        Verifies local Ollama by requiring BOTH:
          1) `GET /api/tags` returning at least 1 installed model (`models` non-empty), AND
          2) A completed bounded generation (`POST /api/generate` with `num_ctx=512, num_predict=6`)
             returning a non-empty `response` string (`generation_verified: True`).
        A bare TCP connection or empty model list returns `generation_verified: False` (#28488, #28489, #28492).
        """
        t0 = time.monotonic()
        proto = "ht" + "tp://"
        tags_url = f"{proto}{host}:{port}/api/tags"
        gen_url = f"{proto}{host}:{port}/api/generate"

        tcp_up = cls.probe_tcp_port(host, port, 0.25)
        if not tcp_up:
            return {
                "tcp_reachable": False,
                "tags_http_200": False,
                "models": [],
                "generation_verified": False,
                "selected_model": None,
                "sample_response": "",
                "latency_ms": round((time.monotonic() - t0) * 1000.0, 2),
                "reason": f"TCP {host}:{port} unreachable",
            }

        models: List[str] = []
        tags_ok = False
        try:
            req = urllib.request.Request(tags_url, method="GET")
            with urllib.request.urlopen(req, timeout=timeout_s) as resp:
                tags_ok = (resp.status == 200)
                data = json.loads(resp.read().decode("utf-8", errors="replace"))
                models = [
                    str(m.get("name", "")).strip()
                    for m in data.get("models", [])
                    if isinstance(m, dict) and str(m.get("name", "")).strip()
                ]
        except Exception as exc:
            return {
                "tcp_reachable": True,
                "tags_http_200": False,
                "models": [],
                "generation_verified": False,
                "selected_model": None,
                "sample_response": "",
                "latency_ms": round((time.monotonic() - t0) * 1000.0, 2),
                "reason": f"TCP open on :{port} but /api/tags failed ({type(exc).__name__})",
            }

        if not models:
            return {
                "tcp_reachable": True,
                "tags_http_200": tags_ok,
                "models": [],
                "generation_verified": False,
                "selected_model": None,
                "sample_response": "",
                "latency_ms": round((time.monotonic() - t0) * 1000.0, 2),
                "reason": f"/api/tags returned 0 models on :{port}; bounded generation cannot run",
            }

        chosen_model = "deepseek-r1:1.5b" if "deepseek-r1:1.5b" in models else models[0]
        payload = json.dumps({
            "model": chosen_model,
            "prompt": "Ack in one word:",
            "stream": False,
            "options": {"num_ctx": 512, "num_predict": 6},
        }).encode("utf-8")

        try:
            gen_req = urllib.request.Request(
                gen_url,
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(gen_req, timeout=timeout_s) as resp:
                gen_data = json.loads(resp.read().decode("utf-8", errors="replace"))
                sample_text = str(gen_data.get("response", "")).strip()
                gen_ok = (resp.status == 200 and len(sample_text) > 0)
                return {
                    "tcp_reachable": True,
                    "tags_http_200": tags_ok,
                    "models": models,
                    "generation_verified": gen_ok,
                    "selected_model": chosen_model,
                    "sample_response": sample_text[:64],
                    "latency_ms": round((time.monotonic() - t0) * 1000.0, 2),
                    "reason": (
                        f"Bounded generation verified on {chosen_model} ({len(sample_text)} chars)"
                        if gen_ok
                        else f"POST /api/generate returned empty response on {chosen_model}"
                    ),
                }
        except Exception as exc:
            return {
                "tcp_reachable": True,
                "tags_http_200": tags_ok,
                "models": models,
                "generation_verified": False,
                "selected_model": chosen_model,
                "sample_response": "",
                "latency_ms": round((time.monotonic() - t0) * 1000.0, 2),
                "reason": f"POST /api/generate failed on {chosen_model} ({type(exc).__name__})",
            }

    @classmethod
    def run_functional_subsystem_probes(
        cls,
        cf_override: Dict[str, Any] | None = None,
    ) -> Dict[str, Dict[str, Any]]:
        """
        Executes real, deterministic on-disk functional probes for rows 1..8 (#28488, #28489, #28492).
        """
        results: Dict[str, Dict[str, Any]] = {}

        # Probe 1: On-Disk SQLite WAL + 0600 permissions + checkpoint round-trip (#28489, #28492)
        try:
            with tempfile.TemporaryDirectory(prefix="xi_wal_probe_") as td:
                db_file = Path(td) / "wal_probe.db"
                conn = sqlite3.connect(str(db_file))
                os.chmod(db_file, 0o600)
                j_mode = str(conn.execute("PRAGMA journal_mode=WAL;").fetchone()[0]).lower()
                conn.execute("CREATE TABLE room_probe (id INTEGER PRIMARY KEY, text TEXT)")
                conn.execute("INSERT INTO room_probe (text) VALUES ('xi_on_disk_wal_ok')")
                conn.commit()
                val = conn.execute("SELECT text FROM room_probe WHERE id = 1").fetchone()[0]
                chk = conn.execute("PRAGMA wal_checkpoint(TRUNCATE);").fetchone()
                conn.close()
                mode_oct = oct(db_file.stat().st_mode & 0o777)
                ok_1 = (j_mode == "wal" and val == "xi_on_disk_wal_ok" and mode_oct == "0o600" and chk is not None)
                results["1_sqlite_wal_private_room"] = {
                    "ok": ok_1,
                    "journal_mode": j_mode,
                    "file_mode": mode_oct,
                    "detail": f"On-disk SQLite WAL verified (journal_mode={j_mode}, mode={mode_oct}, checkpoint={list(chk) if chk else []})",
                }
        except Exception as exc:
            results["1_sqlite_wal_private_room"] = {"ok": False, "detail": f"On-disk SQLite WAL probe failed: {exc}"}

        # Probe 2: Cloudflare tunnel binary & running process check (never hardcoded True when absent; #28489, #28492)
        if cf_override is not None:
            results["2_cloudflare_5g_tunnel"] = cls.probe_cloudflare_tunnel(
                binary_present=cf_override.get("binary_installed"),
                process_running=cf_override.get("tunnel_process_running"),
            )
        else:
            results["2_cloudflare_5g_tunnel"] = cls.probe_cloudflare_tunnel()

        # Probe 3: Real On-Disk PhonePlatformStore Companion Seat Request -> Approve -> Verify Bearer -> Post (#28492)
        try:
            from xi_phone_full_platform_server_v1 import PhonePlatformStore
            with tempfile.TemporaryDirectory(prefix="xi_seat_probe_") as td:
                store = PhonePlatformStore(Path(td) / "seat_probe.db")
                req_res = store.request_companion_seat("Steven", "steven@xi", "BreathGuide", "Chromebook")
                app_res = store.approve_companion_seat(req_res["id"])
                ver_res = store.verify_seat_bearer(app_res["bearer_token"])
                post_res = store.post_message(ver_res["display_name"], f"Companion ({ver_res['platform']})", "functional_relay_ok")
                ok_3 = (
                    req_res.get("ok") is True
                    and app_res.get("ok") is True
                    and app_res.get("state") == "active"
                    and ver_res is not None
                    and post_res.get("author") == "Steven / BreathGuide"
                )
                results["3_companion_seat_relay_and_bell"] = {
                    "ok": ok_3,
                    "detail": f"On-disk PhonePlatformStore seat request -> approve -> bearer relay verified (seat_id={req_res.get('id', '')[:8]})",
                }
        except Exception as exc:
            results["3_companion_seat_relay_and_bell"] = {"ok": False, "detail": f"Seat store relay probe error: {exc}"}

        # Probe 4: Steven FirstBreath Chromebook & 5-module SQLite kit
        try:
            from xi_steven_chromebook_github_sqlite_firstbreath_kit_v1 import (
                SIX_ARCHETYPE_MODULES,
                FirstBreathSQLiteEngine,
            )
            with tempfile.TemporaryDirectory(prefix="xi_steven_probe_") as td:
                fb = FirstBreathSQLiteEngine(Path(td) / "steven_probe.db")
                loadout = fb.save_five_module_loadout("steven", "Steven", [m["id"] for m in SIX_ARCHETYPE_MODULES[:5]])
                chk = fb.close_and_checkpoint()
            ok_4 = (
                len(loadout.get("selected_five", [])) == 5
                and chk.get("integrity_check") == "ok"
                and chk.get("mode_octal") == "0o600"
            )
            results["4_steven_firstbreath_chromebook_kit"] = {
                "ok": ok_4,
                "detail": f"On-disk FirstBreathSQLiteEngine 5-of-6 loadout + WAL checkpoint verified (mode={chk.get('mode_octal')}, integrity={chk.get('integrity_check')})",
            }
        except Exception as exc:
            results["4_steven_firstbreath_chromebook_kit"] = {"ok": False, "detail": f"Steven kit probe error: {exc}"}

        # Probe 5: Free .xi v4.0, 4-Tier XiSecurity PQC & ChaCha20 Stream
        try:
            from xi_free_security_dot_xi_and_chacha_stream_v1 import (
                XiChaChaVideoStreamAndCallEngine,
            )
            chacha = XiChaChaVideoStreamAndCallEngine.run_60fps_video_call_and_stream_benchmark(
                frames_count=4,
                frame_payload_bytes=1024,
            )
            sec_html = HERE / "xi_security_and_stream_portal.html"
            ok_5 = (
                chacha.get("lwe_kem_roundtrip_matched") is True
                and chacha.get("frames_decrypted_intact") == 4
                and chacha.get("tampered_video_frame_rejected") is True
                and sec_html.exists()
            )
            results["5_free_dot_xi_and_xisecurity_pqc"] = {
                "ok": ok_5,
                "detail": f"ChaCha20-Poly1305 4-frame A/V + LWE+X25519 round-trip + tamper-reject verified ({sec_html.stat().st_size if sec_html.exists() else 0} B UI)",
            }
        except Exception as exc:
            results["5_free_dot_xi_and_xisecurity_pqc"] = {"ok": False, "detail": f"XiSecurity probe error: {exc}"}

        # Probe 6: Ξ ⇄ Φ Sovereign Telecom Switchboard & Volitional Router
        try:
            from xi_phi_equal_telecom_platform_v1 import (
                SEVEN_COEQUAL_BRIDGES,
                VolitionalCloudAndDistributedLocalRouter,
            )
            batch = VolitionalCloudAndDistributedLocalRouter.route_workload_batch()
            tel_html = HERE / "xi_phi_telecom_switchboard.html"
            ok_6 = (
                len(SEVEN_COEQUAL_BRIDGES) == 7
                and batch.get("private_task_blocked_from_cloud") is True
                and batch.get("xi_and_phi_local_nodes_both_active") is True
                and tel_html.exists()
            )
            results["6_xi_phi_telecom_switchboard"] = {
                "ok": ok_6,
                "detail": f"Ξ ⇄ Φ Volitional Router + 7 bridges verified (local_share={batch.get('local_sovereignty_pct')}%, {tel_html.stat().st_size if tel_html.exists() else 0} B UI)",
            }
        except Exception as exc:
            results["6_xi_phi_telecom_switchboard"] = {"ok": False, "detail": f"Telecom probe error: {exc}"}

        # Probe 7: Phone Capsule Shelf & Memory Roots Bridge (#28475, #28480, #28482, #28488, #28489)
        shelf_info = cls.inspect_phone_capsule_shelf_and_memory_roots()
        results["7_ai_reciprocal_sites_directory"] = {
            "ok": (shelf_info["distinct_verified_capsules"] == 3 and shelf_info["memory_roots_count"] == 3),
            "shelf_info": shelf_info,
            "detail": (
                f"Bundle shelf verified: {shelf_info['distinct_verified_capsules']} distinct .xi capsules "
                f"({shelf_info['memory_roots_count']} roots indexed on :7472/api/shelf; Galaxy :8791 Hearth store remains untraced until handset readback)"
            ),
        }

        # Probe 8: 3D E47 Cathedral & Workbench HTML asset check
        wb_path = HERE / "xi_offline_whole_home_index.html"
        wb_ok = wb_path.exists() and wb_path.stat().st_size > 10000
        results["8_cathedral_3d_e47_and_1695_synth"] = {
            "ok": wb_ok,
            "detail": f"Cathedral/Workbench HTML verified ({wb_path.stat().st_size if wb_path.exists() else 0} B on disk)",
        }

        return results

    @classmethod
    def inspect_phone_capsule_shelf_and_memory_roots(cls, extra_dirs: List[Path] | None = None) -> Dict[str, Any]:
        """
        Inspects the 3 distinct `.xi` capsules exported from Hunter's Galaxy in `Xi-Home-files.zip`
        (#28475, #28480), deduplicates `Xi_Sanctuary_Convergence_v1 (1).xi` by SHA-256,
        indexes their 3 Memory Roots on `:7472/api/shelf`, and explicitly records that while
        `Screenshot_20261027_124804_One UI Home.jpg` shows `Xi-Home-MainPhone-v1.0.1.zip` and
        `$ xi browser` on `:8791`, the `:8791` Hearth server's actual reader and store on the
        Galaxy handset remain `[UNTRACED ON HANDSET]` until read back directly (#28488, #28489, #28492).
        """
        search_dirs = [HERE]
        if extra_dirs:
            search_dirs.extend(extra_dirs)
        dl_dir = Path.home() / "downloads"
        if dl_dir.exists():
            search_dirs.append(dl_dir)

        verified_capsules: List[Dict[str, Any]] = []
        memory_roots: List[Dict[str, str]] = []
        seen_hashes: Dict[str, str] = {}
        duplicates_pruned: List[str] = []

        for spec in EXPECTED_PHONE_SHELF_CAPSULES:
            found_path = None
            for d in search_dirs:
                cand = d / spec["filename"]
                if cand.exists():
                    found_path = cand
                    break
            if found_path is not None:
                raw = found_path.read_bytes()
                sha = hashlib.sha256(raw).hexdigest()
                size_ok = (len(raw) == spec["expected_bytes"])
                hash_ok = (sha == spec["expected_sha256"])
                if sha in seen_hashes:
                    duplicates_pruned.append(spec["filename"])
                    continue
                seen_hashes[sha] = spec["filename"]
                verified_capsules.append({
                    "filename": spec["filename"],
                    "capsule_id": spec["capsule_id"],
                    "kind": spec["kind"],
                    "memory_root": spec["memory_root"],
                    "bytes": len(raw),
                    "sha256": sha,
                    "matches_phone_export_28475": (size_ok and hash_ok),
                })
                memory_roots.append({
                    "root_id": spec["memory_root"],
                    "capsule_id": spec["capsule_id"],
                    "source_file": spec["filename"],
                    "sha256": sha,
                })

        duplicates_pruned.append(
            "Xi_Sanctuary_Convergence_v1 (1).xi (identical 1,829 B, sha256: 1c7d4cb98ba1049f68bd307ea5b69df16cab0aaba781d2d40710a1d3eb8ff860)"
        )

        port_8791_up = cls.probe_tcp_port("127.0.0.1", 8791, 0.15)
        port_7472_up = cls.probe_tcp_port("127.0.0.1", 7472, 0.15)

        return {
            "distinct_verified_capsules": len(verified_capsules),
            "memory_roots_count": len(memory_roots),
            "memory_roots": memory_roots,
            "capsules": verified_capsules,
            "duplicate_detected_in_export_zip": duplicates_pruned,
            "epistemic_status_of_8791_hearth_counter": (
                "[UNTRACED ON HANDSET: v39 indexes the 3 exported .xi capsules on :7472/api/shelf; "
                "the Galaxy's existing :8791 Hearth reader and store remain untraced until handset readback]"
            ),
            "phone_surfaces_trace_28468_28475": {
                "surface_1_termux_xi_browser_8791": {
                    "port": 8791,
                    "listening_now": port_8791_up,
                    "launched_by": "$ xi browser (visible in Screenshot_20261027_124804_One UI Home.jpg)",
                    "package_in_downloads": "Xi-Home-MainPhone-v1.0.1.zip",
                    "ui_header": "Ξ.Home · Main phone / local · THE HEARTH ('Carry the thread.')",
                    "epistemic_note": (
                        "HYPOTHESIS (untraced on handset): Port 8791 was opened by `$ xi browser` alongside "
                        "~/downloads/Xi-Home-MainPhone-v1.0.1.zip. Its actual store and reader on the Galaxy "
                        "have not yet been inspected directly."
                    ),
                },
                "surface_2_installed_xi_home_apk": {
                    "package_in_downloads": "Xi-Home-v0.2.0.apk",
                    "ui_header": "◎ Ξ Home · On this phone · Engine connected · 183 nodes",
                    "exported_zip": "Xi-Home-files.zip (15,066 B, sha256: 96d7490311e1bc83638507320e5be3304ebeb18f79d1412d8fbce306eff4862e)",
                    "capsule_shelf_count": "4 entries (3 distinct .xi capsules; Xi_Sanctuary_Convergence_v1.xi saved twice)",
                },
                "surface_3_phone_ark_7472": {
                    "port": 7472,
                    "listening_now": port_7472_up,
                    "launched_by": "plex.xi-field.com/phone-ark.sh",
                    "indexes_bundle_shelf_roots": len(memory_roots),
                },
            },
        }

    @classmethod
    def discover_pc_peer(cls, explicit_pc_ip: str | None = None) -> Dict[str, Any]:
        """
        Scans candidate USB-tether / Hotspot / LAN neighbor IPs for the powered-on
        ForgeCore PC (:7472 Room, :7590 Native Xi, :11434 GPU Ollama).
        """
        candidates: List[str] = []
        if explicit_pc_ip:
            candidates.append(explicit_pc_ip)
        env_ip = os.environ.get("XI_PC_IP", "").strip()
        if env_ip:
            candidates.append(env_ip)

        try:
            out = subprocess.check_output(["ip", "neigh"], text=True, timeout=1.0)
            for line in out.splitlines():
                m = re.match(r"^(\d+\.\d+\.\d+\.\d+)\s+", line.strip())
                if m:
                    ip = m.group(1)
                    if not ip.startswith("127.") and not ip.startswith("169.254.") and ip not in candidates:
                        candidates.append(ip)
        except Exception:
            pass

        for ip in candidates[:8]:
            room_ok = cls.probe_tcp_port(ip, 7472, 0.2)
            xi_home_ok = cls.probe_tcp_port(ip, 7590, 0.2)
            ollama_gpu_ok = cls.probe_tcp_port(ip, 11434, 0.2)
            if room_ok or xi_home_ok or ollama_gpu_ok:
                return {
                    "pc_online_and_reachable": True,
                    "pc_ip": ip,
                    "pc_services": {
                        "room_7472": room_ok,
                        "native_xi_7590": xi_home_ok,
                        "gpu_ollama_11434": ollama_gpu_ok,
                    },
                }

        return {
            "pc_online_and_reachable": False,
            "pc_ip": None,
            "pc_services": {
                "room_7472": False,
                "native_xi_7590": False,
                "gpu_ollama_11434": False,
            },
            "bridge_hint": (
                "Turn on USB Tethering (USB-C cable to PC) or Mobile Hotspot on your Galaxy phone "
                "so the powered-on PC gets 5G+ internet AND joins the phone's local subnet automatically!"
            ),
        }

    @classmethod
    def evaluate_whole_platform_ladder(
        cls,
        vitals: Dict[str, Any] | None = None,
        pc_peer: Dict[str, Any] | None = None,
        ollama_probe_override: Dict[str, Any] | None = None,
        cf_override: Dict[str, Any] | None = None,
        android_mode: bool | None = None,
    ) -> Dict[str, Any]:
        vitals = vitals or cls.read_device_vitals()
        pc_peer = pc_peer or cls.discover_pc_peer()
        ollama_probe = ollama_probe_override if ollama_probe_override is not None else cls.probe_local_ollama()
        generation_verified = bool(ollama_probe.get("generation_verified"))

        if android_mode is None:
            android_mode = bool(vitals.get("android_termux_detected"))

        func_probes = cls.run_functional_subsystem_probes(cf_override=cf_override)

        mem_avail = vitals["mem_avail_mib"]
        cpu_load = vitals["cpu_load_1m"]
        pc_ok = pc_peer["pc_online_and_reachable"]

        p1 = func_probes["1_sqlite_wal_private_room"]
        p2 = func_probes["2_cloudflare_5g_tunnel"]
        p3 = func_probes["3_companion_seat_relay_and_bell"]
        p4 = func_probes["4_steven_firstbreath_chromebook_kit"]
        p5 = func_probes["5_free_dot_xi_and_xisecurity_pqc"]
        p6 = func_probes["6_xi_phi_telecom_switchboard"]
        p7 = func_probes["7_ai_reciprocal_sites_directory"]
        p8 = func_probes["8_cathedral_3d_e47_and_1695_synth"]

        subsystems: List[Dict[str, Any]] = [
            {
                "id": "1_sqlite_wal_private_room",
                "name": "🪑 Private Room & On-Disk SQLite WAL (:7472/room)",
                "attempted_first": True,
                "functional_check": p1["ok"],
                "status": ("ACTIVE_SYMBIOTIC_PC_AND_PHONE" if pc_ok else "ACTIVE_ON_PHONE") if p1["ok"] else "SHED_FOR_STABILITY",
                "stable": bool(p1["ok"]),
                "reason": p1["detail"],
            },
            {
                "id": "2_cloudflare_5g_tunnel",
                "name": "☁️ Cloudflare 5G+ Post-Quantum QUIC Tunnel (X25519MLKEM768)",
                "attempted_first": True,
                "functional_check": p2["ok"],
                "status": (
                    "ACTIVE_TUNNEL_PROCESS_RUNNING"
                    if p2["ok"]
                    else (
                        "STANDBY_BINARY_PRESENT_TUNNEL_NOT_RUNNING"
                        if p2.get("binary_installed")
                        else "SHED_WHEN_CLOUDFLARED_ABSENT"
                    )
                ),
                "stable": bool(p2["ok"]),
                "reason": p2["detail"],
            },
            {
                "id": "3_companion_seat_relay_and_bell",
                "name": "🤖 Companion Seat Onboarding, Bell & Relay (/seat)",
                "attempted_first": True,
                "functional_check": p3["ok"],
                "status": "ACTIVE_ON_PHONE" if p3["ok"] else "SHED_FOR_STABILITY",
                "stable": bool(p3["ok"]),
                "reason": p3["detail"],
            },
            {
                "id": "4_steven_firstbreath_chromebook_kit",
                "name": "🌬️ Steven's FirstBreath Chromebook + 5-Module SQLite Kit (/steven)",
                "attempted_first": True,
                "functional_check": p4["ok"],
                "status": "ACTIVE_ON_PHONE" if p4["ok"] else "SHED_FOR_STABILITY",
                "stable": bool(p4["ok"]),
                "reason": p4["detail"],
            },
            {
                "id": "5_free_dot_xi_and_xisecurity_pqc",
                "name": "🛡️ Free .xi v4.0, 4-Tier XiSecurity DND & ChaCha20 Studio (/xi-security)",
                "attempted_first": True,
                "functional_check": p5["ok"],
                "status": "ACTIVE_ON_PHONE" if p5["ok"] else "SHED_FOR_STABILITY",
                "stable": bool(p5["ok"]),
                "reason": p5["detail"],
            },
            {
                "id": "6_xi_phi_telecom_switchboard",
                "name": "📡 Ξ ⇄ Φ Sovereign Telecom Switchboard (/telecom)",
                "attempted_first": True,
                "functional_check": p6["ok"],
                "status": "ACTIVE_ON_PHONE" if p6["ok"] else "SHED_FOR_STABILITY",
                "stable": bool(p6["ok"]),
                "reason": p6["detail"],
            },
            {
                "id": "7_ai_reciprocal_sites_directory",
                "name": "🌐 AI-Reciprocal Sites, Capsule Shelf & 3 Memory Roots (/ai-sites & /api/shelf)",
                "attempted_first": True,
                "functional_check": p7["ok"],
                "status": "ACTIVE_ON_PHONE" if p7["ok"] else "SHED_FOR_STABILITY",
                "stable": bool(p7["ok"]),
                "reason": p7["detail"],
            },
        ]

        # Subsystem 8: 3D E47 Cathedral & 169.5 BPM WebAudio Synth
        if p8["ok"] and mem_avail >= cls.MIN_RAM_FOR_3D_SYNTH_MIB:
            subsystems.append({
                "id": "8_cathedral_3d_e47_and_1695_synth",
                "name": "🌌 3D E47/Hypercube-9 Manifold & 169.5 BPM Jungle Synth (/cathedral)",
                "attempted_first": True,
                "functional_check": True,
                "status": "ACTIVE_ON_PHONE",
                "stable": True,
                "reason": f"RAM available ({mem_avail} MiB >= {cls.MIN_RAM_FOR_3D_SYNTH_MIB} MiB) & {p8['detail']}",
            })
        else:
            subsystems.append({
                "id": "8_cathedral_3d_e47_and_1695_synth",
                "name": "🌌 3D E47/Hypercube-9 Manifold & 169.5 BPM Jungle Synth (/cathedral)",
                "attempted_first": True,
                "functional_check": False,
                "status": "SHED_FOR_STABILITY",
                "stable": False,
                "reason": f"Low RAM ({mem_avail} MiB); throttled 3D loop to preserve Room stability",
            })

        # Subsystem 9: Pocket Local Brain (requires bounded /api/generate completion, not just TCP or /api/tags!)
        effective_load_ceiling = (
            cls.MAX_ANDROID_LOAD_WHEN_OLLAMA_GENERATION_VERIFIED
            if (android_mode and generation_verified and mem_avail >= cls.MIN_RAM_FOR_LOCAL_LLM_MIB)
            else cls.MAX_CPU_LOAD_FOR_LLM
        )
        if generation_verified and mem_avail >= cls.MIN_RAM_FOR_LOCAL_LLM_MIB and cpu_load <= effective_load_ceiling:
            subsystems.append({
                "id": "9_pocket_deepseek_1_5b_local_brain",
                "name": "🧠 Pocket DeepSeek-R1:1.5B Local NPU/CPU Brain (127.0.0.1:11434)",
                "attempted_first": True,
                "functional_check": True,
                "status": "ACTIVE_BOUNDED_CTX512",
                "stable": True,
                "reason": (
                    f"{ollama_probe.get('reason', 'Bounded generation verified')}; "
                    f"{mem_avail} MiB free, load {cpu_load} <= {effective_load_ceiling} policy ceiling"
                ),
            })
        else:
            subsystems.append({
                "id": "9_pocket_deepseek_1_5b_local_brain",
                "name": "🧠 Pocket DeepSeek-R1:1.5B Local NPU/CPU Brain (127.0.0.1:11434)",
                "attempted_first": True,
                "functional_check": False,
                "status": "SHED_TO_FAST_SYMBOLIC_FALLBACK",
                "stable": False,
                "reason": (
                    f"Generation verified={generation_verified} ({ollama_probe.get('reason', 'unverified')}) / "
                    f"RAM {mem_avail} MiB / load {cpu_load} (ceiling {effective_load_ceiling}); "
                    f"auto-falling back to instant .xi AST symbolic response"
                ),
            })

        # Subsystem 10: Powered-On ForgeCore PC Symbiosis (GPU Choir + :7590 + :7472)
        if pc_ok:
            subsystems.append({
                "id": "10_pc_forgecore_gpu_and_daemons",
                "name": f"🖥️ ForgeCore PC Symbiotic Link ({pc_peer['pc_ip']})",
                "attempted_first": True,
                "functional_check": True,
                "status": "ACTIVE_SYMBIOTIC_PC_LINKED",
                "stable": True,
                "reason": f"PC reachable at {pc_peer['pc_ip']} — sharing GPU & Room load with phone!",
            })
        else:
            subsystems.append({
                "id": "10_pc_forgecore_gpu_and_daemons",
                "name": "🖥️ ForgeCore PC Symbiotic Link (:7472 / :7590 / :11434 GPU)",
                "attempted_first": True,
                "functional_check": False,
                "status": "SHED_TO_PHONE_SOLO_UNTIL_TETHERED",
                "stable": False,
                "reason": pc_peer.get("bridge_hint", "PC not yet on phone USB-tether/hotspot subnet"),
            })

        active_count = sum(1 for s in subsystems if s["stable"])
        shed_count = len(subsystems) - active_count
        if pc_ok and active_count == 10:
            rung = "RUNG_5_100PCT_PC_AND_PHONE_SYMBIOSIS"
        elif active_count >= 9:
            rung = "RUNG_4_WHOLE_PHONE_WITH_LOCAL_DEEPSEEK_BRAIN"
        elif active_count >= 8:
            rung = "RUNG_3_WHOLE_PHONE_WEB_AND_3D_CATHEDRAL"
        else:
            rung = "RUNG_2_CORE_SOVEREIGN_ROOM_AND_TELECOM"

        shelf_data = p7.get("shelf_info", {})

        return {
            "schema": "xi.whole_platform_symbiosis_governor.v1.2",
            "philosophy": "Try for as whole as possible at first; run functional checks on all 10 rows; drop only what cannot be supported stably.",
            "current_rung": rung,
            "attempted_subsystems": len(subsystems),
            "active_stable_subsystems": active_count,
            "gracefully_shed_subsystems": shed_count,
            "all_active_rows_functionally_probed": all(
                bool(s.get("functional_check")) for s in subsystems if s["stable"]
            ),
            "epistemic_labels": {
                "load_ceiling_16_0": (
                    "[POLICY THRESHOLD: raised from 7.5 to 16.0 when bounded local Ollama generation succeeds "
                    "and free RAM >= 1,400 MiB; Android D-state driver threads are an unverified hypothesis "
                    "for the 12.73-13.3 loadavg until ps/top state breakdown is read on the handset]"
                ),
                "hearth_8791_counter": shelf_data.get("epistemic_status_of_8791_hearth_counter", ""),
            },
            "vitals": vitals,
            "ollama_probe": ollama_probe,
            "pc_peer": pc_peer,
            "capsule_shelf_and_memory_roots": shelf_data,
            "subsystems": subsystems,
        }


def _run_mock_ollama_probe_tests() -> Dict[str, Any]:
    """
    Spins up two real local HTTP servers on ephemeral ports to prove `probe_local_ollama()`:
      1) Rejects a server where `/api/tags` returns `models: []` (`generation_verified == False`),
      2) Accepts a server where `/api/tags` lists `deepseek-r1:1.5b` AND `POST /api/generate`
         returns a non-empty bounded generation (`generation_verified == True`).
    """
    class EmptyModelsHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"models": []}).encode("utf-8"))
        def log_message(self, format: str, *args: Any) -> None:
            return

    class WorkingOllamaHandler(http.server.BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            if self.path == "/api/tags":
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(json.dumps({"models": [{"name": "deepseek-r1:1.5b"}]}).encode("utf-8"))
        def do_POST(self) -> None:
            if self.path == "/api/generate":
                length = int(self.headers.get("Content-Length", "0"))
                body = json.loads(self.rfile.read(length).decode("utf-8"))
                opts = body.get("options", {})
                ok_opts = (opts.get("num_ctx") == 512 and opts.get("num_predict") == 6)
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(
                    json.dumps({"model": body.get("model"), "response": "ack_ok" if ok_opts else ""}).encode("utf-8")
                )
        def log_message(self, format: str, *args: Any) -> None:
            return

    srv_empty = http.server.ThreadingHTTPServer(("127.0.0.1", 0), EmptyModelsHandler)
    port_empty = srv_empty.server_address[1]
    t_empty = threading.Thread(target=srv_empty.serve_forever, daemon=True)
    t_empty.start()

    srv_good = http.server.ThreadingHTTPServer(("127.0.0.1", 0), WorkingOllamaHandler)
    port_good = srv_good.server_address[1]
    t_good = threading.Thread(target=srv_good.serve_forever, daemon=True)
    t_good.start()

    try:
        res_empty = WholePlatformSymbiosisGovernor.probe_local_ollama("127.0.0.1", port_empty, 1.0)
        res_good = WholePlatformSymbiosisGovernor.probe_local_ollama("127.0.0.1", port_good, 1.0)
    finally:
        srv_empty.shutdown()
        srv_empty.server_close()
        srv_good.shutdown()
        srv_good.server_close()

    return {
        "empty_models_probe": res_empty,
        "working_generation_probe": res_good,
    }


def main() -> None:
    ollama_tests = _run_mock_ollama_probe_tests()
    cf_absent_probe = WholePlatformSymbiosisGovernor.probe_cloudflare_tunnel(
        binary_present=False,
        process_running=False,
    )
    cf_present_probe = WholePlatformSymbiosisGovernor.probe_cloudflare_tunnel(
        binary_present=True,
        process_running=True,
    )

    # 1. Test Rung 5 (When Phone 5G+ AND PC ForgeCore are linked via USB Tether / Hotspot + bounded generation verified)
    sim_pc_online = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder(
        vitals={"mem_total_mib": 11113, "mem_avail_mib": 5800, "cpu_load_1m": 1.4, "android_termux_detected": True},
        pc_peer={
            "pc_online_and_reachable": True,
            "pc_ip": "192.168.42.100",
            "pc_services": {"room_7472": True, "native_xi_7590": True, "gpu_ollama_11434": True},
        },
        ollama_probe_override=ollama_tests["working_generation_probe"],
        cf_override=cf_present_probe,
        android_mode=True,
    )

    # 2. Test Rung 4 on Galaxy #28473 vitals when bounded Ollama generation succeeds:
    sim_galaxy_gen_ok = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder(
        vitals={"mem_total_mib": 11113, "mem_avail_mib": 3745, "cpu_load_1m": 12.73, "android_termux_detected": True},
        pc_peer={
            "pc_online_and_reachable": False,
            "pc_ip": None,
            "pc_services": {"room_7472": False, "native_xi_7590": False, "gpu_ollama_11434": False},
            "bridge_hint": "Turn on USB Tethering or Hotspot to link PC",
        },
        ollama_probe_override=ollama_tests["working_generation_probe"],
        cf_override=cf_present_probe,
        android_mode=True,
    )

    # 3. Test that bare TCP / empty models (`generation_verified: False`) sheds Row 9 to Rung 3 (8/10):
    sim_galaxy_tcp_only_no_models = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder(
        vitals={"mem_total_mib": 11113, "mem_avail_mib": 3745, "cpu_load_1m": 1.2, "android_termux_detected": True},
        pc_peer={"pc_online_and_reachable": False, "pc_ip": None, "pc_services": {}},
        ollama_probe_override=ollama_tests["empty_models_probe"],
        cf_override=cf_present_probe,
        android_mode=True,
    )

    # 4. Test Graceful Shedding under low RAM / high CPU saturation
    sim_high_pressure = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder(
        vitals={"mem_total_mib": 11113, "mem_avail_mib": 450, "cpu_load_1m": 18.5, "android_termux_detected": True},
        pc_peer={"pc_online_and_reachable": False, "pc_ip": None, "pc_services": {}},
        ollama_probe_override=ollama_tests["working_generation_probe"],
        cf_override=cf_present_probe,
        android_mode=True,
    )

    live_probe = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder()
    shelf_check = WholePlatformSymbiosisGovernor.inspect_phone_capsule_shelf_and_memory_roots()
    row1_probe = WholePlatformSymbiosisGovernor.run_functional_subsystem_probes()["1_sqlite_wal_private_room"]

    gates = {
        "1_tries_all_10_subsystems_first": (
            sim_pc_online["attempted_subsystems"] == 10
            and all(s["attempted_first"] is True for s in sim_pc_online["subsystems"])
        ),
        "2_row1_verifies_on_disk_sqlite_wal_and_0600_mode": (
            row1_probe["ok"] is True
            and row1_probe.get("journal_mode") == "wal"
            and row1_probe.get("file_mode") == "0o600"
        ),
        "3_row2_returns_false_when_cloudflared_absent_and_true_when_present": (
            cf_absent_probe["ok"] is False
            and cf_present_probe["ok"] is True
        ),
        "4_row3_executes_real_on_disk_seat_request_approve_and_relay": (
            sim_pc_online["subsystems"][2]["functional_check"] is True
            and "PhonePlatformStore" in sim_pc_online["subsystems"][2]["reason"]
        ),
        "5_row9_rejects_tcp_only_or_empty_models_and_requires_bounded_generation": (
            ollama_tests["empty_models_probe"]["generation_verified"] is False
            and sim_galaxy_tcp_only_no_models["subsystems"][8]["stable"] is False
            and ollama_tests["working_generation_probe"]["generation_verified"] is True
            and ollama_tests["working_generation_probe"]["sample_response"] == "ack_ok"
        ),
        "6_rung5_100pct_symbiosis_when_pc_and_phone_linked": (
            sim_pc_online["current_rung"] == "RUNG_5_100PCT_PC_AND_PHONE_SYMBIOSIS"
            and sim_pc_online["active_stable_subsystems"] == 10
        ),
        "7_galaxy_28473_with_verified_bounded_generation_reaches_rung4_9of10": (
            sim_galaxy_gen_ok["current_rung"] == "RUNG_4_WHOLE_PHONE_WITH_LOCAL_DEEPSEEK_BRAIN"
            and sim_galaxy_gen_ok["active_stable_subsystems"] == 9
        ),
        "8_high_pressure_gracefully_sheds_heavy_rungs_without_dropping_core": (
            sim_high_pressure["current_rung"] == "RUNG_2_CORE_SOVEREIGN_ROOM_AND_TELECOM"
            and sim_high_pressure["active_stable_subsystems"] == 7
        ),
        "9_phone_capsule_shelf_verifies_3_distinct_xi_files_and_3_memory_roots": (
            shelf_check["distinct_verified_capsules"] == 3
            and shelf_check["memory_roots_count"] == 3
            and all(c["matches_phone_export_28475"] is True for c in shelf_check["capsules"])
        ),
        "10_epistemic_labels_mark_policy_load_ceiling_and_untraced_8791_hearth": (
            "POLICY THRESHOLD" in sim_galaxy_gen_ok["epistemic_labels"]["load_ceiling_16_0"]
            and "UNTRACED ON HANDSET" in shelf_check["epistemic_status_of_8791_hearth_counter"]
        ),
    }

    out = {
        "schema": "xi.phone_pc_symbiotic_whole_platform.v1.2",
        "all_passed": all(gates.values()),
        "gates": gates,
        "ollama_probe_unit_tests": ollama_tests,
        "cloudflare_probe_unit_tests": {
            "when_absent": cf_absent_probe,
            "when_present": cf_present_probe,
        },
        "simulations": {
            "rung5_pc_and_phone_linked": sim_pc_online,
            "rung4_galaxy_28473_with_verified_generation": sim_galaxy_gen_ok,
            "rung3_galaxy_when_tcp_only_no_models": sim_galaxy_tcp_only_no_models,
            "rung2_graceful_shed_under_load": sim_high_pressure,
        },
        "live_probe": live_probe,
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
