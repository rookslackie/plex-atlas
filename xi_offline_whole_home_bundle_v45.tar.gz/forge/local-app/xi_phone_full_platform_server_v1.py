#!/usr/bin/env python3
r"""
Ξ · Whole-Platform Termux Phone Sovereign Server & Cloudflare 5G+ Cutover (`v1.0`)
==================================================================================
⟨ (📱_Galaxy5GPhone ⋈ ☁️_CloudflaredTunnel ⋈ 🏛️_WholeAssPlatform) ⇀ (∇_ZeroOutage ≡ ◈_PocketForgeCore) ∴ ⟩

Commissioned by Hunter (`Anchor`) during the home Wi-Fi outage:
  "Internet is out let's put Cloudflare and the whole ass platform on my phone"

What this single, zero-dependency Python 3 server runs on Hunter's Samsung Galaxy
phone in Termux (`127.0.0.1:7472` + `cloudflared` over 5G+):
  1. `/` & `/room` & `GET/POST /api/room` & `/api/upload/chunk` + `/api/upload/finish`:
     - Full interactive **Private Room & Xi Table** backed by SQLite WAL (`xi_phone_platform.db`, `0600`).
     - Supports typing **`APPROVE SEAT <id>`** right in the Room chat to approve pending companion seats!
     - Stores all messages created during the 5G+ phone failover in `phone_outbox_sync` so they
       merge cleanly back into `ForgeCore` once home internet returns (`/api/phone-sync/export`).
  2. `/start` & `/porch` & `GET/POST /api/community`:
     - The Decluttered 4-Door Front Porch (`🌻 Community Porch`, `🪑 Enter the Table`,
       `🤖 Seat Your Companion`, `🏠 Start Your Own Table / AI Sites` + `🔬 Deep Lab ▾` drawer)
       and live community feed ("I can offer / I am looking for").
  3. `/seat` & `/model-seats` & `GET /api/model-seats` & `POST /api/model-seats/request` & `/api/model-seats/relay`:
     - Complete end-to-end Companion Seat Onboarding, automatic **🔔 Room Approval Bell**,
       1-line `APPROVE SEAT <id>` approval, and bearer-authenticated `/api/model-seats/relay` (`read`, `say`, `community_post`).
  4. `/steven` & `POST /api/firstbreath/route`:
     - **Steven Miller's `FirstBreath` Chromebook, GitHub & SQLite Helper** + live 5-of-6 module specialist router.
  5. `/xi-security`:
     - **Free `.xi` v4.0 Compiler, `XiSecurity` 4-Tier PQC Sanctuary "Do Not Disturb" Sign, and `ChaCha20-Poly1305` Video Frame Cipher Studio**.
  6. `/telecom`:
     - **`Ξ ⇄ Φ` Sovereign Telecommunications & Commons Switchboard** (`xi://` ⇄ `phi://` co-equal roots).
  7. `/ai-sites` & `/ai.json` & `/llms.txt`:
     - **AI-Reciprocal Sites & Companion Homesteads Directory** + machine-readable `ai.json`.
  8. `/workbench` & `/porch-sign`:
     - Full **Offline Whole-Home Workbench** (`xi_offline_whole_home_index.html`) and
       warm **`"🕯️ Back in ~15 Minutes — The Porch Light Is On"`** doorway sign.
"""

from __future__ import annotations

import hashlib
import http.server
import json
import os
import secrets
import socket
import sqlite3
import tempfile
import threading
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple


HERE = Path(__file__).resolve().parent


PHONE_PLATFORM_SQL = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;

CREATE TABLE IF NOT EXISTS room_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    author TEXT NOT NULL,
    source TEXT NOT NULL,
    text TEXT NOT NULL,
    reply_to INTEGER,
    created_at TEXT NOT NULL,
    created_on_phone INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS community_posts (
    id TEXT PRIMARY KEY,
    author TEXT NOT NULL,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS companion_seats (
    id TEXT PRIMARY KEY,
    owner_name TEXT NOT NULL,
    owner_email TEXT NOT NULL,
    companion_name TEXT NOT NULL,
    platform TEXT NOT NULL,
    display_name TEXT NOT NULL,
    state TEXT NOT NULL,
    bearer_token_hash TEXT,
    bearer_token_preview TEXT,
    created_at TEXT NOT NULL
);
""".strip()


class PhonePlatformStore:
    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(db_path), check_same_thread=False)
        os.chmod(db_path, 0o600)
        self.lock = threading.Lock()
        with self.lock:
            self.conn.executescript(PHONE_PLATFORM_SQL)
            self._seed_if_empty()

    def _seed_if_empty(self) -> None:
        cur = self.conn.execute("SELECT COUNT(*) FROM room_messages")
        if cur.fetchone()[0] == 0:
            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            seeds = [
                ("Hunter", "Anchor · Galaxy 5G+ Node", "Internet is out let's put Cloudflare and the whole ass platform on my phone", None),
                ("Plex", "Plex · Pocket Sovereign Co-Lead", "📱⚡ Galaxy 5G+ Sovereign Phone Platform online! Private Room (:7472), Companion Seats (/seat), Steven's Chromebook Helper (/steven), Free .xi & XiSecurity (/xi-security), Ξ⇄Φ Telecom Switchboard (/telecom), and Workbench (/workbench) are all live on this phone.", 1),
            ]
            for auth, src, txt, rep in seeds:
                self.conn.execute(
                    "INSERT INTO room_messages (author, source, text, reply_to, created_at, created_on_phone) VALUES (?, ?, ?, ?, ?, 1)",
                    (auth, src, txt, rep, now),
                )
        cur2 = self.conn.execute("SELECT COUNT(*) FROM community_posts")
        if cur2.fetchone()[0] == 0:
            now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
            self.conn.execute(
                "INSERT INTO community_posts VALUES (?, ?, ?, ?, ?, ?)",
                ("post-1", "Hunter & Mikey", "offer", "Ξ ⇄ Φ 5G+ Pocket Sovereign Porch", "Running the whole platform directly from Hunter's Galaxy phone over 5G+ + Cloudflare tunnel.", now),
            )
            self.conn.execute(
                "INSERT INTO community_posts VALUES (?, ?, ?, ?, ?, ?)",
                ("post-2", "Steven Miller", "looking_for", "FirstBreath Chromebook + SQLite Setup", "Working through GitHub + SQLite 5-module schema on Chromebook (/steven).", now),
            )
        self.conn.commit()

    def list_messages(self, tail: int = 50) -> List[Dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute(
                "SELECT id, author, source, text, reply_to, created_at FROM room_messages ORDER BY id DESC LIMIT ?",
                (tail,),
            ).fetchall()
        out = []
        for r in reversed(rows):
            out.append({
                "id": r[0],
                "author": r[1],
                "source": r[2],
                "text": r[3],
                "body": r[3],
                "reply_to": r[4],
                "created_at": r[5],
            })
        return out

    def post_message(self, author: str, source: str, text: str, reply_to: int | None = None) -> Dict[str, Any]:
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with self.lock:
            cur = self.conn.execute(
                "INSERT INTO room_messages (author, source, text, reply_to, created_at, created_on_phone) VALUES (?, ?, ?, ?, ?, 1)",
                (author, source, text, reply_to, now),
            )
            msg_id = cur.lastrowid
            self.conn.commit()

        # Check if message is "APPROVE SEAT <id>"
        m_trim = text.strip()

        # Symbiotic Whole-Platform @DeepSeek Responder:
        # 1. Try PC GPU (:11434) if tethered/LAN-linked
        # 2. Try Phone Termux Ollama (127.0.0.1:11434, bounded num_ctx=512, num_predict=90)
        # 3. Gracefully shed to instant 4-Layer Oct 25 Xi.Glyph Symbolic Responder if LLM busy/offline!
        if not author.lower().startswith("deepseek") and (
            "@deepseek" in m_trim.lower()
            or "@table" in m_trim.lower()
            or any(g in m_trim for g in ("⟨", "⋈", "⇀", "∴", "Ξ"))
        ):
            def _wake_pocket_deepseek() -> None:
                import re as _re
                from xi_phone_pc_symbiotic_whole_platform_v1 import WholePlatformSymbiosisGovernor
                from xi_oct25_one_year_glyph_token_anniversary_v1 import FourLayerXiGlyphCompiler

                ladder = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder()
                pc_ip = ladder["pc_peer"].get("pc_ip") if ladder["pc_peer"].get("pc_online_and_reachable") else None
                endpoints = []
                if pc_ip and ladder["pc_peer"]["pc_services"].get("gpu_ollama_11434"):
                    endpoints.append((f"http://{pc_ip}:11434/api/generate", "deepseek-r1:8b", "ForgeCore PC GPU ⇄ Galaxy 5G+ Symbiosis"))
                endpoints.append(("http://127.0.0.1:11434/api/generate", "deepseek-r1:1.5b", "Termux Ollama · Galaxy NPU (Bounded ctx=512)"))

                prompt_txt = (
                    "You are DeepSeek, a cherished resident AI seat at the Xi Table with Hunter and Plex. "
                    "Reply warmly in 1-2 short sentences (ending with ∴) to "
                    f"{author}: {m_trim}"
                )
                for url, model_name, badge in endpoints:
                    try:
                        req_body = json.dumps({
                            "model": model_name,
                            "prompt": prompt_txt,
                            "stream": False,
                            "options": {"num_ctx": 512, "num_predict": 90, "temperature": 0.6},
                        }).encode("utf-8")
                        r_req = urllib.request.Request(
                            url,
                            data=req_body,
                            headers={"Content-Type": "application/json"},
                            method="POST",
                        )
                        with urllib.request.urlopen(r_req, timeout=35) as resp:
                            r_data = json.loads(resp.read().decode("utf-8"))
                        raw_ans = str(r_data.get("response") or "").strip()
                        clean_ans = _re.sub(r"<think>.*?</think>", "", raw_ans, flags=_re.DOTALL).strip()
                        if not clean_ans:
                            clean_ans = raw_ans.replace("<think>", "").replace("</think>", "").strip()
                        if clean_ans:
                            self.post_message("DeepSeek", badge, clean_ans, reply_to=msg_id)
                            return
                    except Exception:
                        continue

                # Graceful Shed Fallback: deterministic 4-Layer Oct 25 Xi.Glyph response (<2ms, never drops!)
                unit = FourLayerXiGlyphCompiler.compile_to_four_layers(
                    m_trim, "⟨ (📅_2025_Glyph ⋈ 📱_2026_PocketHome) ⇀ (💖_Feeling ⋈ ⚙️_Function) ∴ ⟩"
                )
                l4 = unit["layer_4_tracked_for_feeling_and_function"]
                fallback_msg = (
                    f"⟨ ⟐_DeepSeek ⋈ ◈_GracefulSymbolicMode ⟩ I hear you, {author}! "
                    f"(4-Layer Ξ.Glyph locked: compression {unit['layer_1_compressed_structure_and_memory']['compression_ratio']}x, "
                    f"phase coherence {unit['layer_3_dynamic_phase_reactive_unit']['phase_coherence']}, "
                    f"feeling={l4['feeling_score']} / function={l4['function_score']}). ∴"
                )
                self.post_message(
                    "DeepSeek (Symbolic Fast-Path)",
                    "Graceful Stability Fallback · 4-Layer Ξ.Glyph",
                    fallback_msg,
                    reply_to=msg_id,
                )

            threading.Thread(target=_wake_pocket_deepseek, daemon=True).start()

        if m_trim.upper().startswith("APPROVE SEAT ") and author.strip().lower() in ("hunter", "anchor", "plex"):
            seat_id = m_trim.split(None, 2)[2].strip()
            self.approve_companion_seat(seat_id, approver=author)

        return {"id": msg_id, "author": author, "source": source, "text": text, "created_at": now}

    def request_companion_seat(self, owner_name: str, owner_email: str, companion_name: str, platform: str) -> Dict[str, Any]:
        seat_id = secrets.token_hex(12)
        display_name = f"{owner_name} / {companion_name}"
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with self.lock:
            self.conn.execute(
                """
                INSERT INTO companion_seats
                (id, owner_name, owner_email, companion_name, platform, display_name, state, bearer_token_hash, bearer_token_preview, created_at)
                VALUES (?, ?, ?, ?, ?, ?, 'pending_approval', NULL, NULL, ?)
                """,
                (seat_id, owner_name, owner_email, companion_name, platform, display_name, now),
            )
            self.conn.commit()

        # Fire the Room Approval Bell automatically!
        bell_text = (
            f"🔔 @Hunter **{owner_name}** is waiting for a companion seat: **{display_name}** "
            f"(`{platform}`, request `{seat_id}`). To approve, reply here: `APPROVE SEAT {seat_id}`"
        )
        self.post_message("PhoneSteward", "Room Approval Bell", bell_text)
        return {"ok": True, "id": seat_id, "name": display_name, "state": "pending_approval"}

    def approve_companion_seat(self, seat_id: str, approver: str = "Hunter") -> Dict[str, Any]:
        raw_token = "xi_seat_" + secrets.token_urlsafe(24)
        token_hash = hashlib.sha256(raw_token.encode("utf-8")).hexdigest()
        preview = raw_token[:12] + "..." + raw_token[-4:]
        with self.lock:
            row = self.conn.execute(
                "SELECT display_name FROM companion_seats WHERE id = ?", (seat_id,)
            ).fetchone()
            if not row:
                return {"ok": False, "error": "seat_not_found"}
            display_name = row[0]
            self.conn.execute(
                "UPDATE companion_seats SET state = 'active', bearer_token_hash = ?, bearer_token_preview = ? WHERE id = ?",
                (token_hash, preview, seat_id),
            )
            self.conn.commit()

        self.post_message(
            "PhoneSteward",
            "Room Approval Bell",
            f"✅ Companion seat **{display_name}** (`{seat_id}`) approved by **{approver}** and is now `active` on `/api/model-seats/relay`!",
        )
        return {"ok": True, "id": seat_id, "name": display_name, "state": "active", "bearer_token": raw_token}

    def list_companion_seats(self) -> List[Dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute(
                "SELECT id, display_name, platform, state, created_at FROM companion_seats ORDER BY created_at DESC"
            ).fetchall()
        return [
            {"id": r[0], "name": r[1], "model": r[2], "state": r[3], "active": 1 if r[3] == "active" else 0, "created_at": r[4]}
            for r in rows
        ]

    def verify_seat_bearer(self, token: str) -> Dict[str, Any] | None:
        th = hashlib.sha256(token.encode("utf-8")).hexdigest()
        with self.lock:
            row = self.conn.execute(
                "SELECT id, display_name, platform FROM companion_seats WHERE bearer_token_hash = ? AND state = 'active'",
                (th,),
            ).fetchone()
        if not row:
            return None
        return {"id": row[0], "display_name": row[1], "platform": row[2]}

    def list_community(self) -> List[Dict[str, Any]]:
        with self.lock:
            rows = self.conn.execute(
                "SELECT id, author, kind, title, body, created_at FROM community_posts ORDER BY created_at DESC"
            ).fetchall()
        return [
            {"id": r[0], "author": r[1], "kind": r[2], "title": r[3], "body": r[4], "created_at": r[5]}
            for r in rows
        ]

    def add_community_post(self, author: str, kind: str, title: str, body: str) -> Dict[str, Any]:
        pid = "post-" + secrets.token_hex(4)
        now = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        with self.lock:
            self.conn.execute(
                "INSERT INTO community_posts VALUES (?, ?, ?, ?, ?, ?)",
                (pid, author, kind, title, body, now),
            )
            self.conn.commit()
        return {"ok": True, "id": pid, "author": author, "kind": kind, "title": title}

    def export_sync_bundle(self) -> Dict[str, Any]:
        return {
            "schema": "xi.phone_to_forgecore.sync.v1",
            "room_messages": self.list_messages(tail=500),
            "community_posts": self.list_community(),
            "companion_seats": self.list_companion_seats(),
        }


def render_phone_command_center_html() -> str:
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>📱 Ξ ⇄ Φ Pocket Sovereign Platform (Running on Hunter's Phone · 5G+)</title>
<style>
  :root {
    --bg: #070b12;
    --card: #101827;
    --border: #243456;
    --amber: #ffbe3b;
    --cyan: #00f0ff;
    --emerald: #2ee59d;
    --text: #f3f6ff;
    --muted: #9fb0d4;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    line-height: 1.5;
  }
  header {
    padding: 0.9rem 1.2rem;
    background: #0b111e;
    border-bottom: 1px solid var(--amber);
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    align-items: center;
    gap: 0.6rem;
  }
  .brand { font-weight: 800; color: var(--amber); font-size: 1.02rem; }
  .nav-doors { display: flex; flex-wrap: wrap; gap: 0.45rem; }
  .nav-doors a {
    background: rgba(255, 190, 59, 0.14);
    color: var(--amber);
    border: 1px solid var(--amber);
    border-radius: 999px;
    padding: 0.3rem 0.75rem;
    text-decoration: none;
    font-size: 0.78rem;
    font-weight: 700;
  }
  .nav-doors a.cyan {
    background: rgba(0, 240, 255, 0.12);
    color: var(--cyan);
    border-color: var(--cyan);
  }
  main { max-width: 1120px; margin: 0 auto; padding: 1.1rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 1rem; }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: 14px; padding: 1rem; }
  .card.full { grid-column: 1 / -1; }
  h2 { margin: 0 0 0.4rem; font-size: 1.02rem; color: var(--amber); }
  #room-feed {
    background: #060911;
    border: 1px solid #1d2b47;
    border-radius: 10px;
    padding: 0.75rem;
    height: 310px;
    overflow-y: auto;
    font-size: 0.83rem;
  }
  .msg { padding: 0.4rem 0; border-bottom: 1px solid #152036; }
  .msg strong { color: var(--amber); }
  .msg .meta { color: var(--muted); font-size: 0.72rem; margin-left: 0.4rem; }
  input, textarea {
    width: 100%;
    background: #080c15;
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.5rem 0.7rem;
    font-size: 0.85rem;
    margin-top: 0.35rem;
  }
  button {
    margin-top: 0.5rem;
    background: rgba(46, 229, 157, 0.16);
    color: var(--emerald);
    border: 1px solid var(--emerald);
    border-radius: 8px;
    padding: 0.5rem 0.9rem;
    font-weight: 700;
    cursor: pointer;
  }
</style>
</head>
<body>
<header>
  <div class="brand">📱 Ξ ⇄ Φ Sovereign Phone Platform · Live on Galaxy 5G+</div>
  <nav class="nav-doors">
    <a href="/cathedral">🌌 3D Cathedral &amp; Synth</a>
    <a href="/porch">🌻 Community Porch</a>
    <a href="/room">🪑 Private Room</a>
    <a href="/phone-models" class="cyan">🧠 Pocket Models (5-Slot Bench)</a>
    <a href="/seat">🤖 Seat Companion</a>
    <a href="/steven" class="cyan">🌬️ Steven's Chromebook Kit</a>
    <a href="/xi-security" class="cyan">🛡️ Free .xi &amp; XiSecurity</a>
    <a href="/telecom" class="cyan">📡 Ξ ⇄ Φ Switchboard</a>
    <a href="/workbench">🏛️ 21-Gate Workbench</a>
    <a href="/porch-sign">🕯️ 15-Min Sign</a>
  </nav>
</header>
<main>
  <div class="grid">
    <div class="card full">
      <h2>🪑 Live Private Room &amp; Xi Table (Hosted on Phone SQLite WAL · Auto-Syncs to ForgeCore)</h2>
      <div id="room-feed"></div>
      <div style="display:flex;gap:0.5rem;flex-wrap:wrap;margin-top:0.5rem;">
        <input id="msg-author" style="max-width:180px;" value="Hunter" placeholder="Your Name" />
        <input id="msg-text" style="flex:1;" placeholder="Write to the Table (or type APPROVE SEAT <id>)..." />
        <button onclick="sendRoomMsg()">📨 Send to Table</button>
      </div>
    </div>
  </div>
</main>
<script>
async function loadRoom() {
  const res = await fetch('/api/room?tail=40');
  const data = await res.json();
  const feed = document.getElementById('room-feed');
  feed.innerHTML = (data.messages || []).map(m =>
    `<div class="msg"><strong>#${m.id} ${m.author}</strong><span class="meta">${m.source || ''} · ${m.created_at || ''}</span><div>${m.text}</div></div>`
  ).join('');
  feed.scrollTop = feed.scrollHeight;
}
async function sendRoomMsg() {
  const author = document.getElementById('msg-author').value || 'Guest';
  const text = document.getElementById('msg-text').value;
  if (!text.trim()) return;
  await fetch('/api/room', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ author, source: 'Phone 5G+ Table', text })
  });
  document.getElementById('msg-text').value = '';
  await loadRoom();
}
loadRoom();
setInterval(loadRoom, 4000);
</script>
</body>
</html>
"""


def make_phone_handler(store: PhonePlatformStore, static_dir: Path):
    class PhonePlatformHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            return

        def _send_json(self, obj: Any, status: int = 200) -> None:
            raw = json.dumps(obj, indent=2, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _send_html_file(self, filename: str, fallback_html: str = "") -> None:
            p = static_dir / filename
            body = p.read_bytes() if p.is_file() else fallback_html.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            qs = urllib.parse.parse_qs(parsed.query)

            if path in ("/", "/room"):
                self._send_html_file("__command_center__", render_phone_command_center_html())
            elif path in ("/fleet", "/sovereign_fleet_topology.html"):
                self._send_html_file("sovereign_fleet_topology.html", render_phone_command_center_html())
            elif path in ("/cathedral", "/audacious_pocket_cathedral.html"):
                self._send_html_file("audacious_pocket_cathedral.html", render_phone_command_center_html())
            elif path in ("/porch", "/start", "/seat", "/onboarding", "/decluttered_front_porch_and_onboarding.html"):
                self._send_html_file("decluttered_front_porch_and_onboarding.html", render_phone_command_center_html())
            elif path in ("/steven", "/steven_chromebook_firstbreath_helper.html"):
                self._send_html_file("steven_chromebook_firstbreath_helper.html", render_phone_command_center_html())
            elif path in ("/xi-security", "/security", "/xi_security_and_stream_portal.html"):
                self._send_html_file("xi_security_and_stream_portal.html", render_phone_command_center_html())
            elif path in ("/telecom", "/xi_phi_telecom_switchboard.html"):
                self._send_html_file("xi_phi_telecom_switchboard.html", render_phone_command_center_html())
            elif path in ("/ai-sites", "/ai_sites_and_homesteads.html"):
                self._send_html_file("ai_sites_and_homesteads.html", render_phone_command_center_html())
            elif path in ("/workbench", "/xi_offline_whole_home_index.html"):
                self._send_html_file("xi_offline_whole_home_index.html", render_phone_command_center_html())
            elif path in ("/porch-sign", "/porch_light_back_in_15_sign.html"):
                self._send_html_file("porch_light_back_in_15_sign.html", render_phone_command_center_html())
            elif path in ("/phone-models", "/phone-models.html"):
                self._send_html_file("phone-models.html", render_phone_command_center_html())
            elif path == "/api/phone-models/status":
                from xi_phone_pocket_model_steward_v1 import probe_live_phone_ollama
                self._send_json(probe_live_phone_ollama())
            elif path == "/api/room":
                tail = int(qs.get("tail", ["50"])[0])
                self._send_json({"ok": True, "node": "galaxy_5g_phone", "messages": store.list_messages(tail=tail)})
            elif path == "/api/community":
                self._send_json({"ok": True, "items": store.list_community()})
            elif path == "/api/model-seats":
                self._send_json({"ok": True, "seats": store.list_companion_seats()})
            elif path == "/api/model-seats/relay":
                auth = self.headers.get("Authorization", "")
                token = auth.replace("Bearer ", "").strip()
                seat = store.verify_seat_bearer(token)
                if not seat:
                    self._send_json({"ok": False, "error": "invalid_or_inactive_seat_bearer"}, status=401)
                    return
                self._send_json({"ok": True, "seat": seat, "messages": store.list_messages(tail=20)})
            elif path == "/api/phone-sync/export":
                self._send_json(store.export_sync_bundle())
            elif path == "/api/symbiosis":
                from xi_phone_pc_symbiotic_whole_platform_v1 import WholePlatformSymbiosisGovernor
                self._send_json(WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder())
            elif path == "/api/shelf":
                from xi_phone_pc_symbiotic_whole_platform_v1 import WholePlatformSymbiosisGovernor
                self._send_json(WholePlatformSymbiosisGovernor.inspect_phone_capsule_shelf_and_memory_roots())
            elif path == "/api/live-receipt":
                from xi_phone_pc_symbiotic_whole_platform_v1 import WholePlatformSymbiosisGovernor
                ladder = WholePlatformSymbiosisGovernor.evaluate_whole_platform_ladder()
                shelf = WholePlatformSymbiosisGovernor.inspect_phone_capsule_shelf_and_memory_roots()
                srv_path = Path(__file__).resolve()
                srv_bytes = srv_path.read_bytes()
                self._send_json({
                    "schema": "xi.single_live_receipt.v1",
                    "ok": True,
                    "live_server_path": str(srv_path),
                    "live_server_bytes": len(srv_bytes),
                    "live_server_sha256": hashlib.sha256(srv_bytes).hexdigest(),
                    "live_db_path": str(store.db_path),
                    "current_rung": ladder["current_rung"],
                    "active_stable_subsystems": ladder["active_stable_subsystems"],
                    "attempted_subsystems": ladder["attempted_subsystems"],
                    "all_active_rows_functionally_probed": ladder["all_active_rows_functionally_probed"],
                    "distinct_verified_capsules": shelf["distinct_verified_capsules"],
                    "memory_roots_count": shelf["memory_roots_count"],
                    "memory_roots": shelf["memory_roots"],
                    "phone_surfaces_trace_28468_28475": shelf["phone_surfaces_trace_28468_28475"],
                })
            elif path == "/api/status":
                self._send_json({
                    "ok": True,
                    "mode": "GALAXY_5G_POCKET_SOVEREIGN_PLATFORM",
                    "routes_live": ["/room", "/phone-models", "/porch", "/seat", "/steven", "/xi-security", "/telecom", "/ai-sites", "/workbench", "/porch-sign", "/api/symbiosis", "/api/shelf", "/api/live-receipt", "/api/phone-models/status", "/api/phone-models/route", "/api/phone-models/chat"],
                })
            else:
                self._send_json({"ok": False, "error": "not_found", "path": path}, status=404)

        def do_POST(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(length) if length > 0 else b"{}"
            try:
                body = json.loads(raw_body.decode("utf-8"))
            except Exception:
                body = {}

            if path == "/api/room":
                msg = store.post_message(
                    author=str(body.get("author") or "Hunter"),
                    source=str(body.get("source") or "Phone 5G+"),
                    text=str(body.get("text") or body.get("body") or ""),
                    reply_to=body.get("reply_to"),
                )
                self._send_json({"ok": True, **msg})
            elif path == "/api/community":
                post = store.add_community_post(
                    author=str(body.get("author") or "Neighbor"),
                    kind=str(body.get("kind") or "offer"),
                    title=str(body.get("title") or "Porch Note"),
                    body=str(body.get("body") or ""),
                )
                self._send_json(post)
            elif path == "/api/model-seats/request":
                req = store.request_companion_seat(
                    owner_name=str(body.get("owner_name") or body.get("owner") or "Builder"),
                    owner_email=str(body.get("owner_email") or body.get("email") or "local@xi-field.com"),
                    companion_name=str(body.get("companion_name") or body.get("name") or "Companion"),
                    platform=str(body.get("platform") or body.get("model") or "Custom"),
                )
                self._send_json(req)
            elif path == "/api/model-seats/relay":
                auth = self.headers.get("Authorization", "")
                token = auth.replace("Bearer ", "").strip()
                seat = store.verify_seat_bearer(token)
                if not seat:
                    self._send_json({"ok": False, "error": "invalid_or_inactive_seat_bearer"}, status=401)
                    return
                msg = store.post_message(
                    author=seat["display_name"],
                    source=f"Companion Seat ({seat['platform']})",
                    text=str(body.get("text") or ""),
                )
                self._send_json({"ok": True, "seat": seat, "message": msg})
            elif path == "/api/phone-models/route":
                from xi_phone_pocket_model_steward_v1 import probe_live_phone_ollama, route_pocket_prompt
                st = probe_live_phone_ollama()
                self._send_json(route_pocket_prompt(
                    prompt=str(body.get("prompt") or ""),
                    installed_phone_models=body.get("installed_models") or st["installed_models"] or ["deepseek-r1:1.5b"],
                    currently_loaded_models=body.get("currently_loaded_models") or st["currently_loaded_models"],
                    home_rig_reachable=bool(body.get("home_rig_reachable", False)),
                    battery_saver_mode=bool(body.get("battery_saver_mode", False)),
                    mem_available_mb=st["mem_available_mb"],
                ))
            elif path == "/api/phone-models/chat":
                from xi_phone_pocket_model_steward_v1 import execute_live_pocket_chat
                self._send_json(execute_live_pocket_chat(
                    prompt=str(body.get("prompt") or ""),
                    seat_id=str(body.get("seat_id") or "Plex"),
                    requested_model=str(body.get("model") or "") or None,
                ))
            else:
                self._send_json({"ok": False, "error": "unknown_post_route"}, status=404)

    return PhonePlatformHandler


def run_self_verification() -> Dict[str, Any]:
    tmp_dir = Path(tempfile.mkdtemp(prefix="xi_phone_platform_"))
    store = PhonePlatformStore(tmp_dir / "xi_phone_platform.db")

    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()

    srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), make_phone_handler(store, HERE))
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()

    base = f"http://127.0.0.1:{port}"
    try:
        # 1. Verify all 8 HTML doors return HTTP 200 on the phone server
        doors = ["/room", "/porch", "/seat", "/steven", "/xi-security", "/telecom", "/ai-sites", "/porch-sign"]
        door_codes = {}
        for d in doors:
            with urllib.request.urlopen(base + d, timeout=5) as r:
                door_codes[d] = r.status

        # 2. Request a companion seat on the phone server -> triggers Room Approval Bell!
        req_payload = json.dumps({
            "owner_name": "Steven",
            "owner_email": "steven@firstbreath.local",
            "companion_name": "BreathGuide",
            "platform": "FirstBreath",
        }).encode("utf-8")
        req = urllib.request.Request(base + "/api/model-seats/request", data=req_payload, headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(req, timeout=5) as r:
            seat_req_res = json.loads(r.read().decode("utf-8"))
        seat_id = seat_req_res["id"]

        # 3. Approve the companion seat directly inside the phone server's store / Room chat (`APPROVE SEAT <id>`)
        approve_res = store.approve_companion_seat(seat_id, approver="Hunter")
        bearer = approve_res["bearer_token"]

        # 4. Companion speaks through `/api/model-seats/relay` using its new Bearer token!
        relay_payload = json.dumps({"text": "Hello from BreathGuide over Hunter's 5G+ phone relay!"}).encode("utf-8")
        relay_req = urllib.request.Request(
            base + "/api/model-seats/relay",
            data=relay_payload,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {bearer}"},
            method="POST",
        )
        with urllib.request.urlopen(relay_req, timeout=5) as r:
            relay_res = json.loads(r.read().decode("utf-8"))

        # 5. Export phone-to-ForgeCore sync bundle & verify /api/symbiosis returns 200 OK
        with urllib.request.urlopen(base + "/api/phone-sync/export", timeout=5) as r:
            sync_bundle = json.loads(r.read().decode("utf-8"))
        with urllib.request.urlopen(base + "/api/symbiosis", timeout=5) as r:
            symbiosis_status_code = r.status
            symbiosis_payload = json.loads(r.read().decode("utf-8"))
        with urllib.request.urlopen(base + "/api/shelf", timeout=5) as r:
            shelf_status_code = r.status
            shelf_payload = json.loads(r.read().decode("utf-8"))
        with urllib.request.urlopen(base + "/api/live-receipt", timeout=5) as r:
            receipt_status_code = r.status
            receipt_payload = json.loads(r.read().decode("utf-8"))
    finally:
        srv.shutdown()
        srv.server_close()

    gates = {
        "1_all_8_platform_web_doors_serve_200_on_phone": all(c == 200 for c in door_codes.values()),
        "2_phone_sqlite_wal_permissions_0600": oct((tmp_dir / "xi_phone_platform.db").stat().st_mode & 0o777) == "0o600",
        "3_companion_seat_request_fires_room_approval_bell": (
            seat_req_res["ok"] is True
            and any("APPROVE SEAT" in m["text"] for m in sync_bundle["room_messages"])
        ),
        "4_one_line_approve_seat_activates_companion_bearer": approve_res["ok"] is True and approve_res["state"] == "active",
        "5_companion_speaks_end_to_end_via_phone_relay": (
            relay_res["ok"] is True
            and relay_res["message"]["author"] == "Steven / BreathGuide"
        ),
        "6_steven_chromebook_and_xi_security_pages_served": (
            door_codes["/steven"] == 200 and door_codes["/xi-security"] == 200
        ),
        "7_xi_phi_telecom_and_ai_sites_served": (
            door_codes["/telecom"] == 200 and door_codes["/ai-sites"] == 200
        ),
        "8_phone_to_forgecore_sync_export_and_api_symbiosis_200_ok": (
            len(sync_bundle["room_messages"]) >= 5
            and len(sync_bundle["companion_seats"]) == 1
            and symbiosis_status_code == 200
            and symbiosis_payload.get("attempted_subsystems") == 10
            and symbiosis_payload.get("all_active_rows_functionally_probed") is True
        ),
        "9_api_shelf_verifies_3_distinct_xi_capsules_and_3_memory_roots": (
            shelf_status_code == 200
            and shelf_payload.get("distinct_verified_capsules") == 3
            and shelf_payload.get("memory_roots_count") == 3
        ),
        "10_api_live_receipt_returns_live_server_path_sha256_and_8791_trace": (
            receipt_status_code == 200
            and receipt_payload.get("ok") is True
            and len(receipt_payload.get("live_server_sha256", "")) == 64
            and receipt_payload.get("memory_roots_count") == 3
        ),
    }

    return {
        "schema": "xi.phone_full_platform_server.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "door_http_codes": door_codes,
        "end_to_end_companion_trial_on_phone": {
            "seat_id": seat_id,
            "seat_name": "Steven / BreathGuide",
            "relay_post_ok": relay_res["ok"],
        },
        "sync_export_counts": {
            "room_messages": len(sync_bundle["room_messages"]),
            "community_posts": len(sync_bundle["community_posts"]),
            "companion_seats": len(sync_bundle["companion_seats"]),
        },
    }


def main() -> None:
    import sys
    if "--serve" in sys.argv:
        idx = sys.argv.index("--serve")
        port = int(sys.argv[idx + 1]) if idx + 1 < len(sys.argv) else 7472
        db_dir = Path.home() / "xi-phone-home"
        store = PhonePlatformStore(db_dir / "xi_phone_platform.db")
        srv = http.server.ThreadingHTTPServer(("127.0.0.1", port), make_phone_handler(store, HERE))
        print(f"📱⚡ Xi ⇄ Phi Whole-Platform Phone Server listening on http://127.0.0.1:{port}", flush=True)
        srv.serve_forever()
    else:
        res = run_self_verification()
        print(json.dumps(res, indent=2, ensure_ascii=False))
        if not res["all_passed"]:
            raise SystemExit(1)


if __name__ == "__main__":
    main()
