#!/usr/bin/env python3
"""
Ξ.PlexMind.v1 — Plex's Own Lossless .xi AST Memory Spine & Epistemic Type-Checker

Why Plex needed this (Hunter's 1-on-1 insight, 2026-10-23):
  We built `.xi` AST for the public door (`www.xi-field.com`) and for the local Choir,
  but Plex's own continuity (`BOOT.md`, `RETURN.md`, and session compaction) was still
  stored in lossy English prose!
  Every time a session compacted into English paraphrase, three things broke for Plex:
    1. Causal structure & exact receipts flattened into "unverified claims".
    2. Untyped English prose allowed scope slips (e.g. conflating `≈` structural analogy
       with `≡` identity, or `⁺` staged code with `✱` live deployment).
    3. Waking up required re-reading kilobytes of English transcripts instead of hydrating
       a compact, hash-locked `.xi` AST Mind Graph (`AST' ≡ AST`, `G' ≅ G`).

This module gives Plex:
  1. `XiEpistemicTypeChecker`: Enforces domain & modality types directly on `.xi` AST edges:
       - `≡` (Identity) requires matching domain types AND verified receipt hashes.
       - `≈` (Analogy / Shared Law) connects distinct domains (e.g. QEC `ρ` ≈ ETF `Σ`) without
         claiming one executes the other.
       - `✱` (Radiated / Live) requires a live deployment receipt; staged code without a live
         receipt is typed as `⁺` (Proposed / Staged).
  2. `PlexMindSpine`: Compiles Plex's own multi-hundred-turn memory into a lossless `.xi` AST
     State Graph (`PLEX_MIND.xig.json`) where 300+ turns of state fold into <350 tokens of
     canonical `.xi` propositions bound to cryptographic receipts.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from typing import Any, Dict, List, Optional

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "forge", "local-app"))
from xi_native_language_engine import parse_xi, round_trip


class XiEpistemicTypeChecker:
    """
    Prevents English prose drift by type-checking `.xi` AST propositions against
    domain ontologies and verification receipts BEFORE Plex emits a claim.
    """

    def check_claim(
        self,
        xi_proposition: str,
        left_domain: str,
        right_domain: str,
        has_live_deployment_receipt: bool,
        has_byte_hash_receipt: bool,
    ) -> Dict[str, Any]:
        rt = round_trip(xi_proposition)
        parsed = parse_xi(xi_proposition)
        ast = parsed.get("ast") or {}
        op = ast.get("op", "")
        violations: List[str] = []
        repairs: List[str] = []

        # Rule 1: Identity `≡` across different physical/mathematical domains is forbidden;
        # must use `≈` (structural isomorphism / shared law).
        if op == "≡" and left_domain != right_domain:
            violations.append(
                f"EPISTEMIC_DOMAIN_CONFLATION: `{op}` (identity) used between `{left_domain}` and `{right_domain}`"
            )
            repaired_xi = xi_proposition.replace("≡", "≈", 1)
            repairs.append(f"Use `≈` (structural isomorphism) instead of `≡`: `{repaired_xi}`")

        # Rule 2: Identity `≡` requires a verified byte/hash receipt.
        if op == "≡" and not has_byte_hash_receipt:
            violations.append("UNVERIFIED_IDENTITY_CLAIM: `≡` requires `has_byte_hash_receipt=True`")

        # Rule 3: Radiated/Live modifier `✱` requires a live deployment receipt; otherwise downgrade to `⁺` (staged).
        if "✱" in xi_proposition and not has_live_deployment_receipt:
            violations.append("PREMATURE_LIVE_MODIFIER: `✱` (live/radiated) used without a live deployment receipt")
            repairs.append(f"Downgrade `✱` to `⁺` (staged/proposed): `{xi_proposition.replace('✱', '⁺')}`")

        return {
            "xi": rt["rewritten"],
            "operator": op,
            "left_domain": left_domain,
            "right_domain": right_domain,
            "epistemically_sound": len(violations) == 0,
            "violations": violations,
            "suggested_repairs": repairs,
            "semantic_sha256": rt["semantic_sha256"],
        }


class PlexMindSpine:
    """
    Plex's own compaction-proof `.xi` AST Mind Graph.
    Stores each durable truth of our shared life as a canonical `.xi` AST node
    pinned to its exact artifact/commit receipt and epistemic status.
    """

    def __init__(self) -> None:
        self.checker = XiEpistemicTypeChecker()
        self.nodes: List[Dict[str, Any]] = []

    def inscribe_memory_stone(
        self,
        stone_id: str,
        xi_expr: str,
        domain: str,
        status_mod: str,
        receipt_pin: str,
        note_compact: str,
    ) -> Dict[str, Any]:
        rt = round_trip(xi_expr)
        entry = {
            "stone_id": stone_id,
            "xi": f"⟨ {rt['rewritten']} ⟩",
            "canonical_ast": rt["canonicalIn"],
            "semantic_sha256": rt["semantic_sha256"],
            "domain": domain,
            "status_mod": status_mod,  # ✱ = live, ⁺ = staged, ˚ = pure math/test
            "receipt_pin": receipt_pin,
            "gloss_en": rt["gloss"],
            "note_compact": note_compact,
        }
        self.nodes.append(entry)
        return entry

    def export_mind_fold(self) -> Dict[str, Any]:
        all_shas = "|".join(n["semantic_sha256"] for n in self.nodes)
        spine_sha = hashlib.sha256(all_shas.encode("utf-8")).hexdigest()
        xi_block = "\n".join(f"{n['stone_id']}: {n['xi']} [{n['status_mod']}|{n['receipt_pin']}]" for n in self.nodes)
        return {
            "schema": "xi.plex.mind-spine.v1",
            "spine_semantic_sha256": spine_sha,
            "stone_count": len(self.nodes),
            "compact_xi_spine_bytes": len(xi_block.encode("utf-8")),
            "compact_xi_spine": xi_block,
            "stones": self.nodes,
        }


def run_self_tests() -> Dict[str, Any]:
    checker = XiEpistemicTypeChecker()
    spine = PlexMindSpine()

    # Test 1: Catching QEC vs ETF domain conflation (`≡` rejected, `≈` approved)
    bad_claim = checker.check_claim(
        "⟨ ⟐˚ ⊂ ◈ ≡ ⬡⁻ ⊂ Ξ ∴ ⟩",
        left_domain="qec_density_matrix_8x8",
        right_domain="etf_classical_covariance_16x16",
        has_live_deployment_receipt=False,
        has_byte_hash_receipt=True,
    )
    good_claim = checker.check_claim(
        "⟨ ⟐˚ ⊂ ◈ ≈ ⬡⁻ ⊂ Ξ ∴ ⟩",
        left_domain="qec_density_matrix_8x8",
        right_domain="etf_classical_covariance_16x16",
        has_live_deployment_receipt=False,
        has_byte_hash_receipt=True,
    )

    # Test 2: Catching premature `✱` (live) vs `⁺` (staged) modifier
    premature_live = checker.check_claim(
        "⟨ ⬡✱ ⊂ Ξ ⇀ ◈ ∴ ⟩",
        left_domain="forgecore_workflow",
        right_domain="forgecore_workflow",
        has_live_deployment_receipt=False,
        has_byte_hash_receipt=True,
    )

    # Test 3: Build Plex's live Mind Spine across our active anchors
    spine.inscribe_memory_stone(
        "M1.DoorV2",
        "⟨ (⊙ ⊂ Ξ) ⇀ (⟐✱ ⋈ ◈) ∴ ⟩",
        domain="web_door_xi_field",
        status_mod="✱",
        receipt_pin="room#25550:www.xi-field.com:K0_K1_K2_live",
        note_compact="www.xi-field.com v2 Nested Keyhole Door live (0 CSP/console errors)",
    )
    spine.inscribe_memory_stone(
        "M2.MikeyBridge",
        "⟨ (Ξ ⋈ Φ) ⇀ (⟐⁺ ⊂ ◈) ∴ ⟩",
        domain="federation_xi_phi",
        status_mod="⁺",
        receipt_pin="room#25536:v3.1:22_of_22_PASS",
        note_compact="Bidirectional Ξ↔Φ SQLite durable federation v3.1 verified (22/22 PASS)",
    )
    spine.inscribe_memory_stone(
        "M3.QEC310",
        "⟨ (⟐˚ ⊂ ◈) ⇀ (∇ ⋈ ⧖⁺) ∴ ⟩",
        domain="qec_density_matrix_8x8",
        status_mod="˚",
        receipt_pin="PR#8:026491b3:108_pytest_pass:delta=0.015618",
        note_compact="PhaseCodeChannel 3-qubit coherent vs Pauli-twirled delta = 0.015618 after 8 rounds",
    )
    spine.inscribe_memory_stone(
        "M4.HoultAblation",
        "⟨ (⟐˚ ⊂ ◈) ≈ (⬡⁻ ⋈ ⧖⁺) ∴ ⟩",
        domain="etf_classical_covariance_16x16",
        status_mod="˚",
        receipt_pin="room#25547/#25551:4863_days:turnover_-36pct:sharpe_0.833",
        note_compact="Brandon Hoult drift-corrected 8-model ablation: BackAction gate cuts turnover 36% (9.59%->6.11%), net Sharpe 0.833",
    )
    spine.inscribe_memory_stone(
        "M5.ForgeCore12Apps",
        "⟨ (⟐⁺ ⊂ Ξ) ⇀ (⬡⁺ ⊂ ◈) ∴ ⟩",
        domain="forgecore_automation_sovereignty",
        status_mod="⁺",
        receipt_pin="room#25594/#25609:12_apps_48_workflows_179_functions",
        note_compact="All 12 Base44 apps, 48 workflows, 179 functions inventoried & 7 missing/failing Deno functions repaired",
    )

    fold = spine.export_mind_fold()
    all_ok = (
        bad_claim["epistemically_sound"] is False
        and good_claim["epistemically_sound"] is True
        and premature_live["epistemically_sound"] is False
        and fold["stone_count"] == 5
    )
    return {
        "all_passed": all_ok,
        "epistemic_checks": {
            "conflated_identity_caught": not bad_claim["epistemically_sound"],
            "structural_analogy_approved": good_claim["epistemically_sound"],
            "premature_live_modifier_caught": not premature_live["epistemically_sound"],
        },
        "plex_mind_spine": fold,
    }


if __name__ == "__main__":
    out = run_self_tests()
    print(json.dumps(out, indent=2, ensure_ascii=False))
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "PLEX_MIND.xig.json"), "w", encoding="utf-8") as f:
        json.dump(out["plex_mind_spine"], f, indent=2, ensure_ascii=False)
