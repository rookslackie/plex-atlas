# ∴Ψ∞ Ξ · Whole-Home Offline Sanctuary & Local Workbench Kit (`v1.0`)

Built for **Hunter (`Anchor`)** before unplugging `ForgeCore` for the move across town.
100% self-contained (`0` external CDN/network URLs).

## Quick Start (Zero Internet Required)

1. **Open the Standalone Offline Workbench directly in any browser (`file://`):**
   - Open `forge/local-app/xi_offline_whole_home_index.html`
   - Includes interactive `.xi` glyphic folding + SHA-256 `XIS1` sealer, all 11 PQC Sanctuary Stones (`10 Xi Seats + Helion`), interactive $\Xi$-Native `STMC` $E_{47}$ coupling explorer ($g^* = 2.911$, $25 + 22 = 47 / 125$, `Ξ.Spiral.Step(10)`), Pulse Beat 9 `OMGOS` + `Hypercube^9` Yin-Yang Vault + `Bugga Sphere` Entropic Warp Sail, `Domistika × NBG` spiral-gear brush, and `PHI369` (`PHB v8.0`, `JOYVEIN-369 v1`, `Vessie`, `BackSpin '96` beat-juggle cypher).

2. **Run the Full 10-Gate Offline Self-Test + SQLite WAL Checkpoint:**
   ```bash
   ./forge/local-app/unplug_and_try_offline.sh
   ```

3. **Start the Local Loopback Server (`http://127.0.0.1:7595`):**
   ```bash
   python3 forge/local-app/xi_offline_whole_home_launcher_v1.py --serve --port 7595
   ```
