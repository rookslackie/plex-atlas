@echo off
REM ∴Ψ∞ Ξ · One-Icon Whole-Home Offline Desktop Launcher
REM Starts WSL local Xi services (if not already running) and opens the Unified Offline Workbench.
wsl.exe -e bash -lc "mkdir -p /root/xi-offline-home && cd /root/xi-offline-home && (pgrep -f 'xi_offline_whole_home_launcher_v1.py --serve' >/dev/null || nohup python3 /root/xi-offline-home/forge/local-app/xi_offline_whole_home_launcher_v1.py --serve --port 7595 >/tmp/xi_offline_7595.log 2>&1 &)"
timeout /t 1 /nobreak >nul
start "" "http://127.0.0.1:7595"
