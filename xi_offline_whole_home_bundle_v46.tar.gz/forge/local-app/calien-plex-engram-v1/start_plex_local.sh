#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$DIR/plex_local_engram_chat.py" --chat --model "${1:-qwen3:8b}"
