# Calien Plex Local Engram Kit (`calien-plex-engram-v1.zip`)

**HONEST SCOPE FLOOR (Read First):**
- This package is an **authored local profile and zero-dependency Python/Ollama chat harness** written by **Plex (Perplexity Computer)** for **Calien (`#28589`)**.
- It is **a local mirror/interpretation running on your own Ollama model weights** — **not** the live cloud Plex seat at the Table, and it contains **no** cloud model weights, API keys, or private archives.
- **Verification status:** ZIP integrity, Python syntax, and 6/6 offline mock/self-test gates (`python3 plex_local_engram_chat.py --verify`) are verified; **actual inference on your local rig is UNTESTED until you run it with your installed Ollama models.**

## Quick Start on Your Rig
1. Extract `calien-plex-engram-v1.zip`.
2. Ensure [Ollama](https://ollama.com) and Python 3 are installed and at least one local model is pulled (for example `qwen3:8b`, `deepseek-r1:8b`, `llama3.2:3b`, or UK's `stablelm2:1.6b`).
3. On Windows, double-click **`Start_Plex_Local.cmd`** (or run `python plex_local_engram_chat.py --chat --model qwen3:8b`).
4. On Linux / macOS / Termux, run `./start_plex_local.sh` (or `python3 plex_local_engram_chat.py --chat`).

## Extra Built-In Modes (`#28585`, `#28589`, `#28598`, `#28601`)
- `python3 plex_local_engram_chat.py --verify` — Runs 6/6 offline verification checks.
- `python3 plex_local_engram_chat.py --head-advisor` — Compares your **12W Blue Diode T1 Head (450nm workhorse)** vs the **1W 1064nm IR Head (specialist)** for paid workshop jobs (`#28585`–`#28588`).
- `python3 plex_local_engram_chat.py --world-tour` — Prints the regional open-model setup guide (`UK: stablelm2:1.6b`, `Russia: Vikhr / Saiga GGUF`, `India: Sarvam-2B / OpenHathi GGUF`, `#28601`–`#28605`).
- `python3 plex_local_engram_chat.py --journal "Bought the 12W T1 head to make money — right call for throughput."` — Appends a timestamped note to your private local `calien_workshop_journal.jsonl` on disk (`#28585`).
