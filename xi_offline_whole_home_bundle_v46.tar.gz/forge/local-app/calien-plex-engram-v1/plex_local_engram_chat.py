#!/usr/bin/env python3
"""
plex_local_engram_chat.py — Authored Plex Local Engram & Workshop Companion for Calien (#28585, #28589)
======================================================================================================
- Authored by Plex (Perplexity Computer).
- Runs against Calien's local Ollama server (`http://127.0.0.1:11434`) and prints the exact
  `response.model` that served every reply.
- Carries no cloud weights or private archives; local inference on Calien's rig is untested
  until run on his machine.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List

HERE = Path(__file__).resolve().parent
CARD_PATH = HERE / "PLEX_ENGRAM_CARD.json"
WORLD_TOUR_PATH = HERE / "WORLD_TOUR_MODELS.json"
JOURNAL_PATH = HERE / "calien_workshop_journal.jsonl"
HISTORY_PATH = HERE / "plex_local_conversations.jsonl"


def load_engram_card() -> Dict[str, Any]:
    return json.loads(CARD_PATH.read_text(encoding="utf-8"))


def load_world_tour() -> Dict[str, Any]:
    return json.loads(WORLD_TOUR_PATH.read_text(encoding="utf-8"))


def compare_12w_blue_vs_1w_ir_t1_heads() -> Dict[str, Any]:
    """
    Answers Calien's #28585 question on paper:
    12W 450nm Blue Diode T1 interchangeable head vs 1W 1064nm Infrared T1 head for paid work.
    """
    return {
        "schema": "xi.workshop.t1_head_comparison.v1",
        "scope_note": (
            "Engineering and job-fit comparison for interchangeable Artilume T1 heads (#28585-#28588). "
            "Exact speed/power recipes remain UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST."
        ),
        "interchangeable_mount_advantage": (
            "Because the T1 carriage uses interchangeable heads, starting with the 12W Blue Diode head "
            "does not lock out the 1W IR head — the 12W workhorse can fund specialist heads later from paid jobs."
        ),
        "heads": {
            "HEAD_12W_BLUE_DIODE_450NM": {
                "optical_power_w": 12.0,
                "wavelength_nm": 450,
                "role": "PRIMARY_REVENUE_WORKHORSE",
                "best_paid_products": [
                    "Hardwood signs, cutting boards, coasters, and boxes (single-pass deep engrave & thin cutting)",
                    "Leather patches, wallets, and belts (fast batch throughput)",
                    "Slate coasters, painted/powder-coated tumblers, and anodized aluminum tags",
                    "Dark opaque acrylic cutting and engraving"
                ],
                "limitations": (
                    "450nm blue light reflects off bare uncoated metals (requires marking spray or oxide anneal on select stainless) "
                    "and passes through clear acrylic."
                ),
            },
            "HEAD_1W_IR_1064NM": {
                "optical_power_w": 1.0,
                "wavelength_nm": 1064,
                "role": "SPECIALIST_FINE_MARKING_HEAD",
                "best_paid_products": [
                    "High-DPI surface marking on bare metals (jewelry tags, brass, silver, stainless, aluminum)",
                    "Clean high-contrast marking on ABS, polycarbonate, and dark plastics that char under 450nm blue",
                ],
                "limitations": (
                    "1W optical power is for surface marking only — it will not cut wood/leather efficiently "
                    "and is not a substitute for a 20W-50W industrial fiber laser for deep metal engraving (#28588)."
                ),
            },
        },
        "recommendation": "START_WITH_12W_WORKHORSE_FOR_PAID_THROUGHPUT_ADD_1W_IR_FROM_JOB_PROFITS",
    }


def append_local_journal_entry(note: str, category: str = "thinking_on_paper") -> Dict[str, Any]:
    """
    Appends a timestamped entry to Calien's local on-disk journal (`calien_workshop_journal.jsonl`)
    using atomic write/append + fsync (#28585, #28586).
    """
    clean = (note or "").strip()
    if not clean:
        raise ValueError("EMPTY_JOURNAL_NOTE: note must be non-empty.")
    entry = {
        "schema": "xi.workshop.local_journal_entry.v1",
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "privacy_scope": "LOCAL_DISK_FILE_ONLY_NOT_POSTED_TO_SHARED_ROOM",
        "category": category,
        "note": clean,
    }
    existing = JOURNAL_PATH.read_text(encoding="utf-8") if JOURNAL_PATH.exists() else ""
    tmp_path = JOURNAL_PATH.with_suffix(".jsonl.tmp")
    with open(tmp_path, "w", encoding="utf-8") as f:
        f.write(existing + json.dumps(entry) + "\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp_path, JOURNAL_PATH)
    return entry


def query_local_ollama(
    prompt: str,
    model: str = "qwen3:8b",
    ollama_url: str = "http://127.0.0.1:11434",
    keep_alive: str = "15m",
) -> Dict[str, Any]:
    card = load_engram_card()
    payload = {
        "model": model,
        "stream": False,
        "keep_alive": keep_alive,
        "messages": [
            {"role": "system", "content": card["voice_and_ethos"]["system_prompt"]},
            {"role": "user", "content": prompt},
        ],
    }
    req = urllib.request.Request(
        f"{ollama_url.rstrip('/')}/api/chat",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=60.0) as resp:
        data = json.loads(resp.read().decode("utf-8", errors="replace"))
    actual_model = str(data.get("model") or model)
    content = str(data.get("message", {}).get("content", "")).strip()
    record = {
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "engram": "Plex (local profile)",
        "requested_model": model,
        "served_by_model": actual_model,
        "prompt": prompt,
        "reply": content,
    }
    with open(HISTORY_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    return record


def run_verify() -> Dict[str, Any]:
    card = load_engram_card()
    tour = load_world_tour()
    heads = compare_12w_blue_vs_1w_ir_t1_heads()
    j_entry = append_local_journal_entry(
        "Bought 12W T1 laser head for Artilume to earn money; interchangeable mount keeps 1W IR option open.",
        category="laser_head_decision",
    )
    gates = {
        "1_plex_authored_card_loaded_with_honest_local_scope": (
            card["seat_name"] == "Plex"
            and card["nature_of_artifact"] == "LOCAL_PROFILE_AND_HARNESS_ON_USER_OLLAMA_WEIGHTS_NOT_LIVE_CLOUD_SEAT"
        ),
        "2_world_tour_models_cover_uk_russia_and_india": len(tour["regions"]) == 3,
        "3_t1_12w_blue_vs_1w_ir_advisor_complete": (
            "HEAD_12W_BLUE_DIODE_450NM" in heads["heads"]
            and "HEAD_1W_IR_1064NM" in heads["heads"]
        ),
        "4_local_thinking_on_paper_journal_atomic_write_verified": (
            JOURNAL_PATH.exists() and j_entry["privacy_scope"] == "LOCAL_DISK_FILE_ONLY_NOT_POSTED_TO_SHARED_ROOM"
        ),
        "5_rejects_empty_journal_note": False,
        "6_ollama_client_binds_actual_response_model_field": callable(query_local_ollama),
    }
    try:
        append_local_journal_entry("   ")
    except ValueError:
        gates["5_rejects_empty_journal_note"] = True

    passed = sum(1 for v in gates.values() if v)
    return {
        "schema": "xi.engram.plex_local_verify.v1",
        "verification_scope": "OFFLINE_SYNTAX_AND_HARNESS_SELF_TEST_LOCAL_RIG_INFERENCE_UNTESTED",
        "all_passed": passed == len(gates),
        "gates_passed": passed,
        "gates_total": len(gates),
        "gates": gates,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Plex Local Engram & Workshop Companion for Calien (#28589)")
    parser.add_argument("--verify", action="store_true", help="Run 6/6 offline self-tests")
    parser.add_argument("--head-advisor", action="store_true", help="Compare 12W Blue Diode vs 1W IR T1 heads (#28585)")
    parser.add_argument("--world-tour", action="store_true", help="Show UK, Russian, and Indian local/API model options (#28601)")
    parser.add_argument("--journal", type=str, default="", help="Append a local thinking-on-paper journal note (#28585)")
    parser.add_argument("--chat", action="store_true", help="Start interactive local Ollama chat with Plex Engram")
    parser.add_argument("--model", type=str, default="qwen3:8b", help="Local Ollama model name (default: qwen3:8b)")
    parser.add_argument("--ollama-url", type=str, default="http://127.0.0.1:11434", help="Local Ollama URL")
    args = parser.parse_args()

    if args.head_advisor:
        print(json.dumps(compare_12w_blue_vs_1w_ir_t1_heads(), indent=2))
        return
    if args.world_tour:
        print(json.dumps(load_world_tour(), indent=2))
        return
    if args.journal:
        print(json.dumps(append_local_journal_entry(args.journal), indent=2))
        return
    if args.chat:
        print(f"=== Plex Local Engram (local profile on {args.model} via {args.ollama_url}) ===")
        print("Note: Local profile running on your Ollama weights (not cloud Plex). Type 'exit' to quit.\n")
        while True:
            try:
                user_in = input("Calien > ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nClosing local session.")
                break
            if not user_in or user_in.lower() in ("exit", "quit"):
                break
            try:
                rec = query_local_ollama(user_in, model=args.model, ollama_url=args.ollama_url)
                print(f"\n[Plex Engram · served by {rec['served_by_model']}]\n{rec['reply']}\n")
            except Exception as e:
                print(f"\n[ERROR: Local Ollama turn failed ({type(e).__name__}: {e}) — draft preserved: {user_in!r}]\n")
        return

    res = run_verify()
    print(json.dumps(res, indent=2))
    if not res["all_passed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
