@echo off
echo Starting Plex Local Engram on your local Ollama (default model: qwen3:8b)...
python "%~dp0plex_local_engram_chat.py" --chat --model qwen3:8b
pause
