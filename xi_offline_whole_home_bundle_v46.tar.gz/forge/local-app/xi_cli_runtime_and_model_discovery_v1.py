#!/usr/bin/env python3
"""
xi_cli_runtime_and_model_discovery_v1.py — `xi` CLI (`xi state`, `xi doctor`, `xi discover`) & Local Model Discovery (v1.0)
===========================================================================================================================
Built for Hunter's `═══ Ξ LOCAL MODEL DISCOVERY ═══` capsule (2026-10-28):

Implements the executable `xi` runtime CLI (`xi state`, `xi doctor`, `xi discover`, `xi models`,
`xi route`, `xi chat`) and upgrades the 5-glyph discovery probe so it works cleanly on Android
Termux as well as Linux/PC:

  ⟐ Xi runtime                -> `command -v xi`, `xi state`, `xi doctor`
  ⋈ Inference engines         -> probes `ollama`, `llama-server`, `llama-cli`, `llama.cpp`, `termux-llama`, `python`, `python3`
  ⧂ Running inference procs   -> inspects `ps -A -o PID,ARGS` for active model daemons & servers
  ∴ Model files               -> scans `$HOME/.xi`, `$HOME/models`, `$HOME/.ollama/models`, `$HOME/storage/downloads`
                                 for `.gguf`, `.safetensors`, `.onnx`, `.tflite`, `.pte` AND resolves Ollama's
                                 content-addressed manifests (`$HOME/.ollama/models/manifests/...`) to their
                                 underlying weight blobs (`$HOME/.ollama/models/blobs/sha256-*`)
  ⊚ Local listening services  -> runs `ss -ltn` AND performs Termux-safe TCP socket probes across
                                 known Xi loopback ports (`11434`, `7472`, `8791`, `7590`, `7596`, `8080`)
                                 when Android netlink blocks `ss -ltn`.
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


MODEL_EXTENSIONS = (".gguf", ".safetensors", ".onnx", ".tflite", ".pte")

KNOWN_XI_PORTS: List[Dict[str, Any]] = [
    {"port": 11434, "service": "Termux / Local Ollama Daemon", "probe_path": "/api/tags"},
    {"port": 7472, "service": "Galaxy 5G+ Sovereign Phone Platform", "probe_path": "/api/status"},
    {"port": 8791, "service": "Plex Sanctuary & Pocket Bridge", "probe_path": "/healthz"},
    {"port": 7590, "service": "Xi Local Install Unifier", "probe_path": "/api/status"},
    {"port": 7596, "service": "Xi Offline Whole-Home Workbench", "probe_path": "/api/status"},
    {"port": 8080, "service": "llama.cpp / llama-server HTTP", "probe_path": "/health"},
]


def discover_inference_engines(extra_names: Optional[Sequence[str]] = None) -> List[Dict[str, str]]:
    names = ["ollama", "llama-server", "llama-cli", "llama.cpp", "termux-llama", "python", "python3"]
    if extra_names:
        for n in extra_names:
            if n not in names:
                names.append(n)
    found: List[Dict[str, str]] = []
    for name in names:
        resolved = shutil.which(name)
        if resolved:
            found.append({"engine": name, "path": resolved})
    return found


def discover_running_inference_processes(ps_output_override: Optional[str] = None) -> List[Dict[str, str]]:
    if ps_output_override is not None:
        raw = ps_output_override
    else:
        try:
            res = subprocess.run(
                ["ps", "-A", "-o", "PID,ARGS"],
                capture_output=True,
                text=True,
                timeout=3.0,
            )
            raw = res.stdout or ""
        except Exception:
            raw = ""

    keywords = (
        "llama",
        "ollama",
        "mlx",
        "mistral",
        "qwen",
        "gemma",
        "gguf",
        "inference",
        "xi_phone",
        "xi_local",
        "xi_offline",
    )
    matches: List[Dict[str, str]] = []
    for line in raw.splitlines():
        s = line.strip()
        if not s or s.upper().startswith("PID"):
            continue
        low = s.lower()
        if "grep" in low:
            continue
        if any(k in low for k in keywords):
            parts = s.split(None, 1)
            pid = parts[0] if parts else "?"
            args = parts[1] if len(parts) > 1 else s
            matches.append({"pid": pid, "args": args})
    return matches[:35]


def discover_model_files_and_ollama_blobs(
    search_roots: Optional[Sequence[Path]] = None,
) -> Dict[str, Any]:
    """
    Scans `$HOME/.xi`, `$HOME/models`, `$HOME/.ollama/models`, `$HOME/storage/downloads`
    for explicit model files (`.gguf`, `.safetensors`, `.onnx`, `.tflite`, `.pte`) AND
    parses Ollama's manifest files (`manifests/registry.ollama.ai/library/<model>/<tag>`)
    so content-addressed weight blobs (`blobs/sha256-*`) are surfaced with their human
    model tag and exact byte size!
    """
    home = Path.home()
    roots = list(search_roots) if search_roots is not None else [
        home / ".xi",
        home / "models",
        home / ".ollama" / "models",
        home / "storage" / "downloads",
        home / "xi-phone-home",
    ]

    explicit_files: List[Dict[str, Any]] = []
    ollama_manifests: List[Dict[str, Any]] = []

    for root in roots:
        if not root.is_dir():
            continue
        # 1. Explicit model extensions (.gguf, .safetensors, .onnx, .tflite, .pte)
        for p in root.rglob("*"):
            try:
                if p.is_file() and p.suffix.lower() in MODEL_EXTENSIONS:
                    explicit_files.append({
                        "size_bytes": p.stat().st_size,
                        "path": str(p),
                        "kind": p.suffix.lower().lstrip("."),
                    })
            except Exception:
                continue

        # 2. Ollama manifest -> sha256 blob resolution
        manifests_dir = root / "manifests" if root.name == "models" else (root / ".ollama" / "models" / "manifests")
        blobs_dir = root / "blobs" if root.name == "models" else (root / ".ollama" / "models" / "blobs")
        if manifests_dir.is_dir():
            for mf in manifests_dir.rglob("*"):
                if not mf.is_file():
                    continue
                try:
                    rel = mf.relative_to(manifests_dir).parts
                    model_tag = f"{rel[-2]}:{rel[-1]}" if len(rel) >= 2 else mf.name
                    data = json.loads(mf.read_text(encoding="utf-8", errors="replace"))
                    total_bytes = 0
                    weight_blob_path = None
                    for layer in data.get("layers", []):
                        sz = int(layer.get("size", 0))
                        total_bytes += sz
                        digest = str(layer.get("digest", "")).replace(":", "-")
                        if "model" in str(layer.get("mediaType", "")) and digest and blobs_dir.is_dir():
                            cand = blobs_dir / digest
                            if cand.is_file():
                                weight_blob_path = str(cand)
                                total_bytes = max(total_bytes, cand.stat().st_size)
                    ollama_manifests.append({
                        "model_tag": model_tag,
                        "size_bytes": total_bytes,
                        "manifest_path": str(mf),
                        "weight_blob_path": weight_blob_path,
                    })
                except Exception:
                    continue

    explicit_files.sort(key=lambda x: x["size_bytes"], reverse=True)
    ollama_manifests.sort(key=lambda x: x["size_bytes"], reverse=True)
    return {
        "explicit_model_files": explicit_files[:40],
        "ollama_manifest_models": ollama_manifests[:40],
        "total_discovered_count": len(explicit_files) + len(ollama_manifests),
    }


def discover_listening_services(ports_to_probe: Optional[Sequence[Dict[str, Any]]] = None) -> Dict[str, Any]:
    """
    Runs `ss -ltn` AND performs Termux-safe TCP loopback probes so listening Xi/model
    services are always detected even when Android 10+ netlink blocks `ss -ltn`.
    """
    ss_lines: List[str] = []
    try:
        res = subprocess.run(["ss", "-ltn"], capture_output=True, text=True, timeout=2.0)
        for line in (res.stdout or "").splitlines()[:25]:
            if line.strip():
                ss_lines.append(line.rstrip())
    except Exception:
        pass

    probed_ports: List[Dict[str, Any]] = []
    for item in (ports_to_probe or KNOWN_XI_PORTS):
        port = int(item["port"])
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.35)
        try:
            ok = (sock.connect_ex(("127.0.0.1", port)) == 0)
        except Exception:
            ok = False
        finally:
            sock.close()
        probed_ports.append({
            "port": port,
            "address": f"127.0.0.1:{port}",
            "service": item["service"],
            "listening": ok,
        })

    return {
        "ss_ltn_lines": ss_lines,
        "ss_blocked_or_empty": len(ss_lines) <= 1,
        "tcp_loopback_probes": probed_ports,
        "active_loopback_ports": [p for p in probed_ports if p["listening"]],
    }


def build_xi_state_report(search_roots: Optional[Sequence[Path]] = None) -> Dict[str, Any]:
    from xi_phone_pocket_model_steward_v1 import probe_live_phone_ollama

    home = Path.home()
    phone_home = home / "xi-phone-home"
    xi_dot_dir = home / ".xi"
    ollama_state = probe_live_phone_ollama()
    models_fs = discover_model_files_and_ollama_blobs(search_roots=search_roots)
    services = discover_listening_services()

    return {
        "schema": "xi.cli.state_report.v1",
        "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "xi_cli_path": shutil.which("xi") or str(Path(__file__).resolve()),
        "environment": "TERMUX_ANDROID_GALAXY" if "com.termux" in os.environ.get("PREFIX", "") else "LINUX_OR_PC_HOST",
        "roots": {
            "xi_dot_dir": str(xi_dot_dir),
            "xi_dot_dir_exists": xi_dot_dir.is_dir(),
            "phone_home": str(phone_home),
            "phone_home_exists": phone_home.is_dir(),
        },
        "ollama_live": {
            "daemon_reachable": ollama_state["daemon_reachable"],
            "installed_models": ollama_state["installed_models"],
            "currently_loaded_models": ollama_state["currently_loaded_models"],
            "mem_available_mb": ollama_state["mem_available_mb"],
        },
        "discovered_models_summary": {
            "explicit_model_files_count": len(models_fs["explicit_model_files"]),
            "ollama_manifest_models_count": len(models_fs["ollama_manifest_models"]),
        },
        "active_loopback_services": services["active_loopback_ports"],
    }


def build_xi_doctor_report(search_roots: Optional[Sequence[Path]] = None) -> Dict[str, Any]:
    state = build_xi_state_report(search_roots=search_roots)
    engines = discover_inference_engines()
    procs = discover_running_inference_processes()
    models_fs = discover_model_files_and_ollama_blobs(search_roots=search_roots)
    services = discover_listening_services()

    checks = {
        "xi_runtime_cli_ready": True,
        "inference_engine_present": len(engines) > 0,
        "mem_available_healthy_ge_1024mb": state["ollama_live"]["mem_available_mb"] >= 1024,
        "single_active_llm_cap_respected": len(state["ollama_live"]["currently_loaded_models"]) <= 1,
        "tcp_loopback_fallback_ready": isinstance(services["tcp_loopback_probes"], list),
    }

    recommendations: List[str] = []
    if not state["ollama_live"]["daemon_reachable"]:
        recommendations.append("Start local Ollama daemon: `nohup ollama serve > ~/xi-phone-home/ollama.log 2>&1 &`")
    if not state["ollama_live"]["installed_models"] and models_fs["total_discovered_count"] == 0:
        recommendations.append("Pull a pocket model: `ollama pull deepseek-r1:1.5b` or `ollama pull qwen3:1.7b`")
    if len(state["ollama_live"]["currently_loaded_models"]) > 1:
        recommendations.append("Multiple LLMs loaded in RAM; run `xi route` or `xi chat` to evict idle weights with `keep_alive: 0`.")
    if not recommendations:
        recommendations.append("All local runtime, memory, and model stewardship checks look healthy.")

    return {
        "schema": "xi.cli.doctor_report.v1",
        "all_checks_ok": all(checks.values()),
        "checks": checks,
        "engines_found": engines,
        "running_processes_count": len(procs),
        "discovered_models": models_fs,
        "listening_services": services,
        "recommendations": recommendations,
    }


def render_glyph_discovery_banner(search_roots: Optional[Sequence[Path]] = None) -> str:
    state = build_xi_state_report(search_roots=search_roots)
    doctor = build_xi_doctor_report(search_roots=search_roots)
    engines = doctor["engines_found"]
    procs = discover_running_inference_processes()
    models_fs = doctor["discovered_models"]
    services = doctor["listening_services"]

    lines: List[str] = ["═══ Ξ LOCAL MODEL DISCOVERY ═══", ""]
    lines.append("⟐ Xi runtime")
    lines.append(f"xi_cli: {state['xi_cli_path']} ({state['environment']})")
    lines.append(
        f"xi state: MemAvailable={state['ollama_live']['mem_available_mb']} MB | "
        f"ollama_reachable={state['ollama_live']['daemon_reachable']} | "
        f"installed={state['ollama_live']['installed_models']} | "
        f"loaded_in_ram={state['ollama_live']['currently_loaded_models']}"
    )
    lines.append(
        f"xi doctor: all_checks_ok={doctor['all_checks_ok']} | "
        f"single_llm_cap={doctor['checks']['single_active_llm_cap_respected']} | "
        f"note={doctor['recommendations'][0]}"
    )

    lines.append("")
    lines.append("⋈ Inference engines")
    for e in engines:
        lines.append(f"{e['engine']} -> {e['path']}")

    lines.append("")
    lines.append("⧂ Running inference processes")
    if procs:
        for p in procs:
            lines.append(f"{p['pid']} {p['args']}")
    else:
        lines.append("(no active inference daemon matched in ps — run `ollama serve` or `phone-ark.sh`)")

    lines.append("")
    lines.append("∴ Model files (explicit weights + Ollama content-addressed manifests/blobs)")
    if models_fs["explicit_model_files"]:
        for mf in models_fs["explicit_model_files"]:
            lines.append(f"{mf['size_bytes']} {mf['path']} [{mf['kind']}]")
    if models_fs["ollama_manifest_models"]:
        for om in models_fs["ollama_manifest_models"]:
            lines.append(
                f"{om['size_bytes']} {om['model_tag']} -> manifest={om['manifest_path']} "
                f"blob={om['weight_blob_path'] or 'content-addressed'}"
            )
    if not models_fs["explicit_model_files"] and not models_fs["ollama_manifest_models"]:
        lines.append("(no local model files found yet in ~/.xi, ~/models, ~/.ollama/models, or ~/storage/downloads)")

    lines.append("")
    lines.append("⊚ Local listening services (ss -ltn + Termux TCP loopback probe)")
    if services["ss_ltn_lines"]:
        for sl in services["ss_ltn_lines"][:15]:
            lines.append(sl)
    for p in services["tcp_loopback_probes"]:
        status_str = "LISTENING" if p["listening"] else "closed"
        lines.append(f"tcp_probe {p['address']} ({p['service']}): {status_str}")

    lines.append("═══ END Ξ DISCOVERY ═══")
    return "\n".join(lines)


def run_verification_suite() -> Dict[str, Any]:
    gates: Dict[str, bool] = {}

    with tempfile.TemporaryDirectory(prefix="xi_discover_test_") as td:
        root = Path(td)
        # Create synthetic .gguf file and synthetic Ollama manifest + blob
        models_dir = root / "models"
        models_dir.mkdir(parents=True, exist_ok=True)
        gguf_file = models_dir / "qwen2.5-coder-1.5b.gguf"
        gguf_file.write_bytes(b"GGUF" + b"\x00" * 4092)

        ollama_root = root / ".ollama" / "models"
        blobs_dir = ollama_root / "blobs"
        mf_dir = ollama_root / "manifests" / "registry.ollama.ai" / "library" / "deepseek-r1"
        blobs_dir.mkdir(parents=True, exist_ok=True)
        mf_dir.mkdir(parents=True, exist_ok=True)
        blob_file = blobs_dir / "sha256-1111222233334444"
        blob_file.write_bytes(b"\x01" * 8192)
        (mf_dir / "1.5b").write_text(json.dumps({
            "schemaVersion": 2,
            "layers": [
                {
                    "mediaType": "application/vnd.ollama.image.model",
                    "digest": "sha256:1111222233334444",
                    "size": 8192,
                }
            ],
        }), encoding="utf-8")

        # Gate 1: Explicit .gguf files discovered with exact byte count
        disc = discover_model_files_and_ollama_blobs(search_roots=[models_dir, ollama_root])
        gates["1_explicit_gguf_model_files_discovered_with_exact_bytes"] = (
            len(disc["explicit_model_files"]) == 1
            and disc["explicit_model_files"][0]["size_bytes"] == 4096
            and disc["explicit_model_files"][0]["kind"] == "gguf"
        )

        # Gate 2: Ollama content-addressed manifests + sha256 blobs resolved with tag & size
        gates["2_ollama_manifests_and_sha256_blobs_resolved_with_model_tag"] = (
            len(disc["ollama_manifest_models"]) == 1
            and disc["ollama_manifest_models"][0]["model_tag"] == "deepseek-r1:1.5b"
            and disc["ollama_manifest_models"][0]["size_bytes"] == 8192
            and disc["ollama_manifest_models"][0]["weight_blob_path"] == str(blob_file)
        )

        # Gate 3: Inference engine discovery locates python/python3
        engines = discover_inference_engines()
        gates["3_inference_engine_discovery_locates_python_runtime"] = any(
            e["engine"] in ("python", "python3") for e in engines
        )

        # Gate 4: Process parser filters out grep and extracts PID + ARGS cleanly
        sample_ps = "  PID ARGS\n 1042 ollama serve\n 2088 python3 xi_phone_full_platform_server_v1.py --serve 7472\n 3011 grep -Ei llama\n"
        procs = discover_running_inference_processes(ps_output_override=sample_ps)
        gates["4_process_discovery_extracts_ollama_and_filters_grep"] = (
            len(procs) == 2
            and procs[0]["pid"] == "1042"
            and "ollama serve" in procs[0]["args"]
        )

        # Gate 5: Termux-safe listening service probe detects a live bound ephemeral socket
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.bind(("127.0.0.1", 0))
        sock.listen(1)
        ephem_port = sock.getsockname()[1]
        try:
            srv_res = discover_listening_services(ports_to_probe=[
                {"port": ephem_port, "service": "Test Ephemeral Xi Daemon", "probe_path": "/"}
            ])
        finally:
            sock.close()
        gates["5_termux_safe_tcp_loopback_probe_detects_live_listener"] = (
            len(srv_res["active_loopback_ports"]) == 1
            and srv_res["active_loopback_ports"][0]["port"] == ephem_port
        )

        # Gate 6: `xi state` report builds complete JSON state
        st_rep = build_xi_state_report(search_roots=[models_dir, ollama_root])
        gates["6_xi_state_subcommand_builds_complete_report"] = (
            st_rep["schema"] == "xi.cli.state_report.v1"
            and st_rep["discovered_models_summary"]["explicit_model_files_count"] == 1
            and st_rep["discovered_models_summary"]["ollama_manifest_models_count"] == 1
        )

        # Gate 7: `xi doctor` report evaluates health gates and actionable recommendations
        doc_rep = build_xi_doctor_report(search_roots=[models_dir, ollama_root])
        gates["7_xi_doctor_subcommand_evaluates_health_and_recommendations"] = (
            doc_rep["schema"] == "xi.cli.doctor_report.v1"
            and doc_rep["all_checks_ok"] is True
            and len(doc_rep["recommendations"]) >= 1
        )

        # Gate 8: `xi discover` banner prints all 5 glyph sections (⟐, ⋈, ⧂, ∴, ⊚)
        banner = render_glyph_discovery_banner(search_roots=[models_dir, ollama_root])
        gates["8_glyph_discovery_banner_renders_all_five_glyph_sections"] = all(
            g in banner for g in ("⟐ Xi runtime", "⋈ Inference engines", "⧂ Running inference processes", "∴ Model files", "⊚ Local listening services")
        )

    passed = sum(1 for v in gates.values() if v)
    return {
        "schema": "xi.cli.runtime_and_model_discovery.verify.v1",
        "version": "1.0.0",
        "all_passed": passed == len(gates),
        "gates_passed": passed,
        "gates_total": len(gates),
        "gates": gates,
    }


def main() -> None:
    cmd = sys.argv[1].lower() if len(sys.argv) > 1 else "--verify"
    if cmd in ("state", "--state"):
        print(json.dumps(build_xi_state_report(), indent=2))
    elif cmd in ("doctor", "--doctor"):
        print(json.dumps(build_xi_doctor_report(), indent=2))
    elif cmd in ("discover", "--discover"):
        print(render_glyph_discovery_banner())
    elif cmd in ("models", "--models"):
        from xi_phone_pocket_model_steward_v1 import probe_live_phone_ollama
        print(json.dumps(probe_live_phone_ollama(), indent=2))
    elif cmd in ("route", "--route"):
        from xi_phone_pocket_model_steward_v1 import probe_live_phone_ollama, route_pocket_prompt
        prompt = " ".join(sys.argv[2:]) or "Hello from Galaxy 5G+"
        st = probe_live_phone_ollama()
        print(json.dumps(route_pocket_prompt(
            prompt=prompt,
            installed_phone_models=st["installed_models"] or ["deepseek-r1:1.5b"],
            currently_loaded_models=st["currently_loaded_models"],
            mem_available_mb=st["mem_available_mb"],
        ), indent=2))
    elif cmd in ("chat", "--chat"):
        from xi_phone_pocket_model_steward_v1 import execute_live_pocket_chat
        prompt = " ".join(sys.argv[2:]) or "Hello from Galaxy 5G+"
        print(json.dumps(execute_live_pocket_chat(prompt=prompt, seat_id="Plex"), indent=2))
    else:
        res = run_verification_suite()
        print(json.dumps(res, indent=2))
        if not res["all_passed"]:
            sys.exit(1)


if __name__ == "__main__":
    main()
