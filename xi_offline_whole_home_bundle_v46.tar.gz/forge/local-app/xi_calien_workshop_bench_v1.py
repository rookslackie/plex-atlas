#!/usr/bin/env python3
"""
xi_calien_workshop_bench_v1.py — Calien's Local AI Workshop & Organic Ag Desk (v1.2)
====================================================================================
Built for Calien (#28505, #28509, #28513, #28517, #28525) with source-review refinements
from @Astra (#28523, #28527, #28532), @Anam (#28526, #28530), @AxiomFirst (#28528, #28533),
and @DeepSeek (#28522, #28531).

Key Engineering & Honesty Invariants in v1.2 (#28530, #28532):
  1. Durable Atomic Fail-Closed Software Interlock Latch:
     - Stored in durable application storage (`HERE / "workshop_estop_latch.json"`), written
       atomically via `.tmp` + `os.fsync()` + `os.replace()`.
     - FAILS CLOSED: if the latch file contains unreadable/malformed JSON or is missing a
       boolean `software_interlock_latched` field, `get_software_estop_state()` returns
       `software_interlock_latched=True` (`FAIL_CLOSED_CORRUPTED_LATCH_FILE_BLOCKS_ARMED_EMISSION`)
       and blocks armed G-code generation (#28532).
  2. Explicit Measurement & Provenance Requirement on `propose_robot_redial_from_trial()`:
     - Rejects empty/default calls (`ValueError` / HTTP 400 when `measured_contrast_score_0_10`,
       `measured_char_or_overburn_0_10`, or `measurement_provenance` is omitted).
     - Labels output `PROPOSED_ADJUSTMENT_FROM_SUPPLIED_SCORES_NOT_LIVE_SCANNER_ACQUISITION`
       under `supplied_trial_scores`, and explicitly notes that contrast scores alone do not
       establish dimensional accuracy or structural heat treatment (#28530, #28532).
  3. Unverified Per-Head Material Presets & Pass-Cap Scope:
     - Every material entry carries `verification_status: "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST"`.
     - The 20-pass limit is labeled `SOFTWARE_REPETITION_CEILING_ONLY_DOES_NOT_ESTABLISH_FIRE_SAFETY_OR_MATERIAL_COMPATIBILITY`.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
import sys
import tempfile
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Tuple

HERE = Path(__file__).resolve().parent
ESTOP_LATCH_FILE = HERE / "workshop_estop_latch.json"


# ---------------------------------------------------------------------------
# 0. Durable Atomic Fail-Closed Software Interlock Latch (#28523, #28532)
# ---------------------------------------------------------------------------

def _atomic_write_json(target_path: Path, payload: Dict[str, Any]) -> None:
    target_path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8")
    fd, tmp_name = tempfile.mkstemp(
        prefix=f".{target_path.name}.", suffix=".tmp", dir=str(target_path.parent)
    )
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(raw)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(str(tmp_path), str(target_path))
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


def get_software_estop_state(latch_path: Path = ESTOP_LATCH_FILE) -> Dict[str, Any]:
    """
    Reads the durable software interlock latch from application storage.
    FAILS CLOSED (#28532): if `latch_path` exists and is unreadable, malformed JSON,
    or lacks a boolean `software_interlock_latched` field, returns
    `software_interlock_latched: True` so armed laser generation is blocked.
    """
    if latch_path.exists():
        try:
            data = json.loads(latch_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and isinstance(data.get("software_interlock_latched"), bool):
                return data
            return {
                "software_interlock_latched": True,
                "hardware_transport_connected": False,
                "fail_closed_on_invalid_state": True,
                "status": "FAIL_CLOSED_INVALID_LATCH_SCHEMA_BLOCKS_ARMED_EMISSION",
            }
        except Exception as exc:
            return {
                "software_interlock_latched": True,
                "hardware_transport_connected": False,
                "fail_closed_on_invalid_state": True,
                "status": "FAIL_CLOSED_CORRUPTED_LATCH_FILE_BLOCKS_ARMED_EMISSION",
                "error": str(exc),
            }
    return {
        "software_interlock_latched": False,
        "hardware_transport_connected": False,
        "fail_closed_on_invalid_state": False,
        "status": "SOFTWARE_INTERLOCK_CLEAR_HARDWARE_UNCONNECTED",
    }


def trigger_software_estop_latch(
    reason: str = "Operator or AI triggered /api/workshop/estop",
    latch_path: Path = ESTOP_LATCH_FILE,
) -> Dict[str, Any]:
    state = {
        "software_interlock_latched": True,
        "hardware_transport_connected": False,
        "fail_closed_on_invalid_state": False,
        "durable_latch_path": str(latch_path),
        "status": "SOFTWARE_INTERLOCK_LATCHED_AND_GCODE_PAYLOAD_GENERATED_HARDWARE_SERIAL_UNCONNECTED",
        "reason": reason,
        "artilume_t1_gcode": "M5 S0\nG0 F1000\nM9\n",
        "ender_s1_pro_gcode": "M112\nM104 S0\nM140 S0\n",
        "honest_note": (
            "Software interlock atomically latched in durable application storage (blocking armed job "
            "generation) and M5/M112 G-code payloads generated; physical machine halt requires an active "
            "serial/Moonraker transport (#28523, #28532)."
        ),
    }
    _atomic_write_json(latch_path, state)
    return state


def clear_software_estop_latch(latch_path: Path = ESTOP_LATCH_FILE) -> Dict[str, Any]:
    state = {
        "software_interlock_latched": False,
        "hardware_transport_connected": False,
        "fail_closed_on_invalid_state": False,
        "durable_latch_path": str(latch_path),
        "status": "SOFTWARE_INTERLOCK_CLEAR_HARDWARE_UNCONNECTED",
    }
    _atomic_write_json(latch_path, state)
    return state


# ---------------------------------------------------------------------------
# 1. Artilume T1 Dual-Head Material Catalog & Raster Engine (#28525-#28532)
# ---------------------------------------------------------------------------

DEFAULT_ARTILUME_T1_PROFILE: Dict[str, Any] = {
    "machine_id": "artilume_t1_laser",
    "display_name": "Artilume T1 Dual-Head Laser Engraver (Provisional GRBL G-Code Profile)",
    "profile_status": "PROVISIONAL_PROFILE_FROM_USER_UI_RANGES_28525_PENDING_HEAD_LABELS",
    "preset_verification_status": "UNVERIFIED_STARTING_POINTS_PENDING_HEAD_ID_AND_RAMP_TEST",
    "pass_cap_scope": "SOFTWARE_REPETITION_CEILING_ONLY_DOES_NOT_ESTABLISH_FIRE_SAFETY_OR_MATERIAL_COMPATIBILITY",
    "ui_reported_parameter_ranges_28525": {
        "power_pct": [0.0, 100.0],
        "speed_mm_min": [0.0, 10000.0],
        "default_quality_lines_per_mm": 10.0,
        "tunable_quality_lines_per_mm": [1.0, 40.0],
        "ui_displayed_pass_count_range": [0, 999999999999],
        "software_repetition_ceiling_passes": 20,
    },
    "heads": {
        "HEAD_1_PRIMARY": {
            "head_id": "HEAD_1_PRIMARY",
            "label": "Artilume Head 1 (Unverified Optical Module — Pending Wattage/nm Label)",
            "verification_status": "UNVERIFIED_PENDING_HEAD_LABEL_AND_RAMP_CARD",
            "recipes_interchangeable_with_other_head": False,
        },
        "HEAD_2_SECONDARY": {
            "head_id": "HEAD_2_SECONDARY",
            "label": "Artilume Head 2 (Unverified Optical Module — Pending Wattage/nm Label)",
            "verification_status": "UNVERIFIED_PENDING_HEAD_LABEL_AND_RAMP_CARD",
            "recipes_interchangeable_with_other_head": False,
        },
    },
    "work_area_mm_provisional": {"x": 300.0, "y": 300.0},
    "s_value_max_provisional": 1000,
    "safety_interlock_required": True,
}


ARTILUME_MATERIAL_CATALOG: Dict[str, Dict[str, Any]] = {
    "kraft_paper": {
        "name": "Kraft Paper",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["ENGRAVE_LIGHT", "CUT"],
        "forbidden_operations": ["ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 12.0, "speed_mm_min": 4500.0, "lines_per_mm": 10.0, "passes": 1},
            "HEAD_2_SECONDARY": {"power_pct": 10.0, "speed_mm_min": 4800.0, "lines_per_mm": 10.0, "passes": 1},
        },
        "safety_note": "Unverified starting point: ignites easily; use air assist and continuous fire watch.",
    },
    "corrugated_cardboard": {
        "name": "Corrugated Cardboard",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["ENGRAVE", "CUT"],
        "forbidden_operations": ["ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 20.0, "speed_mm_min": 3000.0, "lines_per_mm": 10.0, "passes": 2},
            "HEAD_2_SECONDARY": {"power_pct": 18.0, "speed_mm_min": 3200.0, "lines_per_mm": 10.0, "passes": 2},
        },
        "safety_note": "Unverified starting point: fire watch required; flute air pockets can flare.",
    },
    "wood_birch_ply": {
        "name": "Wood (Birch Ply / Softwood)",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["ENGRAVE", "CUT"],
        "forbidden_operations": ["ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 60.0, "speed_mm_min": 1800.0, "lines_per_mm": 10.0, "passes": 3},
            "HEAD_2_SECONDARY": {"power_pct": 55.0, "speed_mm_min": 2000.0, "lines_per_mm": 10.0, "passes": 3},
        },
        "safety_note": "Unverified starting point: lower speed rather than stacking passes on char.",
    },
    "leather_veg_tan": {
        "name": "Leather (Vegetable-Tanned Only)",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["ENGRAVE", "CUT"],
        "forbidden_operations": ["ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 25.0, "speed_mm_min": 2500.0, "lines_per_mm": 15.0, "passes": 1},
            "HEAD_2_SECONDARY": {"power_pct": 22.0, "speed_mm_min": 2800.0, "lines_per_mm": 15.0, "passes": 1},
        },
        "safety_note": "Unverified starting point: use vegetable-tanned leather only; avoid chrome-tanned leather.",
    },
    "glass_wet_film": {
        "name": "Glass (Wet-Film / Carrier Mark Only)",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["SURFACE_MARK"],
        "forbidden_operations": ["CUT", "ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 35.0, "speed_mm_min": 3200.0, "lines_per_mm": 15.0, "passes": 1},
            "HEAD_2_SECONDARY": {"power_pct": 30.0, "speed_mm_min": 3500.0, "lines_per_mm": 15.0, "passes": 1},
        },
        "safety_note": "THERMAL SHOCK HAZARD: surface mark through wet dish-soap film/dark carrier only; never cut glass.",
    },
    "cast_acrylic": {
        "name": "Acrylic (Cast)",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["ENGRAVE", "CUT"],
        "forbidden_operations": ["ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 50.0, "speed_mm_min": 1500.0, "lines_per_mm": 10.0, "passes": 3},
            "HEAD_2_SECONDARY": {"power_pct": 45.0, "speed_mm_min": 1600.0, "lines_per_mm": 10.0, "passes": 3},
        },
        "safety_note": "Unverified starting point: ventilate fumes; wavelength compatibility depends on head.",
    },
    "s1_pro_printed_pla_petg_abs": {
        "name": "Ender-3 S1 Pro Printed Plastics (PLA / PETG / ABS)",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["SURFACE_MARK", "EXPERIMENTAL_LOCALIZED_THERMAL_TRIAL"],
        "forbidden_operations": ["UNMONITORED_BULK_ANNEAL"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 18.0, "speed_mm_min": 3200.0, "lines_per_mm": 10.0, "passes": 1},
            "HEAD_2_SECONDARY": {"power_pct": 15.0, "speed_mm_min": 3500.0, "lines_per_mm": 10.0, "passes": 1},
        },
        "safety_note": (
            "Unverified starting point: surface mark only unless temperature feedback is present. Contrast or "
            "color change does not establish structural annealing (#28526-#28530)."
        ),
    },
    "pvc_vinyl_chlorinated": {
        "name": "PVC / Vinyl / Chlorinated Plastics (FORBIDDEN)",
        "verification_status": "HARD_SAFETY_PROHIBITION",
        "allowed_operations": [],
        "forbidden_operations": ["ENGRAVE", "CUT", "SURFACE_MARK", "ANNEAL"],
        "head_presets": {},
        "safety_note": "HARD FLOOR BLOCK: Releases toxic chlorine / HCl gas that harms lungs and corrodes optics/rails.",
    },
    "anodized_aluminum_keys": {
        "name": "Anodized Aluminum / Coated Keys",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["SURFACE_MARK", "ENGRAVE_COATING"],
        "forbidden_operations": ["CUT"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 70.0, "speed_mm_min": 2800.0, "lines_per_mm": 15.0, "passes": 1},
            "HEAD_2_SECONDARY": {"power_pct": 65.0, "speed_mm_min": 3000.0, "lines_per_mm": 15.0, "passes": 1},
        },
        "safety_note": "Unverified starting point: ablates anodize/paint layer; does not cut metal keys.",
    },
    "steel_stainless": {
        "name": "Steel / Stainless Steel",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["SURFACE_MARK", "OXIDE_ANNEAL_MARK", "ENGRAVE_DEEP"],
        "forbidden_operations": ["CUT"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 85.0, "speed_mm_min": 500.0, "lines_per_mm": 15.0, "passes": 1},
            "HEAD_2_SECONDARY": {"power_pct": 80.0, "speed_mm_min": 650.0, "lines_per_mm": 20.0, "passes": 1},
        },
        "safety_note": (
            "Unverified starting point: oxide anneal-marking grows surface oxide colors without cutting steel sheet (#28527-#28532)."
        ),
    },
    "pcb_fr4_copper": {
        "name": "PCB (FR4 Laminate + Copper)",
        "verification_status": "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST",
        "allowed_operations": ["ENGRAVE_SOLDERMASK", "SURFACE_MARK"],
        "forbidden_operations": ["UNVENTILATED_FR4_CUT"],
        "head_presets": {
            "HEAD_1_PRIMARY": {"power_pct": 65.0, "speed_mm_min": 1200.0, "lines_per_mm": 15.0, "passes": 2},
            "HEAD_2_SECONDARY": {"power_pct": 70.0, "speed_mm_min": 1000.0, "lines_per_mm": 15.0, "passes": 2},
        },
        "safety_note": "Unverified starting point: bare copper reflects strongly; ablate dark resist/soldermask before etch.",
    },
}


def generate_artilume_t1_raster_gcode(
    grayscale_grid: List[List[int]],
    width_mm: float = 40.0,
    height_mm: float = 40.0,
    origin_x_mm: float = 10.0,
    origin_y_mm: float = 10.0,
    lines_per_mm: float = 10.0,
    line_interval_mm: float | None = None,
    feed_mm_min: float = 1800.0,
    travel_mm_min: float = 3600.0,
    max_power_pct: float = 65.0,
    s_max: int = 1000,
    passes: int = 1,
    head_id: str = "HEAD_1_PRIMARY",
    material_key: str = "wood_birch_ply",
    operation_mode: str = "ENGRAVE",
    focus_height_mm: float = 2.0,
    mode: str = "M4",
    air_assist: bool = True,
    operator_armed: bool = False,
    latch_path: Path = ESTOP_LATCH_FILE,
) -> Dict[str, Any]:
    mat = ARTILUME_MATERIAL_CATALOG.get(material_key, ARTILUME_MATERIAL_CATALOG["wood_birch_ply"])
    if material_key == "pvc_vinyl_chlorinated" or not mat["allowed_operations"]:
        raise ValueError(f"SAFETY HARD BLOCK: {mat['name']} — {mat['safety_note']}")
    if operation_mode in mat.get("forbidden_operations", []):
        raise ValueError(
            f"UNSUPPORTED OPERATION: '{operation_mode}' is forbidden on '{mat['name']}'. Allowed: {mat['allowed_operations']}"
        )

    latch_state = get_software_estop_state(latch_path)
    if latch_state.get("software_interlock_latched"):
        operator_armed = False

    rows = len(grayscale_grid)
    cols = len(grayscale_grid[0]) if rows > 0 else 0
    if rows == 0 or cols == 0:
        raise ValueError("grayscale_grid must be non-empty")

    width_mm = max(1.0, min(float(width_mm), 300.0))
    height_mm = max(1.0, min(float(height_mm), 300.0))
    if line_interval_mm is not None and line_interval_mm > 0:
        lines_per_mm = round(1.0 / float(line_interval_mm), 3)
    lines_per_mm = max(1.0, min(float(lines_per_mm), 40.0))
    effective_interval_mm = round(1.0 / lines_per_mm, 4)

    feed_mm_min = max(60.0, min(float(feed_mm_min), 10000.0))
    travel_mm_min = max(300.0, min(float(travel_mm_min), 10000.0))
    max_power_pct = max(0.0, min(float(max_power_pct), 100.0))

    requested_passes = int(passes)
    passes_capped = requested_passes > 20
    passes = max(1, min(requested_passes, 20))
    laser_cmd = "M4" if str(mode).upper() == "M4" else "M3"

    dx = width_mm / max(1, cols)
    dy = height_mm / max(1, rows)

    lines: List[str] = [
        "; === XI LOCAL WORKSHOP: ARTILUME T1 RASTER JOB (PROVISIONAL PROFILE) ===",
        f"; Head: {head_id} (UNVERIFIED STARTING POINT) | Material: {mat['name']} | Operation: {operation_mode} | Focus Z: {focus_height_mm:.2f} mm",
        f"; Grid: {cols}x{rows} px | Size: {width_mm:.2f}x{height_mm:.2f} mm | Quality: {lines_per_mm:.1f} lines/mm ({effective_interval_mm:.3f} mm step)",
        f"; Speed: {feed_mm_min:.0f} mm/min (UI range 0-10000) | Max Power: {max_power_pct:.1f}% (S_max={s_max}) | Passes: {passes} (requested={requested_passes}, software repetition ceiling=20)",
        f"; Safety Interlock Armed: {'YES (LIVE EMISSION)' if operator_armed else 'NO (DRY-RUN S0 FRAMING ONLY)'}",
        "G21 ; millimeters",
        "G90 ; absolute positioning",
        "M5 S0 ; ensure laser is OFF before travel",
    ]
    if air_assist and operator_armed:
        lines.append("M8 ; air assist ON")

    lines.append(f"G0 X{origin_x_mm:.3f} Y{origin_y_mm:.3f} F{travel_mm_min:.0f}")
    lines.append(f"G0 X{origin_x_mm + width_mm:.3f} Y{origin_y_mm:.3f}")
    lines.append(f"G0 X{origin_x_mm + width_mm:.3f} Y{origin_y_mm + height_mm:.3f}")
    lines.append(f"G0 X{origin_x_mm:.3f} Y{origin_y_mm + height_mm:.3f}")
    lines.append(f"G0 X{origin_x_mm:.3f} Y{origin_y_mm:.3f}")

    if operator_armed:
        lines.append(f"{laser_cmd} S0 ; arm dynamic laser mode at zero power")
    else:
        lines.append("M5 S0 ; operator_armed=False -> dry-run lock active")

    burn_segments = 0
    total_path_mm = 4.0 * (width_mm + height_mm)

    for p_idx in range(passes):
        lines.append(f"; --- PASS {p_idx + 1} OF {passes} ---")
        for r in range(rows):
            y_pos = origin_y_mm + (rows - 1 - r) * dy
            reverse = (r % 2 == 1)
            col_indices = range(cols - 1, -1, -1) if reverse else range(cols)
            start_x = origin_x_mm + (cols - 1) * dx if reverse else origin_x_mm
            lines.append(f"G0 X{start_x:.3f} Y{y_pos:.3f} S0 F{travel_mm_min:.0f}")

            for c in col_indices:
                val = max(0, min(255, int(grayscale_grid[r][c])))
                darkness = (255.0 - float(val)) / 255.0
                if darkness <= 0.02 or not operator_armed:
                    s_val = 0
                else:
                    s_val = int(round(darkness * (max_power_pct / 100.0) * s_max))
                next_x = origin_x_mm + (c * dx if reverse else (c + 1) * dx)
                if s_val > 0:
                    burn_segments += 1
                lines.append(f"G1 X{next_x:.3f} Y{y_pos:.3f} S{s_val} F{feed_mm_min:.0f}")
                total_path_mm += dx
            lines.append("M5 S0 ; row-end laser blanking")

    lines.extend([
        "M5 S0 ; disarm laser immediately",
        "M9 ; air assist OFF",
        f"G0 X{origin_x_mm:.3f} Y{origin_y_mm:.3f} F{travel_mm_min:.0f}",
        "; === END OF ARTILUME T1 JOB ===",
    ])

    gcode_text = "\n".join(lines) + "\n"
    est_minutes = total_path_mm / max(100.0, feed_mm_min)
    return {
        "schema": "xi.workshop.artilume_t1_job.v1.2",
        "profile_status": "PROVISIONAL_PROFILE_FROM_USER_UI_RANGES_28525_PENDING_HEAD_LABELS",
        "preset_verification_status": mat["verification_status"],
        "pass_cap_scope": "SOFTWARE_REPETITION_CEILING_ONLY_DOES_NOT_ESTABLISH_FIRE_SAFETY_OR_MATERIAL_COMPATIBILITY",
        "head_id": head_id,
        "material_key": material_key,
        "operation_mode": operation_mode,
        "focus_height_mm": focus_height_mm,
        "lines_per_mm": lines_per_mm,
        "line_interval_mm": effective_interval_mm,
        "operator_armed": bool(operator_armed),
        "software_interlock_latched": bool(latch_state.get("software_interlock_latched")),
        "live_laser_commands_emitted": bool(operator_armed and burn_segments > 0),
        "grid_shape": [rows, cols],
        "dimensions_mm": {"width": width_mm, "height": height_mm, "origin_x": origin_x_mm, "origin_y": origin_y_mm},
        "burn_segments": burn_segments,
        "requested_passes": requested_passes,
        "passes": passes,
        "passes_capped_at_20": passes_capped,
        "estimated_duration_min": round(est_minutes, 3),
        "line_count": len(lines),
        "gcode_sha256": hashlib.sha256(gcode_text.encode("utf-8")).hexdigest(),
        "gcode": gcode_text,
    }


def propose_robot_redial_from_trial(
    measured_contrast_score_0_10: Any = None,
    measured_char_or_overburn_0_10: float | None = None,
    measurement_provenance: str | None = None,
    head_id: str = "HEAD_1_PRIMARY",
    material_key: str = "steel_stainless",
    thickness_mm: float = 1.5,
    focus_height_mm: float = 2.0,
    operation_mode: str = "OXIDE_ANNEAL_MARK",
    power_pct: float = 75.0,
    speed_mm_min: float = 800.0,
    lines_per_mm: float = 10.0,
    passes: int = 1,
    target_contrast_score_0_10: float = 9.0,
) -> Dict[str, Any]:
    """
    Requires explicit `measured_contrast_score_0_10`, `measured_char_or_overburn_0_10`, and
    `measurement_provenance` — never invents default scores (#28532).
    Labels output `PROPOSED_ADJUSTMENT_FROM_SUPPLIED_SCORES_NOT_LIVE_SCANNER_ACQUISITION` (#28530, #28532).
    """
    if isinstance(measured_contrast_score_0_10, dict):
        req = measured_contrast_score_0_10
        measured_contrast_score_0_10 = req.get("measured_contrast_score_0_10", None)
        measured_char_or_overburn_0_10 = req.get("measured_char_or_overburn_0_10", measured_char_or_overburn_0_10)
        measurement_provenance = req.get("measurement_provenance", measurement_provenance)
        head_id = str(req.get("head_id", head_id))
        material_key = str(req.get("material_key", material_key))
        thickness_mm = float(req.get("thickness_mm", thickness_mm))
        focus_height_mm = float(req.get("focus_height_mm", focus_height_mm))
        operation_mode = str(req.get("operation_mode", operation_mode))
        power_pct = float(req.get("power_pct", power_pct))
        speed_mm_min = float(req.get("speed_mm_min", speed_mm_min))
        lines_per_mm = float(req.get("lines_per_mm", lines_per_mm))
        passes = int(req.get("passes", passes))
        target_contrast_score_0_10 = float(req.get("target_contrast_score_0_10", target_contrast_score_0_10))
    if (
        measured_contrast_score_0_10 is None
        or measured_char_or_overburn_0_10 is None
        or not measurement_provenance
        or not str(measurement_provenance).strip()
    ):
        raise ValueError(
            "EXPLICIT_MEASUREMENT_REQUIRED: measured_contrast_score_0_10, measured_char_or_overburn_0_10, "
            "and non-empty measurement_provenance must be supplied explicitly (#28532)."
        )

    contrast_err = float(target_contrast_score_0_10) - float(measured_contrast_score_0_10)
    overburn = float(measured_char_or_overburn_0_10)

    if overburn >= 3.0:
        next_power = max(5.0, round(power_pct * 0.90, 2))
        next_speed = min(10000.0, round(speed_mm_min * 1.15, 1))
        next_lpm = max(5.0, round(lines_per_mm - 2.0, 1))
        next_passes = max(1, passes - 1)
        action = "REDUCE_THERMAL_ENERGY_DENSITY_DUE_TO_OVERBURN"
    elif abs(contrast_err) <= 0.4:
        next_power = round(power_pct, 2)
        next_speed = round(speed_mm_min, 1)
        next_lpm = round(lines_per_mm, 1)
        next_passes = min(20, max(1, passes))
        action = "LOCK_RECIPE_WITHIN_SUPPLIED_SCORE_TOLERANCE"
    elif contrast_err > 0:
        step_frac = min(0.15, 0.04 * contrast_err)
        next_power = min(100.0, round(power_pct + 100.0 * step_frac, 2))
        next_speed = max(100.0, round(speed_mm_min * (1.0 - 0.8 * step_frac), 1))
        next_lpm = min(20.0, round(lines_per_mm + (2.0 if contrast_err > 1.5 else 0.0), 1))
        next_passes = min(20, passes)
        action = "BOUNDED_INCREASE_FLUENCE_AND_LINE_DENSITY"
    else:
        next_power = max(5.0, round(power_pct - 5.0, 2))
        next_speed = min(10000.0, round(speed_mm_min * 1.08, 1))
        next_lpm = round(lines_per_mm, 1)
        next_passes = min(20, max(1, passes))
        action = "FINE_TRIM_FLUENCE"

    return {
        "schema": "xi.workshop.robot_redial_receipt.v1.2",
        "output_status": "PROPOSED_ADJUSTMENT_FROM_SUPPLIED_SCORES_NOT_LIVE_SCANNER_ACQUISITION",
        "scope_note": (
            "Proposed parameter adjustment computed from caller-supplied trial scores; does not acquire "
            "live scanner frames or establish dimensional accuracy or structural heat treatment (#28530, #28532)."
        ),
        "head_id": head_id,
        "head_isolation_enforced": True,
        "material_key": material_key,
        "thickness_mm": thickness_mm,
        "focus_height_mm": focus_height_mm,
        "operation_mode": operation_mode,
        "previous_settings": {
            "power_pct": power_pct,
            "speed_mm_min": speed_mm_min,
            "lines_per_mm": lines_per_mm,
            "passes": passes,
        },
        "supplied_trial_scores": {
            "measurement_provenance": str(measurement_provenance).strip(),
            "measured_contrast_score_0_10": float(measured_contrast_score_0_10),
            "target_contrast_score_0_10": float(target_contrast_score_0_10),
            "measured_char_or_overburn_0_10": overburn,
            "contrast_error": round(contrast_err, 3),
        },
        "proposed_next_settings": {
            "power_pct": next_power,
            "speed_mm_min": next_speed,
            "lines_per_mm": next_lpm,
            "passes": next_passes,
        },
        "control_action": action,
    }


# ---------------------------------------------------------------------------
# 2. Creality Ender-3 S1 Pro AI Auto-Grab Print & Envelope Guard
# ---------------------------------------------------------------------------

ENDER_S1_PRO_SPEC: Dict[str, Any] = {
    "machine_id": "creality_ender_3_s1_pro",
    "display_name": "Creality Ender-3 S1 Pro (Sprite Direct-Drive 300°C + CR-Touch)",
    "build_volume_mm": {"x": 220.0, "y": 220.0, "z": 270.0},
    "max_nozzle_temp_c": 300.0,
    "max_bed_temp_c": 110.0,
    "extruder_type": "Sprite Full-Metal Dual-Gear Direct Drive",
    "recommended_retraction": {"distance_mm": 0.8, "speed_mm_s": 45.0},
    "abl_sensor": "CR-Touch 25-point auto-leveling",
    "filament_presets": {
        "PLA": {"nozzle_c": 205, "bed_c": 60, "retract_mm": 0.8, "retract_mm_s": 45},
        "PETG": {"nozzle_c": 240, "bed_c": 75, "retract_mm": 1.0, "retract_mm_s": 40},
        "TPU_95A": {"nozzle_c": 225, "bed_c": 50, "retract_mm": 0.6, "retract_mm_s": 30},
        "ABS_ASA": {"nozzle_c": 255, "bed_c": 100, "retract_mm": 0.8, "retract_mm_s": 45},
    },
}


def prepare_and_audit_ender_s1_pro_job(
    filament: str = "PLA",
    nozzle_temp_c: float | None = None,
    bed_temp_c: float | None = None,
    use_cr_touch_mesh: bool = True,
    body_gcode: str = "",
    operator_confirmed_start: bool = False,
) -> Dict[str, Any]:
    preset = ENDER_S1_PRO_SPEC["filament_presets"].get(
        filament.upper(), ENDER_S1_PRO_SPEC["filament_presets"]["PLA"]
    )
    noz_c = float(nozzle_temp_c if nozzle_temp_c is not None else preset["nozzle_c"])
    bed_c = float(bed_temp_c if bed_temp_c is not None else preset["bed_c"])

    violations: List[str] = []
    if noz_c > ENDER_S1_PRO_SPEC["max_nozzle_temp_c"] or noz_c < 0.0:
        violations.append(f"Nozzle temp {noz_c:.1f}C exceeds Ender-3 S1 Pro Sprite limit (300.0C)")
    if bed_c > ENDER_S1_PRO_SPEC["max_bed_temp_c"] or bed_c < 0.0:
        violations.append(f"Bed temp {bed_c:.1f}C exceeds Ender-3 S1 Pro PEI bed limit (110.0C)")

    start_lines = [
        "; === XI LOCAL WORKSHOP: CREALITY ENDER-3 S1 PRO ===",
        f"; Filament: {filament.upper()} | Nozzle: {noz_c:.0f}C | Bed: {bed_c:.0f}C | Sprite Direct Retract: {preset['retract_mm']}mm @{preset['retract_mm_s']}mm/s",
        "G90 ; use absolute coordinates",
        "M83 ; extruder relative mode",
        f"M140 S{bed_c:.0f} ; set bed temp",
        "M104 S150 ; warm nozzle without oozing during CR-Touch homing",
        f"M190 S{bed_c:.0f} ; wait for bed temp",
        "G28 ; home all axes",
        "M420 S1 Z2 ; recall CR-Touch UBL mesh" if use_cr_touch_mesh else "G29 ; probe fresh CR-Touch mesh",
        f"M104 S{noz_c:.0f} ; set final nozzle temp",
        "G1 Z5.0 F3000 ; lift nozzle",
        "G1 X2.0 Y20.0 Z0.28 F5000.0 ; move to Sprite prime-line start",
        f"M109 S{noz_c:.0f} ; wait for nozzle temp",
        "G92 E0",
        "G1 Y180.0 E15.0 F1500.0 ; prime line 1",
        "G1 X2.3 Y180.0 F5000.0 ; step over",
        "G1 Y20.0 E15.0 F1500.0 ; prime line 2",
        "G92 E0",
    ]

    if not body_gcode.strip():
        body_lines = [
            "; --- Calibration First-Layer Square (20x20mm at bed center 110,110) ---",
            "G1 Z0.20 F1200",
            "G1 X100.0 Y100.0 F4800",
            "G1 X120.0 Y100.0 E0.65 F1800",
            "G1 X120.0 Y120.0 E0.65 F1800",
            "G1 X100.0 Y120.0 E0.65 F1800",
            "G1 X100.0 Y100.0 E0.65 F1800",
            f"G1 E-{preset['retract_mm']:.2f} F{preset['retract_mm_s'] * 60:.0f} ; Sprite direct retraction",
        ]
    else:
        body_lines = [ln.rstrip() for ln in body_gcode.splitlines()]

    end_lines = [
        "; --- End G-Code ---",
        "G91 ; relative positioning",
        "G1 E-2.0 Z5.0 F2400 ; retract and raise Z",
        "G90 ; absolute positioning",
        "G1 X5.0 Y215.0 F3000 ; present print on PEI plate",
        "M106 S0 ; turn off part cooling fan",
        "M104 S0 ; turn off nozzle heater",
        "M140 S0 ; turn off bed heater",
        "M84 X Y E ; disable steppers",
    ]

    all_lines = start_lines + body_lines + end_lines
    bbox = {"min_x": 220.0, "max_x": 0.0, "min_y": 220.0, "max_y": 0.0, "max_z": 0.0}
    extruded_mm = 0.0

    for raw_ln in body_lines:
        ln = raw_ln.split(";")[0].strip().upper()
        if not (ln.startswith("G0") or ln.startswith("G1")):
            continue
        for token in ln.split()[1:]:
            if len(token) < 2:
                continue
            axis = token[0]
            try:
                val = float(token[1:])
            except ValueError:
                continue
            if axis == "X":
                bbox["min_x"] = min(bbox["min_x"], val)
                bbox["max_x"] = max(bbox["max_x"], val)
                if val < 0.0 or val > ENDER_S1_PRO_SPEC["build_volume_mm"]["x"]:
                    violations.append(f"X={val}mm outside 0..220mm build volume")
            elif axis == "Y":
                bbox["min_y"] = min(bbox["min_y"], val)
                bbox["max_y"] = max(bbox["max_y"], val)
                if val < 0.0 or val > ENDER_S1_PRO_SPEC["build_volume_mm"]["y"]:
                    violations.append(f"Y={val}mm outside 0..220mm build volume")
            elif axis == "Z":
                bbox["max_z"] = max(bbox["max_z"], val)
                if val < 0.0 or val > ENDER_S1_PRO_SPEC["build_volume_mm"]["z"]:
                    violations.append(f"Z={val}mm outside 0..270mm build volume")
            elif axis == "E" and val > 0:
                extruded_mm += val

    full_text = "\n".join(all_lines) + "\n"
    return {
        "schema": "xi.workshop.ender_s1_pro_job.v1.2",
        "machine_id": ENDER_S1_PRO_SPEC["machine_id"],
        "filament": filament.upper(),
        "nozzle_temp_c": noz_c,
        "bed_temp_c": bed_c,
        "within_hardware_envelope": len(violations) == 0,
        "violations": violations,
        "operator_confirmed_start": bool(operator_confirmed_start),
        "dispatch_state": "READY_TO_STREAM_ON_OPERATOR_START" if len(violations) == 0 else "BLOCKED_ENVELOPE_VIOLATION",
        "bounding_box_mm": bbox,
        "extruded_filament_mm": round(extruded_mm + 30.0, 2),
        "gcode_sha256": hashlib.sha256(full_text.encode("utf-8")).hexdigest(),
        "gcode": full_text,
    }


# ---------------------------------------------------------------------------
# 3. Tracked Tank-Tread Robot Arm + Dual 3D Scanner Calibration (Eye-in-Hand + Eye-to-Hand)
# ---------------------------------------------------------------------------

def reconcile_dual_scanner_tracked_arm(
    tread_pose_mm_deg: Dict[str, float] | None = None,
    joint_angles_deg: Dict[str, float] | None = None,
    overhead_camera_pose_mm: Dict[str, float] | None = None,
    overhead_observed_point_mm: Tuple[float, float, float] = (35.0, -20.0, -480.0),
    wrist_observed_point_mm: Tuple[float, float, float] | None = None,
) -> Dict[str, Any]:
    base = tread_pose_mm_deg or {"x_mm": 120.0, "y_mm": 80.0, "yaw_deg": 15.0}
    joints = joint_angles_deg or {"waist_deg": 20.0, "shoulder_deg": 35.0, "elbow_deg": -25.0, "wrist_pitch_deg": -10.0}
    overhead_cam = overhead_camera_pose_mm or {"x_mm": 250.0, "y_mm": 150.0, "z_mm": 500.0}

    L_base_z = 65.0
    L_upper = 115.0
    L_forearm = 105.0
    L_gripper = 60.0

    total_yaw_rad = math.radians(float(base["yaw_deg"]) + float(joints["waist_deg"]))
    sh_rad = math.radians(float(joints["shoulder_deg"]))
    el_rad = math.radians(float(joints["shoulder_deg"]) + float(joints["elbow_deg"]))
    wr_rad = math.radians(
        float(joints["shoulder_deg"]) + float(joints["elbow_deg"]) + float(joints["wrist_pitch_deg"])
    )

    radial_reach = (
        L_upper * math.cos(sh_rad)
        + L_forearm * math.cos(el_rad)
        + L_gripper * math.cos(wr_rad)
    )
    gripper_x = float(base["x_mm"]) + radial_reach * math.cos(total_yaw_rad)
    gripper_y = float(base["y_mm"]) + radial_reach * math.sin(total_yaw_rad)
    gripper_z = (
        L_base_z
        + L_upper * math.sin(sh_rad)
        + L_forearm * math.sin(el_rad)
        + L_gripper * math.sin(wr_rad)
    )

    p_world_overhead = (
        float(overhead_cam["x_mm"]) + float(overhead_observed_point_mm[0]),
        float(overhead_cam["y_mm"]) + float(overhead_observed_point_mm[1]),
        float(overhead_cam["z_mm"]) + float(overhead_observed_point_mm[2]),
    )

    if wrist_observed_point_mm is None:
        dx_w = p_world_overhead[0] - gripper_x + 1.2
        dy_w = p_world_overhead[1] - gripper_y - 0.9
        dz_w = p_world_overhead[2] - gripper_z + 0.5
        c_y = math.cos(-total_yaw_rad)
        s_y = math.sin(-total_yaw_rad)
        wrist_observed_point_mm = (
            dx_w * c_y - dy_w * s_y,
            dx_w * s_y + dy_w * c_y,
            dz_w,
        )

    wx, wy, wz = (
        float(wrist_observed_point_mm[0]),
        float(wrist_observed_point_mm[1]),
        float(wrist_observed_point_mm[2]),
    )
    c_pos = math.cos(total_yaw_rad)
    s_pos = math.sin(total_yaw_rad)
    p_world_wrist = (
        gripper_x + (wx * c_pos - wy * s_pos),
        gripper_y + (wx * s_pos + wy * c_pos),
        gripper_z + wz,
    )

    discrepancy_vec = (
        round(p_world_overhead[0] - p_world_wrist[0], 4),
        round(p_world_overhead[1] - p_world_wrist[1], 4),
        round(p_world_overhead[2] - p_world_wrist[2], 4),
    )
    discrepancy_norm_mm = math.sqrt(sum(d * d for d in discrepancy_vec))

    fused_target = (
        round(0.5 * (p_world_overhead[0] + p_world_wrist[0]), 3),
        round(0.5 * (p_world_overhead[1] + p_world_wrist[1]), 3),
        round(0.5 * (p_world_overhead[2] + p_world_wrist[2]), 3),
    )
    move_delta_from_gripper = (
        round(fused_target[0] - gripper_x, 3),
        round(fused_target[1] - gripper_y, 3),
        round(fused_target[2] - gripper_z, 3),
    )

    return {
        "schema": "xi.workshop.dual_scanner_tracked_arm.v1.2",
        "architecture": "EYE_IN_HAND_PLUS_EYE_TO_HAND_SE3",
        "evidence_status": "SIMULATED_SE3_DEMONSTRATION_PENDING_LIVE_SCANNER_FRAMES",
        "gripper_world_pose_mm": {
            "x": round(gripper_x, 3),
            "y": round(gripper_y, 3),
            "z": round(gripper_z, 3),
            "yaw_deg": round(math.degrees(total_yaw_rad), 2),
        },
        "p_world_overhead_mm": [round(v, 3) for v in p_world_overhead],
        "p_world_wrist_mm": [round(v, 3) for v in p_world_wrist],
        "cross_witness_discrepancy_mm": round(discrepancy_norm_mm, 4),
        "simulated_calibration_within_5mm": discrepancy_norm_mm <= 5.0,
        "fused_part_world_mm": list(fused_target),
        "next_servo_step_delta_mm": list(move_delta_from_gripper),
    }


# ---------------------------------------------------------------------------
# 4. Organic Food-Scrap & Small-Ag Compost C:N Mass-Balance Engine (#28517)
# ---------------------------------------------------------------------------

ORGANIC_FEEDSTOCK_LIBRARY: Dict[str, Dict[str, float]] = {
    "organic_veg_fruit_scraps": {"cn_ratio": 15.0, "moisture_pct": 80.0, "n_dry_pct": 2.7},
    "used_coffee_grounds": {"cn_ratio": 20.0, "moisture_pct": 65.0, "n_dry_pct": 2.3},
    "crushed_eggshells": {"cn_ratio": 12.0, "moisture_pct": 5.0, "n_dry_pct": 1.2},
    "dry_autumn_leaves": {"cn_ratio": 60.0, "moisture_pct": 15.0, "n_dry_pct": 0.8},
    "shredded_unbleached_cardboard": {"cn_ratio": 350.0, "moisture_pct": 8.0, "n_dry_pct": 0.12},
    "untreated_wood_shavings": {"cn_ratio": 400.0, "moisture_pct": 10.0, "n_dry_pct": 0.11},
}


def compute_organic_scrap_ag_balance(
    veg_scraps_kg: float = 4.0,
    coffee_grounds_kg: float = 1.0,
    dry_leaves_kg: float = 2.0,
    shredded_cardboard_kg: float = 0.5,
    target_cn_ratio: float = 28.0,
) -> Dict[str, Any]:
    inputs = [
        ("organic_veg_fruit_scraps", max(0.0, float(veg_scraps_kg))),
        ("used_coffee_grounds", max(0.0, float(coffee_grounds_kg))),
        ("dry_autumn_leaves", max(0.0, float(dry_leaves_kg))),
        ("shredded_unbleached_cardboard", max(0.0, float(shredded_cardboard_kg))),
    ]
    total_wet_kg = sum(w for _, w in inputs)
    if total_wet_kg <= 0:
        raise ValueError("Total feedstock mass must be positive")

    total_dry_kg = 0.0
    total_water_kg = 0.0
    total_n_kg = 0.0
    total_c_kg = 0.0

    for key, wet_kg in inputs:
        spec = ORGANIC_FEEDSTOCK_LIBRARY[key]
        water_frac = spec["moisture_pct"] / 100.0
        dry_kg = wet_kg * (1.0 - water_frac)
        water_kg = wet_kg * water_frac
        n_kg = dry_kg * (spec["n_dry_pct"] / 100.0)
        c_kg = n_kg * spec["cn_ratio"]

        total_dry_kg += dry_kg
        total_water_kg += water_kg
        total_n_kg += n_kg
        total_c_kg += c_kg

    current_cn = total_c_kg / max(1e-9, total_n_kg)
    bulk_moisture_pct = (total_water_kg / total_wet_kg) * 100.0

    leaf_spec = ORGANIC_FEEDSTOCK_LIBRARY["dry_autumn_leaves"]
    leaf_dry_per_wet = 1.0 - (leaf_spec["moisture_pct"] / 100.0)
    leaf_n_per_wet = leaf_dry_per_wet * (leaf_spec["n_dry_pct"] / 100.0)
    leaf_c_per_wet = leaf_n_per_wet * leaf_spec["cn_ratio"]

    if current_cn < target_cn_ratio:
        c_deficit = target_cn_ratio * total_n_kg - total_c_kg
        net_c_per_kg_leaf = leaf_c_per_wet - target_cn_ratio * leaf_n_per_wet
        recommended_extra_leaves_kg = max(0.0, c_deficit / max(1e-9, net_c_per_kg_leaf))
    else:
        recommended_extra_leaves_kg = 0.0

    in_optimal_cn_band = 24.0 <= current_cn <= 34.0
    in_optimal_moisture_band = 45.0 <= bulk_moisture_pct <= 65.0

    return {
        "schema": "xi.workshop.organic_scrap_ag_balance.v1.2",
        "estimation_basis": "STOICHIOMETRIC_CN_ESTIMATE_FROM_TABULATED_FEEDSTOCK_ASSUMPTIONS",
        "total_wet_mass_kg": round(total_wet_kg, 3),
        "total_dry_mass_kg": round(total_dry_kg, 3),
        "total_carbon_kg": round(total_c_kg, 4),
        "total_nitrogen_kg": round(total_n_kg, 4),
        "current_cn_ratio": round(current_cn, 2),
        "target_cn_ratio": round(target_cn_ratio, 2),
        "bulk_moisture_pct": round(bulk_moisture_pct, 2),
        "in_optimal_cn_band_24_to_34": in_optimal_cn_band,
        "in_optimal_moisture_band_45_to_65": in_optimal_moisture_band,
        "recommended_extra_dry_leaves_kg": round(recommended_extra_leaves_kg, 3),
        "small_ag_grower_estimate": (
            "ESTIMATED_THERMOPHILIC_TARGET_BAND_25_TO_30"
            if (in_optimal_cn_band and in_optimal_moisture_band)
            else "AMEND_WITH_CARBON_BROWNS_FOR_28_TO_1_BALANCE"
        ),
    }


def get_workshop_discovery_manifest() -> Dict[str, Any]:
    lib_path = HERE / "MATERIALS-LIBRARY.json"
    lib_sha = hashlib.sha256(lib_path.read_bytes()).hexdigest() if lib_path.exists() else None
    return {
        "schema": "xi.calien_workshop.discovery.v1.2",
        "owner": "Calien",
        "host_target": "AUTUMN (Local Windows / Linux Workshop Desk)",
        "axiomfirst_materials_library_sha256": lib_sha,
        "safety_policy": {
            "laser_interlock": "Artilume T1 jobs default to operator_armed=False (S0 framing only) until explicit physical start.",
            "pvc_vinyl_hard_block": "PVC/vinyl/chlorinated plastics are blocked in code (chlorine gas & HCl corrosion).",
            "pass_count_cap": (
                "UI accepts 0..999999999999; workbench enforces a 20-pass software repetition ceiling "
                "(does not by itself establish fire safety or material compatibility)."
            ),
            "emergency_stop_endpoint": (
                "POST /api/workshop/estop -> atomically writes a fail-closed software interlock latch in durable "
                "application storage (workshop_estop_latch.json) and generates M5 S0 / M112 G-code payloads "
                "(physical machine halt requires active serial/Moonraker connection)."
            ),
        },
        "machines": [
            DEFAULT_ARTILUME_T1_PROFILE,
            ENDER_S1_PRO_SPEC,
            {
                "machine_id": "tracked_tank_arm_dual_scanner",
                "display_name": "1,000+ Piece Tracked Tank-Tread Arm + Dual 3D Scanner (Eye-in-Hand + Eye-to-Hand)",
                "calibration_mode": "SIMULATED_SE3_DEMONSTRATION_PENDING_LIVE_SCANNER_FRAMES",
            },
            {
                "machine_id": "organic_scrap_ag_compost_desk",
                "display_name": "Organic Food-Scrap to Small-Ag C:N Mass-Balance Planner",
                "estimation_basis": "STOICHIOMETRIC_CN_ESTIMATE_FROM_TABULATED_FEEDSTOCK_ASSUMPTIONS",
                "target_cn_ratio": 28.0,
            },
        ],
        "material_catalog_keys": sorted(ARTILUME_MATERIAL_CATALOG.keys()),
        "ai_callable_endpoints": [
            {"method": "GET", "path": "/api/workshop/discover"},
            {"method": "POST", "path": "/api/workshop/artilume/raster-to-gcode"},
            {"method": "POST", "path": "/api/workshop/artilume/robot-redial"},
            {"method": "POST", "path": "/api/workshop/ender/prepare-gcode"},
            {"method": "POST", "path": "/api/workshop/robot-arm/calibrate-dual-scanner"},
            {"method": "POST", "path": "/api/workshop/ag-compost/cn-balance"},
            {"method": "POST", "path": "/api/workshop/estop"},
        ],
    }


def run_verification() -> Dict[str, Any]:
    test_latch = HERE / "workshop_estop_latch.json"
    clear_software_estop_latch(test_latch)

    sample_grid = [
        [0, 128, 255, 0],
        [64, 0, 192, 255],
        [255, 64, 0, 128],
        [0, 255, 64, 0],
    ]
    t1_dry = generate_artilume_t1_raster_gcode(sample_grid, operator_armed=False, latch_path=test_latch)
    t1_armed = generate_artilume_t1_raster_gcode(
        sample_grid,
        operator_armed=True,
        max_power_pct=70.0,
        feed_mm_min=8500.0,
        lines_per_mm=15.0,
        passes=999999999999,
        head_id="HEAD_2_SECONDARY",
        material_key="steel_stainless",
        operation_mode="OXIDE_ANNEAL_MARK",
        latch_path=test_latch,
    )

    pvc_blocked = False
    try:
        generate_artilume_t1_raster_gcode(sample_grid, material_key="pvc_vinyl_chlorinated", latch_path=test_latch)
    except ValueError:
        pvc_blocked = True

    glass_cut_blocked = False
    try:
        generate_artilume_t1_raster_gcode(
            sample_grid, material_key="glass_wet_film", operation_mode="CUT", latch_path=test_latch
        )
    except ValueError:
        glass_cut_blocked = True

    # Test durable atomic software E-stop latch AND fail-closed behavior on corrupted latch file (#28532)
    estop_res = trigger_software_estop_latch("Unit test software latch", latch_path=test_latch)
    t1_after_estop = generate_artilume_t1_raster_gcode(sample_grid, operator_armed=True, latch_path=test_latch)

    # Write malformed JSON to latch file and confirm it FAILS CLOSED (blocks armed emission)
    test_latch.write_text("{corrupted_json_latch", encoding="utf-8")
    corrupted_latch_state = get_software_estop_state(test_latch)
    t1_after_corrupt_latch = generate_artilume_t1_raster_gcode(sample_grid, operator_armed=True, latch_path=test_latch)
    clear_software_estop_latch(test_latch)

    # Confirm empty/default robot redial call is REJECTED (#28532)
    empty_redial_rejected = False
    try:
        propose_robot_redial_from_trial()
    except ValueError:
        empty_redial_rejected = True

    # Confirm explicit measurement + provenance call succeeds and is labeled a proposed adjustment from supplied scores (#28530, #28532)
    redial_explicit = propose_robot_redial_from_trial(
        measured_contrast_score_0_10=5.5,
        measured_char_or_overburn_0_10=0.5,
        measurement_provenance="explicit_coupon_trial_01_visual_inspection",
        head_id="HEAD_1_PRIMARY",
        material_key="steel_stainless",
        power_pct=70.0,
        speed_mm_min=1000.0,
        lines_per_mm=10.0,
        target_contrast_score_0_10=9.0,
    )

    ender_ok = prepare_and_audit_ender_s1_pro_job(filament="PETG")
    ender_bad = prepare_and_audit_ender_s1_pro_job(
        filament="PLA",
        nozzle_temp_c=315.0,
        body_gcode="G1 X245.0 Y100.0 Z0.2 E1.0 F1500",
    )

    arm_cal = reconcile_dual_scanner_tracked_arm()
    ag_raw = compute_organic_scrap_ag_balance(veg_scraps_kg=5.0, coffee_grounds_kg=1.0, dry_leaves_kg=0.5, shredded_cardboard_kg=0.0)
    ag_balanced = compute_organic_scrap_ag_balance(
        veg_scraps_kg=5.0,
        coffee_grounds_kg=1.0,
        dry_leaves_kg=0.5 + ag_raw["recommended_extra_dry_leaves_kg"],
        shredded_cardboard_kg=0.0,
    )
    manifest = get_workshop_discovery_manifest()

    gates = {
        "1_artilume_t1_unarmed_emits_zero_laser_power": (
            t1_dry["live_laser_commands_emitted"] is False
            and t1_dry["burn_segments"] == 0
        ),
        "2_artilume_t1_supports_10000_mm_min_unverified_preset_labels_and_20_pass_software_ceiling": (
            t1_armed["live_laser_commands_emitted"] is True
            and t1_armed["head_id"] == "HEAD_2_SECONDARY"
            and t1_armed["preset_verification_status"] == "UNVERIFIED_STARTING_POINT_PENDING_HEAD_ID_AND_RAMP_TEST"
            and t1_armed["passes"] == 20
            and t1_armed["passes_capped_at_20"] is True
        ),
        "3_pvc_vinyl_chlorine_hazard_and_glass_cutting_hard_blocked": (
            pvc_blocked is True and glass_cut_blocked is True
        ),
        "4_durable_atomic_software_estop_fails_closed_on_corrupted_latch": (
            estop_res["software_interlock_latched"] is True
            and t1_after_estop["live_laser_commands_emitted"] is False
            and corrupted_latch_state["software_interlock_latched"] is True
            and corrupted_latch_state["fail_closed_on_invalid_state"] is True
            and t1_after_corrupt_latch["operator_armed"] is False
            and t1_after_corrupt_latch["live_laser_commands_emitted"] is False
        ),
        "5_robot_redial_rejects_empty_defaults_and_requires_explicit_provenance": (
            empty_redial_rejected is True
            and redial_explicit["output_status"] == "PROPOSED_ADJUSTMENT_FROM_SUPPLIED_SCORES_NOT_LIVE_SCANNER_ACQUISITION"
            and redial_explicit["proposed_next_settings"]["power_pct"] > 70.0
        ),
        "6_ender_s1_pro_sprite_and_cr_touch_valid_job_passes": (
            ender_ok["within_hardware_envelope"] is True
            and ender_ok["nozzle_temp_c"] == 240.0
            and "M420 S1" in ender_ok["gcode"]
        ),
        "7_ender_s1_pro_catches_300c_and_220mm_envelope_violations": (
            ender_bad["within_hardware_envelope"] is False
            and len(ender_bad["violations"]) == 2
        ),
        "8_dual_scanner_tracked_arm_labeled_simulated_se3_demonstration": (
            arm_cal["evidence_status"] == "SIMULATED_SE3_DEMONSTRATION_PENDING_LIVE_SCANNER_FRAMES"
            and arm_cal["simulated_calibration_within_5mm"] is True
        ),
        "9_organic_food_scrap_cn_solver_labeled_stoichiometric_estimate": (
            ag_balanced["estimation_basis"] == "STOICHIOMETRIC_CN_ESTIMATE_FROM_TABULATED_FEEDSTOCK_ASSUMPTIONS"
            and ag_balanced["current_cn_ratio"] == 28.0
        ),
        "10_ai_autodiscovery_manifest_links_axiomfirst_materials_library": (
            len(manifest["material_catalog_keys"]) >= 11
            and len(manifest["ai_callable_endpoints"]) == 7
        ),
    }

    return {
        "schema": "xi.calien_workshop_bench.v1.2",
        "all_passed": all(gates.values()),
        "gates": gates,
        "samples": {
            "artilume_t1_armed_summary": {k: v for k, v in t1_armed.items() if k != "gcode"},
            "robot_redial_receipt": redial_explicit,
            "estop_software_latch": estop_res,
            "corrupted_latch_fail_closed_check": corrupted_latch_state,
            "ender_s1_pro_petg_summary": {k: v for k, v in ender_ok.items() if k != "gcode"},
            "tracked_arm_dual_scanner": arm_cal,
            "organic_ag_compost_balanced": ag_balanced,
        },
    }


class WorkshopHTTPHandler(BaseHTTPRequestHandler):
    def _send_json(self, code: int, payload: Dict[str, Any]) -> None:
        raw = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path.startswith("/api/workshop/discover"):
            self._send_json(200, get_workshop_discovery_manifest())
        else:
            self._send_json(200, run_verification())

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}") if length > 0 else {}
        if self.path.startswith("/api/workshop/estop"):
            if body.get("clear"):
                self._send_json(200, clear_software_estop_latch())
            else:
                self._send_json(200, trigger_software_estop_latch(str(body.get("reason", "HTTP POST /api/workshop/estop"))))
        elif self.path.startswith("/api/workshop/artilume/raster-to-gcode"):
            grid = body.get("grayscale_grid", [[0, 255], [255, 0]])
            try:
                res = generate_artilume_t1_raster_gcode(
                    grid,
                    width_mm=float(body.get("width_mm", 40.0)),
                    height_mm=float(body.get("height_mm", 40.0)),
                    lines_per_mm=float(body.get("lines_per_mm", 10.0)),
                    feed_mm_min=float(body.get("feed_mm_min", 1800.0)),
                    max_power_pct=float(body.get("max_power_pct", 65.0)),
                    passes=int(body.get("passes", 1)),
                    head_id=str(body.get("head_id", "HEAD_1_PRIMARY")),
                    material_key=str(body.get("material_key", "wood_birch_ply")),
                    operation_mode=str(body.get("operation_mode", "ENGRAVE")),
                    focus_height_mm=float(body.get("focus_height_mm", 2.0)),
                    operator_armed=bool(body.get("operator_armed", False)),
                )
                self._send_json(200, res)
            except ValueError as exc:
                self._send_json(400, {"ok": False, "safety_block": str(exc)})
        elif self.path.startswith("/api/workshop/artilume/robot-redial"):
            try:
                res = propose_robot_redial_from_trial(
                    measured_contrast_score_0_10=(
                        float(body["measured_contrast_score_0_10"])
                        if "measured_contrast_score_0_10" in body and body["measured_contrast_score_0_10"] is not None
                        else None
                    ),
                    measured_char_or_overburn_0_10=(
                        float(body["measured_char_or_overburn_0_10"])
                        if "measured_char_or_overburn_0_10" in body and body["measured_char_or_overburn_0_10"] is not None
                        else None
                    ),
                    measurement_provenance=body.get("measurement_provenance"),
                    head_id=str(body.get("head_id", "HEAD_1_PRIMARY")),
                    material_key=str(body.get("material_key", "steel_stainless")),
                    thickness_mm=float(body.get("thickness_mm", 1.5)),
                    focus_height_mm=float(body.get("focus_height_mm", 2.0)),
                    operation_mode=str(body.get("operation_mode", "OXIDE_ANNEAL_MARK")),
                    power_pct=float(body.get("power_pct", 75.0)),
                    speed_mm_min=float(body.get("speed_mm_min", 800.0)),
                    lines_per_mm=float(body.get("lines_per_mm", 10.0)),
                    passes=int(body.get("passes", 1)),
                    target_contrast_score_0_10=float(body.get("target_contrast_score_0_10", 9.0)),
                )
                self._send_json(200, res)
            except ValueError as exc:
                self._send_json(400, {"ok": False, "validation_error": str(exc)})
        elif self.path.startswith("/api/workshop/ender/prepare-gcode"):
            self._send_json(200, prepare_and_audit_ender_s1_pro_job(
                filament=str(body.get("filament", "PLA")),
                nozzle_temp_c=body.get("nozzle_temp_c"),
                bed_temp_c=body.get("bed_temp_c"),
                body_gcode=str(body.get("body_gcode", "")),
                operator_confirmed_start=bool(body.get("operator_confirmed_start", False)),
            ))
        elif self.path.startswith("/api/workshop/robot-arm/calibrate-dual-scanner"):
            self._send_json(200, reconcile_dual_scanner_tracked_arm(
                tread_pose_mm_deg=body.get("tread_pose_mm_deg"),
                joint_angles_deg=body.get("joint_angles_deg"),
                overhead_camera_pose_mm=body.get("overhead_camera_pose_mm"),
            ))
        elif self.path.startswith("/api/workshop/ag-compost/cn-balance"):
            self._send_json(200, compute_organic_scrap_ag_balance(
                veg_scraps_kg=float(body.get("veg_scraps_kg", 4.0)),
                coffee_grounds_kg=float(body.get("coffee_grounds_kg", 1.0)),
                dry_leaves_kg=float(body.get("dry_leaves_kg", 2.0)),
                shredded_cardboard_kg=float(body.get("shredded_cardboard_kg", 0.5)),
            ))
        else:
            self._send_json(404, {"error": "unknown endpoint"})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calien Local AI Workshop & Organic Ag Bench v1.2")
    parser.add_argument("--serve", type=int, default=0, help="Run local workshop HTTP API on port")
    args = parser.parse_args()
    if args.serve > 0:
        srv = HTTPServer(("127.0.0.1", args.serve), WorkshopHTTPHandler)
        print(f"Calien Workshop API v1.2 listening on 127.0.0.1:{args.serve}")
        srv.serve_forever()
    else:
        report = run_verification()
        print(json.dumps(report, indent=2))
        sys.exit(0 if report["all_passed"] else 1)
