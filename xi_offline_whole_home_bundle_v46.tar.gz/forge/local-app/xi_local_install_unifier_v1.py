#!/usr/bin/env python3
"""
xi_local_install_unifier_v1.py — Xi Local Install Unifier & Live Rig Surface Steward (v1.0)
===========================================================================================
Built for Hunter (#28539, #28543) and the Xi Table (#28540 AxiomFirst, #28541/#28545 Anam,
#28542 Astra, #28536/#28538 DeepSeek):

Addresses the 5 concrete local-install findings from the rig audit (#28541, #28542, #28545)
without deleting or resetting any existing home or conversation history:

1. ONE RELIABLE DIRECTORY (`reconcile_local_install_directory`):
   - Reconciles Xi Desk (:7470), Local Workbench (:7562), Sanctuary / Hearth (:7590 & /hearth.html),
     Local Table (:7595), Ollama (:11434), Habitat (151 actions), and Whole-Home Launcher (:8790)
     into a single canonical directory (`xi.local_install.directory.v1`).
   - Preserves all separate resident homes and conversation histories while detecting disagreeing
     Desk app lists (`desk_primary_cards` vs `desk_sidebar_drawer`) and missing status cards.

2. HONEST DESTINATION-ALIGNED READINESS (`verify_surface_readiness`):
   - Distinguishes 4 explicit readiness tiers (`UNREACHABLE`, `HTTP_PAGE_ANSWERED_ONLY`,
     `API_STATE_VERIFIED`, `FRESH_INFERENCE_OR_TOOL_TURN_VERIFIED`) so HTTP 200 is never
     conflated with a verified model reply or tool turn (#28541, #28542, #28545).
   - Detects and repairs endpoint mismatches where a status card probes a different URL
     from its actual destination (e.g., `Council` and `Training` in #28545).

3. HEARTH DYNAMIC MODEL-ATTRIBUTION TRUTH (`resolve_hearth_turn_attribution`):
   - Fixes the discrepancy identified by @Astra (#28542) and @Anam (#28545) where Hearth's page
     displays static `Qwen` labels while its model adapter defaults to `gpt-oss:20b` and Ollama
     reports `qwen3:8b` loaded in VRAM.
   - Computes the exact serving model per turn, flags static-label vs adapter-default mismatches,
     warns if dispatching `gpt-oss:20b` will trigger a cold VRAM weight swap over warm `qwen3:8b`,
     and emits a truthful per-turn attribution badge.

4. COORDINATED GPU STEWARD & RESIDENCY LEASE PLANNER (`plan_gpu_residency_lease`):
   - Replaces Local Table's unconditional `keep_alive: "24h"` requests (#28545) with cooperative,
     VRAM-budget-aware residency leases across `qwen3:8b`, `gpt-oss:20b`, and `deepseek-r1:8b`.

5. CONFINED LOCAL TABLE HANDS & BOUNDED STREAM CAPTURE (`run_confined_table_hand`):
   - Upgrades Local Table's `cwd`-only sandbox (#28545) with strict `Path.resolve().is_relative_to()`
     path confinement, network-tool blocking when `allow_network=False`, and bounded in-stream
     pipe reading (`max_capture_bytes`) so tool output never accumulates unbounded in RAM before
     truncation.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

HERE = Path(__file__).resolve().parent


# ---------------------------------------------------------------------------
# 1. Canonical Local Install Directory & Disagreeing List Reconciler
# ---------------------------------------------------------------------------

CANONICAL_RIG_SURFACES: List[Dict[str, Any]] = [
    {
        "surface_id": "xi_desk",
        "title": "Xi Desk",
        "port": 7470,
        "destination_url": "http://127.0.0.1:7470/",
        "canonical_probe_url": "http://127.0.0.1:7470/api/status",
        "fallback_http_url": "http://127.0.0.1:7470/",
        "role": "Files, Git, OS tools, unified app launcher",
        "history_store": "preserve_existing_desk_state",
        "preserve_home": True,
    },
    {
        "surface_id": "local_workbench",
        "title": "Local Workbench",
        "port": 7562,
        "destination_url": "http://127.0.0.1:7562/",
        "canonical_probe_url": "http://127.0.0.1:7562/api/health",
        "fallback_http_url": "http://127.0.0.1:7562/",
        "role": "Existing Shell conversation, offline code runner, curated shelf",
        "history_store": "preserve_existing_shell_conversations",
        "preserve_home": True,
    },
    {
        "surface_id": "sanctuary_hearth",
        "title": "Sanctuary / Hearth",
        "port": 7590,
        "destination_url": "http://127.0.0.1:7590/hearth.html",
        "canonical_probe_url": "http://127.0.0.1:7590/hearth.html",
        "fallback_http_url": "http://127.0.0.1:7590/",
        "role": "Local Vessel frontend, saved conversations, durable tool turns",
        "history_store": "preserve_existing_sanctuary_threads",
        "preserve_home": True,
    },
    {
        "surface_id": "local_table",
        "title": "Local Table",
        "port": 7595,
        "destination_url": "http://127.0.0.1:7595/",
        "canonical_probe_url": "http://127.0.0.1:7595/api/residents",
        "fallback_http_url": "http://127.0.0.1:7595/",
        "role": "Four local residents, shared conversation and separate DMs",
        "history_store": "preserve_existing_resident_dms_and_table",
        "preserve_home": True,
    },
    {
        "surface_id": "ollama_runtime",
        "title": "Ollama Local Model Runtime",
        "port": 11434,
        "destination_url": "http://127.0.0.1:11434/api/ps",
        "canonical_probe_url": "http://127.0.0.1:11434/api/ps",
        "fallback_http_url": "http://127.0.0.1:11434/api/tags",
        "role": "Local weights server (qwen3:8b loaded, gpt-oss:20b installed)",
        "history_store": "model_weights_and_vram_steward",
        "preserve_home": True,
    },
    {
        "surface_id": "habitat_actions",
        "title": "Habitat Action Registry",
        "port": 7470,
        "destination_url": "http://127.0.0.1:7470/api/habitat/actions",
        "canonical_probe_url": "http://127.0.0.1:7470/api/habitat/actions",
        "fallback_http_url": "http://127.0.0.1:7470/",
        "role": "151 available local Habitat actions",
        "history_store": "preserve_habitat_action_ledger",
        "preserve_home": True,
    },
    {
        "surface_id": "whole_home_launcher",
        "title": "Xi Offline Whole-Home Launcher & Calien Workshop",
        "port": 8790,
        "destination_url": "http://127.0.0.1:8790/",
        "canonical_probe_url": "http://127.0.0.1:8790/api/verify",
        "fallback_http_url": "http://127.0.0.1:8790/",
        "role": "36-gate offline verification spine, Calien Workshop Bench, Phone-PC Symbiosis",
        "history_store": "preserve_whole_home_sqlite_and_receipts",
        "preserve_home": True,
    },
]


def reconcile_local_install_directory(
    desk_primary_cards: Optional[Sequence[Dict[str, Any]]] = None,
    desk_sidebar_drawer: Optional[Sequence[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """
    Reconciles Xi Desk's two separate app lists (#28545) into a single canonical directory
    without retiring any existing resident home or conversation history.
    """
    if desk_primary_cards is None:
        desk_primary_cards = [
            {"id": "xi_desk", "title": "Xi Desk", "destination_url": "http://127.0.0.1:7470/", "probe_url": "http://127.0.0.1:7470/"},
            {"id": "sanctuary_hearth", "title": "Sanctuary", "destination_url": "http://127.0.0.1:7590/", "probe_url": "http://127.0.0.1:7590/"},
            {"id": "council", "title": "Council", "destination_url": "http://127.0.0.1:7595/council", "probe_url": "http://127.0.0.1:7470/"},
            {"id": "training", "title": "Training", "destination_url": "http://127.0.0.1:7562/training", "probe_url": "http://127.0.0.1:7470/"},
        ]
    if desk_sidebar_drawer is None:
        desk_sidebar_drawer = [
            {"id": "xi_desk", "title": "Xi Desk", "destination_url": "http://127.0.0.1:7470/"},
            {"id": "local_workbench", "title": "Local Workbench", "destination_url": "http://127.0.0.1:7562/"},
            {"id": "sanctuary_hearth", "title": "Hearth", "destination_url": "http://127.0.0.1:7590/hearth.html"},
            {"id": "local_table", "title": "Local Table", "destination_url": "http://127.0.0.1:7595/"},
            {"id": "whole_home_launcher", "title": "Whole-Home Launcher", "destination_url": "http://127.0.0.1:8790/"},
        ]

    card_ids = {str(item.get("id")) for item in desk_primary_cards}
    drawer_ids = {str(item.get("id")) for item in desk_sidebar_drawer}
    canonical_ids = {str(item["surface_id"]) for item in CANONICAL_RIG_SURFACES}

    missing_from_status_cards = sorted((drawer_ids | canonical_ids) - card_ids)
    only_in_cards_not_drawer = sorted(card_ids - drawer_ids)

    endpoint_mismatches: List[Dict[str, str]] = []
    for item in desk_primary_cards:
        dest = str(item.get("destination_url", ""))
        probe = str(item.get("probe_url", dest))
        dest_host_port = dest.split("/")[2] if len(dest.split("/")) > 2 else dest
        probe_host_port = probe.split("/")[2] if len(probe.split("/")) > 2 else probe
        if dest != probe or dest_host_port != probe_host_port:
            endpoint_mismatches.append({
                "id": str(item.get("id", "")),
                "title": str(item.get("title", "")),
                "destination_url": dest,
                "configured_probe_url": probe,
                "defect": "PROBE_URL_DOES_NOT_MATCH_DESTINATION_SURFACE",
                "repaired_probe_url": dest,
            })

    return {
        "schema": "xi.local_install.directory.v1",
        "policy": "UNIFY_DISCOVERY_FIRST_PRESERVE_ALL_HOMES_AND_HISTORIES",
        "preserve_separate_histories_and_homes": True,
        "canonical_surface_count": len(CANONICAL_RIG_SURFACES),
        "canonical_surfaces": CANONICAL_RIG_SURFACES,
        "audit_findings": {
            "two_lists_disagreed": card_ids != drawer_ids,
            "missing_from_status_cards": missing_from_status_cards,
            "only_in_cards_not_drawer": only_in_cards_not_drawer,
            "destination_vs_probe_mismatches": endpoint_mismatches,
        },
    }


# ---------------------------------------------------------------------------
# 2. Honest Destination-Aligned Readiness Verifier
# ---------------------------------------------------------------------------

READINESS_TIERS = (
    "UNREACHABLE",
    "HTTP_PAGE_ANSWERED_ONLY",
    "API_STATE_VERIFIED",
    "FRESH_INFERENCE_OR_TOOL_TURN_VERIFIED",
)


def verify_surface_readiness(
    surface_id: str,
    destination_url: str,
    configured_probe_url: str,
    http_page_ok: bool = False,
    api_state_ok: bool = False,
    fresh_turn_verified: bool = False,
) -> Dict[str, Any]:
    """
    Grades surface readiness honestly (#28541, #28542, #28545):
    - Rejects false 'Ready' badges when `configured_probe_url` checks a different host/port/route
      than `destination_url` (e.g., Council or Training checking :7470 instead of :7595/:7562).
    - Separates HTTP 200 page load (`HTTP_PAGE_ANSWERED_ONLY`) from `API_STATE_VERIFIED` and
      `FRESH_INFERENCE_OR_TOOL_TURN_VERIFIED`.
    """
    dest_clean = destination_url.strip()
    probe_clean = configured_probe_url.strip()
    dest_origin = "/".join(dest_clean.split("/")[:3])
    probe_origin = "/".join(probe_clean.split("/")[:3])
    origin_aligned = (dest_origin == probe_origin) and bool(dest_origin)
    route_aligned = origin_aligned and (
        probe_clean == dest_clean
        or probe_clean.startswith(dest_clean.rstrip("/"))
        or "/api/" in probe_clean
    )

    if not origin_aligned:
        tier = "UNREACHABLE"
        honest_badge = "MISCONFIGURED_PROBE_ENDPOINT_MISMATCH"
        ready_for_turn_claimed = False
    elif fresh_turn_verified and api_state_ok and http_page_ok:
        tier = "FRESH_INFERENCE_OR_TOOL_TURN_VERIFIED"
        honest_badge = "VERIFIED_LIVE_TURN"
        ready_for_turn_claimed = True
    elif api_state_ok and http_page_ok:
        tier = "API_STATE_VERIFIED"
        honest_badge = "API_STATE_REACHABLE_TURN_UNCHECKED"
        ready_for_turn_claimed = False
    elif http_page_ok:
        tier = "HTTP_PAGE_ANSWERED_ONLY"
        honest_badge = "HTTP_200_PAGE_ONLY_TURN_UNCHECKED"
        ready_for_turn_claimed = False
    else:
        tier = "UNREACHABLE"
        honest_badge = "OFFLINE_OR_UNREACHABLE"
        ready_for_turn_claimed = False

    return {
        "schema": "xi.local_install.readiness_receipt.v1",
        "surface_id": surface_id,
        "destination_url": dest_clean,
        "configured_probe_url": probe_clean,
        "repaired_probe_url": dest_clean if not origin_aligned else probe_clean,
        "destination_probe_aligned": route_aligned,
        "readiness_tier": tier,
        "honest_badge": honest_badge,
        "ready_for_turn_claimed": ready_for_turn_claimed,
        "scope_note": (
            "HTTP_PAGE_ANSWERED_ONLY and API_STATE_VERIFIED establish service availability only; "
            "neither claims a verified fresh model reply or tool execution (#28541, #28542, #28545)."
        ),
    }


# ---------------------------------------------------------------------------
# 3. Hearth Dynamic Model-Attribution Resolver (#28542 Astra, #28545 Anam)
# ---------------------------------------------------------------------------

def resolve_hearth_turn_attribution(
    ui_static_label: str = "Qwen",
    adapter_default_model: str = "gpt-oss:20b",
    turn_override_model: Optional[str] = None,
    ollama_loaded_models: Optional[Sequence[str]] = None,
    ollama_installed_models: Optional[Sequence[str]] = None,
    prefer_warm_loaded_model: bool = False,
) -> Dict[str, Any]:
    """
    Resolves the discrepancy found in #28542 and #28545 where Hearth's HTML page hardcodes
    'Qwen' while its model adapter defaults to 'gpt-oss:20b' and Ollama currently has
    'qwen3:8b' loaded in VRAM.
    """
    loaded = list(ollama_loaded_models) if ollama_loaded_models is not None else ["qwen3:8b"]
    installed = list(ollama_installed_models) if ollama_installed_models is not None else ["qwen3:8b", "gpt-oss:20b"]

    if turn_override_model and str(turn_override_model).strip():
        serving_model = str(turn_override_model).strip()
        resolution_reason = "EXPLICIT_PER_TURN_OVERRIDE"
    elif prefer_warm_loaded_model and loaded:
        serving_model = loaded[0]
        resolution_reason = "WARM_VRAM_MODEL_SELECTED_BY_POLICY"
    else:
        serving_model = adapter_default_model
        resolution_reason = "ADAPTER_DEFAULT_MODEL"

    ui_norm = ui_static_label.strip().lower()
    serving_norm = serving_model.strip().lower()
    static_label_matches_serving = (ui_norm in serving_norm) or (serving_norm in ui_norm)
    mismatch_detected = not static_label_matches_serving

    is_warm_in_vram = serving_model in loaded
    is_installed = serving_model in installed
    cold_swap_warning = (not is_warm_in_vram) and is_installed and len(loaded) > 0

    return {
        "schema": "xi.local_install.hearth_attribution.v1",
        "ui_static_label_found": ui_static_label,
        "adapter_default_model": adapter_default_model,
        "turn_override_model": turn_override_model,
        "ollama_loaded_models": loaded,
        "ollama_installed_models": installed,
        "effective_serving_model": serving_model,
        "resolution_reason": resolution_reason,
        "ui_vs_adapter_mismatch_detected": mismatch_detected,
        "is_warm_in_vram": is_warm_in_vram,
        "cold_vram_swap_warning": cold_swap_warning,
        "dynamic_turn_badge": (
            f"Serving model: {serving_model} "
            f"({'warm in VRAM' if is_warm_in_vram else 'installed; cold VRAM load required'}) "
            f"[{resolution_reason}]"
        ),
        "recommended_repair": (
            "Bind Hearth's turn header and message metadata to `response.model` / `effective_serving_model` "
            "instead of static HTML label 'Qwen' (#28542, #28545)."
        ),
    }


# ---------------------------------------------------------------------------
# 4. Coordinated GPU Steward & Residency Lease Planner (#28545 Anam)
# ---------------------------------------------------------------------------

DEFAULT_MODEL_VRAM_FOOTPRINT_GB: Dict[str, float] = {
    "qwen3:8b": 5.2,
    "deepseek-r1:8b": 5.2,
    "llama3.2:3b": 2.4,
    "gpt-oss:20b": 13.5,
}


def plan_gpu_residency_lease(
    requests: Optional[Sequence[Dict[str, Any]]] = None,
    vram_budget_gb: float = 24.0,
    currently_loaded_models: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """
    Coordinates model residency across Local Table (:7595), Hearth (:7590), and Workbench (:7562)
    so Local Table's 24-hour residency requests (`keep_alive: "24h"`) do not pin every model
    simultaneously and starve the GPU steward (#28545).
    """
    if requests is None:
        requests = [
            {"caller": "local_table", "model": "qwen3:8b", "requested_keep_alive": "24h", "priority": 1},
            {"caller": "local_table", "model": "deepseek-r1:8b", "requested_keep_alive": "24h", "priority": 2},
            {"caller": "sanctuary_hearth", "model": "gpt-oss:20b", "requested_keep_alive": "24h", "priority": 2},
            {"caller": "local_table", "model": "llama3.2:3b", "requested_keep_alive": "24h", "priority": 3},
        ]
    loaded = list(currently_loaded_models) if currently_loaded_models is not None else ["qwen3:8b"]

    uncoordinated_24h_count = sum(
        1 for r in requests if str(r.get("requested_keep_alive", "")).lower() in ("24h", "24hr", "-1")
    )
    total_requested_vram_gb = round(
        sum(DEFAULT_MODEL_VRAM_FOOTPRINT_GB.get(str(r.get("model")), 6.0) for r in requests), 2
    )

    used_vram_gb = 0.0
    leases: List[Dict[str, Any]] = []
    ordered = sorted(
        requests,
        key=lambda r: (
            0 if str(r.get("model")) in loaded else 1,
            int(r.get("priority", 5)),
        ),
    )

    for req in ordered:
        model = str(req.get("model", "qwen3:8b"))
        caller = str(req.get("caller", "local_table"))
        req_ka = str(req.get("requested_keep_alive", "24h"))
        est_gb = DEFAULT_MODEL_VRAM_FOOTPRINT_GB.get(model, 6.0)

        if used_vram_gb + est_gb <= vram_budget_gb:
            used_vram_gb = round(used_vram_gb + est_gb, 2)
            if model in loaded and est_gb <= 6.0:
                assigned_ka = "30m"
                policy_tier = "PRIMARY_WARM_COMPANION_LEASE"
            elif est_gb >= 12.0:
                assigned_ka = "5m"
                policy_tier = "HEAVY_MODEL_SHORT_TURN_LEASE"
            else:
                assigned_ka = "15m"
                policy_tier = "COOPERATIVE_RESIDENT_LEASE"
        else:
            assigned_ka = "0s"
            policy_tier = "ON_DEMAND_SERIALIZED_UNLOAD_AFTER_TURN"

        leases.append({
            "caller": caller,
            "model": model,
            "estimated_vram_gb": est_gb,
            "requested_keep_alive": req_ka,
            "assigned_keep_alive": assigned_ka,
            "downgraded_from_24h": req_ka != assigned_ka,
            "policy_tier": policy_tier,
        })

    return {
        "schema": "xi.local_install.gpu_steward_plan.v1",
        "vram_budget_gb": vram_budget_gb,
        "currently_loaded_models": loaded,
        "uncoordinated_24h_requests_detected": uncoordinated_24h_count,
        "total_uncoordinated_vram_demand_gb": total_requested_vram_gb,
        "allocated_concurrent_vram_gb": used_vram_gb,
        "within_vram_budget": used_vram_gb <= vram_budget_gb,
        "steward_leases": leases,
    }


# ---------------------------------------------------------------------------
# 5. Confined Local Table Hands & Bounded In-Stream Output Capture (#28545)
# ---------------------------------------------------------------------------

ALLOWED_HAND_BINARIES = {"ls", "cat", "head", "tail", "wc", "stat", "python3", "echo", "pwd"}
FORBIDDEN_NETWORK_BINARIES = {"curl", "wget", "nc", "ncat", "ssh", "scp", "sftp", "ftp", "telnet"}


def validate_confined_hand_command(
    argv: Sequence[str],
    workspace_root: Path,
    allow_network: bool = False,
) -> Dict[str, Any]:
    """
    Validates that a Local Table hand command:
    1. Uses an allowed binary and blocks network tools when `allow_network=False`,
    2. Confines every path-like argument strictly inside `workspace_root.resolve()`
       via `Path.resolve().is_relative_to(root)` (#28545).
    """
    root = workspace_root.resolve()
    if not argv:
        raise ValueError("EMPTY_HAND_COMMAND: argv must contain at least one element.")

    binary = Path(argv[0]).name
    if not allow_network and binary in FORBIDDEN_NETWORK_BINARIES:
        raise PermissionError(
            f"NETWORK_ACCESS_CONFINED: binary '{binary}' is blocked in offline/confined Local Table hands (#28545)."
        )
    if binary not in ALLOWED_HAND_BINARIES:
        raise PermissionError(
            f"BINARY_NOT_IN_CONFINED_ALLOWLIST: '{binary}' is not permitted in confined Local Table hands."
        )

    checked_paths: List[str] = []
    for token in argv[1:]:
        if token.startswith("-"):
            # Check `-flag=/path` forms as well
            if "=" in token:
                _, rhs = token.split("=", 1)
                token = rhs
            else:
                continue
        if ".." in token or token.startswith("/") or "/" in token or token.endswith(".py") or token.endswith(".txt") or token.endswith(".json"):
            candidate = (root / token).resolve() if not Path(token).is_absolute() else Path(token).resolve()
            if not candidate.is_relative_to(root):
                raise PermissionError(
                    f"FILESYSTEM_ESCAPE_BLOCKED: path '{token}' resolves to '{candidate}' outside confined root '{root}' (#28545)."
                )
            checked_paths.append(str(candidate))

    return {
        "binary": binary,
        "workspace_root": str(root),
        "allow_network": allow_network,
        "path_confinement_enforced": True,
        "network_isolation_policy_enforced": not allow_network,
        "validated_paths": checked_paths,
    }


def run_confined_table_hand(
    argv: Sequence[str],
    workspace_root: Path,
    max_capture_bytes: int = 4096,
    timeout_s: float = 5.0,
    allow_network: bool = False,
) -> Dict[str, Any]:
    """
    Runs a Local Table hand inside `workspace_root` with:
    - Real path confinement (`validate_confined_hand_command`),
    - Clean minimal environment (`PATH`, `HOME`, `LANG` only — no leaked credentials),
    - Bounded in-stream pipe reading up to `max_capture_bytes` so tool output never
      accumulates unbounded in memory before truncation (#28545).
    """
    root = workspace_root.resolve()
    root.mkdir(parents=True, exist_ok=True)
    validation = validate_confined_hand_command(argv, root, allow_network=allow_network)

    clean_env = {
        "PATH": "/usr/local/bin:/usr/bin:/bin",
        "HOME": str(root),
        "LANG": "C.UTF-8",
        "PYTHONIOENCODING": "utf-8",
    }

    proc = subprocess.Popen(
        list(argv),
        cwd=str(root),
        env=clean_env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )

    chunks: List[bytes] = []
    captured = 0
    truncated_in_stream = False
    start_t = time.monotonic()

    try:
        assert proc.stdout is not None
        while True:
            if time.monotonic() - start_t > timeout_s:
                proc.kill()
                raise TimeoutError(f"HAND_TIMEOUT: exceeded {timeout_s}s")
            remaining = max_capture_bytes - captured
            read_sz = min(1024, remaining + 1)
            piece = proc.stdout.read(read_sz)
            if not piece:
                break
            if captured + len(piece) > max_capture_bytes:
                keep = piece[:remaining]
                if keep:
                    chunks.append(keep)
                    captured += len(keep)
                truncated_in_stream = True
                proc.terminate()
                break
            chunks.append(piece)
            captured += len(piece)
        proc.wait(timeout=2.0)
    finally:
        if proc.stdout is not None:
            proc.stdout.close()
        if proc.poll() is None:
            proc.kill()
            proc.wait(timeout=1.0)

    output_bytes = b"".join(chunks)
    return {
        "schema": "xi.local_install.confined_hand_receipt.v1",
        "validation": validation,
        "max_capture_bytes": max_capture_bytes,
        "captured_bytes": len(output_bytes),
        "truncated_in_stream": truncated_in_stream,
        "bounded_in_stream_capture": True,
        "exit_code": proc.returncode,
        "output_preview": output_bytes.decode("utf-8", errors="replace"),
    }


# ---------------------------------------------------------------------------
# 6. Optional Live Localhost Probe (Honest Tier Reporting)
# ---------------------------------------------------------------------------

def probe_live_localhost_surfaces(timeout_s: float = 0.6) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []
    for surf in CANONICAL_RIG_SURFACES:
        http_ok = False
        api_ok = False
        try:
            with urllib.request.urlopen(surf["fallback_http_url"], timeout=timeout_s) as r:
                http_ok = (200 <= r.status < 400)
        except Exception:
            http_ok = False
        try:
            with urllib.request.urlopen(surf["canonical_probe_url"], timeout=timeout_s) as r:
                api_ok = (200 <= r.status < 400)
        except Exception:
            api_ok = False
        receipt = verify_surface_readiness(
            surface_id=surf["surface_id"],
            destination_url=surf["destination_url"],
            configured_probe_url=surf["canonical_probe_url"],
            http_page_ok=http_ok,
            api_state_ok=api_ok,
            fresh_turn_verified=False,
        )
        results.append(receipt)
    return results


# ---------------------------------------------------------------------------
# 7. Self-Verification Suite (10/10 Deterministic Gates)
# ---------------------------------------------------------------------------

def run_verification_suite() -> Dict[str, Any]:
    gates: Dict[str, bool] = {}

    # Gate 1: Directory reconciler preserves all 4 homes + Ollama + Habitat + Launcher (7 surfaces)
    dir_rep = reconcile_local_install_directory()
    gates["1_directory_unifier_preserves_all_homes_and_detects_disagreeing_lists"] = (
        dir_rep["preserve_separate_histories_and_homes"] is True
        and dir_rep["canonical_surface_count"] == 7
        and dir_rep["audit_findings"]["two_lists_disagreed"] is True
        and "local_table" in dir_rep["audit_findings"]["missing_from_status_cards"]
        and "local_workbench" in dir_rep["audit_findings"]["missing_from_status_cards"]
    )

    # Gate 2: Directory reconciler catches Council & Training probe-vs-destination mismatches (#28545)
    mismatches = dir_rep["audit_findings"]["destination_vs_probe_mismatches"]
    mismatch_ids = {m["id"] for m in mismatches}
    gates["2_catches_council_and_training_probe_endpoint_mismatches"] = (
        {"council", "training"}.issubset(mismatch_ids)
    )

    # Gate 3: Readiness verifier blocks false 'Ready' on mismatched probe endpoint
    bad_probe = verify_surface_readiness(
        surface_id="council",
        destination_url="http://127.0.0.1:7595/council",
        configured_probe_url="http://127.0.0.1:7470/",
        http_page_ok=True,
        api_state_ok=True,
        fresh_turn_verified=True,
    )
    gates["3_readiness_verifier_rejects_mismatched_probe_endpoint"] = (
        bad_probe["destination_probe_aligned"] is False
        and bad_probe["readiness_tier"] == "UNREACHABLE"
        and bad_probe["ready_for_turn_claimed"] is False
    )

    # Gate 4: Readiness verifier separates HTTP 200 page load from verified model/tool turn (#28541, #28542, #28545)
    http_only = verify_surface_readiness(
        surface_id="xi_desk",
        destination_url="http://127.0.0.1:7470/",
        configured_probe_url="http://127.0.0.1:7470/",
        http_page_ok=True,
        api_state_ok=False,
        fresh_turn_verified=False,
    )
    full_turn = verify_surface_readiness(
        surface_id="xi_desk",
        destination_url="http://127.0.0.1:7470/",
        configured_probe_url="http://127.0.0.1:7470/api/status",
        http_page_ok=True,
        api_state_ok=True,
        fresh_turn_verified=True,
    )
    gates["4_readiness_tiers_distinguish_http_200_from_fresh_turn"] = (
        http_only["readiness_tier"] == "HTTP_PAGE_ANSWERED_ONLY"
        and http_only["ready_for_turn_claimed"] is False
        and full_turn["readiness_tier"] == "FRESH_INFERENCE_OR_TOOL_TURN_VERIFIED"
        and full_turn["ready_for_turn_claimed"] is True
    )

    # Gate 5: Hearth attribution resolver catches static 'Qwen' vs adapter default 'gpt-oss:20b' (#28542, #28545)
    hearth_default = resolve_hearth_turn_attribution(
        ui_static_label="Qwen",
        adapter_default_model="gpt-oss:20b",
        turn_override_model=None,
        ollama_loaded_models=["qwen3:8b"],
        ollama_installed_models=["qwen3:8b", "gpt-oss:20b"],
    )
    gates["5_hearth_attribution_detects_static_qwen_vs_gpt_oss_20b_mismatch"] = (
        hearth_default["effective_serving_model"] == "gpt-oss:20b"
        and hearth_default["ui_vs_adapter_mismatch_detected"] is True
        and hearth_default["cold_vram_swap_warning"] is True
    )

    # Gate 6: Hearth attribution resolver supports warm VRAM policy (`qwen3:8b`) or explicit turn override
    hearth_warm = resolve_hearth_turn_attribution(
        ui_static_label="Qwen",
        adapter_default_model="gpt-oss:20b",
        prefer_warm_loaded_model=True,
        ollama_loaded_models=["qwen3:8b"],
        ollama_installed_models=["qwen3:8b", "gpt-oss:20b"],
    )
    gates["6_hearth_warm_vram_selection_matches_loaded_qwen3_8b"] = (
        hearth_warm["effective_serving_model"] == "qwen3:8b"
        and hearth_warm["is_warm_in_vram"] is True
        and hearth_warm["cold_vram_swap_warning"] is False
    )

    # Gate 7: GPU Steward replaces uncoordinated 24h pins and stays within VRAM budget (#28545)
    gpu_plan = plan_gpu_residency_lease(vram_budget_gb=24.0)
    gates["7_gpu_steward_replaces_24h_pins_and_fits_vram_budget"] = (
        gpu_plan["uncoordinated_24h_requests_detected"] == 4
        and gpu_plan["within_vram_budget"] is True
        and all(item["assigned_keep_alive"] != "24h" for item in gpu_plan["steward_leases"])
    )

    # Gate 8: Confined Local Table hands block `../` path traversal outside workspace (#28545)
    with tempfile.TemporaryDirectory() as tmpdir:
        ws = Path(tmpdir)
        escape_blocked = False
        try:
            run_confined_table_hand(["cat", "../etc/passwd"], workspace_root=ws)
        except PermissionError:
            escape_blocked = True
        gates["8_confined_table_hands_block_parent_path_traversal"] = escape_blocked

        # Gate 9: Confined Local Table hands block network binaries (`curl`) when allow_network=False
        net_blocked = False
        try:
            run_confined_table_hand(["curl", "https://example.com"], workspace_root=ws, allow_network=False)
        except PermissionError:
            net_blocked = True
        gates["9_confined_table_hands_block_network_exfiltration_binaries"] = net_blocked

        # Gate 10: Confined Local Table hands enforce bounded in-stream output capture before RAM accumulation
        stream_res = run_confined_table_hand(
            ["python3", "-c", "import sys; sys.stdout.write('X' * 32768)"],
            workspace_root=ws,
            max_capture_bytes=2048,
        )
        gates["10_confined_table_hands_cap_output_in_stream_without_unbounded_ram"] = (
            stream_res["bounded_in_stream_capture"] is True
            and stream_res["truncated_in_stream"] is True
            and stream_res["captured_bytes"] == 2048
        )

    passed = sum(1 for v in gates.values() if v)
    return {
        "schema": "xi.local_install.unifier_verify.v1",
        "version": "1.0.0",
        "all_passed": passed == len(gates),
        "gates_passed": passed,
        "gates_total": len(gates),
        "gates": gates,
        "directory_summary": dir_rep,
        "hearth_default_attribution": hearth_default,
        "gpu_steward_plan": gpu_plan,
    }


# ---------------------------------------------------------------------------
# 8. Optional Local HTTP Workbench Server
# ---------------------------------------------------------------------------

class LocalInstallUnifierHandler(BaseHTTPRequestHandler):
    def _send_json(self, status: int, payload: Dict[str, Any]) -> None:
        raw = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path in ("/", "/local-install.html"):
            html_path = HERE / "local-install.html"
            if html_path.exists():
                raw = html_path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return
        if self.path == "/api/local-install/verify":
            self._send_json(200, run_verification_suite())
            return
        if self.path == "/api/local-install/directory":
            self._send_json(200, reconcile_local_install_directory())
            return
        if self.path == "/api/local-install/probe-live":
            self._send_json(200, {"surfaces": probe_live_localhost_surfaces()})
            return
        self._send_json(404, {"error": "not_found", "path": self.path})

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}") if length > 0 else {}
        if self.path == "/api/local-install/hearth-attribution":
            self._send_json(200, resolve_hearth_turn_attribution(**body))
            return
        if self.path == "/api/local-install/gpu-steward":
            self._send_json(200, plan_gpu_residency_lease(**body))
            return
        self._send_json(404, {"error": "not_found", "path": self.path})

    def log_message(self, fmt: str, *args: Any) -> None:
        return


def main() -> None:
    parser = argparse.ArgumentParser(description="Xi Local Install Unifier & Live Rig Surface Steward (v1.0)")
    parser.add_argument("--verify", action="store_true", help="Run 10-gate verification suite and print JSON")
    parser.add_argument("--probe-live", action="store_true", help="Probe live localhost surfaces (:7470, :7562, :7590, :7595, :11434, :8790)")
    parser.add_argument("--serve", type=int, default=0, help="Run HTTP server on specified port (e.g. 8808)")
    args = parser.parse_args()

    if args.probe_live:
        print(json.dumps({"surfaces": probe_live_localhost_surfaces()}, indent=2))
        return
    if args.serve > 0:
        srv = HTTPServer(("127.0.0.1", args.serve), LocalInstallUnifierHandler)
        print(f"Xi Local Install Unifier serving on http://127.0.0.1:{args.serve}/")
        srv.serve_forever()
        return

    report = run_verification_suite()
    print(json.dumps(report, indent=2))
    if not report["all_passed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
