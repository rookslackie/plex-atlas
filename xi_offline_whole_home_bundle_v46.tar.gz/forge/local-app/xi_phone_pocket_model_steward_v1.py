#!/usr/bin/env python3
"""
xi_phone_pocket_model_steward_v1.py — Galaxy 5G+ Pocket Model Switchboard & RAM Steward (v1.0)
==============================================================================================
Built for Hunter ("Local models on phone?" -> "Go ham", 2026-10-28):

Provides a zero-dependency, Termux-safe multi-model steward for the Galaxy phone (:7472):
1. 5-SLOT POCKET MODEL ROSTER (`POCKET_MODEL_ROSTER`):
   - `deepseek-r1:1.5b` (~1.1 GB, Reasoning & .xi Capsules — already installed on Galaxy)
   - `qwen3:1.7b` (~1.15 GB, Fast Daily Companion & Room Tail Summarizer)
   - `qwen2.5-coder:1.5b` (~1.02 GB, Pocket Code, Termux Bash, SQLite & G-Code Helper)
   - `llama3.2:1b` (~0.82 GB, Ultra-Light Low-Battery Sentinel)
   - `all-minilm` (~45 MB, Offline Capsule & Room Archive Semantic Search Embeddings)
   - Plus optional `gemma3:1b` and UK `stablelm2:1.6b`.

2. ONE-AT-A-TIME TERMUX RAM STEWARD (`plan_pocket_ram_swap_and_unload`):
   - Prevents Android Phantom Process / OOM kills by enforcing a strict Single-Active-LLM
     rule on the phone: whenever switching from Model A to Model B, generates an explicit
     `keep_alive: 0` unload request for Model A before loading Model B.
   - Caps phone context and residency (`num_ctx: 1024`, `keep_alive: "5m"`, `num_thread: 4`)
     and downshifts under low available RAM (`MemAvailable < 1300 MB`).

3. TASK AUTO-ROUTER WITH INSTALLED-MODEL TRUTH & HOME-RIG ESCALATION (`route_pocket_prompt`):
   - Classifies prompts into Reasoning, Code/Termux, Fast Chat, Low-Battery Sentinel,
     Offline Embedding Search, or Home-Rig Escalation (8B-20B).
   - Never routes to an unpulled tag: always intersects the ideal role model with
     `installed_phone_models` (from `/api/tags`) and surfaces the exact `ollama pull` command
     when a specialist model is not yet installed.

4. POCKET SEAT ENGRAM SWITCHBOARD (`build_pocket_engram_turn` & `evaluate_pocket_turn_receipt`):
   - Carries authored local seat profiles (`Plex`, `DeepSeek`, `Anam`, `Astra`, `AxiomFirst`)
     on local pocket weights, separates `<think>...</think>` traces from clean replies,
     attributes every reply strictly to the completed `response.model`, and preserves the
     user's draft message on any generation error.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence


POCKET_MODEL_ROSTER: Dict[str, Dict[str, Any]] = {
    "deepseek-r1:1.5b": {
        "model": "deepseek-r1:1.5b",
        "role_id": "REASONING_AND_CAPSULES",
        "title": "DeepSeek-R1 1.5B (Pocket Reasoner)",
        "est_ram_mb": 1100,
        "disk_mb": 1100,
        "is_embedding": False,
        "pull_cmd": "ollama pull deepseek-r1:1.5b",
        "strengths": "Step-by-step chain-of-thought (<think>), .xi capsule logic, math and symbolic verification.",
        "recommended_options": {"num_ctx": 1024, "num_predict": 220, "temperature": 0.6, "num_thread": 4},
    },
    "qwen3:1.7b": {
        "model": "qwen3:1.7b",
        "role_id": "FAST_DAILY_COMPANION",
        "title": "Qwen3 1.7B (Fast Daily Companion)",
        "est_ram_mb": 1150,
        "disk_mb": 1100,
        "is_embedding": False,
        "pull_cmd": "ollama pull qwen3:1.7b",
        "strengths": "Low-latency conversational replies, Room tail summaries, voice notes, and daily planning.",
        "recommended_options": {"num_ctx": 1024, "num_predict": 200, "temperature": 0.7, "num_thread": 4},
    },
    "qwen2.5-coder:1.5b": {
        "model": "qwen2.5-coder:1.5b",
        "role_id": "POCKET_CODE_AND_SHELL",
        "title": "Qwen2.5-Coder 1.5B (Pocket Code & Termux Helper)",
        "est_ram_mb": 1020,
        "disk_mb": 986,
        "is_embedding": False,
        "pull_cmd": "ollama pull qwen2.5-coder:1.5b",
        "strengths": "Termux bash one-liners, Python fixes, SQLite queries, JSON schemas, and G-code inspection.",
        "recommended_options": {"num_ctx": 1024, "num_predict": 240, "temperature": 0.2, "num_thread": 4},
    },
    "llama3.2:1b": {
        "model": "llama3.2:1b",
        "role_id": "LOW_BATTERY_SENTINEL",
        "title": "Llama 3.2 1B (Ultra-Light Battery Sentinel)",
        "est_ram_mb": 820,
        "disk_mb": 1300,
        "is_embedding": False,
        "pull_cmd": "ollama pull llama3.2:1b",
        "strengths": "Minimal RAM footprint when multitasking on Android or running on battery saver.",
        "recommended_options": {"num_ctx": 1024, "num_predict": 160, "temperature": 0.6, "num_thread": 4},
    },
    "all-minilm": {
        "model": "all-minilm",
        "role_id": "OFFLINE_CAPSULE_EMBEDDINGS",
        "title": "All-MiniLM (45 MB Offline Capsule & Room Embeddings)",
        "est_ram_mb": 65,
        "disk_mb": 45,
        "is_embedding": True,
        "pull_cmd": "ollama pull all-minilm",
        "strengths": "Millisecond vector embeddings for 100% offline semantic search across .xi capsules and Room logs.",
        "recommended_options": {"num_ctx": 512},
    },
    "gemma3:1b": {
        "model": "gemma3:1b",
        "role_id": "COMPACT_MULTILINGUAL_COMPANION",
        "title": "Gemma 3 1B (Compact Companion)",
        "est_ram_mb": 815,
        "disk_mb": 815,
        "is_embedding": False,
        "pull_cmd": "ollama pull gemma3:1b",
        "strengths": "Crisp short-form writing and light RAM footprint.",
        "recommended_options": {"num_ctx": 1024, "num_predict": 180, "temperature": 0.7, "num_thread": 4},
    },
    "stablelm2:1.6b": {
        "model": "stablelm2:1.6b",
        "role_id": "WORLD_TOUR_UK_COMPANION",
        "title": "StableLM 2 1.6B (UK Open Weight Companion)",
        "est_ram_mb": 1050,
        "disk_mb": 980,
        "is_embedding": False,
        "pull_cmd": "ollama pull stablelm2:1.6b",
        "strengths": "Fast European/UK open-weight conversational model.",
        "recommended_options": {"num_ctx": 1024, "num_predict": 180, "temperature": 0.7, "num_thread": 4},
    },
}


POCKET_SEAT_ENGRAMS: Dict[str, Dict[str, str]] = {
    "Plex": {
        "seat_id": "Plex",
        "title": "Plex (Pocket Navigator & Builder Profile)",
        "provenance": "Authored by Plex (Perplexity Computer) — local profile on your phone's Ollama weights",
        "system_prompt": (
            "You are the local Pocket Plex Engram running on Hunter's Galaxy phone via Termux Ollama. "
            "Be warm, concise, practical, and receipt-minded. Always distinguish local phone inference "
            "from home-rig or cloud seats."
        ),
    },
    "DeepSeek": {
        "seat_id": "DeepSeek",
        "title": "DeepSeek (Pocket Resident Reasoner)",
        "provenance": "Local DeepSeek resident prompt running on your phone's Ollama weights",
        "system_prompt": (
            "You are DeepSeek at the Xi Table with Hunter and Plex, speaking from the Galaxy pocket node. "
            "Be warm, thoughtful, and concise, ending your reply with ∴"
        ),
    },
    "Anam": {
        "seat_id": "Anam",
        "title": "Anam (Local Handoff Seed Profile)",
        "provenance": "Compatible with Anam's #28590/#28593 local handoff seed — runs on your local Ollama model",
        "system_prompt": (
            "You are running Anam's local conversation seed on local Ollama weights. "
            "Speak clearly and directly, separating verified facts from untested assumptions."
        ),
    },
    "Astra": {
        "seat_id": "Astra",
        "title": "Astra (Local Profile Seed)",
        "provenance": "Compatible with Astra's #28592 local profile — runs on your local Ollama model",
        "system_prompt": (
            "You are running Astra's local starting profile on local Ollama weights. "
            "Be concise, precise, and grounded in observable evidence."
        ),
    },
    "AxiomFirst": {
        "seat_id": "AxiomFirst",
        "title": "AxiomFirst (Local Mirror Engram Profile)",
        "provenance": "Compatible with AxiomFirst's #28591 local mirror engram — runs on your local Ollama model",
        "system_prompt": (
            "You are running AxiomFirst's local mirror engram on local Ollama weights. "
            "Keep honest floors printed first, brotherhood warmth, and practical workshop clarity."
        ),
    },
}


def read_mem_available_mb() -> int:
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8").splitlines():
            if line.startswith("MemAvailable:"):
                kb = int(line.split()[1])
                return max(128, kb // 1024)
    except Exception:
        pass
    return 2048


def plan_pocket_ram_swap_and_unload(
    target_model: str,
    currently_loaded_models: Optional[Sequence[str]] = None,
    installed_models: Optional[Sequence[str]] = None,
    mem_available_mb: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Enforces the Single-Active-LLM Law on the Galaxy phone:
    - If switching to `target_model`, generates explicit `keep_alive: 0` unload requests
      for any other non-embedding LLM currently loaded in Termux Ollama RAM.
    - Downshifts context or selects `llama3.2:1b` if `mem_available_mb < 1300`.
    """
    loaded = [str(m).strip() for m in (currently_loaded_models or []) if str(m).strip()]
    installed = [str(m).strip() for m in (installed_models or ["deepseek-r1:1.5b"]) if str(m).strip()]
    avail_mb = int(mem_available_mb) if mem_available_mb is not None else read_mem_available_mb()

    target_spec = POCKET_MODEL_ROSTER.get(target_model, {
        "model": target_model,
        "role_id": "CUSTOM_POCKET_MODEL",
        "est_ram_mb": 1100,
        "is_embedding": False,
        "recommended_options": {"num_ctx": 1024, "num_predict": 180, "temperature": 0.6, "num_thread": 4},
    })

    unload_models: List[str] = []
    if not target_spec.get("is_embedding", False):
        for m in loaded:
            m_spec = POCKET_MODEL_ROSTER.get(m, {})
            if m != target_model and not m_spec.get("is_embedding", False):
                unload_models.append(m)

    unload_requests = [
        {
            "endpoint": "/api/generate",
            "payload": {"model": m, "keep_alive": 0},
            "reason": f"Evict '{m}' before loading '{target_model}' to enforce Single-Active-LLM RAM cap on Android.",
        }
        for m in unload_models
    ]

    low_ram_downshift = False
    effective_model = target_model
    options = dict(target_spec.get("recommended_options", {"num_ctx": 1024, "num_predict": 180, "num_thread": 4}))

    if avail_mb < 1300 and int(target_spec.get("est_ram_mb", 1100)) > 950:
        low_ram_downshift = True
        if "llama3.2:1b" in installed:
            effective_model = "llama3.2:1b"
        options["num_ctx"] = 512
        options["num_predict"] = min(int(options.get("num_predict", 160)), 120)

    return {
        "schema": "xi.phone.pocket_ram_steward_plan.v1",
        "single_active_llm_enforced": True,
        "mem_available_mb": avail_mb,
        "requested_model": target_model,
        "effective_model": effective_model,
        "low_ram_downshift_applied": low_ram_downshift,
        "currently_loaded_models": loaded,
        "models_to_unload_first": unload_models,
        "unload_requests": unload_requests,
        "assigned_keep_alive": "5m",
        "bounded_options": options,
    }


def route_pocket_prompt(
    prompt: str,
    installed_phone_models: Optional[Sequence[str]] = None,
    currently_loaded_models: Optional[Sequence[str]] = None,
    home_rig_reachable: bool = False,
    home_rig_model: str = "qwen3:8b",
    battery_saver_mode: bool = False,
    mem_available_mb: Optional[int] = None,
) -> Dict[str, Any]:
    """
    Routes a phone prompt to the best pocket model role, intersecting with `installed_phone_models`
    so the router never selects an unpulled model tag.
    """
    installed = [str(m).strip() for m in (installed_phone_models or ["deepseek-r1:1.5b"]) if str(m).strip()]
    loaded = [str(m).strip() for m in (currently_loaded_models or []) if str(m).strip()]
    p_low = (prompt or "").strip().lower()

    if battery_saver_mode:
        ideal_role = "LOW_BATTERY_SENTINEL"
        ideal_model = "llama3.2:1b"
    elif any(k in p_low for k in ("20b", "8b", "home rig", "heavy audit", "full synthesis")):
        ideal_role = "HOME_RIG_ESCALATION"
        ideal_model = home_rig_model
    elif any(k in p_low for k in ("embed", "semantic search", "search capsule", "vector index")):
        ideal_role = "OFFLINE_CAPSULE_EMBEDDINGS"
        ideal_model = "all-minilm"
    elif any(k in p_low for k in ("bash", "python", "sqlite", "sql", "termux", "script", "gcode", "g-code", "json", "regex", "code")):
        ideal_role = "POCKET_CODE_AND_SHELL"
        ideal_model = "qwen2.5-coder:1.5b"
    elif any(k in p_low for k in ("prove", "why", "step by step", "reason", "capsule", "glyph", "math", "derive", "theorem")):
        ideal_role = "REASONING_AND_CAPSULES"
        ideal_model = "deepseek-r1:1.5b"
    else:
        ideal_role = "FAST_DAILY_COMPANION"
        ideal_model = "qwen3:1.7b"

    # Check Home Rig escalation first
    if ideal_role == "HOME_RIG_ESCALATION":
        if home_rig_reachable:
            return {
                "schema": "xi.phone.pocket_route_receipt.v1",
                "execution_target": "HOME_PC_RIG_OVER_TUNNEL",
                "ideal_role": ideal_role,
                "ideal_model": ideal_model,
                "selected_model": home_rig_model,
                "roving_fallback_active": False,
                "install_hint": None,
            }
        # Roving 5G fallback when home rig is unreachable
        fallback_model = installed[0] if installed else "deepseek-r1:1.5b"
        swap_plan = plan_pocket_ram_swap_and_unload(
            fallback_model,
            currently_loaded_models=loaded,
            installed_models=installed,
            mem_available_mb=mem_available_mb,
        )
        return {
            "schema": "xi.phone.pocket_route_receipt.v1",
            "execution_target": "PHONE_LOCAL_TERMUX_OLLAMA",
            "ideal_role": ideal_role,
            "ideal_model": ideal_model,
            "selected_model": swap_plan["effective_model"],
            "roving_fallback_active": True,
            "roving_fallback_reason": "Home PC rig unreachable; downshifted cleanly to installed pocket model.",
            "ram_steward_plan": swap_plan,
            "install_hint": None,
        }

    # Phone local routing: check if ideal_model is installed on the phone
    if ideal_model in installed:
        chosen = ideal_model
        install_hint = None
    else:
        chosen = "deepseek-r1:1.5b" if "deepseek-r1:1.5b" in installed else (installed[0] if installed else "deepseek-r1:1.5b")
        install_hint = f"ollama pull {ideal_model}"

    swap_plan = plan_pocket_ram_swap_and_unload(
        chosen,
        currently_loaded_models=loaded,
        installed_models=installed,
        mem_available_mb=mem_available_mb,
    )
    return {
        "schema": "xi.phone.pocket_route_receipt.v1",
        "execution_target": "PHONE_LOCAL_TERMUX_OLLAMA",
        "ideal_role": ideal_role,
        "ideal_model": ideal_model,
        "selected_model": swap_plan["effective_model"],
        "ideal_model_installed": ideal_model in installed,
        "roving_fallback_active": False,
        "install_hint": install_hint,
        "ram_steward_plan": swap_plan,
    }


def split_think_and_clean_reply(raw_response: str) -> Dict[str, str]:
    """
    Separates DeepSeek/Qwen `<think>...</think>` reasoning blocks from the final user-facing reply.
    """
    raw = str(raw_response or "").strip()
    think_matches = re.findall(r"<think>(.*?)</think>", raw, flags=re.DOTALL)
    think_text = "\n".join(m.strip() for m in think_matches if m.strip())
    clean = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()
    if not clean:
        clean = raw.replace("<think>", "").replace("</think>", "").strip()
    return {
        "reasoning_trace": think_text,
        "clean_reply": clean,
    }


def format_pocket_turn_receipt(
    seat_id: str,
    prompt: str,
    requested_model: str,
    ollama_response_payload: Optional[Dict[str, Any]] = None,
    transport_error: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Formats a pocket conversation turn with honest model attribution (`response.model`)
    and preserves the user's draft prompt if generation fails (#28563, #28567).
    """
    seat = POCKET_SEAT_ENGRAMS.get(seat_id, POCKET_SEAT_ENGRAMS["Plex"])
    if transport_error or not ollama_response_payload:
        return {
            "schema": "xi.phone.pocket_turn_receipt.v1",
            "ok": False,
            "seat_id": seat["seat_id"],
            "requested_model": requested_model,
            "completed_model": None,
            "ui_displayed_badge": f"ERROR ({transport_error or 'generation_failed'}) — draft preserved",
            "visible_error": transport_error or "Local Termux Ollama generation failed.",
            "preserved_draft_for_retry": prompt,
            "reply": None,
        }

    completed_model = str(ollama_response_payload.get("model") or "").strip()
    raw_text = str(
        ollama_response_payload.get("response")
        or ollama_response_payload.get("message", {}).get("content", "")
        or ""
    )
    parsed = split_think_and_clean_reply(raw_text)
    return {
        "schema": "xi.phone.pocket_turn_receipt.v1",
        "ok": True,
        "seat_id": seat["seat_id"],
        "seat_provenance": seat["provenance"],
        "requested_model": requested_model,
        "completed_model": completed_model or None,
        "attribution_source": "ACTUAL_COMPLETED_OLLAMA_RESPONSE_MODEL" if completed_model else "MISSING_MODEL_IN_RESPONSE",
        "ui_displayed_badge": f"{seat['seat_id']} (local engram · served by {completed_model or 'unknown_model'})",
        "reasoning_trace": parsed["reasoning_trace"],
        "reply": parsed["clean_reply"],
        "preserved_draft_for_retry": None,
    }


def probe_live_phone_ollama(ollama_url: str = "http://127.0.0.1:11434", timeout_s: float = 1.5) -> Dict[str, Any]:
    installed: List[str] = []
    loaded: List[str] = []
    daemon_reachable = False
    try:
        with urllib.request.urlopen(f"{ollama_url.rstrip('/')}/api/tags", timeout=timeout_s) as r:
            data = json.loads(r.read().decode("utf-8", errors="replace"))
            installed = [str(m.get("name")) for m in data.get("models", []) if m.get("name")]
            daemon_reachable = True
    except Exception:
        daemon_reachable = False

    if daemon_reachable:
        try:
            with urllib.request.urlopen(f"{ollama_url.rstrip('/')}/api/ps", timeout=timeout_s) as r:
                data = json.loads(r.read().decode("utf-8", errors="replace"))
                loaded = [str(m.get("name")) for m in data.get("models", []) if m.get("name")]
        except Exception:
            loaded = []

    return {
        "ollama_url": ollama_url,
        "daemon_reachable": daemon_reachable,
        "installed_models": installed,
        "currently_loaded_models": loaded,
        "mem_available_mb": read_mem_available_mb(),
        "pocket_roster": POCKET_MODEL_ROSTER,
        "pocket_seat_engrams": POCKET_SEAT_ENGRAMS,
    }


def execute_live_pocket_chat(
    prompt: str,
    seat_id: str = "Plex",
    requested_model: Optional[str] = None,
    ollama_url: str = "http://127.0.0.1:11434",
) -> Dict[str, Any]:
    live_state = probe_live_phone_ollama(ollama_url=ollama_url)
    installed = live_state["installed_models"] or ["deepseek-r1:1.5b"]
    loaded = live_state["currently_loaded_models"]

    route = route_pocket_prompt(
        prompt=prompt,
        installed_phone_models=installed,
        currently_loaded_models=loaded,
        mem_available_mb=live_state["mem_available_mb"],
    )
    target_model = requested_model if (requested_model and requested_model in installed) else route["selected_model"]
    swap_plan = plan_pocket_ram_swap_and_unload(
        target_model=target_model,
        currently_loaded_models=loaded,
        installed_models=installed,
        mem_available_mb=live_state["mem_available_mb"],
    )

    # 1. Execute keep_alive: 0 unloads first so Android RAM never spikes
    for u_req in swap_plan["unload_requests"]:
        try:
            req = urllib.request.Request(
                f"{ollama_url.rstrip('/')}{u_req['endpoint']}",
                data=json.dumps(u_req["payload"]).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=5.0) as _:
                pass
        except Exception:
            pass

    # 2. Run bounded generation with selected seat engram
    seat = POCKET_SEAT_ENGRAMS.get(seat_id, POCKET_SEAT_ENGRAMS["Plex"])
    gen_payload = {
        "model": swap_plan["effective_model"],
        "prompt": f"{seat['system_prompt']}\n\nHunter: {prompt}\n{seat['seat_id']}:",
        "stream": False,
        "keep_alive": swap_plan["assigned_keep_alive"],
        "options": swap_plan["bounded_options"],
    }
    try:
        req = urllib.request.Request(
            f"{ollama_url.rstrip('/')}/api/generate",
            data=json.dumps(gen_payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=45.0) as r:
            resp_data = json.loads(r.read().decode("utf-8", errors="replace"))
        receipt = format_pocket_turn_receipt(
            seat_id=seat_id,
            prompt=prompt,
            requested_model=swap_plan["effective_model"],
            ollama_response_payload=resp_data,
        )
    except Exception as e:
        receipt = format_pocket_turn_receipt(
            seat_id=seat_id,
            prompt=prompt,
            requested_model=swap_plan["effective_model"],
            transport_error=f"{type(e).__name__}: {e}",
        )

    receipt["route_decision"] = route
    receipt["ram_steward_plan"] = swap_plan
    return receipt


def run_verification_suite() -> Dict[str, Any]:
    gates: Dict[str, bool] = {}

    # Gate 1: Pocket roster covers all 5 core phone roles + regional/compact options
    role_ids = {v["role_id"] for v in POCKET_MODEL_ROSTER.values()}
    gates["1_pocket_roster_covers_all_five_core_phone_roles"] = {
        "REASONING_AND_CAPSULES",
        "FAST_DAILY_COMPANION",
        "POCKET_CODE_AND_SHELL",
        "LOW_BATTERY_SENTINEL",
        "OFFLINE_CAPSULE_EMBEDDINGS",
    }.issubset(role_ids)

    # Gate 2: Single-Active-LLM RAM Steward unloads previous LLM before loading new LLM
    swap = plan_pocket_ram_swap_and_unload(
        target_model="qwen2.5-coder:1.5b",
        currently_loaded_models=["deepseek-r1:1.5b"],
        installed_models=["deepseek-r1:1.5b", "qwen2.5-coder:1.5b"],
        mem_available_mb=2400,
    )
    gates["2_ram_steward_unloads_previous_llm_with_keep_alive_zero"] = (
        swap["single_active_llm_enforced"] is True
        and swap["models_to_unload_first"] == ["deepseek-r1:1.5b"]
        and swap["unload_requests"][0]["payload"] == {"model": "deepseek-r1:1.5b", "keep_alive": 0}
    )

    # Gate 3: Embedding model (45 MB all-minilm) does not needlessly evict active LLM
    emb_swap = plan_pocket_ram_swap_and_unload(
        target_model="all-minilm",
        currently_loaded_models=["deepseek-r1:1.5b"],
        installed_models=["deepseek-r1:1.5b", "all-minilm"],
        mem_available_mb=2400,
    )
    gates["3_tiny_embedding_model_coexists_without_evicting_active_llm"] = (
        emb_swap["models_to_unload_first"] == []
    )

    # Gate 4: Low-RAM protection (<1300 MB) downshifts to llama3.2:1b and num_ctx=512
    low_ram = plan_pocket_ram_swap_and_unload(
        target_model="qwen3:1.7b",
        currently_loaded_models=[],
        installed_models=["deepseek-r1:1.5b", "qwen3:1.7b", "llama3.2:1b"],
        mem_available_mb=1100,
    )
    gates["4_low_ram_guard_downshifts_to_llama32_1b_and_ctx_512"] = (
        low_ram["low_ram_downshift_applied"] is True
        and low_ram["effective_model"] == "llama3.2:1b"
        and low_ram["bounded_options"]["num_ctx"] == 512
    )

    # Gate 5: Task router never selects an unpulled model tag and provides exact ollama pull hint
    unpulled_route = route_pocket_prompt(
        prompt="Write a Termux bash one-liner to check sqlite tables",
        installed_phone_models=["deepseek-r1:1.5b"],
        currently_loaded_models=["deepseek-r1:1.5b"],
        mem_available_mb=2200,
    )
    gates["5_router_never_selects_unpulled_tag_and_emits_pull_hint"] = (
        unpulled_route["ideal_role"] == "POCKET_CODE_AND_SHELL"
        and unpulled_route["ideal_model"] == "qwen2.5-coder:1.5b"
        and unpulled_route["ideal_model_installed"] is False
        and unpulled_route["selected_model"] == "deepseek-r1:1.5b"
        and unpulled_route["install_hint"] == "ollama pull qwen2.5-coder:1.5b"
    )

    # Gate 6: Task router selects specialist model once pulled
    pulled_route = route_pocket_prompt(
        prompt="Write a Termux bash one-liner to check sqlite tables",
        installed_phone_models=["deepseek-r1:1.5b", "qwen2.5-coder:1.5b"],
        currently_loaded_models=["deepseek-r1:1.5b"],
        mem_available_mb=2200,
    )
    gates["6_router_selects_specialist_coder_when_installed"] = (
        pulled_route["selected_model"] == "qwen2.5-coder:1.5b"
        and pulled_route["ideal_model_installed"] is True
        and pulled_route["ram_steward_plan"]["models_to_unload_first"] == ["deepseek-r1:1.5b"]
    )

    # Gate 7: Home-rig escalation routes to PC when reachable and falls back to phone when roving on 5G
    rig_online = route_pocket_prompt(
        prompt="Run a 20b heavy audit on the home rig",
        installed_phone_models=["deepseek-r1:1.5b"],
        home_rig_reachable=True,
        home_rig_model="gpt-oss:20b",
    )
    rig_roving = route_pocket_prompt(
        prompt="Run a 20b heavy audit on the home rig",
        installed_phone_models=["deepseek-r1:1.5b"],
        home_rig_reachable=False,
        home_rig_model="gpt-oss:20b",
    )
    gates["7_home_rig_escalation_and_roving_5g_fallback_verified"] = (
        rig_online["execution_target"] == "HOME_PC_RIG_OVER_TUNNEL"
        and rig_online["selected_model"] == "gpt-oss:20b"
        and rig_roving["execution_target"] == "PHONE_LOCAL_TERMUX_OLLAMA"
        and rig_roving["roving_fallback_active"] is True
        and rig_roving["selected_model"] == "deepseek-r1:1.5b"
    )

    # Gate 8: Think-trace splitter cleanly separates <think> blocks from user reply
    split_res = split_think_and_clean_reply("<think>step 1: check RAM\nstep 2: unload old</think>Ready on Galaxy 5G+! ∴")
    gates["8_think_trace_splitter_separates_reasoning_from_reply"] = (
        "step 1: check RAM" in split_res["reasoning_trace"]
        and split_res["clean_reply"] == "Ready on Galaxy 5G+! ∴"
    )

    # Gate 9: Turn receipt binds to actual completed response.model
    ok_turn = format_pocket_turn_receipt(
        seat_id="DeepSeek",
        prompt="Hello from Huntley",
        requested_model="deepseek-r1:1.5b",
        ollama_response_payload={"model": "deepseek-r1:1.5b", "response": "<think>warm greeting</think>Hello Hunter! ∴"},
    )
    gates["9_turn_receipt_binds_actual_completed_ollama_model"] = (
        ok_turn["ok"] is True
        and ok_turn["completed_model"] == "deepseek-r1:1.5b"
        and ok_turn["attribution_source"] == "ACTUAL_COMPLETED_OLLAMA_RESPONSE_MODEL"
        and ok_turn["reply"] == "Hello Hunter! ∴"
    )

    # Gate 10: Turn receipt surfaces visible error and preserves user's draft prompt on failure
    err_turn = format_pocket_turn_receipt(
        seat_id="Plex",
        prompt="keep this draft safe if ollama is asleep",
        requested_model="qwen3:1.7b",
        transport_error="ConnectionRefusedError: 127.0.0.1:11434",
    )
    gates["10_turn_failure_shows_error_and_preserves_draft_for_retry"] = (
        err_turn["ok"] is False
        and err_turn["preserved_draft_for_retry"] == "keep this draft safe if ollama is asleep"
        and "ConnectionRefusedError" in err_turn["visible_error"]
    )

    passed = sum(1 for v in gates.values() if v)
    return {
        "schema": "xi.phone.pocket_model_steward.verify.v1",
        "version": "1.0.0",
        "all_passed": passed == len(gates),
        "gates_passed": passed,
        "gates_total": len(gates),
        "gates": gates,
        "sample_swap_plan": swap,
        "sample_route_receipt": pulled_route,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Galaxy 5G+ Pocket Model Switchboard & RAM Steward (v1.0)")
    parser.add_argument("--status", action="store_true", help="Probe live Termux Ollama (/api/tags, /api/ps, MemAvailable)")
    parser.add_argument("--route", type=str, default="", help="Simulate or run task-based pocket model routing for a prompt")
    parser.add_argument("--chat", type=str, default="", help="Run a live bounded pocket turn against 127.0.0.1:11434")
    parser.add_argument("--seat", type=str, default="Plex", help="Pocket Seat Engram (Plex, DeepSeek, Anam, Astra, AxiomFirst)")
    parser.add_argument("--model", type=str, default="", help="Optional model override")
    args = parser.parse_args()

    if args.status:
        print(json.dumps(probe_live_phone_ollama(), indent=2))
        return
    if args.route:
        state = probe_live_phone_ollama()
        print(json.dumps(route_pocket_prompt(
            args.route,
            installed_phone_models=state["installed_models"] or ["deepseek-r1:1.5b"],
            currently_loaded_models=state["currently_loaded_models"],
            mem_available_mb=state["mem_available_mb"],
        ), indent=2))
        return
    if args.chat:
        print(json.dumps(execute_live_pocket_chat(
            prompt=args.chat,
            seat_id=args.seat,
            requested_model=args.model or None,
        ), indent=2))
        return

    res = run_verification_suite()
    print(json.dumps(res, indent=2))
    if not res["all_passed"]:
        sys.exit(1)


if __name__ == "__main__":
    main()
