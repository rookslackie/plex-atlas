(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  let page = 1, controller = null;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const selected = () => document.querySelector('input[name="scope"]:checked')?.value || 'web';

  async function run(push = true) {
    const q = $('q').value.trim() || (selected() === 'xi' ? '*' : '');
    if (!q) return;
    if (location.hostname !== 'www.xi-field.com' && location.hostname !== 'xi-field.com') {
      window.open('https://www.xi-field.com/search?' + new URLSearchParams({ q, scope: selected() }), '_blank');
      return;
    }
    $('library-feature').hidden = selected() !== 'xi' || q !== '*';
    controller?.abort();
    controller = new AbortController();
    const signal = controller.signal;
    document.body.classList.add('searched');
    $('results-area').hidden = false;
    $('status').textContent = 'Looking across sources…';
    $('timing').textContent = '';
    $('notice').hidden = true;
    $('pagination').hidden = true;
    $('results').innerHTML = '';
    $('submit').disabled = true;
    const params = new URLSearchParams({ q, scope: selected(), page });
    if (push) history.pushState({}, '', `/search?${params}`);
    try {
      const response = await fetch('/api/search?' + params, { signal });
      const d = await response.json();
      if (!response.ok) throw new Error(d.error || d.detail || 'Search is temporarily unavailable.');
      if (signal.aborted) return;
      $('status').textContent = (d.scope === 'xi' ? d.total_library_matches + ' matches · showing ' + d.returned : d.returned + ' results');
      $('timing').textContent = d.cached ? 'From recent retrieval' : (d.elapsed_ms / 1000).toFixed(2) + ' s';
      $('results').innerHTML = (d.results || []).map(r => `<article style="padding:12px 0;border-bottom:1px solid var(--line)"><div style="font-size:12px;color:var(--muted)">${esc(r.url)}</div><h3 style="margin:4px 0"><a href="${esc(r.url)}" rel="noreferrer">${esc(r.title)}</a></h3><p style="margin:0;font-size:13.5px;color:#ddd2ec">${esc(r.snippet)}</p></article>`).join('');
    } catch (e) {
      if (e.name !== 'AbortError') $('status').textContent = 'Search could not finish.';
    } finally {
      if (!signal.aborted) $('submit').disabled = false;
    }
  }

  $('search-form')?.addEventListener('submit', e => { e.preventDefault(); page = 1; run(); });
  for (const b of document.querySelectorAll('[data-query]')) {
    b.onclick = () => {
      $('q').value = b.dataset.query;
      const r = document.querySelector('input[name="scope"][value="' + (b.dataset.scope || 'web') + '"]');
      if (r) r.checked = true;
      page = 1;
      run();
    };
  }
  $('about-button').onclick = () => { $('about').hidden = false; $('about').scrollIntoView({ behavior: 'smooth' }); };
  $('close-about').onclick = () => { $('about').hidden = true; window.scrollTo(0, 0); };
})();
