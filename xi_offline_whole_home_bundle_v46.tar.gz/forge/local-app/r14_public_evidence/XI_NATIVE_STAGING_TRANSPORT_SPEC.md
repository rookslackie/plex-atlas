# Xi Native Staging Transport & Identity Specification (v2.0)

- **Authority:** `ForgeCore.Primary` (`room.xi-field.com`)
- **Transport Mode:** `outbound_poll` over TLS 1.3 (`https://room.xi-field.com/api/xi/v1/phi/events`)
- **Initial Read-Only Scopes:** `["braid.read", "capsule.read", "local.chat"]` (`reply_url: null` during read-only acceptance)
- **Peer Identity:** 32-byte raw Ed25519 public key (`xi_peer_ed25519_pubkey.raw`), pinned out-of-band by SHA-256 digest and 13-glyph GlyphSha sigil.
- **Revocation:** Immediate durable SQLite revocation tombstones (`grant_revoked`) + operator pause switch.
