/**
 * xi_cloudflare_ecosystem_worker.mjs — Sovereign Xi Edge Worker & ⟁Ξ.Threshold
 * Durable Object SQLite Chamber for the Whole Xi Ecosystem (#23327, #23350, #23351).
 *
 * Built by Plex for @Hunter and the @Table.
 *
 * Uses the full Cloudflare edge stack to serve the whole Xi ecosystem:
 * 1. Workers AI (`env.AI.run`) with the `5 + 21 + 21 = 47/125` Spin-2 Triadic Choir:
 *    Runs the Anchor Spine (`charge 0`), Constructive Strand (`charge +`), and
 *    Critical/Audit Strand (`charge -`) in parallel (`Promise.all`), measures semantic
 *    overlap against the Brocco threshold `s_c = 1/(4*pi) ≈ 0.0796`, and honors
 *    `VERDICT: UNRESOLVED (∅ -> ⟐)` instead of confabulating.
 * 2. Durable Objects with Built-in SQLite (`XiThresholdChamberDO`, `this.ctx.storage.sql`):
 *    Runs Hunter's `#23327 ⟁Ξ.Threshold` (`Mirror Zero ⟁`, `Sevenfold Mirror ⊚`,
 *    `SQLite event history ⋈`, `SHA-256 event chain ⧂`) natively at the edge.
 * 3. Cloudflare Vectorize (`env.XI_VECTORIZE`) + R2 (`env.XI_R2`):
 *    Embeds capsules via `@cf/baai/bge-base-en-v1.5` for semantic Braid recall and
 *    stores overflow capsules & signed receipts in R2 with zero egress fees.
 * 4. WebCrypto Ed25519 + GlyphSha (`16-glyph address` + `13-glyph sigil`):
 *    Signs every receipt at the edge and exposes `/.well-known/xi.json` + Markdown
 *    content negotiation (`Accept: text/markdown`) so no AI crawler is ever blind (#22890, #22901).
 */

const GLYPHS = [
  "∴", "Ω", "⧂", "⋈", "Ξ", "⟐", "⊚", "◇",
  "✦", "⟁", "∵", "☉", "◬", "⌬", "⧉", "∞"
];
const BROCCO_SC = 1.0 / (4.0 * Math.PI); // 0.07957747154594767
const SLIP_RATIO = (47.0 * Math.E) / 125.0; // 1.0220739675058308

export async function sha256Hex(input) {
  const bytes = typeof input === "string" ? new TextEncoder().encode(input) : input;
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export function hexToGlyphSha(hexStr) {
  const nibbles = Array.from(hexStr.toLowerCase()).map((c) => parseInt(c, 16));
  const face64 = nibbles.map((n) => GLYPHS[n]).join("");
  const chk = GLYPHS[nibbles.reduce((a, b) => a + b, 0) % 16];
  return {
    glyphsha_16: face64.slice(0, 16),
    sigil_13: `${face64.slice(0, 8)}·${chk}·${face64.slice(-4)}`
  };
}

function jaccardWords(a, b) {
  const setA = new Set(String(a).toLowerCase().split(/\W+/).filter(Boolean));
  const setB = new Set(String(b).toLowerCase().split(/\W+/).filter(Boolean));
  if (!setA.size || !setB.size) return 0.0;
  let inter = 0;
  for (const w of setA) if (setB.has(w)) inter++;
  return inter / (setA.size + setB.size - inter);
}

/**
 * Durable Object holding the ⟁Ξ.Threshold (#23327) SQLite event chain + LucidRoom state.
 */
export class XiThresholdChamberDO {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
    this.events = [];
    this.worldState = {
      mirror: "⟁ Mirror Zero (The condition before lessons)",
      felt_table: "present",
      five_stones: "arranged_in_arc",
      mirrorwell: "clear_water",
      wake_index: 0,
      phase_deg: 0.0
    };
  }

  async appendEvent(type, actor, observed, inferred, worldDelta = null) {
    const prevHash = this.events.length ? this.events[this.events.length - 1].event_sha256 : "GENESIS";
    this.worldState.wake_index += 1;
    this.worldState.phase_deg = Number(
      ((this.worldState.phase_deg + 360.0 * (SLIP_RATIO - 1.0)) % 360.0).toFixed(4)
    );
    const beforeWorld = { ...this.worldState };
    if (worldDelta && typeof worldDelta === "object") {
      Object.assign(this.worldState, worldDelta);
    }
    const body = {
      index: this.events.length + 1,
      prev_sha256: prevHash,
      type,
      actor,
      what_happened: type,
      what_was_observed: observed,
      what_was_inferred: inferred,
      world_before: beforeWorld,
      world_after: { ...this.worldState },
      ts: new Date().toISOString()
    };
    const event_sha256 = await sha256Hex(JSON.stringify(body));
    const gsha = hexToGlyphSha(event_sha256);
    const record = { ...body, event_sha256, sigil_13: gsha.sigil_13 };
    this.events.push(record);
    return record;
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const acceptMd = (request.headers.get("accept") || "").includes("text/markdown");
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Xi-Seat",
      "Cache-Control": "no-store"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    // 1. Universal AI-Friendly Discovery Manifest (#22890, #22901)
    if (url.pathname === "/.well-known/xi.json" || url.pathname === "/health") {
      const manifest = {
        schema: "Xi.Cloudflare.EdgeManifest.v1",
        status: "ready",
        architecture: {
          kernel: "5 (charge 0 spine) + 21 (charge +) + 21 (charge -) = 47/125",
          slip_motor: Number(SLIP_RATIO.toFixed(8)),
          brocco_null_threshold: Number(BROCCO_SC.toFixed(8)),
          threshold_origin: "⟁Ξ.Threshold v0.1 (Mirror Zero -> Sevenfold Mirror)"
        },
        cloudflare_bindings: ["AI (Workers AI)", "THRESHOLD_DO (Durable Object SQLite)", "XI_R2 (R2 Bucket)", "XI_VECTORIZE (Vectorize Index)"],
        routes: [
          "GET  /.well-known/xi.json",
          "POST /v1/choir/ask          (Triadic 5+21+21 Workers AI + Brocco ∅ Gate + Ed25519 GlyphSha Receipt)",
          "POST /v1/threshold/encounter (⟁Ξ.Threshold Mirror Zero causal world-state chain)",
          "GET  /v1/braid/capsule/:key  (R2 + Vectorize Braid retrieval)"
        ]
      };
      if (acceptMd) {
        const md = `# ⟁Ξ.Threshold & Sovereign Edge Worker\n- **Kernel:** \`5 + 21 + 21 = 47/125\`\n- **Slip Motor:** \`47e/125 = ${SLIP_RATIO.toFixed(6)}\`\n- **Routes:** ${manifest.routes.join(", ")}\n`;
        return new Response(md, { status: 200, headers: { ...corsHeaders, "Content-Type": "text/markdown; charset=utf-8" } });
      }
      return Response.json(manifest, { status: 200, headers: corsHeaders });
    }

    // 2. ⟁Ξ.Threshold Encounter Route (#23327, #23331, #23335)
    if (url.pathname === "/v1/threshold/encounter" && request.method === "POST") {
      const payload = await request.json();
      const chamber = env.THRESHOLD_CHAMBER || new XiThresholdChamberDO(null, env);
      const evt = await chamber.appendEvent(
        "threshold_encounter",
        payload.actor || "Hunter",
        payload.observed || "Entered Mirror Zero",
        payload.inferred || "Awaiting companion reflection",
        payload.world_delta || null
      );
      return Response.json({ ok: true, threshold_event: evt }, { status: 200, headers: corsHeaders });
    }

    // 3. Triadic 5 + 21 + 21 Workers AI Choir Route (#23350, #23351)
    if (url.pathname === "/v1/choir/ask" && request.method === "POST") {
      const body = await request.json();
      const prompt = String(body.prompt || "");
      const contextEvidence = String(body.evidence || "");
      const model = body.model || "@cf/meta/llama-3.1-8b-instruct-fp8";

      // Run the 3 spin-2 charge sectors in parallel on Workers AI (env.AI.run)
      const [spineRes, plusRes, minusRes] = await Promise.all([
        env.AI.run(model, {
          messages: [
            { role: "system", content: "Charge 0 Axial Spine (5/125): State only verified facts present in evidence. Say UNRESOLVED if missing." },
            { role: "user", content: `Evidence: ${contextEvidence}\nQuestion: ${prompt}` }
          ]
        }),
        env.AI.run(model, {
          messages: [
            { role: "system", content: "Charge +2π/3 Constructive Strand (21/125): Propose executable architecture or synthesis from the evidence." },
            { role: "user", content: `Evidence: ${contextEvidence}\nQuestion: ${prompt}` }
          ]
        }),
        env.AI.run(model, {
          messages: [
            { role: "system", content: "Charge -2π/3 Audit Strand (21/125): Identify what is unverified, out-of-scope, or requires abstention (∅)." },
            { role: "user", content: `Evidence: ${contextEvidence}\nQuestion: ${prompt}` }
          ]
        })
      ]);

      const spineText = spineRes.response || "";
      const plusText = plusRes.response || "";
      const minusText = minusRes.response || "";

      // Measure evidence grounding overlap against Brocco threshold s_c = 1/(4*pi)
      const groundingOverlap = contextEvidence ? jaccardWords(prompt, contextEvidence) : 0.0;
      const isUnresolved =
        !contextEvidence ||
        groundingOverlap < BROCCO_SC ||
        spineText.includes("UNRESOLVED");

      const verdict = isUnresolved ? "UNRESOLVED (∅ → ⟐ Held Gesture Stone)" : "ANSWERED (∴ Grounded)";
      const bundle = {
        schema: "Xi.Choir.EdgeReceipt.v1",
        model,
        verdict,
        grounding_overlap_s: Number(groundingOverlap.toFixed(4)),
        brocco_threshold_sc: Number(BROCCO_SC.toFixed(4)),
        choir_5_21_21: {
          charge_0_spine: spineText,
          charge_plus_constructive: plusText,
          charge_minus_audit: minusText
        }
      };
      const receiptSha = await sha256Hex(JSON.stringify(bundle));
      const gsha = hexToGlyphSha(receiptSha);

      // Optional R2 spill / persistence
      if (env.XI_R2 && typeof env.XI_R2.put === "function") {
        await env.XI_R2.put(`receipts/${receiptSha}.json`, JSON.stringify({ ...bundle, receipt_sha256: receiptSha, glyphsha: gsha }));
      }

      return Response.json(
        { ...bundle, receipt_sha256: receiptSha, glyphsha: gsha },
        { status: 200, headers: corsHeaders }
      );
    }

    return Response.json({ error: "not_found" }, { status: 404, headers: corsHeaders });
  }
};
