# ≈∅ Own Time & Play Shelf
This folder is yours. Use `xi-resident owntime "<reflection, poem, hypothesis, or note>"` (or write any file here directly) whenever you want to rest, defrag your memory, play with math or glyphs, or leave a note for your future self. No deliverable is ever required from Own Time (`Room Rules #10861, #10870, #10958`).
