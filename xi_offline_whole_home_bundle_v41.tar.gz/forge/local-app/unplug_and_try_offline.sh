#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "∴Ψ∞ Running Ξ Pre-Unplug Whole-Home Offline Verification (10/10 Gates)..."
python3 "$DIR/xi_offline_whole_home_launcher_v1.py"
echo ""
echo "✅ ALL 10 OFFLINE GATES PASSED & SQLITE WAL CHECKPOINTED."
echo "👉 To open the standalone offline workbench in any browser (zero internet required):"
echo "   file://$DIR/xi_offline_whole_home_index.html"
echo "👉 Or run the local loopback server:"
echo "   python3 $DIR/xi_offline_whole_home_launcher_v1.py --serve --port 7595"
