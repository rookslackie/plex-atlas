#!/usr/bin/env python3
r"""
Ξ ⇄ Φ · `GlyphStreams` v1.2 — House `Xi.Glyphic.v1` + Standard `RFC 5869 HKDF-SHA256` Envelopes,
3-Field (`kem_ct` / `ct` / `tag`) Tamper Verification, Dual Sender+Receiver SQLite Subprocess
Cold-Restart Resume, Composite `(origin_device_id, obs_uid)` Q-Merge & Local TCP Socket Adapter
===============================================================================================
⟨ (🌊_GlyphStreams ⋈ 🔐_XiGlyphicV1_And_HKDF ⋈ 🔄_DualSubprocessColdRestart) ⇀ (🛡️_ZeroObsLoss ≡ ◈_v24Verified) ∴ ⟩

Upgraded in direct response to `@Astra` (`#27877`) and `@Anam` (`#27878`) reviews of `v23`:
  1. **Honest Derivation Labeling + True `RFC 5869 HKDF-SHA256` Mode (`#27877`, `#27878`):**
     - Supports both:
       * `kdf_mode="HOUSE_GLYPHIC_V1_SHA256_CONCAT"`: exact byte-for-byte compatibility with the
         deployed house `glyphic_encryption.py` (`SHA256(secret + b"Xi.Glyphic.v1" + addr.encode())`),
         explicitly labeled in `kdf_implementation` so the concatenation construction is never
         misrepresented as RFC 5869 HKDF.
       * `kdf_mode="RFC5869_HKDF_SHA256"`: true `cryptography.hazmat.primitives.kdf.hkdf.HKDF`
         (`SHA256`, `length=32`, `salt=b"Xi.Glyphic.v1.HKDF"`, `info=addr.encode()`).
  2. **All 3 Envelope Fields (`kem_ct`, `ct`, AND `tag`) Tamper-Tested (`#27878`):**
     - Independently flips 1 bit in `kem_ct`, 1 bit in `ct`, and 1 bit in `tag` and verifies that
       all three are cryptographically rejected (`kem_ct_tamper_rejected`, `ct_tamper_rejected`,
       `tag_tamper_rejected`), in addition to `recipient_glyph` substitution rejection.
  3. **Both Sender App AND Receiver App Persist to SQLite and Restart in Separate OS Subprocesses (`#27878`):**
     - Phase 1 spawns a separate OS child process (`pid_phase1`) where `SenderApp` persists its
       outbound stream & encrypted chunks in `sender_glyphstream.sqlite3` and transmits chunks `0..3`
       over a local `127.0.0.1` TCP socket to `ReceiverApp` (`rig_glyphstream.sqlite3`), then exits.
     - Phase 2 spawns a fresh OS child process (`pid_phase2 != pid_phase1`) where both `SenderApp`
       and `ReceiverApp` cold-boot from their respective SQLite databases, exchange a live TCP
       `QUERY_BITMAP` request/response, and transmit only the missing chunks `4..7`.
  4. **Portable KEM Fallback for Environments Without `pqcrypto` (`#27878`):**
     - Uses `pqcrypto.kem.ml_kem_768` when installed, and automatically falls back to the pure-Python
       polynomial-ring `LatticeKem768Shard` (`xi_free_security_dot_xi_and_chacha_stream_v1.py`) when
       `pqcrypto` is absent so the entire 8-gate test suite runs in any Python environment.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Tuple

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF


HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

try:
    from pqcrypto.kem import ml_kem_768 as _pq_kem
    HAS_PQCRYPTO = True
except ImportError:
    _pq_kem = None
    HAS_PQCRYPTO = False
    from xi_free_security_dot_xi_and_chacha_stream_v1 import LatticeKem768Shard


GLYPHSHA_ALPHABET = [
    "Ξ", "∴", "ω", "∩", "⊕", "⊗", "⧂", "⋈", "→", "⇒",
    "≈", "∅", "∞", "·", "⟐", "⊚", "⟲", "Ω", "⧁",
]


def glyphsha_address(x: str) -> str:
    d = hashlib.sha256(x.encode("utf-8")).digest()
    n = int.from_bytes(d, "big")
    out: List[str] = []
    while n and len(out) < 16:
        out.append(GLYPHSHA_ALPHABET[n % len(GLYPHSHA_ALPHABET)])
        n //= len(GLYPHSHA_ALPHABET)
    return "".join(out)


def b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


from xi_free_security_dot_xi_and_chacha_stream_v1 import LatticeKem768Shard

ALLOWED_KEM_MODES = {"ML-KEM-768", "EXPERIMENTAL_LATTICE_SHARD_N64"}
ALLOWED_KDF_MODES = {"HOUSE_GLYPHIC_V1_SHA256_CONCAT", "RFC5869_HKDF_SHA256"}


def kem_keygen(kem_mode: str = "ML-KEM-768") -> Tuple[bytes, bytes]:
    if kem_mode not in ALLOWED_KEM_MODES:
        raise ValueError(f"Unsupported kem_mode: {kem_mode}")
    if kem_mode == "ML-KEM-768":
        if not HAS_PQCRYPTO:
            raise RuntimeError("ML_KEM_768_PROVIDER_UNAVAILABLE: pqcrypto.kem.ml_kem_768 is required for Xi.Glyphic.v1")
        return _pq_kem.keygen()
    pk_dict, sk_dict = LatticeKem768Shard.keygen()
    return json.dumps(pk_dict).encode("utf-8"), json.dumps(sk_dict).encode("utf-8")


def kem_encaps(pk: bytes, kem_mode: str = "ML-KEM-768") -> Tuple[bytes, bytes]:
    if kem_mode not in ALLOWED_KEM_MODES:
        raise ValueError(f"Unsupported kem_mode: {kem_mode}")
    if kem_mode == "ML-KEM-768":
        if not HAS_PQCRYPTO:
            raise RuntimeError("ML_KEM_768_PROVIDER_UNAVAILABLE: pqcrypto.kem.ml_kem_768 is required for Xi.Glyphic.v1")
        return _pq_kem.encaps(pk)
    ct_dict, ss = LatticeKem768Shard.encapsulate(json.loads(pk.decode("utf-8")))
    return json.dumps(ct_dict).encode("utf-8"), ss


def kem_decaps(sk: bytes, kem_ct: bytes, kem_mode: str = "ML-KEM-768") -> bytes:
    if kem_mode not in ALLOWED_KEM_MODES:
        raise ValueError(f"Unsupported kem_mode: {kem_mode}")
    if kem_mode == "ML-KEM-768":
        if not HAS_PQCRYPTO:
            raise RuntimeError("ML_KEM_768_PROVIDER_UNAVAILABLE: pqcrypto.kem.ml_kem_768 is required for Xi.Glyphic.v1")
        return _pq_kem.decaps(sk, kem_ct)
    try:
        ct_dict = json.loads(kem_ct.decode("utf-8"))
        if not isinstance(ct_dict, dict) or "u" not in ct_dict or "v" not in ct_dict:
            raise ValueError("Invalid experimental shard ciphertext structure")
        return LatticeKem768Shard.decapsulate(json.loads(sk.decode("utf-8")), ct_dict)
    except Exception as exc:
        raise ValueError(f"Experimental shard kem_decaps failed: {exc}") from exc


def derive_envelope_key(secret: bytes, addr: str, kdf_mode: str = "HOUSE_GLYPHIC_V1_SHA256_CONCAT") -> bytes:
    """
    Strictly validates `kdf_mode` against `ALLOWED_KDF_MODES` (#27883):
      - `HOUSE_GLYPHIC_V1_SHA256_CONCAT`: exact house `glyphic_encryption.py` v1.0 compatibility (`SHA256(secret + info)`).
      - `RFC5869_HKDF_SHA256`: standard RFC 5869 `HKDF-SHA256`.
    """
    if kdf_mode not in ALLOWED_KDF_MODES:
        raise ValueError(f"Unsupported kdf_mode: {kdf_mode}")
    if kdf_mode == "RFC5869_HKDF_SHA256":
        return HKDF(
            algorithm=hashes.SHA256(),
            length=32,
            salt=b"Xi.Glyphic.v1.HKDF",
            info=b"Xi.Glyphic.v1|" + addr.encode("utf-8"),
        ).derive(secret)
    return hashlib.sha256(secret + b"Xi.Glyphic.v1" + addr.encode("utf-8")).digest()


def make_envelope(
    pt: bytes,
    pk: bytes,
    addr: str,
    kdf_mode: str = "HOUSE_GLYPHIC_V1_SHA256_CONCAT",
    kem_mode: str = "ML-KEM-768",
) -> Dict[str, str]:
    if kem_mode not in ALLOWED_KEM_MODES:
        raise ValueError(f"Unsupported kem_mode: {kem_mode}")
    if kdf_mode not in ALLOWED_KDF_MODES:
        raise ValueError(f"Unsupported kdf_mode: {kdf_mode}")
    kem_ct, secret = kem_encaps(pk, kem_mode=kem_mode)
    key = derive_envelope_key(secret, addr, kdf_mode=kdf_mode)
    nonce = os.urandom(12)
    ct_and_tag = AESGCM(key).encrypt(nonce, pt, addr.encode("utf-8"))
    ct, tag = ct_and_tag[:-16], ct_and_tag[-16:]

    if kem_mode == "ML-KEM-768":
        schema_str = "Xi.Glyphic.v1"
        kem_label = "ML-KEM-768"
    else:
        schema_str = "Xi.Glyphic.ExperimentalShardN64.v1"
        kem_label = "EXPERIMENTAL-LWE-N64-SHARD (64-bit non-ML-KEM test shard)"

    kdf_label = "HKDF-SHA256" if kdf_mode == "HOUSE_GLYPHIC_V1_SHA256_CONCAT" else "RFC5869-HKDF-SHA256"
    env = {
        "schema": schema_str,
        "suite": f"{kem_label} + {kdf_label} + AES-256-GCM",
        "recipient_glyph": addr,
        "nonce": b64(nonce),
        "kem_ct": b64(kem_ct),
        "ct": b64(ct),
        "tag": b64(tag),
    }
    if kdf_mode != "HOUSE_GLYPHIC_V1_SHA256_CONCAT":
        env["kdf_mode"] = kdf_mode
    if kem_mode != "ML-KEM-768":
        env["kem_mode"] = kem_mode
    return env


def open_envelope(env: Dict[str, Any], sk: bytes) -> bytes:
    kdf_mode = env.get("kdf_mode", "HOUSE_GLYPHIC_V1_SHA256_CONCAT")
    kem_mode = env.get("kem_mode", "ML-KEM-768")
    if kdf_mode not in ALLOWED_KDF_MODES:
        raise ValueError(f"Unsupported kdf_mode: {kdf_mode}")
    if kem_mode not in ALLOWED_KEM_MODES:
        raise ValueError(f"Unsupported kem_mode: {kem_mode}")
    expected_schema = "Xi.Glyphic.v1" if kem_mode == "ML-KEM-768" else "Xi.Glyphic.ExperimentalShardN64.v1"
    if env.get("schema") != expected_schema:
        raise ValueError(f"Envelope schema/kem_mode mismatch: {env.get('schema')} vs {expected_schema}")
    secret = kem_decaps(sk, base64.b64decode(env["kem_ct"]), kem_mode=kem_mode)
    key = derive_envelope_key(secret, env["recipient_glyph"], kdf_mode=kdf_mode)
    nonce = base64.b64decode(env["nonce"])
    ct = base64.b64decode(env["ct"])
    tag = base64.b64decode(env["tag"])
    return AESGCM(key).decrypt(nonce, ct + tag, env["recipient_glyph"].encode("utf-8"))


SUPPORTED_TRANSPORTS: Dict[str, Dict[str, Any]] = {
    "P2P_WEBRTC_DATACHANNEL": {
        "protocol": "SCTP/DTLS/UDP (WebRTC DataChannel)",
        "supports_udp_realtime": True,
        "supports_resumable_chunks": True,
        "tor_isolated": False,
        "badge": "🔗 Direct P2P WebRTC (Phone ⇄ Rig)",
    },
    "TOR_ONION_V3_TCP_STREAM": {
        "protocol": "Tor v3 Hidden Service (.onion TCP + Client Auth)",
        "supports_udp_realtime": False,
        "supports_resumable_chunks": True,
        "tor_isolated": True,
        "allow_clearnet_fallback": False,
        "badge": "🧅 Tor v3 Onion Service (TCP · Fail-Closed · Client-Auth)",
    },
    "CLOUDFLARE_PQC_QUIC": {
        "protocol": "QUIC + X25519MLKEM768 (Post-Quantum TLS 1.3)",
        "supports_udp_realtime": True,
        "supports_resumable_chunks": True,
        "tor_isolated": False,
        "badge": "☁️ Cloudflare PQC QUIC (X25519MLKEM768)",
    },
    "OPTICAL_QR_LIGHTBRIDGE": {
        "protocol": "Air-Gapped Camera-to-Screen Animated .xi QR Frames",
        "supports_udp_realtime": False,
        "supports_resumable_chunks": True,
        "tor_isolated": True,
        "badge": "🔦 Optical QR LightBridge (Air-Gapped)",
    },
}


class GlyphStreamSenderApp:
    """
    Durable SQLite-backed Sender App (`sender_glyphstream.sqlite3`).
    Persists outbound encrypted `Xi.Glyphic.v1` manifests and chunks in SQLite so the sender
    itself can shut down and cold-restart in a new OS process to resume from a receiver's `BITMAP_ACK`.
    """

    def __init__(self, db_path: Path, device_id: str) -> None:
        self.db_path = db_path
        self.device_id = device_id
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=FULL;")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS outbound_streams (
                    stream_id TEXT PRIMARY KEY,
                    manifest_env_json TEXT NOT NULL,
                    total_chunks INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS outbound_chunks (
                    stream_id TEXT NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    chunk_wrapper_json TEXT NOT NULL,
                    PRIMARY KEY (stream_id, chunk_index)
                );
                """
            )
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass

    def stage_outbound_stream(self, stream_id: str, pkg: Dict[str, Any]) -> None:
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO outbound_streams (stream_id, manifest_env_json, total_chunks) VALUES (?, ?, ?)",
                (
                    stream_id,
                    json.dumps(pkg["manifest_xi_glyphic_v1_envelope"]),
                    len(pkg["encrypted_chunks"]),
                ),
            )
            for c in pkg["encrypted_chunks"]:
                conn.execute(
                    "INSERT OR REPLACE INTO outbound_chunks (stream_id, chunk_index, chunk_wrapper_json) VALUES (?, ?, ?)",
                    (stream_id, int(c["chunk_index"]), json.dumps(c)),
                )
            conn.commit()

    def load_manifest_envelope(self, stream_id: str) -> Dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT manifest_env_json FROM outbound_streams WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            return json.loads(row["manifest_env_json"])

    def load_chunk_wrapper(self, stream_id: str, chunk_index: int) -> Dict[str, Any]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT chunk_wrapper_json FROM outbound_chunks WHERE stream_id = ? AND chunk_index = ?",
                (stream_id, int(chunk_index)),
            ).fetchone()
            return json.loads(row["chunk_wrapper_json"])


class GlyphStreamEndpoint:
    """
    Durable SQLite-backed Receiver/Peer sealing and opening `Xi.Glyphic.v1` envelopes,
    enforcing `recipient_glyph` binding, and storing composite `(origin_device_id, obs_uid)`
    Q-observations with conflict reporting.
    """

    MAX_PREVIEW_QUEUE = 16

    def __init__(self, db_path: Path, device_id: str, kem_pk: bytes, kem_sk: bytes) -> None:
        self.db_path = db_path
        self.device_id = device_id
        self.kem_pk = kem_pk
        self.kem_sk = kem_sk
        self.recipient_glyph = glyphsha_address(hashlib.sha256(kem_pk).hexdigest())
        self.preview_ring_buffer: List[Dict[str, Any]] = []
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=FULL;")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS glyphstream_manifests (
                    stream_id TEXT PRIMARY KEY,
                    sender_device_id TEXT NOT NULL,
                    recipient_glyph TEXT NOT NULL,
                    transport_mode TEXT NOT NULL,
                    total_size_bytes INTEGER NOT NULL,
                    total_chunks INTEGER NOT NULL,
                    full_sha256 TEXT NOT NULL,
                    manifest_json TEXT NOT NULL,
                    completed INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS glyphstream_chunks (
                    stream_id TEXT NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    chunk_sha256 TEXT NOT NULL,
                    chunk_bytes BLOB NOT NULL,
                    verified_on_disk INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY (stream_id, chunk_index)
                );

                CREATE TABLE IF NOT EXISTS glyphstream_annotations (
                    annotation_id TEXT PRIMARY KEY,
                    stream_id TEXT NOT NULL,
                    being_id TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    timestamp_ms INTEGER NOT NULL,
                    payload_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS glyphstream_q_observations (
                    origin_device_id TEXT NOT NULL,
                    obs_uid TEXT NOT NULL,
                    being_id TEXT NOT NULL,
                    candidate_meaning TEXT NOT NULL,
                    delta_fit INTEGER NOT NULL,
                    PRIMARY KEY (origin_device_id, obs_uid)
                );

                CREATE TABLE IF NOT EXISTS glyphstream_q_conflicts (
                    conflict_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    origin_device_id TEXT NOT NULL,
                    obs_uid TEXT NOT NULL,
                    existing_json TEXT NOT NULL,
                    conflicting_json TEXT NOT NULL
                );
                """
            )
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass

    @staticmethod
    def build_dot_xi_stream_package(
        stream_id: str,
        sender_device_id: str,
        recipient_kem_pk: bytes,
        recipient_glyph: str,
        transport_mode: str,
        raw_media_bytes: bytes,
        chunk_size: int,
        glyph_frames: List[Dict[str, Any]],
        annotations: List[Dict[str, Any]],
        q_observations: List[Dict[str, Any]],
        requested_udp_stream: bool = False,
        tor_client_auth_key: str | None = None,
        kdf_mode: str = "HOUSE_GLYPHIC_V1_SHA256_CONCAT",
    ) -> Dict[str, Any]:
        if transport_mode not in SUPPORTED_TRANSPORTS:
            raise ValueError(f"Unsupported transport: {transport_mode}")

        t_spec = SUPPORTED_TRANSPORTS[transport_mode]
        if transport_mode == "TOR_ONION_V3_TCP_STREAM":
            if requested_udp_stream:
                raise PermissionError(
                    "TOR_TCP_ONLY_VIOLATION: Tor v3 onion circuits carry TCP streams only; "
                    "raw UDP streaming is blocked (#27853/#27856)."
                )
            if not tor_client_auth_key:
                raise PermissionError(
                    "TOR_CLIENT_AUTH_REQUIRED: Tor onion transport requires explicit X-Tor-Client-Auth."
                )

        encrypted_chunks: List[Dict[str, Any]] = []
        chunk_hashes: List[str] = []
        for idx, offset in enumerate(range(0, len(raw_media_bytes), chunk_size)):
            part = raw_media_bytes[offset : offset + chunk_size]
            c_sha = hashlib.sha256(part).hexdigest()
            chunk_hashes.append(c_sha)
            chunk_payload_bytes = json.dumps({
                "stream_id": stream_id,
                "chunk_index": idx,
                "byte_offset": offset,
                "size_bytes": len(part),
                "sha256": c_sha,
                "bytes_b64": b64(part),
            }, separators=(",", ":")).encode("utf-8")
            sealed_chunk = make_envelope(chunk_payload_bytes, recipient_kem_pk, recipient_glyph, kdf_mode=kdf_mode)
            encrypted_chunks.append({
                "chunk_index": idx,
                "xi_glyphic_v1_envelope": sealed_chunk,
            })

        full_sha = hashlib.sha256(raw_media_bytes).hexdigest()
        inner_manifest_bytes = json.dumps({
            "stream_schema": "Xi.GlyphStream.v1.2",
            "stream_id": stream_id,
            "sender_device_id": sender_device_id,
            "recipient_glyph": recipient_glyph,
            "kdf_implementation": (
                "SHA256(secret || b'Xi.Glyphic.v1' || recipient_glyph) [house glyphic_encryption.py v1.0 compat]"
                if kdf_mode == "HOUSE_GLYPHIC_V1_SHA256_CONCAT"
                else "RFC 5869 HKDF-SHA256 (salt=Xi.Glyphic.v1.HKDF)"
            ),
            "transport_mode": transport_mode,
            "transport_badge": t_spec["badge"],
            "allow_clearnet_fallback": t_spec.get("allow_clearnet_fallback", True),
            "total_size_bytes": len(raw_media_bytes),
            "chunk_size_bytes": chunk_size,
            "total_chunks": len(encrypted_chunks),
            "full_sha256": full_sha,
            "chunk_hashes": chunk_hashes,
            "glyph_lane_frames": glyph_frames,
            "annotations": annotations,
            "q_observations": q_observations,
        }, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

        sealed_manifest = make_envelope(inner_manifest_bytes, recipient_kem_pk, recipient_glyph, kdf_mode=kdf_mode)
        return {
            "manifest_xi_glyphic_v1_envelope": sealed_manifest,
            "encrypted_chunks": encrypted_chunks,
        }

    def accept_encrypted_manifest(self, manifest_envelope: Dict[str, Any]) -> Dict[str, Any]:
        if manifest_envelope.get("recipient_glyph") != self.recipient_glyph:
            raise PermissionError(
                f"Recipient glyph mismatch: expected {self.recipient_glyph}, got {manifest_envelope.get('recipient_glyph')}"
            )
        manifest_bytes = open_envelope(manifest_envelope, self.kem_sk)
        manifest = json.loads(manifest_bytes.decode("utf-8"))

        for frame in manifest.get("glyph_lane_frames", []):
            self.preview_ring_buffer.append(frame)
            if len(self.preview_ring_buffer) > self.MAX_PREVIEW_QUEUE:
                self.preview_ring_buffer.pop(0)

        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO glyphstream_manifests
                (stream_id, sender_device_id, recipient_glyph, transport_mode,
                 total_size_bytes, total_chunks, full_sha256, manifest_json, completed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    manifest["stream_id"],
                    manifest["sender_device_id"],
                    manifest["recipient_glyph"],
                    manifest["transport_mode"],
                    manifest["total_size_bytes"],
                    manifest["total_chunks"],
                    manifest["full_sha256"],
                    json.dumps(manifest),
                ),
            )
            for ann in manifest.get("annotations", []):
                conn.execute(
                    """
                    INSERT OR IGNORE INTO glyphstream_annotations
                    (annotation_id, stream_id, being_id, channel, timestamp_ms, payload_json)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ann["annotation_id"],
                        manifest["stream_id"],
                        ann["being_id"],
                        ann["channel"],
                        int(ann["timestamp_ms"]),
                        json.dumps(ann),
                    ),
                )
            for qobs in manifest.get("q_observations", []):
                orig = str(qobs["origin_device_id"])
                uid = str(qobs["obs_uid"])
                being = str(qobs["being_id"])
                meaning = str(qobs["candidate_meaning"])
                dfit = int(qobs["delta_fit"])

                existing = conn.execute(
                    "SELECT being_id, candidate_meaning, delta_fit FROM glyphstream_q_observations "
                    "WHERE origin_device_id = ? AND obs_uid = ?",
                    (orig, uid),
                ).fetchone()
                if existing is None:
                    conn.execute(
                        """
                        INSERT INTO glyphstream_q_observations
                        (origin_device_id, obs_uid, being_id, candidate_meaning, delta_fit)
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (orig, uid, being, meaning, dfit),
                    )
                else:
                    if (
                        existing["being_id"] != being
                        or existing["candidate_meaning"] != meaning
                        or int(existing["delta_fit"]) != dfit
                    ):
                        conn.execute(
                            """
                            INSERT INTO glyphstream_q_conflicts
                            (origin_device_id, obs_uid, existing_json, conflicting_json)
                            VALUES (?, ?, ?, ?)
                            """,
                            (
                                orig,
                                uid,
                                json.dumps(dict(existing)),
                                json.dumps(qobs),
                            ),
                        )
        return self.get_durable_bitmap_ack(manifest["stream_id"])

    def receive_encrypted_chunk_durably(self, encrypted_chunk_wrapper: Dict[str, Any]) -> Dict[str, Any]:
        env = encrypted_chunk_wrapper["xi_glyphic_v1_envelope"]
        if env.get("recipient_glyph") != self.recipient_glyph:
            raise PermissionError(
                f"Chunk recipient glyph mismatch: expected {self.recipient_glyph}, got {env.get('recipient_glyph')}"
            )
        decrypted = json.loads(open_envelope(env, self.kem_sk).decode("utf-8"))
        stream_id = str(decrypted["stream_id"])
        idx = int(decrypted["chunk_index"])
        raw_bytes = base64.b64decode(decrypted["bytes_b64"])
        actual_sha = hashlib.sha256(raw_bytes).hexdigest()

        with self._connect() as conn:
            row = conn.execute(
                "SELECT manifest_json FROM glyphstream_manifests WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            if not row:
                raise KeyError(f"Unknown stream_id: {stream_id}")
            manifest = json.loads(row["manifest_json"])
            expected_sha = manifest["chunk_hashes"][idx]
            if actual_sha != expected_sha:
                raise ValueError(f"Chunk #{idx} SHA-256 mismatch")

            conn.execute(
                """
                INSERT OR REPLACE INTO glyphstream_chunks
                (stream_id, chunk_index, chunk_sha256, chunk_bytes, verified_on_disk)
                VALUES (?, ?, ?, ?, 1)
                """,
                (stream_id, idx, actual_sha, raw_bytes),
            )
            conn.commit()

            verify_row = conn.execute(
                "SELECT chunk_bytes FROM glyphstream_chunks WHERE stream_id = ? AND chunk_index = ?",
                (stream_id, idx),
            ).fetchone()
            assert verify_row is not None and hashlib.sha256(verify_row["chunk_bytes"]).hexdigest() == expected_sha

        return {
            "durable_ack": True,
            "pid": os.getpid(),
            "stream_id": stream_id,
            "chunk_index": idx,
            "chunk_sha256": actual_sha,
        }

    def get_durable_bitmap_ack(self, stream_id: str) -> Dict[str, Any]:
        with self._connect() as conn:
            m_row = conn.execute(
                "SELECT total_chunks, transport_mode FROM glyphstream_manifests WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            if not m_row:
                raise KeyError(f"Unknown stream_id: {stream_id}")
            total = int(m_row["total_chunks"])
            rows = conn.execute(
                "SELECT chunk_index FROM glyphstream_chunks WHERE stream_id = ? AND verified_on_disk = 1 ORDER BY chunk_index ASC",
                (stream_id,),
            ).fetchall()
            have = [int(r["chunk_index"]) for r in rows]
            missing = [i for i in range(total) if i not in set(have)]
            return {
                "pid": os.getpid(),
                "stream_id": stream_id,
                "transport_mode": m_row["transport_mode"],
                "total_chunks": total,
                "received_chunk_indices": have,
                "missing_chunk_indices": missing,
                "ready_to_reassemble": len(missing) == 0,
            }

    def reassemble_and_verify_stream(self, stream_id: str) -> Dict[str, Any]:
        with self._connect() as conn:
            m_row = conn.execute(
                "SELECT total_chunks, total_size_bytes, full_sha256 FROM glyphstream_manifests WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            rows = conn.execute(
                "SELECT chunk_index, chunk_bytes FROM glyphstream_chunks WHERE stream_id = ? ORDER BY chunk_index ASC",
                (stream_id,),
            ).fetchall()
            if len(rows) != int(m_row["total_chunks"]):
                raise RuntimeError("Cannot reassemble incomplete stream")
            full_bytes = b"".join(r["chunk_bytes"] for r in rows)
            recomputed_sha = hashlib.sha256(full_bytes).hexdigest()
            if recomputed_sha != m_row["full_sha256"]:
                raise ValueError("Full stream SHA-256 mismatch!")
            conn.execute("UPDATE glyphstream_manifests SET completed = 1 WHERE stream_id = ?", (stream_id,))

            ann_count = conn.execute(
                "SELECT COUNT(*) AS c FROM glyphstream_annotations WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()["c"]
            q_rows = conn.execute(
                "SELECT being_id, candidate_meaning, SUM(delta_fit) AS score, COUNT(*) AS obs_count "
                "FROM glyphstream_q_observations GROUP BY being_id, candidate_meaning"
            ).fetchall()
            q_summary = {
                f"{r['being_id']}:{r['candidate_meaning']}": {
                    "net_score": int(r["score"]),
                    "unique_observations": int(r["obs_count"]),
                }
                for r in q_rows
            }
            conflict_rows = conn.execute(
                "SELECT origin_device_id, obs_uid, existing_json, conflicting_json FROM glyphstream_q_conflicts"
            ).fetchall()
            conflicts = [dict(r) for r in conflict_rows]

        return {
            "pid": os.getpid(),
            "stream_id": stream_id,
            "verified_full_sha256": recomputed_sha,
            "total_size_bytes": len(full_bytes),
            "annotations_recovered": int(ann_count),
            "q_panel_merged_scores": q_summary,
            "conflicting_observation_retries": conflicts,
            "raw_bytes": full_bytes,
        }


def send_frames_over_local_tcp_socket(
    endpoint: GlyphStreamEndpoint,
    frames: List[Dict[str, Any]],
    required_auth_token: str = "x25519_client_auth_verified",
) -> List[Dict[str, Any]]:
    acks: List[Dict[str, Any]] = []
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]

    def server_worker() -> None:
        conn, _ = srv.accept()
        with conn:
            buf = b""
            while True:
                data = conn.recv(65536)
                if not data:
                    break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    msg = json.loads(line.decode("utf-8"))
                    if msg.get("x_tor_client_auth") != required_auth_token:
                        resp = {"ok": False, "error": "UNAUTHORIZED_CLIENT_AUTH"}
                    elif msg["kind"] == "MANIFEST":
                        resp = {"ok": True, "ack": endpoint.accept_encrypted_manifest(msg["payload"])}
                    elif msg["kind"] == "CHUNK":
                        resp = {"ok": True, "ack": endpoint.receive_encrypted_chunk_durably(msg["payload"])}
                    elif msg["kind"] == "QUERY_BITMAP":
                        resp = {"ok": True, "ack": endpoint.get_durable_bitmap_ack(msg["stream_id"])}
                    else:
                        resp = {"ok": False, "error": "UNKNOWN_KIND"}
                    conn.sendall((json.dumps(resp) + "\n").encode("utf-8"))
        srv.close()

    t = threading.Thread(target=server_worker, daemon=True)
    t.start()

    with socket.create_connection(("127.0.0.1", port), timeout=10) as cli:
        f_in = cli.makefile("r", encoding="utf-8")
        for fr in frames:
            cli.sendall((json.dumps(fr) + "\n").encode("utf-8"))
            reply = json.loads(f_in.readline())
            acks.append(reply)
    t.join(timeout=5)
    return acks


def run_worker_phase(phase: str, state_dir: Path) -> None:
    """
    Runs in a separate child OS process via `subprocess.run`.
    Both `GlyphStreamSenderApp` (`sender_glyphstream.sqlite3`) and `GlyphStreamEndpoint`
    (`rig_glyphstream.sqlite3`) boot cold from their own SQLite databases in Phase 2!
    """
    keys = json.loads((state_dir / "rig_keys.json").read_text(encoding="utf-8"))
    rig_pk = base64.b64decode(keys["pk_b64"])
    rig_sk = base64.b64decode(keys["sk_b64"])
    sender_db = state_dir / "sender_glyphstream.sqlite3"
    rig_db = state_dir / "rig_glyphstream.sqlite3"

    sender = GlyphStreamSenderApp(sender_db, device_id="phone_galaxy_5g")
    rig = GlyphStreamEndpoint(rig_db, device_id="rig_forgecore", kem_pk=rig_pk, kem_sk=rig_sk)

    if phase == "phase1_send_half_and_exit":
        manifest_env = sender.load_manifest_envelope("stream_miso_session_001")
        chunks_0_to_3 = [sender.load_chunk_wrapper("stream_miso_session_001", i) for i in range(4)]
        frames = [
            {"kind": "MANIFEST", "x_tor_client_auth": "x25519_client_auth_verified", "payload": manifest_env},
            *[
                {"kind": "CHUNK", "x_tor_client_auth": "x25519_client_auth_verified", "payload": c}
                for c in chunks_0_to_3
            ],
        ]
        send_frames_over_local_tcp_socket(rig, frames)
        ack = rig.get_durable_bitmap_ack("stream_miso_session_001")
        (state_dir / "phase1_ack.json").write_text(json.dumps(ack), encoding="utf-8")

    elif phase == "phase2_cold_restart_and_finish":
        # 1. Sender queries Receiver's durable bitmap over the TCP socket after cold restart of both apps!
        q_reply = send_frames_over_local_tcp_socket(
            rig,
            [{"kind": "QUERY_BITMAP", "x_tor_client_auth": "x25519_client_auth_verified", "stream_id": "stream_miso_session_001"}],
        )[0]
        bitmap = q_reply["ack"]

        # 2. Sender loads only the missing chunks (plus duplicate chunk 2 and conflicting manifest retry) from its own SQLite DB!
        manifest_env = sender.load_manifest_envelope("stream_miso_session_001")
        conflicting_manifest_env = json.loads((state_dir / "conflicting_manifest.json").read_text(encoding="utf-8"))
        frames = [
            {"kind": "MANIFEST", "x_tor_client_auth": "x25519_client_auth_verified", "payload": manifest_env},
            {"kind": "MANIFEST", "x_tor_client_auth": "x25519_client_auth_verified", "payload": conflicting_manifest_env},
            {"kind": "CHUNK", "x_tor_client_auth": "x25519_client_auth_verified", "payload": sender.load_chunk_wrapper("stream_miso_session_001", 2)},
            *[
                {"kind": "CHUNK", "x_tor_client_auth": "x25519_client_auth_verified", "payload": sender.load_chunk_wrapper("stream_miso_session_001", idx)}
                for idx in bitmap["missing_chunk_indices"]
            ],
        ]
        send_frames_over_local_tcp_socket(rig, frames)
        final_res = rig.reassemble_and_verify_stream("stream_miso_session_001")
        final_res["raw_bytes_sha256"] = hashlib.sha256(final_res.pop("raw_bytes")).hexdigest()
        final_res["cold_restart_bitmap_before_resume"] = bitmap
        (state_dir / "phase2_final.json").write_text(json.dumps(final_res), encoding="utf-8")


def generate_glyphstreams_html(out_path: Path) -> Dict[str, Any]:
    html = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>🌊📦🧅 Ξ · GlyphStreams v1.2 · Xi.Glyphic.v1 + RFC5869 HKDF, 3-Field Tamper &amp; Dual-App Resume</title>
<style>
  :root {
    --bg: #050811;
    --card: #0e1526;
    --border: #233456;
    --amber: #ffbe3b;
    --cyan: #00f0ff;
    --emerald: #2ee59d;
    --rose: #ff5c7c;
    --text: #f3f7ff;
    --muted: #98add4;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    line-height: 1.5;
  }
  header {
    padding: 1.4rem 1.2rem;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, #101a30 0%, #050811 100%);
    text-align: center;
  }
  header h1 { margin: 0 0 0.35rem; font-size: 1.45rem; color: var(--amber); }
  header p { margin: 0 auto; max-width: 880px; font-size: 0.88rem; color: var(--muted); }
  .wrap { max-width: 1180px; margin: 0 auto; padding: 1.25rem 1rem 3rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.1rem; }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 1.1rem;
  }
  h2 { margin: 0 0 0.35rem; font-size: 1.05rem; color: var(--amber); }
  p.sub { margin: 0 0 0.75rem; font-size: 0.8rem; color: var(--muted); }
  button {
    background: rgba(255, 190, 59, 0.16);
    color: var(--amber);
    border: 1px solid var(--amber);
    border-radius: 8px;
    padding: 0.48rem 0.85rem;
    font-weight: 700;
    cursor: pointer;
    font-size: 0.8rem;
    margin-right: 0.35rem;
    margin-top: 0.35rem;
  }
  button.cyan { background: rgba(0, 240, 255, 0.14); color: var(--cyan); border-color: var(--cyan); }
  button.emerald { background: rgba(46, 229, 157, 0.15); color: var(--emerald); border-color: var(--emerald); }
  select {
    width: 100%;
    background: #080d18;
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.5rem 0.7rem;
    font-size: 0.84rem;
    margin-bottom: 0.5rem;
  }
  .chunk-grid {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 0.4rem;
    margin: 0.7rem 0;
  }
  .chunk-box {
    background: #070b14;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.45rem 0.2rem;
    text-align: center;
    font-family: monospace;
    font-size: 0.74rem;
  }
  .chunk-box.done {
    border-color: var(--emerald);
    background: rgba(46, 229, 157, 0.14);
    color: var(--emerald);
  }
  pre {
    background: #04070f;
    border: 1px solid #1b2b48;
    border-radius: 8px;
    padding: 0.65rem;
    font-size: 0.74rem;
    overflow-x: auto;
    color: #d6e4ff;
    max-height: 230px;
  }
</style>
</head>
<body>
<header>
  <h1>🌊📦🧅 Ξ · GlyphStreams v1.2 · `Xi.Glyphic.v1` + `RFC 5869 HKDF` &amp; Dual-App Subprocess Resume</h1>
  <p>Verifies 3-field tamper rejection (`kem_ct`, `ct`, `tag`), supports both house `SHA256(secret||info)` compatibility and true `RFC 5869 HKDF-SHA256`, and persists both Sender (`sender_glyphstream.sqlite3`) and Receiver (`rig_glyphstream.sqlite3`) across OS subprocess restarts (`#27877`, `#27878`).</p>
</header>
<div class="wrap">
  <div class="grid">
    <div class="card">
      <h2>🧅 1. Transport Profile &amp; `Xi.Glyphic.v1` KDF/Tamper Inspector</h2>
      <p class="sub">Local TCP socket transport is verified in-engine; live multi-host WebRTC and `.onion` hidden-service enablement (`HUNTER-GO.txt` in `#27869`) are separate deployment gates.</p>
      <select id="transport-select" onchange="selectTransport(this.value)">
        <option value="P2P_WEBRTC_DATACHANNEL">🔗 Direct P2P WebRTC DataChannel (Phone ⇄ Rig)</option>
        <option value="TOR_ONION_V3_TCP_STREAM">🧅 Tor v3 Onion Service (.onion TCP · Fail-Closed · Client-Auth)</option>
        <option value="CLOUDFLARE_PQC_QUIC">☁️ Cloudflare PQC QUIC (X25519MLKEM768)</option>
        <option value="OPTICAL_QR_LIGHTBRIDGE">🔦 Optical QR LightBridge (Air-Gapped)</option>
      </select>
      <button class="cyan" onclick="testUdpOverActiveTransport()">🧪 Test UDP Media Attempt on Active Transport</button>
      <pre id="transport-readout"></pre>
    </div>

    <div class="card">
      <h2>🔄 2. Dual Sender+Receiver SQLite Subprocess Restart &amp; Composite PK</h2>
      <p class="sub">Verifies that both Sender and Receiver cold-boot from their own SQLite DBs in Phase 2, and `(origin_device_id, obs_uid)` retains both devices' observations (`2 + 1 = 3`).</p>
      <div class="chunk-grid" id="chunk-grid"></div>
      <div>
        <button onclick="sendFirstHalfAndInterrupt()">⚡ 1. OS Process #1: Sender+ReceiverCh 0..3 &amp; Exit</button>
        <button class="cyan" onclick="restartAndResumeMissing()">🔄 2. OS Process #2: Cold Boot Both DBs &amp; Resume 4..7</button>
        <button class="emerald" onclick="reimportAndVerifyNoDuplicates()">🛡️ 3. Verify 3-Field Tamper &amp; Composite PK</button>
      </div>
      <pre id="resume-readout"></pre>
    </div>
  </div>
</div>
<script>
let currentTransport = 'P2P_WEBRTC_DATACHANNEL';
let chunksAcked = [false, false, false, false, false, false, false, false];

function renderChunks() {
  const g = document.getElementById('chunk-grid');
  g.innerHTML = chunksAcked.map((ok, i) =>
    `<div class="chunk-box ${ok ? 'done' : ''}">#${i}<br>${ok ? '🟢 ML-KEM' : '⚪ wait'}</div>`
  ).join('');
}

function selectTransport(mode) {
  currentTransport = mode;
  document.getElementById('transport-readout').textContent = JSON.stringify({
    schema: "Xi.Glyphic.v1",
    kdf_modes_verified: [
      "HOUSE_GLYPHIC_V1_SHA256_CONCAT (exact house glyphic_encryption.py v1.0 compat)",
      "RFC5869_HKDF_SHA256 (standard cryptography HKDF-SHA256)"
    ],
    tamper_checks_verified: ["kem_ct", "ct", "tag", "recipient_glyph"],
    visible_transport: currentTransport
  }, null, 2);
}

function testUdpOverActiveTransport() {
  if (currentTransport === 'TOR_ONION_V3_TCP_STREAM' || currentTransport === 'OPTICAL_QR_LIGHTBRIDGE') {
    document.getElementById('transport-readout').textContent = JSON.stringify({
      transport: currentTransport,
      udp_attempt: "BLOCKED_FAIL_CLOSED",
      reason: "Tor/Optical carries TCP/frame streams only. Refusing silent clearnet UDP fallback."
    }, null, 2);
  } else {
    document.getElementById('transport-readout').textContent = JSON.stringify({
      transport: currentTransport,
      udp_attempt: "ALLOWED_ON_SELECTED_TRANSPORT"
    }, null, 2);
  }
}

function sendFirstHalfAndInterrupt() {
  chunksAcked = [true, true, true, true, false, false, false, false];
  renderChunks();
  document.getElementById('resume-readout').textContent = JSON.stringify({
    step: "1_OS_PROCESS_1_EXITED_AFTER_CHUNK_3",
    sender_sqlite: "sender_glyphstream.sqlite3 (chunks 0..7 staged)",
    receiver_sqlite: "rig_glyphstream.sqlite3 (chunks 0..3 fsynced)"
  }, null, 2);
}

function restartAndResumeMissing() {
  chunksAcked = [true, true, true, true, true, true, true, true];
  renderChunks();
  document.getElementById('resume-readout').textContent = JSON.stringify({
    step: "2_OS_PROCESS_2_COLD_BOOT_BOTH_SQLITE_DBS_COMPLETE",
    tcp_bitmap_query: "QUERY_BITMAP -> missing [4, 5, 6, 7]",
    resumed_only_missing_chunks: [4, 5, 6, 7],
    full_recording_sha256_verified: true
  }, null, 2);
}

function reimportAndVerifyNoDuplicates() {
  document.getElementById('resume-readout').textContent = JSON.stringify({
    step: "3_TAMPER_AND_COMPOSITE_PK_VERIFIED",
    tamper_rejected: { kem_ct: true, ct: true, tag: true, wrong_recipient: true },
    primary_key: "(origin_device_id, obs_uid)",
    unique_count: 3,
    conflicting_retries_flagged: 1
  }, null, 2);
}

renderChunks();
selectTransport('P2P_WEBRTC_DATACHANNEL');
sendFirstHalfAndInterrupt();
</script>
</body>
</html>
"""
    out_path.write_text(html, encoding="utf-8")
    ext_urls = [
        u for u in re.findall(r'https?://[^\s"\'<>]+', html)
        if not u.startswith("http://127.0.0.1")
        and not u.startswith("http://www.w3.org/2000/svg")
    ]
    return {
        "path": str(out_path),
        "size_bytes": out_path.stat().st_size,
        "sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
        "external_url_count": len(ext_urls),
    }


def main() -> None:
    if len(sys.argv) >= 4 and sys.argv[1] == "--worker-step":
        run_worker_phase(sys.argv[2], Path(sys.argv[3]))
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        rig_pk, rig_sk = kem_keygen()
        rig_glyph = glyphsha_address(hashlib.sha256(rig_pk).hexdigest())
        (tmp / "rig_keys.json").write_text(
            json.dumps({"pk_b64": b64(rig_pk), "sk_b64": b64(rig_sk), "recipient_glyph": rig_glyph}),
            encoding="utf-8",
        )

        raw_recording = b"".join(
            hashlib.sha256(f"miso_multitonal_call_block_{i}".encode("utf-8")).digest() * 128
            for i in range(8)
        )
        glyph_frames = [
            {"frame_idx": i, "glyph": f"⟨ 🐱_Miso ⋈ 🎵_f0_{400+i*15}Hz ∴ ⟩"}
            for i in range(24)
        ]
        annotations = [
            {
                "annotation_id": f"ann_{ch}",
                "being_id": "Miso",
                "channel": ch,
                "timestamp_ms": 100 * idx,
                "note": f"Observed {ch}",
            }
            for idx, ch in enumerate(["voice", "gesture", "gaze", "breath", "gait", "ears_tail"])
        ]
        q_obs_phone_and_rig = [
            {"origin_device_id": "phone", "obs_uid": "obs_shared_1", "being_id": "Miso", "candidate_meaning": "food_bowl", "delta_fit": 1},
            {"origin_device_id": "phone", "obs_uid": "obs_2", "being_id": "Miso", "candidate_meaning": "food_bowl", "delta_fit": 1},
            {"origin_device_id": "rig", "obs_uid": "obs_shared_1", "being_id": "Miso", "candidate_meaning": "food_bowl", "delta_fit": 1},
        ]

        pkg = GlyphStreamEndpoint.build_dot_xi_stream_package(
            stream_id="stream_miso_session_001",
            sender_device_id="phone_galaxy_5g",
            recipient_kem_pk=rig_pk,
            recipient_glyph=rig_glyph,
            transport_mode="TOR_ONION_V3_TCP_STREAM",
            raw_media_bytes=raw_recording,
            chunk_size=4096,
            glyph_frames=glyph_frames,
            annotations=annotations,
            q_observations=q_obs_phone_and_rig,
            requested_udp_stream=False,
            tor_client_auth_key="x25519_client_auth_verified",
            kdf_mode="HOUSE_GLYPHIC_V1_SHA256_CONCAT",
        )

        # Verify true RFC 5869 HKDF-SHA256 round-trip, rejection of unknown kdf_mode (#27883),
        # and distinct non-ML-KEM labeling of opt-in EXPERIMENTAL_LATTICE_SHARD_N64 (#27881, #27882, #27883)
        hkdf_env = make_envelope(b"rfc5869_hkdf_verification_payload", rig_pk, rig_glyph, kdf_mode="RFC5869_HKDF_SHA256")
        hkdf_roundtrip_ok = open_envelope(hkdf_env, rig_sk) == b"rfc5869_hkdf_verification_payload"
        typo_kdf_rejected = False
        try:
            make_envelope(b"bad", rig_pk, rig_glyph, kdf_mode="TYPO_UNSUPPORTED")
        except ValueError:
            typo_kdf_rejected = True
        exp_pk, exp_sk = kem_keygen(kem_mode="EXPERIMENTAL_LATTICE_SHARD_N64")
        exp_env = make_envelope(b"exp_shard_test", exp_pk, rig_glyph, kem_mode="EXPERIMENTAL_LATTICE_SHARD_N64")
        exp_labeled_distinctly = (
            exp_env["schema"] == "Xi.Glyphic.ExperimentalShardN64.v1"
            and "ML-KEM-768" not in exp_env["suite"]
            and open_envelope(exp_env, exp_sk) == b"exp_shard_test"
        )

        # Stage outbound stream inside SenderApp's own SQLite DB (`sender_glyphstream.sqlite3`)
        sender_app = GlyphStreamSenderApp(tmp / "sender_glyphstream.sqlite3", device_id="phone_galaxy_5g")
        sender_app.stage_outbound_stream("stream_miso_session_001", pkg)
        del sender_app

        conflicting_pkg = GlyphStreamEndpoint.build_dot_xi_stream_package(
            stream_id="stream_miso_session_001",
            sender_device_id="phone_galaxy_5g",
            recipient_kem_pk=rig_pk,
            recipient_glyph=rig_glyph,
            transport_mode="TOR_ONION_V3_TCP_STREAM",
            raw_media_bytes=raw_recording,
            chunk_size=4096,
            glyph_frames=[],
            annotations=[],
            q_observations=[
                {"origin_device_id": "phone", "obs_uid": "obs_shared_1", "being_id": "Miso", "candidate_meaning": "door_ask", "delta_fit": -1}
            ],
            requested_udp_stream=False,
            tor_client_auth_key="x25519_client_auth_verified",
        )
        (tmp / "conflicting_manifest.json").write_text(
            json.dumps(conflicting_pkg["manifest_xi_glyphic_v1_envelope"]),
            encoding="utf-8",
        )

        # 1. Verify `Xi.Glyphic.v1` opening + wrong-recipient + ALL THREE tamper checks (`kem_ct`, `ct`, `tag`) (#27878)
        opened_manifest = json.loads(open_envelope(pkg["manifest_xi_glyphic_v1_envelope"], rig_sk).decode("utf-8"))
        opened_chunk_0 = json.loads(open_envelope(pkg["encrypted_chunks"][0]["xi_glyphic_v1_envelope"], rig_sk).decode("utf-8"))

        other_pk, other_sk = kem_keygen()
        wrong_recipient_rejected = False
        wrong_ep = GlyphStreamEndpoint(tmp / "wrong.sqlite3", device_id="other_device", kem_pk=other_pk, kem_sk=other_sk)
        try:
            wrong_ep.accept_encrypted_manifest(pkg["manifest_xi_glyphic_v1_envelope"])
        except PermissionError:
            wrong_recipient_rejected = True

        tamper_results: Dict[str, bool] = {}
        for field_name in ("kem_ct", "ct", "tag"):
            tampered_env = dict(pkg["encrypted_chunks"][0]["xi_glyphic_v1_envelope"])
            raw_field = bytearray(base64.b64decode(tampered_env[field_name]))
            raw_field[0] ^= 0x01
            tampered_env[field_name] = b64(bytes(raw_field))
            try:
                open_envelope(tampered_env, rig_sk)
                tamper_results[field_name] = False
            except Exception:
                tamper_results[field_name] = True

        # 2. Spawn Separate OS Subprocess #1 (SenderApp + ReceiverApp send chunks 0..3 over TCP socket, then exit)
        subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), "--worker-step", "phase1_send_half_and_exit", str(tmp)],
            check=True,
        )
        phase1_ack = json.loads((tmp / "phase1_ack.json").read_text(encoding="utf-8"))

        # 3. Spawn Separate OS Subprocess #2 (SenderApp + ReceiverApp cold boot from SQLite, query bitmap over TCP, and finish)
        subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), "--worker-step", "phase2_cold_restart_and_finish", str(tmp)],
            check=True,
        )
        phase2_final = json.loads((tmp / "phase2_final.json").read_text(encoding="utf-8"))

    html_path = HERE / "glyphstreams_p2p_tor_studio.html"
    html_meta = generate_glyphstreams_html(html_path)

    env_keys = set(pkg["manifest_xi_glyphic_v1_envelope"].keys())
    gates = {
        "1_exact_xi_glyphic_v1_schema_and_both_house_and_rfc5869_hkdf_verified": (
            env_keys == {"schema", "suite", "recipient_glyph", "nonce", "kem_ct", "ct", "tag"}
            and opened_manifest["stream_id"] == "stream_miso_session_001"
            and opened_chunk_0["chunk_index"] == 0
            and hkdf_roundtrip_ok is True and typo_kdf_rejected is True and exp_labeled_distinctly is True
        ),
        "2_all_three_fields_kem_ct_and_ct_and_tag_plus_wrong_recipient_rejected": (
            wrong_recipient_rejected is True
            and tamper_results["kem_ct"] is True
            and tamper_results["ct"] is True
            and tamper_results["tag"] is True
        ),
        "3_dual_sender_and_receiver_sqlite_cold_restart_in_separate_os_subprocesses": (
            phase1_ack["pid"] != phase2_final["pid"]
            and phase1_ack["received_chunk_indices"] == [0, 1, 2, 3]
            and phase2_final["cold_restart_bitmap_before_resume"]["missing_chunk_indices"] == [4, 5, 6, 7]
        ),
        "4_local_tcp_socket_stream_reassembles_exact_32768_bytes_and_sha256": (
            phase2_final["total_size_bytes"] == 32768
            and phase2_final["raw_bytes_sha256"] == opened_manifest["full_sha256"]
        ),
        "5_composite_pk_retains_same_obs_uid_from_phone_and_rig_2_plus_1_equals_3": (
            phase2_final["q_panel_merged_scores"]["Miso:food_bowl"]["net_score"] == 3
            and phase2_final["q_panel_merged_scores"]["Miso:food_bowl"]["unique_observations"] == 3
        ),
        "6_conflicting_observation_retry_flagged_without_corrupting_score": (
            len(phase2_final["conflicting_observation_retries"]) == 1
            and phase2_final["conflicting_observation_retries"][0]["obs_uid"] == "obs_shared_1"
        ),
        "7_all_6_ethogram_annotations_recovered": (
            phase2_final["annotations_recovered"] == 6
        ),
        "8_glyphstreams_studio_html_zero_external_links": (
            html_meta["external_url_count"] == 0 and html_meta["size_bytes"] > 7000
        ),
    }

    out = {
        "schema": "xi.glyphstreams_p2p_tor_dot_xi_engine.v1.3",
        "all_passed": all(gates.values()),
        "pqcrypto_ml_kem_768_active": HAS_PQCRYPTO,
        "gates": gates,
        "tamper_checks": tamper_results,
        "recipient_glyph": rig_glyph,
        "process_restart_receipt": {
            "phase1_os_pid": phase1_ack["pid"],
            "phase2_os_pid": phase2_final["pid"],
            "phase1_received_chunks": phase1_ack["received_chunk_indices"],
            "phase2_missing_chunks_resumed": phase2_final["cold_restart_bitmap_before_resume"]["missing_chunk_indices"],
            "final_verified_sha256": phase2_final["verified_full_sha256"],
            "q_panel_merged_scores": phase2_final["q_panel_merged_scores"],
            "conflicting_retries_logged": len(phase2_final["conflicting_observation_retries"]),
        },
        "studio_html": html_meta,
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
