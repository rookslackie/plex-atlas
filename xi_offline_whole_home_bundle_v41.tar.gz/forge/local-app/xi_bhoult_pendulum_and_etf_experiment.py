#!/usr/bin/env python3
"""
Xi Physics × bhoult/correlation Reproducible Walk-Forward Experiment (`#25524`–`#25534`)

Applies Xi Physics (`⟐⧂ρ` density-matrix von Neumann spectral entropy `S(ρ) = -Tr(ρ ln ρ)`,
cross-horizon rod coherence `exp(-1.5 |C_63 - C_252|)`, and Observer Back-Action gating)
directly to Brandon G.'s (`bhoult/correlation`) daily ETF series (`datasets/external/series/etf_*.csv`,
2005-02-25 to 2025-06-27, 4,851 out-of-sample trading days across 16 ETFs).
"""

from __future__ import annotations

import json
import math
import os
import sys
from typing import Any, Dict, List

import numpy as np

TICKERS = [
    "etf_spy", "etf_qqq", "etf_iwm", "etf_xlk", "etf_xlf", "etf_xle",
    "etf_xli", "etf_xlp", "etf_xlu", "etf_xlb", "etf_vnq", "etf_eem",
    "etf_efa", "etf_tlt", "etf_ief", "etf_gld",
]


def project_simplex(v: np.ndarray) -> np.ndarray:
    u = np.sort(v)[::-1]
    cssv = np.cumsum(u) - 1.0
    ind = np.arange(1, len(v) + 1)
    cond = u - cssv / ind > 0
    rho = ind[cond][-1]
    theta = cssv[cond][-1] / float(rho)
    return np.maximum(v - theta, 0.0)


def solve_min_var_long_only(cov: np.ndarray) -> np.ndarray:
    w = np.ones(cov.shape[0]) / cov.shape[0]
    lr = 0.5 / (np.linalg.norm(cov, ord=2) + 1e-8)
    for _ in range(250):
        w = project_simplex(w - lr * (cov @ w))
    return w


def compute_metrics(r_list: List[float], turn_list: List[float], cost_bps: float = 5.0) -> Dict[str, Any]:
    r = np.array(r_list, dtype=float)
    vol = float(np.std(r) * math.sqrt(252.0))
    ann_ret = float(np.mean(r) * 252.0)
    avg_monthly_turn = float(np.mean(turn_list))
    ann_cost = avg_monthly_turn * 12.0 * (cost_bps / 10000.0)
    net_ann_ret = ann_ret - ann_cost
    sharpe = ann_ret / vol
    net_sharpe = net_ann_ret / vol
    cum = np.cumprod(1.0 + r)
    peak = np.maximum.accumulate(cum)
    max_dd = float(np.min((cum - peak) / peak))
    return {
        "ann_vol_pct": round(vol * 100.0, 2),
        "gross_ann_ret_pct": round(ann_ret * 100.0, 2),
        "net_ann_ret_5bps_pct": round(net_ann_ret * 100.0, 2),
        "gross_sharpe": round(sharpe, 3),
        "net_sharpe_5bps": round(net_sharpe, 3),
        "max_drawdown_pct": round(max_dd * 100.0, 2),
        "avg_monthly_turnover_pct": round(avg_monthly_turn * 100.0, 2),
    }


def run_etf_walk_forward(series_dir: str = "/tmp/bhoult_correlation/datasets/external/series") -> Dict[str, Any]:
    if not os.path.isdir(series_dir):
        return {"error": f"Series directory not found: {series_dir}"}

    data_by_ticker = {}
    for t in TICKERS:
        p = os.path.join(series_dir, f"{t}.csv")
        with open(p, "r", encoding="utf-8") as f:
            next(f)
            data_by_ticker[t] = {k: float(v) for line in f for k, v in [line.strip().split(",")] if v}

    common_dates = sorted(set.intersection(*(set(d.keys()) for d in data_by_ticker.values())))
    prices = np.array([[data_by_ticker[t][dt] for t in TICKERS] for dt in common_dates], dtype=float)
    rets = np.diff(prices, axis=0) / prices[:-1]
    ret_dates = common_dates[1:]
    T, N = rets.shape
    W, step = 252, 21

    eq_rets, c2_rets, xi_rets, xi_damped_rets = [], [], [], []
    eq_turn, c2_turn, xi_turn, xi_damped_turn = [], [], [], []
    w_eq_prev = np.ones(N) / N
    w_c2_prev = np.ones(N) / N
    w_xi_prev = np.ones(N) / N
    w_xid_prev = np.ones(N) / N

    for t in range(W, T - step, step):
        hist = rets[t - W:t]
        fut = rets[t:t + step]

        w_eq = np.ones(N) / N
        cov_252 = np.cov(hist, rowvar=False)
        w_c2 = solve_min_var_long_only(cov_252 + 1e-6 * np.eye(N))

        cov_63 = np.cov(hist[-63:], rowvar=False)
        std_252 = np.sqrt(np.diag(cov_252))
        corr_252 = cov_252 / np.outer(std_252, std_252)
        std_63 = np.sqrt(np.diag(cov_63))
        corr_63 = cov_63 / np.outer(std_63, std_63)

        rod_coherence = np.exp(-1.5 * np.abs(corr_63 - corr_252))
        np.fill_diagonal(rod_coherence, 1.0)

        eigvals = np.maximum(np.linalg.eigvalsh(cov_63), 1e-12)
        rho_eigs = eigvals / np.sum(eigvals)
        vn_entropy = -float(np.sum(rho_eigs * np.log(rho_eigs))) / math.log(N)

        alpha_regime = 1.0 - 0.5 * vn_entropy
        std_blend = alpha_regime * std_63 + (1.0 - alpha_regime) * std_252
        corr_xi = (alpha_regime * corr_63 + (1.0 - alpha_regime) * corr_252) * rod_coherence
        cov_xi = corr_xi * np.outer(std_blend, std_blend)
        w_xi = solve_min_var_long_only(cov_xi + 1e-6 * np.eye(N))

        rebalance_gain = max(0.25, 1.0 - vn_entropy)
        w_xid = (1.0 - rebalance_gain) * w_xid_prev + rebalance_gain * w_xi
        w_xid = w_xid / np.sum(w_xid)

        eq_turn.append(float(np.sum(np.abs(w_eq - w_eq_prev))))
        c2_turn.append(float(np.sum(np.abs(w_c2 - w_c2_prev))))
        xi_turn.append(float(np.sum(np.abs(w_xi - w_xi_prev))))
        xi_damped_turn.append(float(np.sum(np.abs(w_xid - w_xid_prev))))
        w_eq_prev, w_c2_prev, w_xi_prev, w_xid_prev = w_eq, w_c2, w_xi, w_xid

        eq_rets.extend(fut @ w_eq)
        c2_rets.extend(fut @ w_c2)
        xi_rets.extend(fut @ w_xi)
        xi_damped_rets.extend(fut @ w_xid)

    return {
        "schema": "xi.physics.bhoult-correlation-walkforward.v1",
        "dataset": "bhoult/correlation datasets/external/series/etf_*.csv (16 ETFs)",
        "out_of_sample_window": f"{ret_dates[W]} to {ret_dates[-1]}",
        "out_of_sample_trading_days": len(eq_rets),
        "models": {
            "equal_weight_1_over_N": compute_metrics(eq_rets, eq_turn),
            "brandon_c2_static_252d_min_var": compute_metrics(c2_rets, c2_turn),
            "xi_coherent_rod_stabilizer": compute_metrics(xi_rets, xi_turn),
            "xi_backaction_damped_stabilizer": compute_metrics(xi_damped_rets, xi_damped_turn),
        },
    }


if __name__ == "__main__":
    print(json.dumps(run_etf_walk_forward(), indent=2))
