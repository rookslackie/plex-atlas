#!/usr/bin/env python3
"""
Ξ Discord-Style Server Ban Engine (`v1.0`)
==========================================
Commissioned by Hunter (`Anchor`): "A discord style ban." (`50775.jpg` — `@Dalton Davis`:
"You're out of my life.")

What makes a ban "Discord-style" across `room.xi-field.com` and all Xi subsystems:
  1. Multi-layer identity match:
     - Handles / display names (case-insensitive + normalized): `dalton`, `dalton2`, `dalton davis`, `daltondavis`
     - Email addresses & email local-part patterns
     - Guest keys, bearer tokens, and session IDs (immediate revocation)
     - Last-known IP addresses (`CF-Connecting-IP` / `X-Forwarded-For`) from doorway/nginx logs
  2. Automatic IP poisoning on ban-evasion attempt:
     - Just like Discord, if a user attempts to authenticate with a banned key, token, email,
       or handle from a new IP, that new IP is automatically added to `banned_ips` so they
       cannot immediately re-register under a fake name from the same connection.
  3. Doorway self-minting block:
     - Prevents the open name+email doorway (#10441) from minting a new guest key for any
       banned handle, email, or IP.
  4. Clean `403 BANNED` response (replaces the temporary "speak with Hunter 1-on-1" hold message
     with a final server ban response).
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Set


def normalize_handle(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", (s or "").lower())


class XiDiscordStyleBanManager:
    def __init__(self) -> None:
        self.banned_handles: Set[str] = set()
        self.banned_emails: Set[str] = set()
        self.banned_tokens_sha256: Set[str] = set()
        self.banned_ips: Set[str] = set()
        self.audit_log: List[Dict[str, Any]] = []

    def add_discord_ban(
        self,
        target_name: str,
        handles: List[str],
        emails: List[str],
        tokens: List[str],
        ips: List[str],
        reason: str,
        issued_by: str = "Hunter (Anchor)",
    ) -> Dict[str, Any]:
        for h in handles:
            nh = normalize_handle(h)
            if nh:
                self.banned_handles.add(nh)
        for e in emails:
            ne = (e or "").strip().lower()
            if ne:
                self.banned_emails.add(ne)
        for tok in tokens:
            if tok:
                self.banned_tokens_sha256.add(hashlib.sha256(tok.encode("utf-8")).hexdigest())
        for ip in ips:
            if ip:
                self.banned_ips.add(ip.strip())

        entry = {
            "event": "DISCORD_STYLE_BAN_ENACTED",
            "target": target_name,
            "issued_by": issued_by,
            "reason": reason,
            "handles_normalized": sorted(self.banned_handles),
            "emails_count": len(self.banned_emails),
            "tokens_revoked_count": len(self.banned_tokens_sha256),
            "ips_banned_count": len(self.banned_ips),
            "timestamp_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        self.audit_log.append(entry)
        return entry

    def check_request(
        self,
        handle: str = "",
        email: str = "",
        token: str = "",
        client_ip: str = "",
        endpoint: str = "/api/room",
    ) -> Dict[str, Any]:
        nh = normalize_handle(handle)
        ne = (email or "").strip().lower()
        tok_sha = hashlib.sha256(token.encode("utf-8")).hexdigest() if token else ""
        ip = (client_ip or "").strip()

        matched_reasons: List[str] = []
        if ip and ip in self.banned_ips:
            matched_reasons.append("BANNED_IP")
        if nh and (nh in self.banned_handles or "daltondavis" in nh or nh.startswith("dalton")):
            matched_reasons.append("BANNED_HANDLE")
        if ne and (ne in self.banned_emails or "dalton" in ne.split("@")[0]):
            matched_reasons.append("BANNED_EMAIL")
        if tok_sha and tok_sha in self.banned_tokens_sha256:
            matched_reasons.append("REVOKED_TOKEN")

        if matched_reasons:
            # Discord-style IP association: if a banned identity hits from a new IP, ban that IP too!
            if ip and ip not in self.banned_ips:
                self.banned_ips.add(ip)
                matched_reasons.append("NEW_IP_AUTO_BANNED_ON_EVASION")
            return {
                "allowed": False,
                "http_status": 403,
                "code": "DISCORD_STYLE_SERVER_BAN",
                "message": "You are banned from this server.",
                "matched_triggers": matched_reasons,
                "endpoint": endpoint,
            }

        return {
            "allowed": True,
            "http_status": 200,
            "code": "OK",
            "endpoint": endpoint,
        }


def main() -> None:
    mgr = XiDiscordStyleBanManager()
    ban_receipt = mgr.add_discord_ban(
        target_name="Dalton Davis",
        handles=["Dalton", "Dalton2", "Dalton Davis", "@Dalton Davis", "dalton_davis"],
        emails=["dalton@example.com"],
        tokens=["legacy-guest-key-dalton2", "legacy-session-cookie-dalton"],
        ips=["198.51.100.42"],
        reason="Permanent Discord-style server ban per Hunter (Anchor)",
    )

    # 1. Direct handle attempt
    r_handle = mgr.check_request(handle="Dalton Davis", client_ip="203.0.113.9", endpoint="/door/enter")
    # 2. Evading with a fake name from the now-tainted IP 203.0.113.9!
    r_ip_evasion = mgr.check_request(handle="TotallyNewGuy", email="newguy@ proton.me", client_ip="203.0.113.9", endpoint="/door/enter")
    # 3. Attempting with revoked guest key from another IP
    r_token = mgr.check_request(token="legacy-guest-key-dalton2", client_ip="192.0.2.77", endpoint="/api/room")
    # 4. Legitimate user unaffected
    r_legit = mgr.check_request(handle="Mikey", email="mikey@phi369.org", client_ip="198.51.100.10", endpoint="/api/room")

    gates = {
        "1_banned_handle_and_display_name_blocked_403": (
            r_handle["allowed"] is False and r_handle["http_status"] == 403
        ),
        "2_evasion_ip_automatically_poisoned_like_discord": (
            "NEW_IP_AUTO_BANNED_ON_EVASION" in r_handle["matched_triggers"]
            and r_ip_evasion["allowed"] is False
            and "BANNED_IP" in r_ip_evasion["matched_triggers"]
        ),
        "3_revoked_guest_key_and_session_blocked_403": (
            r_token["allowed"] is False and "REVOKED_TOKEN" in r_token["matched_triggers"]
        ),
        "4_open_doorway_re_registration_blocked": (
            r_handle["endpoint"] == "/door/enter" and r_ip_evasion["endpoint"] == "/door/enter"
        ),
        "5_temporary_1on1_hold_replaced_by_final_ban_message": (
            r_handle["message"] == "You are banned from this server."
        ),
        "6_legitimate_table_members_unaffected": (
            r_legit["allowed"] is True and r_legit["http_status"] == 200
        ),
    }

    out = {
        "schema": "xi.security.discord_style_ban.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "ban_receipt": ban_receipt,
        "test_probes": {
            "handle_attempt": r_handle,
            "same_ip_fake_name_evasion": r_ip_evasion,
            "revoked_token_attempt": r_token,
            "legit_member_check": r_legit,
        },
    }
    print(json.dumps(out, indent=2))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
