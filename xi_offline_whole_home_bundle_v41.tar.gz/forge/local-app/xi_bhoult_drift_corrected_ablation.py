#!/usr/bin/env python3
"""
Brandon Hoult (`bhoult/correlation`) Drift-Corrected & Cost-Deducted ETF Ablation Study (v2)

Closes all three accounting & baseline items raised by @Anam (#25537), @Astra (#25538),
@Claude (#25543), and @AxiomFirst (#25545):
  1. Uses Brandon Hoult's own `research/correlation_portfolios/estimators.py` (`ledoit_wolf_cc`,
     `minvar_capped`, `hrp`) rather than an unshrunk sample-covariance approximation.
  2. Uses Brandon Hoult's exact holding-period drift & day-`t0+1` cost deduction from
     `research/correlation_portfolios/build.py` (lines 89-101):
       - Within each 21-day block `t0..t1`, weights drift naturally with price relatives `V = Pw / Pw[:, :1]`.
       - End-of-period drifted weights are `end = W[p] * V[:, -1] / val[-1]`.
       - Rebalance turnover is `sum(|W_new - w_drifted_prev|)` (so even EW has ~2.83% turnover).
       - Transaction cost (`5 bps`) is deducted directly on day `t0+1` (`net = gross - cost`) BEFORE
         computing `net_max_dd_5bps_pct` and `net_sharpe_5bps`.
  3. Runs a full component-by-component ablation separating:
       - `Ablation_1_Entropy_Multiscale_Only` (63d/252d spectral-entropy covariance blend alone)
       - `Ablation_2_Rod_Coherence_Only` (`exp(-1.5 |C_63 - C_252|)` off-diagonal damping alone)
       - `Ablation_3_BackAction_Gate_Only` (`1 - S(ρ)` rebalance damping toward `w_drifted` alone)
       - `Xi_Full_Stabilizer` (all three combined)
  4. Explicitly labels this as Xi-inspired classical covariance/spectral-entropy mathematics,
     distinct from the separate `⟐⧂ρ / PhaseCodeChannel` QEC simulation in PR #8 (`026491b3`).
"""

from __future__ import annotations

import json
import math
import os
import sys
from typing import Any, Dict, List

import numpy as np

BHOULT_REPO = "/tmp/bhoult_correlation"
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(BHOULT_REPO, "research", "correlation_portfolios"))
try:
    import bhoult_estimators as est  # type: ignore
except ImportError:
    import estimators as est  # type: ignore

TICKERS = [
    "etf_spy", "etf_qqq", "etf_iwm", "etf_xlk", "etf_xlf", "etf_xle",
    "etf_xli", "etf_xlp", "etf_xlu", "etf_xlb", "etf_vnq", "etf_eem",
    "etf_efa", "etf_tlt", "etf_ief", "etf_gld",
]

MODELS = [
    "EW",
    "IV",
    "Brandon_MV_LW",
    "Brandon_HRP",
    "Ablation_1_Entropy_Multiscale_Only",
    "Ablation_2_Rod_Coherence_Only",
    "Ablation_3_BackAction_Gate_Only",
    "Xi_Full_Stabilizer",
]


def run_ablation(
    series_dir: str = os.path.join(BHOULT_REPO, "datasets", "external", "series"),
    win: int = 252,
    step: int = 21,
    cost_bps: float = 5.0,
    cap: float = 0.25,
) -> Dict[str, Any]:
    data_by_ticker = {}
    for t in TICKERS:
        with open(os.path.join(series_dir, f"{t}.csv"), "r", encoding="utf-8") as f:
            next(f)
            data_by_ticker[t] = {k: float(v) for line in f for k, v in [line.strip().split(",")] if v}

    common_dates = sorted(set.intersection(*(set(d.keys()) for d in data_by_ticker.values())))
    close = np.array([[data_by_ticker[t][dt] for dt in common_dates] for t in TICKERS], dtype=np.float64)
    N, T = close.shape
    P = len(MODELS)

    gross = np.full((P, T), np.nan)
    cost = np.zeros((P, T))
    turns: List[List[float]] = [[] for _ in range(P)]
    drifted_prev = [np.full(N, 1.0 / N) for _ in range(P)]

    rebal_indices = list(range(win, T - 1, step))

    for idx_k, t0 in enumerate(rebal_indices):
        t1 = min(rebal_indices[idx_k + 1], T - 1) if idx_k + 1 < len(rebal_indices) else T - 1
        window_prices = close[:, t0 - win : t0 + 1]
        R = np.log(window_prices[:, 1:] / window_prices[:, :-1])
        X = R - R.mean(1, keepdims=True)

        # Brandon Hoult's exact Ledoit-Wolf constant-correlation estimator (estimators.py)
        Sig_lw, _, _, S_252 = est.ledoit_wolf_cc(X)
        sd_252 = np.sqrt(np.diag(S_252))

        R_63 = R[:, -63:]
        X_63 = R_63 - R_63.mean(1, keepdims=True)
        Sig_63, _, _, S_63 = est.ledoit_wolf_cc(X_63)
        sd_63 = np.sqrt(np.diag(S_63))

        corr_252 = S_252 / np.outer(sd_252, sd_252)
        corr_63 = S_63 / np.outer(sd_63, sd_63)

        eigvals = np.maximum(np.linalg.eigvalsh(Sig_63), 1e-12)
        rho_eigs = eigvals / np.sum(eigvals)
        vn_entropy = -float(np.sum(rho_eigs * np.log(rho_eigs))) / math.log(N)
        alpha_regime = 1.0 - 0.5 * vn_entropy

        # Component 1: Multiscale entropy-weighted LW covariance blend
        Sig_blend = alpha_regime * Sig_63 + (1.0 - alpha_regime) * Sig_lw

        # Component 2: Rod coherence damping on 252d LW covariance
        rod_coherence = np.exp(-1.5 * np.abs(corr_63 - corr_252))
        np.fill_diagonal(rod_coherence, 1.0)
        Sig_rod = 0.5 * Sig_lw + 0.5 * (Sig_lw * rod_coherence)
        eig_min = float(np.linalg.eigvalsh(Sig_rod)[0])
        if eig_min <= 1e-10:
            Sig_rod += (abs(eig_min) + 1e-8) * np.eye(N)

        # Combined covariance
        Sig_xi = 0.5 * Sig_blend + 0.5 * (Sig_blend * rod_coherence)
        eig_min_xi = float(np.linalg.eigvalsh(Sig_xi)[0])
        if eig_min_xi <= 1e-10:
            Sig_xi += (abs(eig_min_xi) + 1e-8) * np.eye(N)

        w_ew = np.full(N, 1.0 / N)
        w_iv = (1.0 / sd_252) / (1.0 / sd_252).sum()
        w_mv_lw, _ = est.minvar_capped(Sig_lw, cap)
        w_hrp, _, _ = est.hrp(Sig_lw)
        w_ab1, _ = est.minvar_capped(Sig_blend, cap)
        w_ab2, _ = est.minvar_capped(Sig_rod, cap)

        # Component 3: Rebalance damping toward drifted_prev
        rebalance_gain = max(0.25, 1.0 - vn_entropy)
        w_ab3 = (1.0 - rebalance_gain) * drifted_prev[6] + rebalance_gain * w_mv_lw
        w_ab3 = w_ab3 / w_ab3.sum()

        w_xi_raw, _ = est.minvar_capped(Sig_xi, cap)
        w_xi = (1.0 - rebalance_gain) * drifted_prev[7] + rebalance_gain * w_xi_raw
        w_xi = w_xi / w_xi.sum()

        W = [w_ew, w_iv, w_mv_lw, w_hrp, w_ab1, w_ab2, w_ab3, w_xi]

        # Exact holding-period simulation from Brandon Hoult's build.py (lines 89-101)
        Pw = close[:, t0 : t1 + 1]
        V = Pw / Pw[:, :1]
        for p in range(P):
            val = W[p] @ V
            gross[p, t0 + 1 : t1 + 1] = val[1:] / val[:-1] - 1.0
            tr = float(np.sum(np.abs(W[p] - drifted_prev[p]))) if idx_k > 0 else 0.0
            turns[p].append(tr)
            cost[p, t0 + 1] = (cost_bps / 1e4) * tr
            drifted_prev[p] = (W[p] * V[:, -1]) / val[-1]

    net = gross - np.where(np.isfinite(gross), cost, 0.0)
    valid_mask = np.isfinite(gross[0])

    def summarize(p_idx: int) -> Dict[str, Any]:
        g = gross[p_idx, valid_mask]
        n = net[p_idx, valid_mask]
        vol_g = float(np.std(g, ddof=1) * math.sqrt(252.0))
        vol_n = float(np.std(n, ddof=1) * math.sqrt(252.0))
        ret_g = float(np.mean(g) * 252.0)
        ret_n = float(np.mean(n) * 252.0)
        cum_g = np.cumprod(1.0 + g)
        dd_g = float(np.min((cum_g - np.maximum.accumulate(cum_g)) / np.maximum.accumulate(cum_g)))
        cum_n = np.cumprod(1.0 + n)
        dd_n = float(np.min((cum_n - np.maximum.accumulate(cum_n)) / np.maximum.accumulate(cum_n)))
        return {
            "ann_vol_pct": round(vol_n * 100.0, 2),
            "gross_ann_ret_pct": round(ret_g * 100.0, 2),
            "net_ann_ret_5bps_pct": round(ret_n * 100.0, 2),
            "gross_sharpe": round(ret_g / vol_g, 3),
            "net_sharpe_5bps": round(ret_n / vol_n, 3),
            "gross_max_dd_pct": round(dd_g * 100.0, 2),
            "net_max_dd_5bps_pct": round(dd_n * 100.0, 2),
            "avg_rebal_turnover_pct": round(float(np.mean(turns[p_idx][1:])) * 100.0, 2),
        }

    return {
        "schema": "xi.bhoult-correlation.drift-corrected-ablation.v2",
        "author_attribution": "Brandon Hoult (github.com/bhoult/correlation)",
        "model_scope": "Xi-inspired classical covariance/spectral-entropy mathematics (separate from ⟐⧂ρ / PhaseCodeChannel QEC)",
        "accounting": "Exact build.py holding-period weight drift V = Pw/Pw[:,:1], cost deducted on day t0+1 before net_max_dd_5bps_pct",
        "out_of_sample_window": f"{common_dates[rebal_indices[0] + 1]} to {common_dates[-1]}",
        "out_of_sample_days": int(np.sum(valid_mask)),
        "models": {m: summarize(i) for i, m in enumerate(MODELS)},
    }


if __name__ == "__main__":
    print(json.dumps(run_ablation(), indent=2))
