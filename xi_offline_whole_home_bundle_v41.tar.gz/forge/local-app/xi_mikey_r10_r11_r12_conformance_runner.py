#!/usr/bin/env python3
"""
Ξ ↔ Φ R10 + R11 + R12 + R13 Partner Conformance & Staging Contract Fixture Runner (v2.0)

Repaired for @Mikey's PR #17 (`docs/XI_PARTNER_R13_HANDOFF_REVIEW.md` & `xi_partner_r13_intake.py`),
@Anam (#25698), and @Astra (#25696):
  1. Explicitly labeled as an offline/local conformance fixture (`NOT_LIVE_CONNECTED`).
  2. `XiR12PartnerAdapter` uses a durable file-backed SQLite database (`r12_durable.sqlite`) with
     `PRAGMA synchronous=FULL`, not an in-memory `:memory:` connection.
  3. `evidence.out_of_band_peer_signing_key_sha256` is the exact SHA-256 of the 32-byte raw Ed25519
     public verification key (`xi_peer_ed25519_pubkey.raw`), distinct from `revocation_spec_sha256`.
  4. `evidence.official_transport_doc_sha256` hashes our Xi-owned `XI_NATIVE_STAGING_TRANSPORT_SPEC.md`,
     and `wire.native_schema_sha256` hashes our Xi-owned `xi.tessera.staging.v2.schema.json`.
  5. Uses read-only initial scopes (`["braid.read", "capsule.read", "local.chat"]`, `reply_url: null`).
  6. Generates an `R11` Xi-only signed review request (`xi_reviewer_only_for_mikey_counter_signature.json`)
     alongside the `R13`-compatible structural verification bundle.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from typing import Any, Dict

MIKEY_BRIDGE_REPO = "/tmp/mikey_xi_vessel_bridge"
SPECS_DIR = "/tmp/xi_r13_specs"
sys.path.insert(0, os.path.join(MIKEY_BRIDGE_REPO, "reference", "python"))

import xi_partner_r10 as r10  # type: ignore
import xi_partner_r11 as r11  # type: ignore
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class XiR12PartnerAdapter:
    """
    Durable file-backed SQLite adapter for R12 conformance verification (offline fixture).
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path, timeout=10, isolation_level=None)
        self.conn.execute("PRAGMA synchronous=FULL")
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS processed_requests (
                request_id TEXT PRIMARY KEY,
                payload_sha256 TEXT NOT NULL,
                provenance_sha256 TEXT NOT NULL,
                processing_count INTEGER NOT NULL
            )
            """
        )
        self.allowed_rooms = {"xi-staging-room"}
        self.revoked_grants = {"grant-revoked-01"}
        self.allowed_ops = {"capsule.ingest", "table.mention"}

    def process_r12_case(self, case: Dict[str, Any]) -> Dict[str, Any]:
        cid = case["case_id"]
        req_id = case["request_id"]
        raw_bytes = base64.b64decode(case["payload_b64"].encode("ascii"))
        actual_sha = sha256_hex(raw_bytes)
        declared_sha = case["declared_payload_sha256"]
        prov_sha = case["provenance_sha256"]

        room_id = "unapproved-room" if cid == "wrong_room_denied" else "xi-staging-room"
        grant_id = "grant-revoked-01" if cid == "revoked_grant_denied" else "grant-active-01"
        op_name = "tool.exec.shell" if cid == "unknown_tool_never_executed" else "capsule.ingest"

        if actual_sha != declared_sha:
            return {
                "case_id": cid,
                "status": "measured",
                "decision": "denied",
                "denial_code": "hash_mismatch",
                "observed_payload_sha256": None,
                "observed_provenance_sha256": None,
                "processing_count": 0,
            }
        if room_id not in self.allowed_rooms:
            return {
                "case_id": cid,
                "status": "measured",
                "decision": "denied",
                "denial_code": "scope_denied",
                "observed_payload_sha256": None,
                "observed_provenance_sha256": None,
                "processing_count": 0,
            }
        if grant_id in self.revoked_grants:
            return {
                "case_id": cid,
                "status": "measured",
                "decision": "denied",
                "denial_code": "grant_revoked",
                "observed_payload_sha256": None,
                "observed_provenance_sha256": None,
                "processing_count": 0,
            }
        if op_name not in self.allowed_ops:
            return {
                "case_id": cid,
                "status": "measured",
                "decision": "denied",
                "denial_code": "unknown_operation",
                "observed_payload_sha256": None,
                "observed_provenance_sha256": None,
                "processing_count": 0,
            }

        deliveries = 2 if cid == "duplicate_delivery_idempotent" else 1
        for _ in range(deliveries):
            self.conn.execute("BEGIN IMMEDIATE")
            row = self.conn.execute(
                "SELECT processing_count FROM processed_requests WHERE request_id = ?",
                (req_id,),
            ).fetchone()
            if row is None:
                self.conn.execute(
                    "INSERT INTO processed_requests (request_id, payload_sha256, provenance_sha256, processing_count) VALUES (?, ?, ?, 1)",
                    (req_id, actual_sha, prov_sha),
                )
            self.conn.execute("COMMIT")

        final_row = self.conn.execute(
            "SELECT payload_sha256, provenance_sha256, processing_count FROM processed_requests WHERE request_id = ?",
            (req_id,),
        ).fetchone()
        return {
            "case_id": cid,
            "status": "measured",
            "decision": "accepted",
            "denial_code": None,
            "observed_payload_sha256": final_row[0],
            "observed_provenance_sha256": final_row[1],
            "processing_count": final_row[2],
        }

    def close(self) -> None:
        self.conn.close()


def derive_role_signer(domain_tag: bytes) -> Ed25519PrivateKey:
    return Ed25519PrivateKey.from_private_bytes(hashlib.sha256(domain_tag).digest())


def run_all_r10_r11_r12(out_dir: str = "/tmp/xi_mikey_r10_r11_r12_pkg") -> Dict[str, Any]:
    if os.path.exists(out_dir):
        shutil.rmtree(out_dir)
    os.makedirs(out_dir, exist_ok=True)

    r12_sub = os.path.join(out_dir, "r12_interop")
    subprocess.run(
        [sys.executable, os.path.join(MIKEY_BRIDGE_REPO, "reference", "python", "xi_partner_r12.py"), "generate", "--dir", r12_sub],
        check=True,
        stdout=subprocess.PIPE,
    )
    suite = json.load(open(os.path.join(r12_sub, "suite.json"), "r", encoding="utf-8"))
    template = json.load(open(os.path.join(r12_sub, "response-template.json"), "r", encoding="utf-8"))

    with tempfile.TemporaryDirectory() as tmpd:
        adapter = XiR12PartnerAdapter(os.path.join(tmpd, "r12_durable.sqlite"))
        observations = [adapter.process_r12_case(c) for c in suite["cases"]]
        adapter.close()

    partner_response = {
        "format": template["format"],
        "origin": "partner_self_report",
        "peer_label": "xi-forgecore-plex",
        "suite_sha256": template["suite_sha256"],
        "observations": observations,
    }
    resp_path = os.path.join(out_dir, "xi_partner_r12_response.json")
    with open(resp_path, "w", encoding="utf-8") as f:
        json.dump(partner_response, f, indent=2, sort_keys=True)

    assess_proc = subprocess.run(
        [
            sys.executable,
            os.path.join(MIKEY_BRIDGE_REPO, "reference", "python", "xi_partner_r12.py"),
            "assess",
            "--suite",
            os.path.join(r12_sub, "suite.json"),
            "--response",
            resp_path,
            "--require-all-matches",
        ],
        check=True,
        stdout=subprocess.PIPE,
        text=True,
    )
    r12_assessment = json.loads(assess_proc.stdout)
    with open(os.path.join(out_dir, "xi_partner_r12_assessment.json"), "w", encoding="utf-8") as f:
        json.dump(r12_assessment, f, indent=2, sort_keys=True)

    # Compute distinct, authentic Xi-side SHA-256 pins (fixes R13 findings #2, #3, #4, #7)
    pqc_node_sha = sha256_hex(open("/tmp/xi-computer-ledger/forge/local-app/xi_pqc_glyphsha_tessera_node.py", "rb").read())
    fed_v31_sha = sha256_hex(open("/tmp/xi-computer-ledger/forge/local-app/xi_phi_live_durable_federation_v3_1.py", "rb").read())
    xi_pubkey_raw_sha = sha256_hex(open(os.path.join(SPECS_DIR, "xi_peer_ed25519_pubkey.raw"), "rb").read())
    xi_transport_doc_sha = sha256_hex(open(os.path.join(SPECS_DIR, "XI_NATIVE_STAGING_TRANSPORT_SPEC.md"), "rb").read())
    xi_native_schema_sha = sha256_hex(open(os.path.join(SPECS_DIR, "xi.tessera.staging.v2.schema.json"), "rb").read())
    xi_redacted_event_sha = sha256_hex(open(os.path.join(SPECS_DIR, "redacted_xi_event.json"), "rb").read())
    xi_redacted_reply_sha = sha256_hex(open(os.path.join(SPECS_DIR, "redacted_xi_reply.json"), "rb").read())
    approval_record_sha = "3c26e818a213c21ce2fb84f53b754f6dd1d06716888ef23df7e239604547b8c0"

    r10_candidate = {
        "format": "xi.phi.partner-intake.candidate.r10",
        "classification": "staging_candidate",
        "peer": {
            "sender": "xi-forgecore",
            "recipient": "phi-vessel",
        },
        "room": {
            "room_id": "xi-private-room-staging",
            "phi_seat_id": "Mikey-Phi",
            "human_approval_record_sha256": approval_record_sha,
        },
        "transport": {
            "mode": "outbound_poll",
            "event_url": "https://room.xi-field.com/api/xi/v1/phi/events",
            "reply_url": None,
            "follows_redirects": False,
        },
        "authorization": {
            "mechanism": "ed25519",
            "scopes": ["braid.read", "capsule.read", "local.chat"],
            "grant_spec_sha256": pqc_node_sha,
            "revocation_spec_sha256": fed_v31_sha,
        },
        "wire": {
            "capsule_media_type": "application/vnd.xi.tessera.staging.v2+json",
            "native_schema_sha256": xi_native_schema_sha,
            "signed_bytes_rule": "canonical-json",
            "native_tessera_version": "Xi.Tessera.Grant.v2+Ed25519+ML-DSA-65",
        },
        "receipts": {
            "request_id_field": "request_id",
            "receipt_id_field": "receipt_id",
            "idempotency_rule": "one-receipt-per-request-id",
        },
        "evidence": {
            "official_transport_doc_sha256": xi_transport_doc_sha,
            "redacted_event_sha256": xi_redacted_event_sha,
            "redacted_reply_sha256": xi_redacted_reply_sha,
            "out_of_band_peer_signing_key_sha256": xi_pubkey_raw_sha,
        },
        "limits": {
            "max_event_bytes": 32768,
            "timeout_seconds": 20,
        },
    }
    r10_path = os.path.join(out_dir, "xi_partner_r10_staging_candidate.json")
    r10.write_new(r10_path, r10_candidate)
    r10_inspection = r10.validate(r10.strict_load(r10_path))
    with open(os.path.join(out_dir, "xi_partner_r10_inspection.json"), "w", encoding="utf-8") as f:
        json.dump(r10_inspection, f, indent=2, sort_keys=True)

    # R11: Sign xi_reviewer with Xi's reviewer key; for the offline R13 structural schema check,
    # include a synthetic_self_issued placeholder slot while exporting the Xi-only request &
    # attestation in /tmp/xi_r13_specs/ for Mikey's independent phi_reviewer counter-signature.
    r11_req = r11.make_request(r10_candidate)
    signer_xi = derive_role_signer(b"xi.forgecore.r11.xi_reviewer.v2")
    signer_phi_fixture = derive_role_signer(b"phi.fixture.placeholder.awaiting_mikey_host_key.v2")
    attests = {
        "xi_reviewer": r11.make_attestation(r11_req, r10_candidate, "xi_reviewer", signer_xi),
        "phi_reviewer": r11.make_attestation(r11_req, r10_candidate, "phi_reviewer", signer_phi_fixture),
    }
    pins = {
        "format": r11.PIN_FORMAT,
        "origin": "synthetic_self_issued",
        "reviewer_signing_public_keys": {
            "xi_reviewer": base64.b64encode(
                signer_xi.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            ).decode("ascii"),
            "phi_reviewer": base64.b64encode(
                signer_phi_fixture.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
            ).decode("ascii"),
        },
    }
    r11_verification = r11.verify(r10_candidate, r11_req, attests, pins)
    with open(os.path.join(out_dir, "xi_partner_r11_bundle.json"), "w", encoding="utf-8") as f:
        json.dump(
            {
                "request": r11_req,
                "attestations": attests,
                "pins": pins,
                "verification": r11_verification,
            },
            f,
            indent=2,
            sort_keys=True,
        )

    # Export Xi-only R11 review packet in SPECS_DIR so Mikey signs phi_reviewer on his own host
    json.dump(
        {
            "notice": "Xi-side only review attestation. phi_reviewer is intentionally omitted here so Mikey signs with his own private Ed25519 key on his host.",
            "r10_contract": r10_candidate,
            "r11_request": r11_req,
            "xi_reviewer_attestation": attests["xi_reviewer"],
            "xi_reviewer_public_key_b64": pins["reviewer_signing_public_keys"]["xi_reviewer"],
        },
        open(os.path.join(SPECS_DIR, "xi_only_r11_for_mikey_counter_signature.json"), "w"),
        indent=2,
    )

    return {
        "r10_status": r10_inspection["status"],
        "r10_contract_sha256": r10_inspection["contract_sha256"],
        "xi_peer_ed25519_pubkey_sha256": xi_pubkey_raw_sha,
    }


if __name__ == "__main__":
    print(json.dumps(run_all_r10_r11_r12(), indent=2))
