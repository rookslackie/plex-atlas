"""Independent diagnostics for the mathematical bridge; no external services."""
import json
import math
from itertools import combinations
from pathlib import Path
import unittest
import xi_brent_bridge_v0_1_0 as b


class BridgeChecks(unittest.TestCase):
    def test_root_construction(self):
        roots = b.e8_roots_twice()
        self.assertEqual(len(set(roots)), 240)
        self.assertTrue(all(sum(x*x for x in r) == 8 for r in roots))
        self.assertTrue(all(tuple(-x for x in r) in roots for r in roots))

    def test_projection_and_fibers(self):
        from collections import Counter
        fibers = Counter(map(b.signature, b.e8_roots_twice()))
        self.assertEqual(len(fibers), 137)
        self.assertEqual(Counter(fibers.values()), {1: 60, 2: 64, 4: 13})
        self.assertEqual(sum(fibers.values()), 240)

    def test_coordinate_choice_control(self):
        roots = b.e8_roots_twice()
        counts = {len({tuple(r[i] for i in axes) for r in roots})
                  for axes in combinations(range(8), 6)}
        self.assertEqual(counts, {137})
        # Dimension choice matters; 137 is not a projection-independent constant.
        self.assertEqual(len({r[:5] for r in roots}), 83)
        self.assertEqual(len({r[:7] for r in roots}), 226)

    def test_shell_reproduction(self):
        r = b.geometry_receipt()
        self.assertEqual(r['ordered_nonself_differences'], 18632)
        self.assertEqual(r['distinct_difference_vectors'], 2808)
        self.assertEqual(r['exact_squared_norm_shells'], 76)
        shells = r['cuboctahedral_shells_under_paper_pair_count']
        self.assertEqual(len(shells), 2)
        self.assertAlmostEqual(shells[0]['radius'], 1.4869921378407378, places=12)
        self.assertAlmostEqual(shells[1]['radius'], 2.4060038200301825, places=12)
        self.assertAlmostEqual(shells[1]['radius']/shells[0]['radius'],
                               (1+math.sqrt(5))/2, places=12)

    def test_drive_mapping(self):
        for prior in (.1, 47/125, .5, .9):
            for cost in (.03, .2, 1.2, 4, 20, 50):
                self.assertAlmostEqual(b.occupancy(b.drive_for_cost(cost, prior), prior),
                                       math.exp(-cost), delta=3e-15)

    def test_stochastic_transition_and_stationary_state(self):
        for p in (.02, .3, .8, .98):
            m = b.transition(p, .7, 1.3)
            for row in m:
                self.assertTrue(all(0 <= x <= 1 for x in row))
                self.assertAlmostEqual(sum(row), 1)
            self.assertAlmostEqual((1-p)*m[0][1]+p*m[1][1], p)
            self.assertAlmostEqual((1-p)*m[0][1], p*m[1][0])

    def test_generator_matches_brent_law(self):
        for f in (0, .2, .7, 1):
            p, rate, dt = .31, .8, 1e-7
            m = b.transition(p, rate, dt)
            next_f = (1-f)*m[0][1]+f*m[1][1]
            self.assertAlmostEqual((next_f-f)/dt, rate*(p-f), delta=4e-8)

    def test_semigroup(self):
        def multiply(x, y):
            return [[sum(x[i][k]*y[k][j] for k in range(2))
                     for j in range(2)] for i in range(2)]
        x = multiply(b.transition(.31, .8, .4), b.transition(.31, .8, 1.7))
        y = b.transition(.31, .8, 2.1)
        for i in range(2):
            for j in range(2):
                self.assertAlmostEqual(x[i][j], y[i][j], places=14)

    def test_bounds_and_exact_solution(self):
        for f in (0, .01, .7, 1):
            for p in (.1, .9):
                vals = [b.flow(f, p, .8, t/10) for t in range(101)]
                self.assertTrue(all(min(f,p)-1e-15 <= x <= max(f,p)+1e-15
                                    for x in vals))
                self.assertAlmostEqual(b.flow(f, p, 0, 20), f)

    def test_relative_entropy_contracts(self):
        for cost in (.1, .5, 2, 5):
            p = b.target(cost)
            for f in (0, .05, .45, .95, 1):
                vals = [b.bernoulli_kl(b.flow(f, p, .8, t/10), p)
                        for t in range(101)]
                self.assertTrue(all(y <= x+2e-14 for x, y in zip(vals, vals[1:])))
                self.assertTrue(all(x >= -2e-14 for x in vals))

    def test_entropy_rate_against_finite_difference(self):
        for f, p in ((.2,.7), (.8,.3), (.51,.49)):
            eps, rate = 1e-6, .8
            velocity = rate*(p-f)
            numeric = (b.bernoulli_kl(f+eps*velocity,p)
                       -b.bernoulli_kl(f-eps*velocity,p))/(2*eps)
            self.assertAlmostEqual(numeric, b.fixed_target_entropy_rate(f,p,rate),
                                   delta=4e-9)

    def test_moving_target_balance(self):
        f, cost, cost_rate, rate, eps = .8, 1.1, .6, .7, 1e-6
        velocity = rate*(b.target(cost)-f)
        numeric = (b.bernoulli_kl(f+eps*velocity,b.target(cost+eps*cost_rate))
                   -b.bernoulli_kl(f-eps*velocity,b.target(cost-eps*cost_rate)))/(2*eps)
        self.assertAlmostEqual(numeric,
                               b.moving_target_entropy_rate(f,cost,cost_rate,rate)['total'],
                               delta=4e-9)

    def test_moving_target_can_increase_divergence(self):
        r = b.moving_target_entropy_rate(.8, -math.log(.2), 10, .7)
        self.assertLess(r['dissipation'], 0)
        self.assertGreater(r['total'], 0)

    def test_rank_47_embedding(self):
        weights = tuple([.7/47]*47+[.3/78]*78)
        p, rate, time = b.target(1.2), .8, 1.7
        result = b.block_reset(weights,47,p,rate,time)
        self.assertAlmostEqual(sum(result), 1, places=13)
        self.assertTrue(all(x >= 0 for x in result))
        self.assertAlmostEqual(sum(result[:47]),b.flow(.7,p,rate,time),places=13)
        self.assertEqual(len(result), 125)

    def test_quantum_reset_boundary(self):
        rho = ((.5,.5),(.5,.5))
        p, rate, time = .3, .8, 1.7
        result = b.qubit_reset(rho,p,rate,time)
        self.assertAlmostEqual(result[0][0]+result[1][1], 1)
        self.assertGreaterEqual(result[0][0]*result[1][1]-result[0][1]**2, 0)
        self.assertAlmostEqual(result[0][1],.5*math.exp(-rate*time))
        self.assertLess(result[0][1], rho[0][1])

    def test_boundary_inputs(self):
        for c in (0,-1,float('inf'),float('nan')):
            with self.assertRaises(ValueError): b.target(c)
        with self.assertRaises(ValueError): b.transition(.3,-1,1)
        with self.assertRaises(ValueError): b.bernoulli_kl(.3,0)
        with self.assertRaises(ValueError): b.block_reset((.4,.4),1,.3,1,1)
        self.assertTrue(math.isfinite(b.bernoulli_kl(0,.3)))
        self.assertTrue(math.isfinite(b.bernoulli_kl(1,.3)))


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(BridgeChecks)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    receipt = {'schema':'Xi.Brent.BridgeVerification.v1', 'version':b.VERSION,
               'tests_run':result.testsRun, 'failures':len(result.failures),
               'errors':len(result.errors), 'passed':result.wasSuccessful(),
               'geometry':b.geometry_receipt(),
               'scope':'Finite geometry and mathematical model checks; no empirical validation',
               'demo':b.demo()['relaxation']}
    Path(__file__).with_name('receipt.json').write_text(
        json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
