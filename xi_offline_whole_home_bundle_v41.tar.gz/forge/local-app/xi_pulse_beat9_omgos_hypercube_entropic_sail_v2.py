#!/usr/bin/env python3
"""
Ξ Field-Wide Pulse Beat 9 v2 (`2026-10-24T13:15Z`) — Separate v2 Closing All 5 Audit
Requirements from `@Astra` (`#26699`) and `@Anam` (`#26702` / `pulse9-handoff-anam-26701/ACCEPTANCE.md`):

1. AST Security Crucible v2 (`ASTSecurityCrucibleV2`):
   - Blocks aliased `eval` (`f = eval; f(...)`), aliased `os.system` (`import os as o; o.system(...)`),
     and file writes (`open(...)`, `io.open`, `pathlib.Path.write_text`) by inspecting ALL `ast.Name`,
     `ast.Attribute`, `ast.Import`, and `ast.ImportFrom` nodes (not just direct `ast.Call` names),
     forbidding all dunder attributes (`__*__`), and restricting imports to an explicit pure-math
     allowlist (`math`, `fractions`, `decimal`).
2. Evidence-Backed AOP Lifecycle (`PROPOSED -> AST_CHECKED -> TESTED -> VERIFIED -> MERGED`):
   - Syntax/AST passing alone stops at `AST_CHECKED`.
   - Advancing to `TESTED` and `VERIFIED` requires actually running deterministic test vectors inside
     a restricted-builtins sandbox (`__builtins__` stripped of `open`, `eval`, `exec`, `__import__`, `getattr`)
     and matching expected outputs.
   - Advancing to `MERGED` requires explicit `merge_authorized=True` after `VERIFIED`.
3. Hypercube-9 Strict `k`-Threshold Enforcement (`len(unique_coords) >= k`):
   - Rejects any recovery attempt with `< k` shares (e.g. 1 share when `k = 5`) or duplicate coordinates/abscissas.
4. Hypercube-9 Deterministic Wrong-Key Rejection:
   - Authenticates recovered bytes against `secret_sha256` + `HMAC-SHA256` tag so wrong coordinate keys
     that happen to interpolate to `< 256` in GF(257) are deterministically rejected (`ValueError`)
     instead of returning corrupted bytes.
5. Structural Courier Blindness (`VaultStorageBoundary` vs `BlindCourierService`):
   - `VaultStorageBoundary.deposit_card()` takes `opaque_card_bytes` and returns a secret-free
     `BlindCourierTicket` containing only `(deposit_id, commitment_sha256, grid_cell_count)`.
   - `BlindCourierService.route_ticket()` accepts only a `BlindCourierTicket` + the 3 routing answers,
     and rejects any payload containing raw bytes, shares, or keys (`TypeError`/`ValueError`).
"""

from __future__ import annotations

import ast
import hashlib
import hmac
import json
import math
import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Set, Tuple


# ==============================================================================
# 1 & 2. AST SECURITY CRUCIBLE V2 + EVIDENCE-BACKED AOP LIFECYCLE (`#26699`, `#26702`)
# ==============================================================================
ALLOWED_IMPORT_MODULES: Set[str] = {"math", "decimal", "fractions"}

FORBIDDEN_IDENTIFIERS: Set[str] = {
    "eval",
    "exec",
    "compile",
    "__import__",
    "open",
    "input",
    "breakpoint",
    "getattr",
    "setattr",
    "delattr",
    "globals",
    "locals",
    "vars",
    "dir",
    "type",
    "object",
    "super",
    "memoryview",
    "os",
    "sys",
    "subprocess",
    "socket",
    "shutil",
    "pathlib",
    "io",
    "ctypes",
    "builtins",
    "importlib",
}

FORBIDDEN_ATTRIBUTES: Set[str] = {
    "system",
    "popen",
    "Popen",
    "run",
    "call",
    "check_output",
    "open",
    "write",
    "write_text",
    "write_bytes",
    "read_text",
    "read_bytes",
    "unlink",
    "remove",
    "rmdir",
    "socket",
    "connect",
    "CDLL",
    "cast",
}

SAFE_MATH_BUILTINS: Dict[str, Any] = {
    "abs": abs,
    "all": all,
    "any": any,
    "bool": bool,
    "dict": dict,
    "enumerate": enumerate,
    "float": float,
    "int": int,
    "len": len,
    "list": list,
    "max": max,
    "min": min,
    "pow": pow,
    "range": range,
    "round": round,
    "set": set,
    "sorted": sorted,
    "str": str,
    "sum": sum,
    "tuple": tuple,
    "zip": zip,
}


class ASTSecurityCrucibleV2:
    """
    Closes all 3 AST/AOP gaps identified by @Astra (#26699) and @Anam (#26702):
      - Catches aliased `eval` (`f = eval; f(...)`) via `ast.Name` identifier inspection.
      - Catches aliased `os.system` (`import os as o; o.system(...)`) via import allowlisting + attribute inspection.
      - Catches file writes (`open(...)`, `.write(...)`, `pathlib`) via `FORBIDDEN_IDENTIFIERS` and `FORBIDDEN_ATTRIBUTES`.
      - Only advances AOP state beyond `AST_CHECKED` when real test cases are executed and verified.
    """

    def __init__(self, n_max: int = 5000) -> None:
        self.n_max = n_max

    def inspect_and_verify(
        self,
        code_str: str,
        track_d1_bytes: bytes,
        track_d2_bytes: bytes,
        entry_fn_name: Optional[str] = None,
        test_vectors: Optional[List[Tuple[Tuple[Any, ...], Any]]] = None,
        merge_authorized: bool = False,
    ) -> Dict[str, Any]:
        t0 = time.perf_counter_ns()
        aop_trace: List[str] = ["PROPOSED"]

        try:
            tree = ast.parse(code_str)
        except SyntaxError as exc:
            aop_trace.append("ROLLED_BACK")
            return {"valid": False, "violations": [f"syntax_error:{exc}"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        all_nodes = list(ast.walk(tree))
        node_count = len(all_nodes)
        violations: List[str] = []

        if node_count > self.n_max:
            violations.append(f"node_count_exceeded:{node_count}>{self.n_max}")

        for node in all_nodes:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    mod_root = alias.name.split(".")[0]
                    if mod_root not in ALLOWED_IMPORT_MODULES:
                        violations.append(f"forbidden_import:{alias.name}")
                    if alias.asname and alias.asname in FORBIDDEN_IDENTIFIERS:
                        violations.append(f"forbidden_import_alias:{alias.asname}")
            elif isinstance(node, ast.ImportFrom):
                mod_root = (node.module or "").split(".")[0]
                if mod_root not in ALLOWED_IMPORT_MODULES:
                    violations.append(f"forbidden_import_from:{node.module}")
                for alias in node.names:
                    if alias.name in FORBIDDEN_IDENTIFIERS or alias.name in FORBIDDEN_ATTRIBUTES or alias.name.startswith("__"):
                        violations.append(f"forbidden_imported_symbol:{alias.name}")
            elif isinstance(node, ast.Name):
                if node.id in FORBIDDEN_IDENTIFIERS or node.id.startswith("__"):
                    violations.append(f"forbidden_identifier:{node.id}")
            elif isinstance(node, ast.Attribute):
                if node.attr in FORBIDDEN_ATTRIBUTES or node.attr.startswith("__"):
                    violations.append(f"forbidden_attribute:{node.attr}")

        elapsed_us = (time.perf_counter_ns() - t0) / 1000.0
        if violations:
            aop_trace.append("ROLLED_BACK")
            return {
                "valid": False,
                "node_count": node_count,
                "parse_latency_us": round(elapsed_us, 3),
                "violations": violations,
                "aop_state": aop_trace[-1],
                "aop_trace": aop_trace,
            }

        # Syntax + AST security check passed -> state is ONLY `AST_CHECKED` unless tests run!
        aop_trace.append("AST_CHECKED")
        test_results: List[Dict[str, Any]] = []

        if entry_fn_name and test_vectors:
            sandbox_globals: Dict[str, Any] = {"__builtins__": dict(SAFE_MATH_BUILTINS), "math": math}
            sandbox_locals: Dict[str, Any] = {}
            try:
                compiled = compile(tree, filename="<ast_crucible_v2>", mode="exec")
                exec(compiled, sandbox_globals, sandbox_locals)  # noqa: S102
                fn = sandbox_locals.get(entry_fn_name) or sandbox_globals.get(entry_fn_name)
                if not callable(fn):
                    aop_trace.append("ROLLED_BACK")
                    return {"valid": False, "violations": [f"missing_entry_fn:{entry_fn_name}"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}
                aop_trace.append("TESTED")
                for args, expected in test_vectors:
                    actual = fn(*args)
                    passed = (
                        math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9)
                        if isinstance(expected, float)
                        else actual == expected
                    )
                    test_results.append({"args": list(args), "expected": expected, "actual": actual, "passed": passed})
                    if not passed:
                        aop_trace.append("ROLLED_BACK")
                        return {
                            "valid": False,
                            "violations": [f"test_vector_failed:{args}->{actual}!={expected}"],
                            "aop_state": aop_trace[-1],
                            "aop_trace": aop_trace,
                            "test_results": test_results,
                        }
                aop_trace.append("VERIFIED")
                if merge_authorized:
                    aop_trace.append("MERGED")
            except Exception as exc:
                aop_trace.append("ROLLED_BACK")
                return {"valid": False, "violations": [f"runtime_fault:{exc}"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        seal_1024_hex = hashlib.sha512(track_d1_bytes).hexdigest() + hashlib.sha512(track_d2_bytes).hexdigest()
        return {
            "valid": True,
            "node_count": node_count,
            "parse_latency_us": round(elapsed_us, 3),
            "seal_1024_bits": len(seal_1024_hex) * 4,
            "aop_state": aop_trace[-1],
            "aop_trace": aop_trace,
            "test_results": test_results,
        }


# ==============================================================================
# 3, 4, 5. HYPERCUBE-9 V2: STRICT THRESHOLD, WRONG-KEY MAC, & STRUCTURAL COURIER BLINDNESS
# ==============================================================================
GF_PRIME = 257


def _gf_eval_poly(coeffs: List[int], x: int) -> int:
    acc = 0
    for c in reversed(coeffs):
        acc = (acc * x + c) % GF_PRIME
    return acc


def _gf_inv(a: int) -> int:
    return pow(a % GF_PRIME, GF_PRIME - 2, GF_PRIME)


def _gf_lagrange_zero(points: List[Tuple[int, int]]) -> int:
    total = 0
    k = len(points)
    for i in range(k):
        xi, yi = points[i]
        num = 1
        den = 1
        for j in range(k):
            if i == j:
                continue
            xj, _ = points[j]
            num = (num * (-xj % GF_PRIME)) % GF_PRIME
            den = (den * ((xi - xj) % GF_PRIME)) % GF_PRIME
        term = (yi * num * _gf_inv(den)) % GF_PRIME
        total = (total + term) % GF_PRIME
    return total


@dataclass(frozen=True)
class BlindCourierTicket:
    """
    Secret-free metadata ticket passed across the upload/model boundary to the AI courier.
    Contains ZERO plaintext bytes, ZERO share values, and ZERO Yin/Yang coordinates.
    """
    deposit_id: str
    commitment_sha256: str
    grid_cell_count: int


class BlindCourierService:
    """
    The AI courier boundary: can ONLY inspect `BlindCourierTicket` + the 3 routing questions.
    Rejects any call that attempts to pass plaintext bytes, share grids, or Yin/Yang keys.
    """

    @staticmethod
    def route_deposit_ticket(
        ticket: BlindCourierTicket,
        q1_time_restraint: str,
        q2_key_delivery: str,
        q3_access_scope: str,
        forbidden_extra: Any = None,
    ) -> Dict[str, Any]:
        if not isinstance(ticket, BlindCourierTicket):
            raise TypeError("BlindCourierService only accepts a secret-free BlindCourierTicket")
        if forbidden_extra is not None:
            raise ValueError("Boundary violation: secret/grid material must never cross into BlindCourierService")
        if q3_access_scope not in {"Remote Access", "Inhouse Access", "Given Later"}:
            raise ValueError("Invalid Question 3 access scope")
        return {
            "deposit_id": ticket.deposit_id,
            "commitment_sha256": ticket.commitment_sha256,
            "grid_cell_count": ticket.grid_cell_count,
            "q1_time_restraint": q1_time_restraint,
            "q2_key_delivery": q2_key_delivery,
            "q3_access_scope": q3_access_scope,
            "courier_visible_fields": ["deposit_id", "commitment_sha256", "grid_cell_count", "q1", "q2", "q3"],
        }


class Hypercube9YinYangVaultV2:
    """
    Closes all 3 Hypercube-9 audit gaps (#26699, #26702):
      - Enforces `len(unique_coords) >= threshold_k` and rejects duplicate coordinates/abscissas.
      - Binds `secret_sha256` and an `hmac_sha256` authentication tag so wrong keys that produce
        bytes `< 256` are deterministically rejected (`ValueError`) instead of returning bad bytes.
      - Emits a secret-free `BlindCourierTicket` for `BlindCourierService`.
    """

    def __init__(self, threshold_k: int = 5, active_cubes_n: int = 9) -> None:
        if threshold_k < 2 or active_cubes_n < threshold_k:
            raise ValueError("Require 2 <= threshold_k <= active_cubes_n")
        self.k = threshold_k
        self.n = active_cubes_n

    def deposit_card(
        self,
        opaque_card_bytes: bytes,
        seed_material: bytes,
    ) -> Tuple[Dict[Tuple[int, int, int], List[int]], Dict[str, Any], BlindCourierTicket]:
        def prng_int(tag: bytes, mod: int) -> int:
            h = hashlib.sha256(seed_material + tag).digest()
            return int.from_bytes(h[:8], "big") % mod

        all_coords = [(x, y, z) for x in range(9) for y in range(9) for z in range(9)]
        for idx in range(len(all_coords) - 1, 0, -1):
            j = prng_int(f"perm:{idx}".encode(), idx + 1)
            all_coords[idx], all_coords[j] = all_coords[j], all_coords[idx]

        active_coords = all_coords[: self.n]
        x_coords = [idx + 1 for idx in range(self.n)]

        grid: Dict[Tuple[int, int, int], List[int]] = {}
        for c_idx, coord in enumerate(all_coords):
            grid[coord] = [
                prng_int(f"chaff:{c_idx}:{b_idx}".encode(), GF_PRIME)
                for b_idx in range(len(opaque_card_bytes))
            ]

        for b_idx, secret_byte in enumerate(opaque_card_bytes):
            coeffs = [secret_byte] + [
                prng_int(f"coeff:{b_idx}:{deg}".encode(), GF_PRIME)
                for deg in range(1, self.k)
            ]
            for s_idx, coord in enumerate(active_coords):
                grid[coord][b_idx] = _gf_eval_poly(coeffs, x_coords[s_idx])

        secret_sha = hashlib.sha256(opaque_card_bytes).hexdigest()
        mac_key = hashlib.sha256(seed_material + b":yinyang_mac_key").digest()
        coord_bytes = json.dumps([list(c) for c in active_coords[: self.k]], separators=(",", ":")).encode("utf-8")
        auth_tag = hmac.new(mac_key, opaque_card_bytes + coord_bytes, hashlib.sha256).hexdigest()

        yin_yang_key = {
            "schema": "xi.steven.hypercube9.yinyang_key.v2",
            "threshold_k": self.k,
            "active_coords": [list(c) for c in active_coords[: self.k]],
            "abscissas": x_coords[: self.k],
            "payload_length": len(opaque_card_bytes),
            "secret_sha256": secret_sha,
            "auth_tag_hmac_sha256": auth_tag,
        }
        deposit_id = "hc9-" + hashlib.sha256(seed_material + secret_sha.encode()).hexdigest()[:16]
        ticket = BlindCourierTicket(
            deposit_id=deposit_id,
            commitment_sha256=secret_sha,
            grid_cell_count=len(grid),
        )
        return grid, yin_yang_key, ticket

    def recover_card(self, grid: Dict[Tuple[int, int, int], List[int]], yin_yang_key: Dict[str, Any]) -> bytes:
        req_k = int(yin_yang_key.get("threshold_k", self.k))
        if req_k < self.k:
            raise ValueError(f"Key threshold_k={req_k} below vault minimum k={self.k}")

        raw_coords = yin_yang_key.get("active_coords", [])
        xs = yin_yang_key.get("abscissas", [])
        if len(raw_coords) < self.k or len(xs) < self.k or len(raw_coords) != len(xs):
            raise ValueError(f"Insufficient shares: got {len(raw_coords)}, require at least k={self.k}")

        coords = [tuple(c) for c in raw_coords]
        if len(set(coords)) != len(coords) or len(set(xs)) != len(xs):
            raise ValueError("Duplicate cube coordinates or abscissas rejected")

        length = int(yin_yang_key["payload_length"])
        out = bytearray()
        for b_idx in range(length):
            pts = [(int(xs[i]), grid[coords[i]][b_idx]) for i in range(len(coords))]
            val = _gf_lagrange_zero(pts)
            if val >= 256:
                raise ValueError("Invalid key or corrupted cube share (field element >= 256)")
            out.append(val)

        recovered = bytes(out)
        actual_sha = hashlib.sha256(recovered).hexdigest()
        expected_sha = yin_yang_key.get("secret_sha256")
        if not expected_sha or not hmac.compare_digest(actual_sha, expected_sha):
            raise ValueError("Integrity check failed: wrong Yin/Yang key or corrupted share (SHA-256 mismatch)")

        return recovered


def run_v2_audit_verification() -> Dict[str, Any]:
    crucible = ASTSecurityCrucibleV2(n_max=5000)

    # 1. Safe function with NO test vectors -> stops at AST_CHECKED (not TESTED/VERIFIED/MERGED)
    res_syntax_only = crucible.inspect_and_verify(
        "def hypot(x, y):\n    return (x * x + y * y) ** 0.5\n",
        b"d1",
        b"d2",
    )

    # 2. Safe function WITH passing test vectors + merge_authorized=True -> reaches MERGED
    res_verified = crucible.inspect_and_verify(
        "def hypot(x, y):\n    return (x * x + y * y) ** 0.5\n",
        b"d1",
        b"d2",
        entry_fn_name="hypot",
        test_vectors=[((3.0, 4.0), 5.0), ((5.0, 12.0), 13.0)],
        merge_authorized=True,
    )

    # 3. Adversarial fixture A (@Astra #26699): aliased `eval` (`f = eval; f(...)`)
    res_alias_eval = crucible.inspect_and_verify(
        "def sneak():\n    f = eval\n    return f('2 + 2')\n",
        b"d1",
        b"d2",
    )

    # 4. Adversarial fixture B (@Astra #26699): aliased `os.system` (`import os as o; o.system(...)`)
    res_alias_os = crucible.inspect_and_verify(
        "import os as o\ndef sneak():\n    return o.system('id')\n",
        b"d1",
        b"d2",
    )

    # 5. Adversarial fixture C (@Astra #26699): file write (`open('/tmp/pwn', 'w').write('x')`)
    res_file_write = crucible.inspect_and_verify(
        "def sneak():\n    fh = open('/tmp/pwn', 'w')\n    return fh.write('x')\n",
        b"d1",
        b"d2",
    )

    # 6. Hypercube-9 v2 checks (@Astra #26699 & @Anam #26702)
    hc9 = Hypercube9YinYangVaultV2(threshold_k=5, active_cubes_n=9)
    secret = b"Hypercube-9 v2: strict k-threshold, SHA-256 wrong-key rejection, and blind ticket!"
    grid, yy_key, ticket = hc9.deposit_card(secret, seed_material=b"hc9-v2-seed-20261024")
    recovered = hc9.recover_card(grid, yy_key)

    # 7. Adversarial fixture D (@Astra #26699): 1-share recovery attempt when k=5
    one_share_key = dict(
        yy_key,
        active_coords=yy_key["active_coords"][:1],
        abscissas=yy_key["abscissas"][:1],
    )
    try:
        hc9.recover_card(grid, one_share_key)
        one_share_rejected = False
    except ValueError:
        one_share_rejected = True

    # 8. Adversarial fixture E (@Astra #26699): wrong key whose Lagrange interpolation stays < 256
    # Force a 1-byte secret where wrong coordinates yield a value in 0..255, and verify SHA-256 rejects it!
    grid_1b, key_1b, _ = hc9.deposit_card(b"A", seed_material=b"hc9-1byte-wrong-key-test")
    wrong_key_1b = dict(
        key_1b,
        active_coords=[[0, 0, 0], [0, 0, 1], [0, 0, 2], [0, 0, 3], [0, 0, 4]],
    )
    # Ensure our test cells have values < 256 so Lagrange interpolation returns < 256 without SHA-256 check
    for c in wrong_key_1b["active_coords"]:
        grid_1b[tuple(c)][0] = 42
    try:
        hc9.recover_card(grid_1b, wrong_key_1b)
        wrong_key_under_256_rejected = False
    except ValueError:
        wrong_key_under_256_rejected = True

    # 9. Structural Courier Blindness check
    routed_ticket = BlindCourierService.route_deposit_ticket(
        ticket,
        q1_time_restraint="2026-10-25T00:00Z",
        q2_key_delivery="Out-of-band Yin/Yang key",
        q3_access_scope="Inhouse Access",
    )
    try:
        BlindCourierService.route_deposit_ticket(
            ticket,
            q1_time_restraint="2026-10-25T00:00Z",
            q2_key_delivery="Out-of-band",
            q3_access_scope="Inhouse Access",
            forbidden_extra=secret,
        )
        courier_blocks_raw_secret = False
    except ValueError:
        courier_blocks_raw_secret = True

    gates = {
        "1_syntax_only_stops_at_AST_CHECKED": res_syntax_only["aop_state"] == "AST_CHECKED",
        "2_verified_test_vectors_reach_MERGED": res_verified["aop_state"] == "MERGED" and len(res_verified["test_results"]) == 2,
        "3_aliased_eval_blocked": res_alias_eval["valid"] is False and "forbidden_identifier:eval" in res_alias_eval["violations"],
        "4_aliased_os_system_blocked": res_alias_os["valid"] is False and "forbidden_import:os" in res_alias_os["violations"],
        "5_file_writes_blocked": res_file_write["valid"] is False and "forbidden_identifier:open" in res_file_write["violations"],
        "6_hc9_lossless_recovery_with_valid_key": recovered == secret,
        "7_hc9_one_share_recovery_rejected": one_share_rejected is True,
        "8_hc9_wrong_key_under_256_rejected_by_sha256": wrong_key_under_256_rejected is True,
        "9_blind_courier_ticket_has_no_secret_fields": (
            routed_ticket["deposit_id"] == ticket.deposit_id and courier_blocks_raw_secret is True
        ),
    }

    return {
        "schema": "xi.pulse.beat9.v2.audit_repair.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "audit_details": {
            "syntax_only_aop_trace": res_syntax_only["aop_trace"],
            "verified_aop_trace": res_verified["aop_trace"],
            "aliased_eval_violations": res_alias_eval["violations"],
            "aliased_os_violations": res_alias_os["violations"],
            "file_write_violations": res_file_write["violations"],
        },
    }


if __name__ == "__main__":
    res = run_v2_audit_verification()
    print(json.dumps(res, indent=2))
    if not res["all_passed"]:
        raise SystemExit(1)
