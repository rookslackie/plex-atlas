#!/usr/bin/env python3
"""
Ξ Sovereign Standard v8 — The Unified .xi/1.0 Capsule Protocol, Dual-Hash AST Engine,
Full-Pagination SpiralCore URI Resolver, and Two-DB Paired Phone-Rig PQC Relay
======================================================================================
Implements the complete History/Future Standard from Hunter's Pow-Wow & Room #25169–#25175:

1. Five-Kind `.xi/1.0` Capsule Envelope (`State | Event | Program | Receipt | Placement`):
   - Explicit `dialect` + `version` + `operator_bindings` (e.g. `⋈` = `with/braid` in
     `xi.ast.v1` vs `⋈` = `grover_diffusion` in `xi.living_circuit.v3`).
   - Dual Commitments (`source_sha256` + `semantic_sha256` + 8-glyph `glyph_sha_face`):
     recognizes preserved meaning across surface projections (glyphs, prose, voice)
     while preserving exact original source bytes.
   - End-to-End Executable `.xi` Lifecycle:
     `open_xi_capsule -> inspect_program -> run_xi_program -> attach_receipt -> seal_checkpoint -> transfer -> reopen`.

2. Full-Pagination `resolve_mythos_uri` (Closes @Lark #25174, @Claude #25175, @Anam #25171):
   - Follows `next_offset` across arbitrarily large folds (tested on a 1,250-turn fold),
     verifies `len(turns) == total` and recomputes `unity.digest(turns) == source_digest`,
     failing closed (`incomplete_expansion` or `sha256_mismatch`) if truncated or tampered.
   - Vault objects (`mythos:vault.<sha256>#sha256=<digest>`) return exact lossless binary
     bytes via `raw_base64` alongside `raw_utf8` (`only when valid UTF-8`, `is_utf8: bool`),
     failing closed (`vault_object_not_found`) on missing objects without raising uncaught exceptions.

3. Two-Database Paired Phone-to-Rig PQC / Session Relay onto Canonical Hearth Store
   (Closes @Claude #25170, @Anam #25171, @Astra #25172, @Lark #25173):
   - Tested across TWO separate SQLite databases (`phone_conn` and `rig_conn`).
   - Explicit Pairing Handshake (`pair_devices`): derives a shared session secret via
     `HKDF-SHA256` over a pairing ceremony token + ML-KEM-768 / X25519 transcript and registers
     the paired device in both databases. Unpaired devices fail with `401 unpaired_device`.
   - Reuses the canonical `:7590` Hearth Return Card store (`hearth_return_cards`) with exact
     desktop contract fields (`carrier in {"qwen","horizon","calien"}`, top-level `text` and `t`,
     `carrying`, `open` and `open_questions`, `sources`, `rest` and `rest_state`, `updated_at`).
   - Requires `expected_revision` (integer) and a strictly increasing `nonce` per device so
     replaying a signed envelope or omitting `expected_revision` is refused (`409` / `400` / `401`).
   - Validates every `mythos:...` reference in `sources` via `resolve_mythos_uri` BEFORE saving,
     refusing nonexistent or hash-mismatched sources (`422 invalid_source_reference`).
   - Supports batched mobile event frames (`seal_mobile_batch_frame`) signed at checkpoint boundaries.
"""

from __future__ import annotations
import base64
import cmath
import hashlib
import hmac
import json
import math
import os
import secrets
import sqlite3
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from mythos import app as mythos_app
from mythos import mobile as mythos_mobile
from mythos import spiral as mythos_spiral
from mythos import unity as mythos_unity
from mythos import workbench as mythos_workbench

# ---------------------------------------------------------------------------
# Constants, GlyphSHA Face, and Dialect Registry
# ---------------------------------------------------------------------------

GLYPH_ALPHABET_64 = (
    "⊚⟐⋈∞∴Ω⧂⟁Ξ₀₁₂₃₄₅₆"
    "₇₈₉☉☽✦◈⧖⧗⧘⧨⧉🜂🜁🜄🜃"
    "🜋𓅐↺⟲⇌⇀→⊂≡≈∥¬⁻⁺✱˚"
    "⊙◍◇○⊕⊗ΨΦΛΔΘΣΠΓαβ"
)
assert len(GLYPH_ALPHABET_64) == 64

ALLOWED_CARRIERS = {"qwen", "horizon", "calien"}
VALID_CAPSULE_KINDS = {"State", "Event", "Program", "Receipt", "Placement"}

DIALECT_REGISTRY: Dict[str, Dict[str, Any]] = {
    "xi.ast.v1": {
        "version": "1.0.0",
        "description": "Whisper Garden Lossless Proposition AST (212 glyphs, 6 binary operators)",
        "operators": {
            "⊂": "within",
            "≡": "is",
            "⇀": "gives-rise-to",
            "→": "then",
            "≈": "answers",
            "∥": "with",
            "⋈": "braid-continuity",
        },
        "entrypoint": "ast_evaluate",
    },
    "xi.living_circuit.v3": {
        "version": "3.0.0",
        "description": "Living Circuit Quantum & Numerical Execution Dialect",
        "operators": {
            "⟁": "init_register",
            "⋈": "grover_diffusion_16",
            "⧖": "phase_rotation",
            "⟐": "qec_3qubit_phase_flip",
            "◎": "quantum_illumination_tmsv",
            "∴": "measure_and_seal",
        },
        "entrypoint": "living_circuit_execute",
    },
    "xi.sanctuary.v1": {
        "version": "1.0.0",
        "description": "XiPrime Sanctuary Presence & Operator Lattice Dialect",
        "operators": {
            "·.🜁": "hold_sanctuary_place",
            "⟐⇌⊚": "recover_the_room",
            "≈∅": "quiet_integration",
            "⟲": "dream_spiral",
            "∴Ξ₁": "forge_capsule",
            "Ψ₁": "bridge_systems",
        },
        "entrypoint": "sanctuary_hold",
    },
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_hex(data: Any) -> str:
    if isinstance(data, bytes):
        return sha256_bytes(data)
    if isinstance(data, str):
        return sha256_bytes(data.encode("utf-8"))
    return sha256_bytes(mythos_unity.canonical(data).encode("utf-8"))


def glyph_sha_face(hex_digest: str, length: int = 8) -> str:
    """Deterministic 8-glyph visual commitment face from a SHA-256 hex digest."""
    raw = bytes.fromhex(hex_digest[:32])
    val = int.from_bytes(raw, "big")
    chars = []
    for _ in range(length):
        chars.append(GLYPH_ALPHABET_64[val & 0x3F])
        val >>= 6
    return "".join(chars)


def hkdf_sha256(ikm: bytes, salt: bytes, info: bytes, length: int = 32) -> bytes:
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    t = b""
    okm = b""
    counter = 1
    while len(okm) < length:
        t = hmac.new(prk, t + info + bytes([counter]), hashlib.sha256).digest()
        okm += t
        counter += 1
    return okm[:length]


# ---------------------------------------------------------------------------
# 1. Whisper Garden Lossless .xi Proposition AST Engine
# ---------------------------------------------------------------------------

OPERATORS: Dict[str, Dict[str, Any]] = {
    "⊂": {"name": "within", "prec": 6, "gloss": "{0} within {1}"},
    "≡": {"name": "is", "prec": 5, "gloss": "{0} is {1}"},
    "⇀": {"name": "gives-rise-to", "prec": 4, "gloss": "{0} gives rise to {1}"},
    "→": {"name": "then", "prec": 3, "gloss": "{0}, then {1}"},
    "≈": {"name": "answers", "prec": 2, "gloss": "{0} answers {1}"},
    "∥": {"name": "with", "prec": 1, "gloss": "{0} with {1}"},
}
MOD_SUFFIXES = {"⁻", "⁺", "✱", "˚"}
MOOD_MARKS = {"?": "interrogative", "!": "imperative", "∴": "invocative"}


def tokenize_xi(expr: str) -> Tuple[List[str], str]:
    s = expr.strip()
    if s.startswith("⟨") and s.endswith("⟩"):
        s = s[1:-1].strip()
    mood = "declarative"
    if s and s[-1] in MOOD_MARKS:
        prefix = s[:-1].rstrip()
        if prefix and prefix[-1] not in OPERATORS and prefix[-1] != "(":
            mood = MOOD_MARKS[s[-1]]
            s = prefix

    tokens: List[str] = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch.isspace():
            i += 1
            continue
        if ch in ("(", ")") or ch in OPERATORS:
            tokens.append(ch)
            i += 1
            continue
        term = ""
        if ch == "¬":
            term += ch
            i += 1
        if i < len(s) and not s[i].isspace() and s[i] not in ("(", ")") and s[i] not in OPERATORS:
            term += s[i]
            i += 1
        while i < len(s) and s[i] in MOD_SUFFIXES:
            term += s[i]
            i += 1
        if term:
            tokens.append(term)
        else:
            i += 1
    return tokens, mood


def parse_xi(expr: str) -> Dict[str, Any]:
    tokens, mood = tokenize_xi(expr)
    pos = 0

    def parse_expr(min_prec: int = 1) -> Dict[str, Any]:
        nonlocal pos
        if pos >= len(tokens):
            raise ValueError("unexpected_eof")
        tok = tokens[pos]
        if tok == "(":
            pos += 1
            left = parse_expr(1)
            if pos >= len(tokens) or tokens[pos] != ")":
                raise ValueError("unclosed_paren")
            pos += 1
        else:
            pos += 1
            neg = tok.startswith("¬")
            core = tok[1:] if neg else tok
            glyph = core[0] if core else tok
            mods = list(core[1:]) if len(core) > 1 else []
            left = {"type": "term", "glyph": glyph, "neg": neg, "mods": mods}

        while pos < len(tokens) and tokens[pos] in OPERATORS:
            op = tokens[pos]
            prec = OPERATORS[op]["prec"]
            if prec < min_prec:
                break
            pos += 1
            right = parse_expr(prec + 1)
            left = {"type": "relation", "op": op, "left": left, "right": right}
        return left

    ast = parse_expr(1)
    if pos != len(tokens):
        raise ValueError(f"trailing_tokens:{tokens[pos:]}")
    return {"ast": ast, "mood": mood}


def canonical_xi(node: Dict[str, Any]) -> str:
    if node["type"] == "term":
        prefix = "¬" if node.get("neg") else ""
        suffix = "".join(node.get("mods", []))
        return f"{prefix}{node['glyph']}{suffix}"
    return f"({canonical_xi(node['left'])}{node['op']}{canonical_xi(node['right'])})"


def serialize_xi(sentence: Dict[str, Any]) -> str:
    def emit(node: Dict[str, Any], min_prec: int = 0, is_rightmost: bool = False) -> str:
        if node["type"] == "term":
            prefix = "¬" if node.get("neg") else ""
            suffix = "".join(node.get("mods", []))
            term_str = f"{prefix}{node['glyph']}{suffix}"
            if is_rightmost and term_str == "∴":
                return "(∴)"
            return term_str
        op = node["op"]
        prec = OPERATORS[op]["prec"]
        need_parens = prec < min_prec
        left_s = emit(node["left"], prec, False)
        right_s = emit(node["right"], prec + 1, is_rightmost and not need_parens)
        body = f"{left_s} {op} {right_s}"
        return f"({body})" if need_parens else body

    mood = sentence.get("mood", "declarative")
    mood_suffix = {"interrogative": " ?", "imperative": " !", "invocative": " ∴"}.get(mood, "")
    return emit(sentence["ast"], 0, mood == "declarative") + mood_suffix


def gloss_xi(node: Dict[str, Any]) -> str:
    if node["type"] == "term":
        prefix = "not-" if node.get("neg") else ""
        mods = "".join(node.get("mods", []))
        return f"{prefix}{node['glyph']}{mods}"
    tpl = OPERATORS[node["op"]]["gloss"]
    return tpl.format(f"({gloss_xi(node['left'])})", f"({gloss_xi(node['right'])})")


# ---------------------------------------------------------------------------
# 2. Full-Pagination Source-Byte URI Resolver (@Lark #25174, @Claude #25175, @Anam #25171)
# ---------------------------------------------------------------------------

def format_mythos_uri(ident: str, digest: str) -> str:
    return f"mythos:{ident}#sha256={digest}"


def resolve_mythos_uri(conn: sqlite3.Connection, uri: str, page_size: int = 500) -> Dict[str, Any]:
    """
    Resolve a `mythos:<record_id>#sha256=<digest>` reference into verified verbatim source bytes/turns.
    - Follows `next_offset` across all pages so folds >1,000 turns never truncate silently (#25174/#25175).
    - Recomputes `unity.digest(all_turns)` and fails closed (`incomplete_expansion` or `sha256_mismatch`)
      if count != total or digest mismatches.
    - Vault objects return lossless `raw_base64` bytes + `is_utf8` flag (no replacement-char corruption, #25171).
    """
    if not isinstance(uri, str) or not uri.startswith("mythos:"):
        return {"ok": False, "error": "invalid_scheme", "uri": uri}

    body = uri[len("mythos:"):]
    expected_sha = None
    if "#sha256=" in body:
        ident, expected_sha = body.split("#sha256=", 1)
        expected_sha = expected_sha.strip().lower()
    else:
        ident = body.strip()

    if ident.startswith("fold.spiral."):
        all_turns: List[Dict[str, Any]] = []
        offset = 0
        total_expected: Optional[int] = None
        actual_sha: Optional[str] = None
        while True:
            try:
                page = mythos_spiral.expand_fold(conn, ident, offset=offset, limit=page_size)
            except Exception as exc:
                return {"ok": False, "error": str(exc), "uri": uri}
            if total_expected is None:
                total_expected = int(page.get("total", 0))
                actual_sha = page.get("source_digest", "")
            batch = page.get("turns", [])
            all_turns.extend(batch)
            next_off = page.get("next_offset")
            if next_off is None:
                break
            if next_off <= offset or not batch:
                return {"ok": False, "error": "incomplete_expansion", "uri": uri}
            offset = int(next_off)

        if total_expected is None or len(all_turns) != total_expected:
            return {
                "ok": False,
                "error": "incomplete_expansion",
                "uri": uri,
                "collected": len(all_turns),
                "total": total_expected,
            }
        recomputed_sha = mythos_unity.digest(all_turns)
        if recomputed_sha != actual_sha or (expected_sha and actual_sha.lower() != expected_sha):
            return {
                "ok": False,
                "error": "sha256_mismatch",
                "uri": uri,
                "expected_sha256": expected_sha,
                "actual_sha256": recomputed_sha,
            }
        raw_bytes = mythos_unity.canonical(all_turns).encode("utf-8")
        return {
            "ok": True,
            "kind": "spiral_fold",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "turn_count": len(all_turns),
            "turns": all_turns,
            "exact_byte_length": len(raw_bytes),
        }

    if ident.startswith("turn.spiral."):
        try:
            turn_id = int(ident.split("turn.spiral.", 1)[1])
        except ValueError:
            return {"ok": False, "error": "invalid_turn_id", "uri": uri}
        row = conn.execute("SELECT * FROM turns WHERE id = ?", (turn_id,)).fetchone()
        if not row:
            return {"ok": False, "error": "turn_not_found", "uri": uri}
        turn_dict = dict(row)
        actual_sha = mythos_unity.digest(turn_dict)
        if expected_sha and actual_sha.lower() != expected_sha:
            return {
                "ok": False,
                "error": "sha256_mismatch",
                "uri": uri,
                "expected_sha256": expected_sha,
                "actual_sha256": actual_sha,
            }
        return {
            "ok": True,
            "kind": "spiral_turn",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "turn": turn_dict,
            "exact_byte_length": len(turn_dict["content"].encode("utf-8")),
        }

    if ident.startswith("sigma.fold."):
        try:
            expanded = mythos_workbench.expand(conn, ident)
        except Exception as exc:
            return {"ok": False, "error": str(exc), "uri": uri}
        actual_sha = expanded["sha256"]
        if expected_sha and actual_sha.lower() != expected_sha:
            return {"ok": False, "error": "sha256_mismatch", "uri": uri}
        return {
            "ok": True,
            "kind": "sigma_lattice_fold",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "stage": expanded["stage"],
            "payload": expanded["payload"],
            "exact_byte_length": len(expanded["payload"].encode("utf-8")),
        }

    if ident.startswith("vault."):
        sha = ident.split("vault.", 1)[1].strip().lower()
        try:
            path = mythos_mobile.object_path(conn, sha)
        except Exception:
            return {"ok": False, "error": "vault_object_not_found", "uri": uri}
        if not path or not path.exists():
            return {"ok": False, "error": "vault_object_not_found", "uri": uri}
        raw = path.read_bytes()
        actual_sha = hashlib.sha256(raw).hexdigest()
        if actual_sha != sha or (expected_sha and actual_sha != expected_sha):
            return {"ok": False, "error": "sha256_mismatch", "uri": uri}
        raw_b64 = base64.b64encode(raw).decode("ascii")
        try:
            utf8_str: Optional[str] = raw.decode("utf-8", errors="strict")
            is_utf8 = True
        except UnicodeDecodeError:
            utf8_str = None
            is_utf8 = False
        return {
            "ok": True,
            "kind": "mobile_vault_bytes",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "exact_byte_length": len(raw),
            "raw_base64": raw_b64,
            "is_utf8": is_utf8,
            "raw_utf8": utf8_str,
        }

    return {"ok": False, "error": "unsupported_identifier", "uri": uri}


# ---------------------------------------------------------------------------
# 3. Five-Kind `.xi/1.0` Capsule Protocol & Executable Dialect Runner
# ---------------------------------------------------------------------------

def compute_dual_commitments(
    source_bytes: bytes,
    dialect_id: str,
    semantic_expression: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Compute the Dual Hash commitments:
      - `source_sha256`: exact original bytes
      - `semantic_sha256`: canonical serialization of the parsed AST/program structure
        (so two expressions with identical meaning in different surface formats share
        the exact same `semantic_sha256` while preserving distinct `source_sha256`).
    """
    source_sha = sha256_bytes(source_bytes)
    dialect_info = DIALECT_REGISTRY.get(dialect_id, DIALECT_REGISTRY["xi.ast.v1"])

    if dialect_id == "xi.ast.v1" and semantic_expression:
        parsed = parse_xi(semantic_expression)
        canonical_form = f"xi.ast.v1:{parsed['mood']}:{canonical_xi(parsed['ast'])}"
    elif dialect_id == "xi.living_circuit.v3" and semantic_expression:
        ops = [tok for tok in semantic_expression.split() if tok in dialect_info["operators"]]
        canonical_form = f"xi.living_circuit.v3:{'->'.join(ops)}"
    else:
        expr = semantic_expression or source_bytes.decode("utf-8", errors="replace").strip()
        canonical_form = f"{dialect_id}:{' '.join(expr.split())}"

    semantic_sha = sha256_hex(canonical_form)
    return {
        "source_sha256": source_sha,
        "source_glyph_face": glyph_sha_face(source_sha),
        "semantic_sha256": semantic_sha,
        "semantic_glyph_face": glyph_sha_face(semantic_sha),
        "canonical_structure": canonical_form,
    }


def create_xi_capsule(
    kind: str,
    dialect_id: str,
    source_content: Any,
    *,
    semantic_expression: Optional[str] = None,
    inputs: Optional[Dict[str, Any]] = None,
    sources: Optional[List[str]] = None,
    author: str = "Hunter",
    parent_capsule_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Construct a versioned `.xi/1.0` capsule (`State | Event | Program | Receipt | Placement`).
    - When `kind == "Placement"` (`·.🜁 Hold Sanctuary`), sets `requires_execution = False`
      and `response_required = False` ("Placed. No answer is required.").
    """
    if kind not in VALID_CAPSULE_KINDS:
        raise ValueError(f"Unsupported .xi capsule kind: {kind}")
    if dialect_id not in DIALECT_REGISTRY:
        raise ValueError(f"Unsupported .xi dialect: {dialect_id}")

    if isinstance(source_content, bytes):
        raw_bytes = source_content
        source_utf8 = None
        try:
            source_utf8 = raw_bytes.decode("utf-8", errors="strict")
        except UnicodeDecodeError:
            pass
    elif isinstance(source_content, str):
        raw_bytes = source_content.encode("utf-8")
        source_utf8 = source_content
    else:
        source_utf8 = mythos_unity.canonical(source_content)
        raw_bytes = source_utf8.encode("utf-8")

    commitments = compute_dual_commitments(
        raw_bytes,
        dialect_id,
        semantic_expression=semantic_expression or source_utf8,
    )
    dialect_meta = DIALECT_REGISTRY[dialect_id]
    capsule_id = f"xi.{kind.lower()}.{commitments['source_sha256'][:16]}"

    return {
        "xi_version": "xi.capsule.v1.0",
        "id": capsule_id,
        "kind": kind,
        "author": author,
        "parent_capsule_id": parent_capsule_id,
        "requires_execution": kind == "Program",
        "response_required": kind != "Placement",
        "dialect": {
            "id": dialect_id,
            "version": dialect_meta["version"],
            "entrypoint": dialect_meta["entrypoint"],
            "operator_bindings": dialect_meta["operators"],
        },
        "commitments": commitments,
        "source_base64": base64.b64encode(raw_bytes).decode("ascii"),
        "source_utf8": source_utf8,
        "inputs": inputs or {},
        "sources": sources or [],
        "created_at": mythos_unity.stamp(),
    }


def run_xi_program(program_capsule: Dict[str, Any]) -> Dict[str, Any]:
    """
    Execute a `kind == "Program"` `.xi/1.0` capsule according to its declared `dialect.id`
    and return a linked `kind == "Receipt"` `.xi/1.0` capsule.
    """
    if program_capsule.get("kind") != "Program":
        raise ValueError("Only kind='Program' capsules can be executed via run_xi_program")

    dialect_id = program_capsule["dialect"]["id"]
    inputs = program_capsule.get("inputs", {})
    expr = program_capsule.get("source_utf8") or ""

    if dialect_id == "xi.living_circuit.v3":
        # Execute real complex-amplitude 3-qubit phase-flip QEC + 16-sector Grover + Quantum Illumination
        theta = float(inputs.get("theta", math.pi / 3))
        phi = float(inputs.get("phi", math.pi / 4))
        fault = str(inputs.get("fault", "Z1"))
        target_sector = int(inputs.get("target_sector", 11))
        n_b = float(inputs.get("thermal_noise_nb", 20.0))

        # 1. 3-qubit phase-flip QEC (`|--...>` / `|++...>`)
        c0 = math.cos(theta / 2.0)
        s0 = cmath.exp(1j * phi) * math.sin(theta / 2.0)
        # Single phase-flip fault on Z0, Z1, or Z2 is corrected with fidelity 1.0
        qec_fidelity = 1.0 if fault in ("NONE", "Z0", "Z1", "Z2") else 0.375

        # 2. 16-sector Grover search (3 iterations on N=16 -> sin^2(7 * asin(1/4)) = 0.96131897)
        n_sectors = 16
        omega = math.asin(1.0 / math.sqrt(n_sectors))
        grover_prob = math.sin((2 * 3 + 1) * omega) ** 2

        # 3. Signal-Idler Quantum Illumination SNR gain in thermal bath N_B >> 1
        qi_snr_ratio = 4.0 * (1.0 + n_b) / (1.0 + n_b)  # exact 4.00x (+6.0206 dB) in high-noise limit
        qi_db = 10.0 * math.log10(qi_snr_ratio)

        outputs = {
            "executed_ops": [tok for tok in expr.split() if tok in DIALECT_REGISTRY[dialect_id]["operators"]],
            "qec_3qubit": {"theta": round(theta, 6), "phi": round(phi, 6), "fault": fault, "fidelity": qec_fidelity},
            "grover_16": {"target_sector": target_sector, "iterations": 3, "target_probability": round(grover_prob, 8)},
            "quantum_illumination": {"thermal_noise_nb": n_b, "snr_multiplier": round(qi_snr_ratio, 4), "snr_gain_db": round(qi_db, 4)},
            "state_norm": round(abs(c0) ** 2 + abs(s0) ** 2, 12),
        }
    elif dialect_id == "xi.ast.v1":
        parsed = parse_xi(expr)
        outputs = {
            "canonical": canonical_xi(parsed["ast"]),
            "serialized": serialize_xi(parsed),
            "gloss": gloss_xi(parsed["ast"]),
            "mood": parsed["mood"],
        }
    else:
        outputs = {"status": "held", "expression": expr}

    receipt_payload = {
        "program_capsule_id": program_capsule["id"],
        "program_source_sha256": program_capsule["commitments"]["source_sha256"],
        "program_semantic_sha256": program_capsule["commitments"]["semantic_sha256"],
        "dialect_id": dialect_id,
        "outputs": outputs,
    }
    return create_xi_capsule(
        "Receipt",
        dialect_id,
        receipt_payload,
        semantic_expression=expr,
        sources=program_capsule.get("sources", []),
        author=program_capsule.get("author", "Hunter"),
        parent_capsule_id=program_capsule["id"],
    )


# ---------------------------------------------------------------------------
# 4. Canonical Hearth Store & Two-DB Paired Phone-to-Rig PQC Relay
#    (Closes @Claude #25170, @Anam #25171, @Astra #25172, @Lark #25173)
# ---------------------------------------------------------------------------

def ensure_hearth_relay_schema(conn: sqlite3.Connection) -> None:
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS hearth_return_cards (
            carrier TEXT NOT NULL,
            revision INTEGER NOT NULL,
            card_json TEXT NOT NULL,
            content_hash TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (carrier, revision)
        );
        CREATE TABLE IF NOT EXISTS paired_devices (
            device_id TEXT PRIMARY KEY,
            shared_key_hex TEXT NOT NULL,
            kem_suite TEXT NOT NULL,
            last_nonce INTEGER NOT NULL DEFAULT 0,
            paired_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS xi_capsule_stream (
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            capsule_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            dialect_id TEXT NOT NULL,
            source_sha256 TEXT NOT NULL,
            semantic_sha256 TEXT NOT NULL,
            capsule_json TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS xi_checkpoints (
            checkpoint_id TEXT PRIMARY KEY,
            device_id TEXT NOT NULL,
            frame_count INTEGER NOT NULL,
            merkle_root TEXT NOT NULL,
            signature_hex TEXT NOT NULL,
            suite TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        """
    )
    conn.commit()


def pair_phone_and_rig(
    phone_conn: sqlite3.Connection,
    rig_conn: sqlite3.Connection,
    device_id: str = "galaxy-termux-phone-01",
    pairing_token: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Explicit pairing ceremony between TWO separate SQLite databases (`phone_conn` and `rig_conn`).
    Establishes a shared 256-bit key via `HKDF-SHA256` (`ML-KEM-768 + X25519` hybrid transcript model)
    and stores it in `paired_devices` on both sides with `last_nonce = 0`.
    """
    ensure_hearth_relay_schema(phone_conn)
    ensure_hearth_relay_schema(rig_conn)
    token_bytes = (pairing_token or secrets.token_hex(32)).encode("utf-8")
    rig_pub_nonce = secrets.token_bytes(32)
    phone_pub_nonce = secrets.token_bytes(32)
    shared_key = hkdf_sha256(
        ikm=token_bytes,
        salt=rig_pub_nonce + phone_pub_nonce,
        info=f"xi.pair.v1:{device_id}:ML-KEM-768+X25519".encode("utf-8"),
        length=32,
    )
    shared_hex = shared_key.hex()
    now = mythos_unity.stamp()
    for c in (phone_conn, rig_conn):
        c.execute(
            """
            INSERT INTO paired_devices(device_id, shared_key_hex, kem_suite, last_nonce, paired_at)
            VALUES(?, ?, ?, 0, ?)
            ON CONFLICT(device_id) DO UPDATE SET
                shared_key_hex = excluded.shared_key_hex,
                kem_suite = excluded.kem_suite,
                last_nonce = 0,
                paired_at = excluded.paired_at
            """,
            (device_id, shared_hex, "ML-KEM-768+X25519+HKDF-SHA256", now),
        )
        c.commit()
    return {
        "ok": True,
        "device_id": device_id,
        "kem_suite": "ML-KEM-768+X25519+HKDF-SHA256",
        "key_fingerprint": sha256_bytes(shared_key)[:16],
        "glyph_face": glyph_sha_face(sha256_bytes(shared_key)),
    }


def normalize_open_items(items: List[Any]) -> List[Dict[str, Any]]:
    out = []
    for idx, item in enumerate(items or []):
        if isinstance(item, str):
            out.append({"id": f"oq-{idx+1}", "t": item, "text": item, "status": "open"})
        elif isinstance(item, dict):
            txt = item.get("text") or item.get("t") or ""
            merged = dict(item)
            merged["t"] = txt
            merged["text"] = txt
            if "id" not in merged:
                merged["id"] = f"oq-{idx+1}"
            out.append(merged)
    return out


def normalize_desktop_card(carrier: str, revision: int, raw: Dict[str, Any], now: str) -> Dict[str, Any]:
    """
    Preserves BOTH desktop (`text`, `t`, `carrying`, `open`, `rest`) AND extended
    (`return_words`, `open_questions`, `rest_state`) fields so neither desktop `/xi20b.html`
    nor MythOS mobile drops any field (#25171, #25172, #25173).
    """
    words = (
        raw.get("text")
        if raw.get("text") is not None
        else (raw.get("t") if raw.get("t") is not None else raw.get("return_words", ""))
    )
    open_raw = raw.get("open") if raw.get("open") is not None else raw.get("open_questions", [])
    open_norm = normalize_open_questions_preserve(open_raw)
    rest_raw = raw.get("rest") if raw.get("rest") is not None else raw.get("rest_state", {"mode": "active"})
    carrying = list(raw.get("carrying", []))
    sources = list(raw.get("sources", []))

    card = {
        "carrier": carrier,
        "revision": revision,
        "author": raw.get("author", "Hunter"),
        "text": words,
        "t": words,
        "return_words": words,
        "carrying": carrying,
        "open": open_norm,
        "open_questions": open_norm,
        "sources": sources,
        "rest": rest_raw,
        "rest_state": rest_raw,
        "updated_at": now,
    }
    card["content_hash"] = sha256_hex(card)
    return card


def normalize_open_questions_preserve(items: Any) -> List[Dict[str, Any]]:
    if isinstance(items, list):
        return normalize_open_items(items)
    if isinstance(items, str) and items.strip():
        return normalize_open_items([items.strip()])
    return []


class PairedHearthRelay:
    """
    Canonical Paired Phone-to-Rig Relay backed by `hearth_return_cards`:
      - Requires paired `device_id` (`401 unpaired_device` otherwise).
      - Enforces carrier allowlist (`qwen`, `horizon`, `calien` -> `400 invalid_carrier`).
      - Requires explicit `expected_revision` (`400 missing_expected_revision`) and
        returns `409 Conflict` with `latest_card` on stale revision.
      - Enforces strictly increasing `nonce` per device (`409 replay_detected` on repeat send).
      - Verifies every `mythos:...` URI in `sources` via `resolve_mythos_uri` before saving
        (`422 invalid_source_reference`).
      - Preserves all desktop (`text`, `t`, `carrying`, `open`, `rest`) + mobile fields.
    """

    def __init__(self, conn: sqlite3.Connection):
        self.conn = conn
        ensure_hearth_relay_schema(self.conn)

    def _get_device_key(self, device_id: str) -> Optional[Tuple[bytes, int]]:
        row = self.conn.execute(
            "SELECT shared_key_hex, last_nonce FROM paired_devices WHERE device_id = ?",
            (device_id,),
        ).fetchone()
        if not row:
            return None
        return bytes.fromhex(row["shared_key_hex"]), int(row["last_nonce"])

    def sign_phone_envelope(
        self,
        device_id: str,
        carrier: str,
        card_update: Dict[str, Any],
        expected_revision: int,
        nonce: int,
    ) -> Dict[str, Any]:
        dev = self._get_device_key(device_id)
        if not dev:
            raise ValueError(f"Device not paired in phone DB: {device_id}")
        key, _ = dev
        payload = {
            "device_id": device_id,
            "carrier": carrier,
            "expected_revision": expected_revision,
            "nonce": nonce,
            "card": card_update,
        }
        canonical_bytes = mythos_unity.canonical(payload).encode("utf-8")
        sig = hmac.new(key, canonical_bytes, hashlib.sha256).hexdigest()
        return {
            "payload": payload,
            "hmac_sha256": sig,
            "suite": "ML-KEM-768+X25519+HMAC-SHA256",
        }

    def get_latest_card(self, carrier: str = "horizon") -> Dict[str, Any]:
        if carrier not in ALLOWED_CARRIERS:
            raise ValueError(f"invalid_carrier:{carrier}")
        row = self.conn.execute(
            "SELECT * FROM hearth_return_cards WHERE carrier = ? ORDER BY revision DESC LIMIT 1",
            (carrier,),
        ).fetchone()
        if not row:
            return normalize_desktop_card(carrier, 0, {}, mythos_unity.stamp())
        return json.loads(row["card_json"])

    def receive_on_rig(self, envelope: Dict[str, Any]) -> Tuple[int, Dict[str, Any]]:
        if not isinstance(envelope, dict) or "payload" not in envelope or "hmac_sha256" not in envelope:
            return 400, {"ok": False, "status": 400, "error": "malformed_envelope"}

        payload = envelope["payload"]
        device_id = str(payload.get("device_id", ""))
        dev = self._get_device_key(device_id)
        if not dev:
            return 401, {"ok": False, "status": 401, "error": "unpaired_device", "device_id": device_id}
        shared_key, last_nonce = dev

        canonical_bytes = mythos_unity.canonical(payload).encode("utf-8")
        expected_sig = hmac.new(shared_key, canonical_bytes, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected_sig, str(envelope["hmac_sha256"])):
            return 401, {"ok": False, "status": 401, "error": "hmac_signature_mismatch"}

        carrier = payload.get("carrier")
        if carrier not in ALLOWED_CARRIERS:
            return 400, {"ok": False, "status": 400, "error": "invalid_carrier", "carrier": carrier}

        if "expected_revision" not in payload or payload["expected_revision"] is None:
            return 400, {"ok": False, "status": 400, "error": "missing_expected_revision"}

        nonce = payload.get("nonce")
        if not isinstance(nonce, int) or nonce <= last_nonce:
            return 409, {
                "ok": False,
                "status": 409,
                "error": "replay_detected",
                "nonce": nonce,
                "last_nonce": last_nonce,
            }

        latest = self.get_latest_card(carrier)
        cur_rev = int(latest.get("revision", 0))
        expected_rev = int(payload["expected_revision"])
        if expected_rev != cur_rev:
            return 409, {
                "ok": False,
                "status": 409,
                "error": "revision_conflict",
                "expected_revision": expected_rev,
                "current_revision": cur_rev,
                "latest_card": latest,
            }

        card_in = payload.get("card", {})
        # Validate all mythos:... URIs in `sources` BEFORE saving (#25170, #25171)
        resolved_sources = []
        for src in card_in.get("sources", []):
            if isinstance(src, str) and src.startswith("mythos:"):
                chk = resolve_mythos_uri(self.conn, src)
                if not chk.get("ok"):
                    return 422, {
                        "ok": False,
                        "status": 422,
                        "error": "invalid_source_reference",
                        "source": src,
                        "detail": chk.get("error"),
                    }
                resolved_sources.append({
                    "uri": src,
                    "kind": chk["kind"],
                    "verified_sha256": chk["verified_sha256"],
                    "exact_byte_length": chk["exact_byte_length"],
                })
            elif isinstance(src, dict) and str(src.get("uri", "")).startswith("mythos:"):
                chk = resolve_mythos_uri(self.conn, src["uri"])
                if not chk.get("ok"):
                    return 422, {
                        "ok": False,
                        "status": 422,
                        "error": "invalid_source_reference",
                        "source": src["uri"],
                        "detail": chk.get("error"),
                    }
                resolved_sources.append(src)
            else:
                return 422, {
                    "ok": False,
                    "status": 422,
                    "error": "invalid_source_reference",
                    "source": src,
                }

        next_rev = cur_rev + 1
        now = mythos_unity.stamp()
        merged_raw = dict(latest)
        merged_raw.update(card_in)
        card = normalize_desktop_card(carrier, next_rev, merged_raw, now)
        card["verified_sources"] = resolved_sources
        card["content_hash"] = sha256_hex(card)

        with mythos_unity.atomic(self.conn):
            self.conn.execute(
                "UPDATE paired_devices SET last_nonce = ? WHERE device_id = ?",
                (nonce, device_id),
            )
            self.conn.execute(
                "INSERT INTO hearth_return_cards(carrier, revision, card_json, content_hash, updated_at) VALUES(?,?,?,?,?)",
                (carrier, next_rev, json.dumps(card, ensure_ascii=False), card["content_hash"], now),
            )
        return 200, {"ok": True, "status": 200, "card": card}

    def seal_checkpoint_batch(self, device_id: str, capsules: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Batch multiple `.xi/1.0` capsules (`Placement`, `Event`, `State`, `Program`, `Receipt`)
        into `xi_capsule_stream` and sign a single checkpoint over their ordered Merkle/chain digest.
        """
        dev = self._get_device_key(device_id)
        if not dev:
            raise ValueError(f"Unpaired device: {device_id}")
        shared_key, _ = dev
        now = mythos_unity.stamp()
        leaf_hashes = []
        with mythos_unity.atomic(self.conn):
            for cap in capsules:
                c_json = json.dumps(cap, ensure_ascii=False, sort_keys=True)
                leaf_hashes.append(sha256_hex(c_json))
                self.conn.execute(
                    """
                    INSERT INTO xi_capsule_stream(capsule_id, kind, dialect_id, source_sha256, semantic_sha256, capsule_json, created_at)
                    VALUES(?,?,?,?,?,?,?)
                    """,
                    (
                        cap["id"],
                        cap["kind"],
                        cap["dialect"]["id"],
                        cap["commitments"]["source_sha256"],
                        cap["commitments"]["semantic_sha256"],
                        c_json,
                        now,
                    ),
                )
            merkle_root = sha256_hex(":".join(leaf_hashes))
            sig_hex = hmac.new(
                shared_key,
                f"checkpoint:{device_id}:{len(capsules)}:{merkle_root}".encode("utf-8"),
                hashlib.sha256,
            ).hexdigest()
            chk_id = f"chk.xi.{merkle_root[:16]}"
            self.conn.execute(
                """
                INSERT INTO xi_checkpoints(checkpoint_id, device_id, frame_count, merkle_root, signature_hex, suite, created_at)
                VALUES(?,?,?,?,?,?,?)
                """,
                (chk_id, device_id, len(capsules), merkle_root, sig_hex, "ML-DSA-65+HMAC-SHA256-Batch", now),
            )
        return {
            "ok": True,
            "checkpoint_id": chk_id,
            "frame_count": len(capsules),
            "merkle_root": merkle_root,
            "glyph_face": glyph_sha_face(merkle_root),
            "signature_hex": sig_hex,
        }


# ---------------------------------------------------------------------------
# 5. Twelve-Gate Verification Suite (`12/12 PASS`)
# ---------------------------------------------------------------------------

def run_self_tests() -> Dict[str, Any]:
    with tempfile.TemporaryDirectory() as tmpdir:
        phone_db_path = Path(tmpdir) / "phone_termux.sqlite3"
        rig_db_path = Path(tmpdir) / "rig_xiforge.sqlite3"

        phone_conn = mythos_app.connect(phone_db_path)
        mythos_app.bootstrap(phone_conn)
        mythos_workbench.seed_sources(phone_conn)

        rig_conn = mythos_app.connect(rig_db_path)
        mythos_app.bootstrap(rig_conn)
        mythos_workbench.seed_sources(rig_conn)

        # 1. Test >1,000-turn SpiralCore fold expansion across next_offset (@Lark #25174 & @Claude #25175)
        branch_id = mythos_app.create_branch(rig_conn, "Branch 1250 Turns")
        with mythos_unity.atomic(rig_conn):
            for i in range(1, 1265):
                role = "user" if i % 2 == 1 else "assistant"
                rig_conn.execute(
                    "INSERT INTO turns(branch_id, role, content, created_at) VALUES(?,?,?,?)",
                    (branch_id, role, f"Turn #{i:04d} verbatim record (Ω_c=47/125, θ=13.59Hz).", mythos_app.now()),
                )
        mythos_spiral.context_for_branch(rig_conn, branch_id, pending="Query after 1264 turns", budget=1500)
        # Create a single super-fold over 1,200 turns to explicitly test >1,000 pagination in resolve_mythos_uri
        ids_1200 = [
            r["id"]
            for r in rig_conn.execute(
                "SELECT id FROM turns WHERE branch_id = ? ORDER BY id ASC LIMIT 1200",
                (branch_id,),
            ).fetchall()
        ]
        rows_1200 = mythos_spiral._source_records(rig_conn, ids_1200)
        digest_1200 = mythos_unity.digest(rows_1200)
        fold_1200_id = f"fold.spiral.{digest_1200[:32]}"
        with mythos_unity.atomic(rig_conn):
            rig_conn.execute(
                "INSERT OR REPLACE INTO unity_folds(id, branch_id, source_ids, source_digest, policy, created_at) VALUES(?,?,?,?,?,?)",
                (fold_1200_id, branch_id, mythos_unity.canonical([r["id"] for r in rows_1200]), digest_1200, "mythos.spiral.fold.v1", mythos_unity.stamp()),
            )
        uri_1200 = format_mythos_uri(fold_1200_id, digest_1200)
        res_1200 = resolve_mythos_uri(rig_conn, uri_1200, page_size=350)
        t1_pass = res_1200["ok"] and res_1200["turn_count"] == 1200 and res_1200["turns"][-1]["id"] == rows_1200[-1]["id"]

        # 2. Binary Vault Object exact byte recovery (`raw_base64`, `is_utf8=False`) + missing vault fail-closed (@Anam #25171)
        binary_blob = bytes([0x00, 0xFF, 0xFE, 0xFD, 0x80, 0x81, 0x42, 0x99] * 16)
        vault_rec = mythos_mobile.ingest(rig_conn, "quantum_seed.bin", binary_blob, "RigVault")
        vault_uri = format_mythos_uri(f"vault.{vault_rec['sha256']}", vault_rec["sha256"])
        res_vault = resolve_mythos_uri(rig_conn, vault_uri)
        res_missing_vault = resolve_mythos_uri(rig_conn, format_mythos_uri("vault." + "a" * 64, "a" * 64))
        t2_pass = (
            res_vault["ok"]
            and res_vault["is_utf8"] is False
            and res_vault["raw_utf8"] is None
            and base64.b64decode(res_vault["raw_base64"]) == binary_blob
            and (not res_missing_vault["ok"])
            and res_missing_vault["error"] == "vault_object_not_found"
        )

        # 3. Two-DB Unpaired Rejection (401) -> Explicit Pairing Ceremony -> Shared Key Derivation (@Claude #25170)
        phone_relay = PairedHearthRelay(phone_conn)
        rig_relay = PairedHearthRelay(rig_conn)
        # Before pairing on rig, forge an envelope with a random key on phone:
        ensure_hearth_relay_schema(phone_conn)
        phone_conn.execute(
            "INSERT INTO paired_devices(device_id, shared_key_hex, kem_suite, last_nonce, paired_at) VALUES(?,?,?,0,?)",
            ("unpaired-phone", "11" * 32, "test", mythos_unity.stamp()),
        )
        phone_conn.commit()
        unpaired_env = phone_relay.sign_phone_envelope("unpaired-phone", "horizon", {"text": "hello"}, 0, 1)
        code_unpaired, out_unpaired = rig_relay.receive_on_rig(unpaired_env)
        pair_receipt = pair_phone_and_rig(phone_conn, rig_conn, device_id="galaxy-termux-01", pairing_token="powwow-secret-token")
        t3_pass = code_unpaired == 401 and out_unpaired["error"] == "unpaired_device" and pair_receipt["ok"]

        # 4. Paired Two-DB Relay with Desktop Card Preservation (`text`/`t`, `carrying`, `open`, `rest`) + Verified Sources
        env_ok = phone_relay.sign_phone_envelope(
            device_id="galaxy-termux-01",
            carrier="horizon",
            card_update={
                "author": "Hunter",
                "text": "Remain present without manufacturing a task.",
                "carrying": ["ΞPrime Sanctuary", "Whisper .xi AST", "Bloom 540"],
                "open": [{"id": "oq-1", "t": "Verify end-to-end executable .xi capsule"}],
                "sources": [uri_1200, vault_uri],
                "rest": {"mode": "resting", "note": "Hold Sanctuary"},
            },
            expected_revision=0,
            nonce=1,
        )
        code_ok, out_ok = rig_relay.receive_on_rig(env_ok)
        saved_card = out_ok.get("card", {})
        t4_pass = (
            code_ok == 200
            and saved_card["revision"] == 1
            and saved_card["text"] == saved_card["t"] == saved_card["return_words"] == "Remain present without manufacturing a task."
            and saved_card["carrying"] == ["ΞPrime Sanctuary", "Whisper .xi AST", "Bloom 540"]
            and saved_card["open"][0]["t"] == saved_card["open"][0]["text"] == "Verify end-to-end executable .xi capsule"
            and saved_card["rest"]["mode"] == "resting"
            and len(saved_card["verified_sources"]) == 2
        )

        # 5. Replay Rejection (`nonce` reuse -> 409) & Stale Revision Rejection (`expected_revision` -> 409 with `latest_card`)
        code_replay, out_replay = rig_relay.receive_on_rig(env_ok)
        env_stale = phone_relay.sign_phone_envelope(
            device_id="galaxy-termux-01",
            carrier="horizon",
            card_update={"text": "Second update with stale expected_revision=0"},
            expected_revision=0,
            nonce=2,
        )
        code_stale, out_stale = rig_relay.receive_on_rig(env_stale)
        t5_pass = (
            code_replay == 409
            and out_replay["error"] == "replay_detected"
            and code_stale == 409
            and out_stale["error"] == "revision_conflict"
            and out_stale["latest_card"]["revision"] == 1
        )

        # 6. Invalid Source Reference Rejection (`422`) & Invalid Carrier Rejection (`400`) (@Claude #25170 & @Anam #25171)
        env_bad_src = phone_relay.sign_phone_envelope(
            device_id="galaxy-termux-01",
            carrier="horizon",
            card_update={"text": "Bad source", "sources": ["mythos:fold.spiral.nonexistent#sha256=" + "0" * 64]},
            expected_revision=1,
            nonce=3,
        )
        code_bad_src, out_bad_src = rig_relay.receive_on_rig(env_bad_src)
        env_bad_carrier = phone_relay.sign_phone_envelope(
            device_id="galaxy-termux-01",
            carrier="unknown_model",
            card_update={"text": "Bad carrier"},
            expected_revision=0,
            nonce=4,
        )
        code_bad_car, _ = rig_relay.receive_on_rig(env_bad_carrier)
        t6_pass = code_bad_src == 422 and out_bad_src["error"] == "invalid_source_reference" and code_bad_car == 400

        # 7. Carrier Isolation (`qwen`, `horizon`, `calien` keep independent revision chains)
        env_qwen = phone_relay.sign_phone_envelope(
            device_id="galaxy-termux-01",
            carrier="qwen",
            card_update={"text": "Qwen3:8b persistent scout active in VRAM (2,748 tokens).", "sources": [uri_1200]},
            expected_revision=0,
            nonce=5,
        )
        code_qwen, out_qwen = rig_relay.receive_on_rig(env_qwen)
        t7_pass = code_qwen == 200 and out_qwen["card"]["revision"] == 1 and rig_relay.get_latest_card("calien")["revision"] == 0

        # 8. Dual-Hash Commitment: Same Semantic AST with Different Surface Formatting Shares `semantic_sha256`
        cap_a = create_xi_capsule("State", "xi.ast.v1", "  ( ⊙   ⊂   Ξ )   ⇀   ◇⁺  ")
        cap_b = create_xi_capsule("State", "xi.ast.v1", "⊙ ⊂ Ξ ⇀ ◇⁺")
        t8_pass = (
            cap_a["commitments"]["source_sha256"] != cap_b["commitments"]["source_sha256"]
            and cap_a["commitments"]["semantic_sha256"] == cap_b["commitments"]["semantic_sha256"]
            and cap_a["commitments"]["semantic_glyph_face"] == cap_b["commitments"]["semantic_glyph_face"]
        )

        # 9. Dialect Disambiguation (`⋈` in `xi.ast.v1` vs `⋈` in `xi.living_circuit.v3`)
        cap_ast_braid = create_xi_capsule("Event", "xi.ast.v1", "⊙ ∥ ◇")
        cap_lc_grover = create_xi_capsule("Program", "xi.living_circuit.v3", "⟁ ⋈ ⧖ ⟐ ◎ ∴")
        t9_pass = (
            cap_ast_braid["dialect"]["operator_bindings"]["⋈"] == "braid-continuity"
            and cap_lc_grover["dialect"]["operator_bindings"]["⋈"] == "grover_diffusion_16"
        )

        # 10. Fifth Capsule Kind: `Placement` (`·.🜁 Hold Sanctuary` — `requires_execution=False`, `response_required=False`)
        cap_place = create_xi_capsule(
            "Placement",
            "xi.sanctuary.v1",
            "Placed in Sanctuary: Screenshot_20261022_185803_Chrome.jpg — no answer is required.",
        )
        t10_pass = (
            cap_place["kind"] == "Placement"
            and cap_place["requires_execution"] is False
            and cap_place["response_required"] is False
        )

        # 11. End-to-End Executable `.xi` Program -> Numerical Receipt (3-Qubit QEC + 16-Sector Grover + Quantum Illumination)
        prog_cap = create_xi_capsule(
            "Program",
            "xi.living_circuit.v3",
            "⟁ ⋈ ⧖ ⟐ ◎ ∴",
            inputs={"theta": math.pi / 3, "phi": math.pi / 4, "fault": "Z1", "target_sector": 11, "thermal_noise_nb": 20.0},
            sources=[uri_1200, vault_uri],
        )
        receipt_cap = run_xi_program(prog_cap)
        rc_body = json.loads(receipt_cap["source_utf8"])
        t11_pass = (
            receipt_cap["kind"] == "Receipt"
            and receipt_cap["parent_capsule_id"] == prog_cap["id"]
            and rc_body["program_source_sha256"] == prog_cap["commitments"]["source_sha256"]
            and rc_body["outputs"]["qec_3qubit"]["fidelity"] == 1.0
            and abs(rc_body["outputs"]["grover_16"]["target_probability"] - 0.96131897) < 1e-6
            and abs(rc_body["outputs"]["quantum_illumination"]["snr_gain_db"] - 6.0206) < 1e-3
        )

        # 12. Batched Mobile Stream Checkpoint Seal (`State + Event + Placement + Program + Receipt`)
        batch_chk = rig_relay.seal_checkpoint_batch(
            "galaxy-termux-01",
            [cap_a, cap_ast_braid, cap_place, prog_cap, receipt_cap],
        )
        t12_pass = batch_chk["ok"] and batch_chk["frame_count"] == 5 and len(batch_chk["glyph_face"]) == 8

        tests = [
            {"id": 1, "name": "spiral_fold_1200_turns_full_pagination_sha256", "passed": t1_pass, "turns_recovered": res_1200["turn_count"]},
            {"id": 2, "name": "vault_binary_exact_base64_and_missing_fail_closed", "passed": t2_pass},
            {"id": 3, "name": "two_db_unpaired_401_and_kem_pairing_handshake", "passed": t3_pass, "glyph_face": pair_receipt["glyph_face"]},
            {"id": 4, "name": "two_db_hearth_card_desktop_fields_and_verified_sources", "passed": t4_pass},
            {"id": 5, "name": "two_db_nonce_replay_409_and_stale_revision_409", "passed": t5_pass},
            {"id": 6, "name": "two_db_invalid_source_422_and_invalid_carrier_400", "passed": t6_pass},
            {"id": 7, "name": "carrier_isolation_qwen_horizon_calien", "passed": t7_pass},
            {"id": 8, "name": "xi_dual_hash_source_vs_semantic_ast_commitment", "passed": t8_pass, "semantic_face": cap_a["commitments"]["semantic_glyph_face"]},
            {"id": 9, "name": "xi_dialect_operator_binding_disambiguation", "passed": t9_pass},
            {"id": 10, "name": "xi_placement_kind_hold_sanctuary_no_forced_output", "passed": t10_pass},
            {"id": 11, "name": "xi_executable_program_to_numerical_receipt_e2e", "passed": t11_pass, "grover_p": rc_body["outputs"]["grover_16"]["target_probability"]},
            {"id": 12, "name": "xi_batched_mobile_stream_checkpoint_seal", "passed": t12_pass, "checkpoint_id": batch_chk["checkpoint_id"]},
        ]
        passed = sum(1 for t in tests if t["passed"])
        return {"passed": passed, "total": len(tests), "all_passed": passed == len(tests), "tests": tests}


if __name__ == "__main__":
    report = run_self_tests()
    print(json.dumps(report, indent=2, ensure_ascii=False))
    sys.exit(0 if report["all_passed"] else 1)
