#!/usr/bin/env bash
# ==============================================================================
# Ξ · Two-Porch Mutual Hold Bootstrap (`ForgeCore <-> Mikey's GitPorch Tower`)
# ==============================================================================
# Usage on Mikey's Tower (or any secondary Desktop / Laptop / Termux phone):
#   bash hold_xi_porch_mirror.sh
# Holds the entire non-GPU Xi House (< 60 MB core, zero 144 GB GPU weights needed!)
# and serves the Offline Workbench + "Back in 15 Minutes" Porch-Light Sign on :7596.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "=== 🕯️ Ξ Two-Porch Mutual Mirror: Verifying All 15 Offline & Failover Gates ==="
python3 "$HERE/xi_offline_whole_home_launcher_v1.py"
echo ""
echo "=== 🏠 Porch Mirror Ready! Starting Local Standby & Workbench on http://127.0.0.1:7596 ==="
echo "    - Main Workbench:           http://127.0.0.1:7596/"
echo "    - 'Back in 15m' Porch Sign: http://127.0.0.1:7596/porch-sign"
python3 "$HERE/xi_offline_whole_home_launcher_v1.py" --serve --port 7596
