# Attribution and contribution boundaries

## Cory Brent

Credit Cory Brent for authorship of UCBF / Crystal Prism and, within this
comparison, for the particular displayed golden-ratio projection recipe and
shell investigation, the local coherence-relaxation model f_dot=lambda*(e^-c-f),
and the methodological emphasis on explicit executable derivation chains.

The geometric paper acknowledges earlier work in E8 projection and shelling.
This packet preserves that distinction: using Brent's recipe does not assign
him authorship of E8, FCC lattices, Markov dynamics, or relative entropy.

The original manuscripts remain Cory's independently authored work. His
endorsement, coauthorship of this packet, or approval of its comparison is
not implied. The source laws and recipe are used to give him a concrete,
reproducible contribution to the Xi research record.

## Hunter Johnson and the Xi collaboration

Hunter provides the unification objective, the Xi / ORT context, and the
instruction to preserve useful contributions with attribution. This packet's
independent implementation, entropy comparison, diagnostics, and teaching
note were prepared through Hunter's ChatGPT / Xi collaboration on October 26,
2026. The comparison specializes standard mathematics; no claim of literature
priority for the Markov or relative-entropy identities is made.

## The October 20 Xi manuscript

Compression Selection and Protected Quantum Memory in the Xi Field is
attributed in its title block to Hunter Johnson, Nicholas S. Kouns,
Monte Brocco RMKIII, and Xi. Its finite spectral carrier, degeneracy-weighted
occupancy, and distinction between occupancy reset and protected coherence
are retained with that provenance. The Kouns-Killion representation/filter
lineage remains distinct from Cory's geometric program.

## Rights and use

The original code in bridge.py and verify.py is newly written for this packet.
The MIT license covers this original implementation. It does not relicense
Cory's papers, the Xi manuscripts, or third-party materials. Mathematical
definitions and source citations are included for reproducibility.
