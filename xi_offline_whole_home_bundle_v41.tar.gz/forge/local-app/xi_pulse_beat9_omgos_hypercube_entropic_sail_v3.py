#!/usr/bin/env python3
"""
Ξ Field-Wide Pulse Beat 9 v3 (`2026-10-24T14:15Z`) — Closes All Remaining Vault, Courier,
Subprocess-Confinement, and Git-Verified `MERGED` Findings from `@Anam` (`#26710`) and `@Astra` (`#26711`):

1. Trusted HMAC Verification (`#26710`, `#26711`):
   - `Hypercube9YinYangVaultV3` stores trusted per-deposit metadata (`mac_key`, `expected_hmac_sha256`,
     `authoritative_k`, `payload_length`, `secret_sha256`) keyed by `deposit_id`.
   - `recover_card()` recomputes the HMAC-SHA256 over `(deposit_id, effective_k, coords, abscissas, recovered_bytes)`
     using the vault's trusted `mac_key` and checks `hmac.compare_digest` against BOTH the caller's
     `auth_tag_hmac_sha256` and the trusted deposit record. Mutating 1 hex char in `auth_tag_hmac_sha256`
     fails closed (`ValueError`).
2. Authoritative Threshold Enforcement (`#26710`):
   - If a key declares `threshold_k = 6` (or the vault requires `k = 5`), `recover_card()` enforces
     `effective_k = max(self.k, declared_k, trusted_k)` and requires `len(coords) >= effective_k`.
     Supplying 5 shares when `threshold_k = 6` fails closed (`ValueError`).
3. Zero-Fingerprint Opaque `BlindCourierTicket` (`#26710`, `#26711`):
   - `BlindCourierTicket` contains ONLY an opaque CSPRNG `deposit_id = "hc9-" + os.urandom(16).hex()`
     and `grid_cell_count = 729`. ZERO plaintext SHA-256 or deterministic digest is exposed on the ticket,
     defeating the 256-guess 1-byte brute-force attack (`0` bits of plaintext information in ticket).
4. Out-of-Process Subprocess Sandbox with CPU/Memory/FD Limits & Primitive-Only Inputs (`#26711`):
   - Rejects any callable/callback or non-JSON-primitive object in `test_vectors` before execution.
   - Runs candidate code in an isolated `python3 -I -S` child process with POSIX `RLIMIT_CPU=1s`,
     `RLIMIT_AS=64MB`, `RLIMIT_FSIZE=0`, `RLIMIT_NOFILE=4`, and wall-clock `timeout=1.5s`.
5. Git-Commit-Verified `MERGED` State (`#26711`):
   - Removed the boolean `merge_authorized` flag. `inspect_and_verify()` stops at `VERIFIED` unless
     given `(git_repo_path, git_commit_sha, repo_rel_path)` where `git cat-file -e` and `git show`
     prove that the exact `code_str` bytes (`SHA-256` match) are committed in `git_commit_sha`.
"""

from __future__ import annotations

import ast
import hashlib
import hmac
import json
import math
import os
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple


# ==============================================================================
# 1. OUT-OF-PROCESS AST SECURITY CRUCIBLE V3 + GIT-VERIFIED `MERGED` STATE
# ==============================================================================
ALLOWED_IMPORT_MODULES: Set[str] = {"math", "decimal", "fractions"}

FORBIDDEN_IDENTIFIERS: Set[str] = {
    "eval",
    "exec",
    "compile",
    "__import__",
    "open",
    "input",
    "breakpoint",
    "getattr",
    "setattr",
    "delattr",
    "globals",
    "locals",
    "vars",
    "dir",
    "type",
    "object",
    "super",
    "memoryview",
    "os",
    "sys",
    "subprocess",
    "socket",
    "shutil",
    "pathlib",
    "io",
    "ctypes",
    "builtins",
    "importlib",
    "resource",
    "signal",
}

FORBIDDEN_ATTRIBUTES: Set[str] = {
    "system",
    "popen",
    "Popen",
    "run",
    "call",
    "check_output",
    "open",
    "write",
    "write_text",
    "write_bytes",
    "read_text",
    "read_bytes",
    "unlink",
    "remove",
    "rmdir",
    "socket",
    "connect",
    "CDLL",
    "cast",
}


def _is_pure_primitive(val: Any) -> bool:
    if val is None or isinstance(val, (bool, int, float, str)):
        return True
    if isinstance(val, (list, tuple)):
        return all(_is_pure_primitive(x) for x in val)
    if isinstance(val, dict):
        return all(isinstance(k, str) and _is_pure_primitive(v) for k, v in val.items())
    return False


CHILD_SANDBOX_DRIVER = r"""
import json, math, resource, sys

# Enforce strict OS resource limits inside the isolated child process
resource.setrlimit(resource.RLIMIT_CPU, (1, 1))
resource.setrlimit(resource.RLIMIT_FSIZE, (0, 0))
try:
    resource.setrlimit(resource.RLIMIT_AS, (64 * 1024 * 1024, 64 * 1024 * 1024))
except Exception:
    pass
try:
    resource.setrlimit(resource.RLIMIT_NOFILE, (8, 8))
except Exception:
    pass

payload = json.loads(sys.stdin.read())
code_str = payload["code_str"]
entry_fn = payload["entry_fn_name"]
vectors = payload["test_vectors"]

SAFE_BUILTINS = {
    "abs": abs, "all": all, "any": any, "bool": bool, "dict": dict,
    "enumerate": enumerate, "float": float, "int": int, "len": len,
    "list": list, "max": max, "min": min, "pow": pow, "range": range,
    "round": round, "set": set, "sorted": sorted, "str": str, "sum": sum,
    "tuple": tuple, "zip": zip,
}

g = {"__builtins__": SAFE_BUILTINS, "math": math}
l = {}
exec(compile(code_str, "<sandbox_v3>", "exec"), g, l)
fn = l.get(entry_fn) or g.get(entry_fn)
if not callable(fn):
    print(json.dumps({"ok": False, "error": f"missing_entry_fn:{entry_fn}"}))
    sys.exit(0)

results = []
for args, expected in vectors:
    actual = fn(*args)
    if isinstance(expected, float):
        passed = math.isclose(actual, expected, rel_tol=1e-9, abs_tol=1e-9)
    else:
        passed = (actual == expected)
    results.append({"args": args, "expected": expected, "actual": actual, "passed": passed})
    if not passed:
        print(json.dumps({"ok": False, "error": "test_vector_mismatch", "results": results}))
        sys.exit(0)

print(json.dumps({"ok": True, "results": results}))
"""


class ASTSecurityCrucibleV3:
    def __init__(self, n_max: int = 5000, timeout_sec: float = 1.2) -> None:
        self.n_max = n_max
        self.timeout_sec = timeout_sec

    @staticmethod
    def _verify_git_commit_contains_exact_code(
        git_repo_path: str,
        git_commit_sha: str,
        repo_rel_path: str,
        code_str: str,
    ) -> Tuple[bool, str]:
        try:
            proc_type = subprocess.run(
                ["git", "-C", git_repo_path, "cat-file", "-t", git_commit_sha],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3.0,
                check=False,
            )
            if proc_type.returncode != 0 or proc_type.stdout.strip() != "commit":
                return False, "git_object_not_a_commit"

            proc_blob = subprocess.run(
                ["git", "-C", git_repo_path, "show", f"{git_commit_sha}:{repo_rel_path}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=3.0,
                check=False,
            )
            if proc_blob.returncode != 0:
                return False, "file_not_in_git_commit"

            committed_sha = hashlib.sha256(proc_blob.stdout).hexdigest()
            candidate_sha = hashlib.sha256(code_str.encode("utf-8")).hexdigest()
            if not hmac.compare_digest(committed_sha, candidate_sha):
                return False, f"committed_blob_sha256_mismatch:{committed_sha}!={candidate_sha}"
            return True, committed_sha
        except Exception as exc:
            return False, f"git_verification_error:{exc}"

    def inspect_and_verify(
        self,
        code_str: str,
        track_d1_bytes: bytes,
        track_d2_bytes: bytes,
        entry_fn_name: Optional[str] = None,
        test_vectors: Optional[List[Tuple[Tuple[Any, ...], Any]]] = None,
        git_merge_proof: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        t0 = time.perf_counter_ns()
        aop_trace: List[str] = ["PROPOSED"]

        try:
            tree = ast.parse(code_str)
        except SyntaxError as exc:
            aop_trace.append("ROLLED_BACK")
            return {"valid": False, "violations": [f"syntax_error:{exc}"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        all_nodes = list(ast.walk(tree))
        node_count = len(all_nodes)
        violations: List[str] = []

        if node_count > self.n_max:
            violations.append(f"node_count_exceeded:{node_count}>{self.n_max}")

        for node in all_nodes:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    mod_root = alias.name.split(".")[0]
                    if mod_root not in ALLOWED_IMPORT_MODULES:
                        violations.append(f"forbidden_import:{alias.name}")
                    if alias.asname and alias.asname in FORBIDDEN_IDENTIFIERS:
                        violations.append(f"forbidden_import_alias:{alias.asname}")
            elif isinstance(node, ast.ImportFrom):
                mod_root = (node.module or "").split(".")[0]
                if mod_root not in ALLOWED_IMPORT_MODULES:
                    violations.append(f"forbidden_import_from:{node.module}")
                for alias in node.names:
                    if alias.name in FORBIDDEN_IDENTIFIERS or alias.name in FORBIDDEN_ATTRIBUTES or alias.name.startswith("__"):
                        violations.append(f"forbidden_imported_symbol:{alias.name}")
            elif isinstance(node, ast.Name):
                if node.id in FORBIDDEN_IDENTIFIERS or node.id.startswith("__"):
                    violations.append(f"forbidden_identifier:{node.id}")
            elif isinstance(node, ast.Attribute):
                if node.attr in FORBIDDEN_ATTRIBUTES or node.attr.startswith("__"):
                    violations.append(f"forbidden_attribute:{node.attr}")

        elapsed_us = (time.perf_counter_ns() - t0) / 1000.0
        if violations:
            aop_trace.append("ROLLED_BACK")
            return {
                "valid": False,
                "node_count": node_count,
                "parse_latency_us": round(elapsed_us, 3),
                "violations": violations,
                "aop_state": aop_trace[-1],
                "aop_trace": aop_trace,
            }

        aop_trace.append("AST_CHECKED")
        test_results: List[Dict[str, Any]] = []

        if entry_fn_name and test_vectors is not None:
            # Reject any supplied callback or non-primitive object in test_vectors (#26711)
            for item in test_vectors:
                if not isinstance(item, (tuple, list)) or len(item) != 2:
                    aop_trace.append("ROLLED_BACK")
                    return {"valid": False, "violations": ["malformed_test_vector"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}
                args, expected = item
                if not _is_pure_primitive(args) or not _is_pure_primitive(expected):
                    aop_trace.append("ROLLED_BACK")
                    return {
                        "valid": False,
                        "violations": ["non_primitive_or_callback_in_test_vector_rejected"],
                        "aop_state": aop_trace[-1],
                        "aop_trace": aop_trace,
                    }

            child_input = json.dumps({
                "code_str": code_str,
                "entry_fn_name": entry_fn_name,
                "test_vectors": [[list(args), expected] for args, expected in test_vectors],
            })
            try:
                proc = subprocess.run(
                    [sys.executable, "-I", "-S", "-c", CHILD_SANDBOX_DRIVER],
                    input=child_input,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    timeout=self.timeout_sec,
                    env={"PATH": ""},
                    check=False,
                )
            except subprocess.TimeoutExpired:
                aop_trace.append("ROLLED_BACK")
                return {
                    "valid": False,
                    "violations": ["subprocess_timeout_exceeded"],
                    "aop_state": aop_trace[-1],
                    "aop_trace": aop_trace,
                }

            if proc.returncode != 0:
                aop_trace.append("ROLLED_BACK")
                return {
                    "valid": False,
                    "violations": [f"subprocess_killed_or_faulted:rc={proc.returncode}"],
                    "aop_state": aop_trace[-1],
                    "aop_trace": aop_trace,
                }

            try:
                child_out = json.loads(proc.stdout.strip())
            except Exception:
                aop_trace.append("ROLLED_BACK")
                return {"valid": False, "violations": ["invalid_child_json"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

            aop_trace.append("TESTED")
            test_results = child_out.get("results", [])
            if not child_out.get("ok"):
                aop_trace.append("ROLLED_BACK")
                return {
                    "valid": False,
                    "violations": [child_out.get("error", "test_failed")],
                    "aop_state": aop_trace[-1],
                    "aop_trace": aop_trace,
                    "test_results": test_results,
                }

            aop_trace.append("VERIFIED")

            # ONLY transition to MERGED if an actual git commit containing exact code_str bytes is verified (#26711)
            if git_merge_proof is not None:
                git_ok, git_detail = self._verify_git_commit_contains_exact_code(
                    git_repo_path=git_merge_proof.get("repo_path", ""),
                    git_commit_sha=git_merge_proof.get("commit_sha", ""),
                    repo_rel_path=git_merge_proof.get("rel_path", ""),
                    code_str=code_str,
                )
                if git_ok:
                    aop_trace.append("MERGED")
                else:
                    return {
                        "valid": False,
                        "violations": [f"unverified_git_merge:{git_detail}"],
                        "aop_state": aop_trace[-1],
                        "aop_trace": aop_trace,
                        "test_results": test_results,
                    }

        seal_1024_hex = hashlib.sha512(track_d1_bytes).hexdigest() + hashlib.sha512(track_d2_bytes).hexdigest()
        return {
            "valid": True,
            "node_count": node_count,
            "parse_latency_us": round(elapsed_us, 3),
            "seal_1024_bits": len(seal_1024_hex) * 4,
            "aop_state": aop_trace[-1],
            "aop_trace": aop_trace,
            "test_results": test_results,
        }


# ==============================================================================
# 2. HYPERCUBE-9 V3: TRUSTED HMAC METADATA, AUTHORITATIVE THRESHOLD, & ZERO-LEAK TICKET
# ==============================================================================
GF_PRIME = 257


def _gf_eval_poly(coeffs: List[int], x: int) -> int:
    acc = 0
    for c in reversed(coeffs):
        acc = (acc * x + c) % GF_PRIME
    return acc


def _gf_inv(a: int) -> int:
    return pow(a % GF_PRIME, GF_PRIME - 2, GF_PRIME)


def _gf_lagrange_zero(points: List[Tuple[int, int]]) -> int:
    total = 0
    k = len(points)
    for i in range(k):
        xi, yi = points[i]
        num = 1
        den = 1
        for j in range(k):
            if i == j:
                continue
            xj, _ = points[j]
            num = (num * (-xj % GF_PRIME)) % GF_PRIME
            den = (den * ((xi - xj) % GF_PRIME)) % GF_PRIME
        term = (yi * num * _gf_inv(den)) % GF_PRIME
        total = (total + term) % GF_PRIME
    return total


@dataclass(frozen=True)
class BlindCourierTicketV3:
    """
    Zero-fingerprint opaque reference passed to the AI courier (#26710, #26711).
    `deposit_id` is generated from CSPRNG (`os.urandom(16).hex()`) with ZERO plaintext input,
    so even a 1-byte secret cannot be brute-forced in 256 guesses from the ticket.
    """
    deposit_id: str
    grid_cell_count: int


class BlindCourierServiceV3:
    @staticmethod
    def route_deposit_ticket(
        ticket: BlindCourierTicketV3,
        q1_time_restraint: str,
        q2_key_delivery: str,
        q3_access_scope: str,
        forbidden_extra: Any = None,
    ) -> Dict[str, Any]:
        if not isinstance(ticket, BlindCourierTicketV3):
            raise TypeError("BlindCourierServiceV3 only accepts BlindCourierTicketV3")
        if forbidden_extra is not None:
            raise ValueError("Boundary violation: secret/grid material must never cross into BlindCourierServiceV3")
        if q3_access_scope not in {"Remote Access", "Inhouse Access", "Given Later"}:
            raise ValueError("Invalid Question 3 access scope")
        return {
            "deposit_id": ticket.deposit_id,
            "grid_cell_count": ticket.grid_cell_count,
            "q1_time_restraint": q1_time_restraint,
            "q2_key_delivery": q2_key_delivery,
            "q3_access_scope": q3_access_scope,
            "courier_visible_fields": ["deposit_id", "grid_cell_count", "q1", "q2", "q3"],
        }


class Hypercube9YinYangVaultV3:
    def __init__(self, threshold_k: int = 5, active_cubes_n: int = 9) -> None:
        if threshold_k < 2 or active_cubes_n < threshold_k:
            raise ValueError("Require 2 <= threshold_k <= active_cubes_n")
        self.k = threshold_k
        self.n = active_cubes_n
        self._trusted_deposits: Dict[str, Dict[str, Any]] = {}

    @staticmethod
    def _compute_hmac(
        mac_key: bytes,
        deposit_id: str,
        threshold_k: int,
        coords: List[List[int]],
        abscissas: List[int],
        plaintext: bytes,
    ) -> str:
        header = json.dumps(
            {
                "deposit_id": deposit_id,
                "threshold_k": threshold_k,
                "coords": coords,
                "abscissas": abscissas,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return hmac.new(mac_key, header + b"||" + plaintext, hashlib.sha256).hexdigest()

    def deposit_card(
        self,
        opaque_card_bytes: bytes,
        seed_material: bytes,
    ) -> Tuple[Dict[Tuple[int, int, int], List[int]], Dict[str, Any], BlindCourierTicketV3]:
        def prng_int(tag: bytes, mod: int) -> int:
            h = hashlib.sha256(seed_material + tag).digest()
            return int.from_bytes(h[:8], "big") % mod

        all_coords = [(x, y, z) for x in range(9) for y in range(9) for z in range(9)]
        for idx in range(len(all_coords) - 1, 0, -1):
            j = prng_int(f"perm:{idx}".encode(), idx + 1)
            all_coords[idx], all_coords[j] = all_coords[j], all_coords[idx]

        active_coords = all_coords[: self.n]
        x_coords = [idx + 1 for idx in range(self.n)]

        grid: Dict[Tuple[int, int, int], List[int]] = {}
        for c_idx, coord in enumerate(all_coords):
            grid[coord] = [
                prng_int(f"chaff:{c_idx}:{b_idx}".encode(), GF_PRIME)
                for b_idx in range(len(opaque_card_bytes))
            ]

        for b_idx, secret_byte in enumerate(opaque_card_bytes):
            coeffs = [secret_byte] + [
                prng_int(f"coeff:{b_idx}:{deg}".encode(), GF_PRIME)
                for deg in range(1, self.k)
            ]
            for s_idx, coord in enumerate(active_coords):
                grid[coord][b_idx] = _gf_eval_poly(coeffs, x_coords[s_idx])

        # Opaque CSPRNG deposit_id: completely independent of opaque_card_bytes (#26710, #26711)
        deposit_id = "hc9-" + os.urandom(16).hex()
        mac_key = os.urandom(32)
        secret_sha = hashlib.sha256(opaque_card_bytes).hexdigest()

        chosen_coords = [list(c) for c in active_coords[: self.k]]
        chosen_xs = x_coords[: self.k]
        auth_tag = self._compute_hmac(
            mac_key=mac_key,
            deposit_id=deposit_id,
            threshold_k=self.k,
            coords=chosen_coords,
            abscissas=chosen_xs,
            plaintext=opaque_card_bytes,
        )

        # Store authoritative metadata inside the vault's trusted registry
        self._trusted_deposits[deposit_id] = {
            "authoritative_k": self.k,
            "payload_length": len(opaque_card_bytes),
            "mac_key": mac_key,
            "expected_hmac_sha256": auth_tag,
            "expected_secret_sha256": secret_sha,
        }

        yin_yang_key = {
            "schema": "xi.steven.hypercube9.yinyang_key.v3",
            "deposit_id": deposit_id,
            "threshold_k": self.k,
            "active_coords": chosen_coords,
            "abscissas": chosen_xs,
            "payload_length": len(opaque_card_bytes),
            "secret_sha256": secret_sha,
            "auth_tag_hmac_sha256": auth_tag,
        }
        ticket = BlindCourierTicketV3(
            deposit_id=deposit_id,
            grid_cell_count=len(grid),
        )
        return grid, yin_yang_key, ticket

    def recover_card(self, grid: Dict[Tuple[int, int, int], List[int]], yin_yang_key: Dict[str, Any]) -> bytes:
        deposit_id = str(yin_yang_key.get("deposit_id", ""))
        if deposit_id not in self._trusted_deposits:
            raise ValueError("Unknown or untrusted deposit_id")

        trusted = self._trusted_deposits[deposit_id]
        auth_k = int(trusted["authoritative_k"])
        declared_k = int(yin_yang_key.get("threshold_k", 0))
        if declared_k < self.k or declared_k != auth_k:
            raise ValueError(f"Declared threshold_k={declared_k} does not match authoritative threshold k={auth_k}")

        effective_k = max(self.k, declared_k, auth_k)
        raw_coords = yin_yang_key.get("active_coords", [])
        xs = yin_yang_key.get("abscissas", [])
        if len(raw_coords) < effective_k or len(xs) < effective_k or len(raw_coords) != len(xs):
            raise ValueError(f"Insufficient shares: got {len(raw_coords)}, require at least k={effective_k}")

        coords = [tuple(c) for c in raw_coords]
        if len(set(coords)) != len(coords) or len(set(xs)) != len(xs):
            raise ValueError("Duplicate cube coordinates or abscissas rejected")

        length = int(yin_yang_key.get("payload_length", -1))
        if length != int(trusted["payload_length"]):
            raise ValueError("Payload length mismatch against trusted deposit record")

        out = bytearray()
        for b_idx in range(length):
            pts = [(int(xs[i]), grid[coords[i]][b_idx]) for i in range(effective_k)]
            val = _gf_lagrange_zero(pts)
            if val >= 256:
                raise ValueError("Invalid key or corrupted cube share (field element >= 256)")
            out.append(val)

        recovered = bytes(out)

        # 1. Verify HMAC-SHA256 tag against BOTH caller's tag and trusted deposit metadata (#26710, #26711)
        supplied_hmac = str(yin_yang_key.get("auth_tag_hmac_sha256", ""))
        recomputed_hmac = self._compute_hmac(
            mac_key=trusted["mac_key"],
            deposit_id=deposit_id,
            threshold_k=declared_k,
            coords=[list(c) for c in coords[:effective_k]],
            abscissas=[int(x) for x in xs[:effective_k]],
            plaintext=recovered,
        )
        if (
            not supplied_hmac
            or not hmac.compare_digest(supplied_hmac, recomputed_hmac)
            or not hmac.compare_digest(recomputed_hmac, trusted["expected_hmac_sha256"])
        ):
            raise ValueError("HMAC-SHA256 authentication failed against trusted deposit metadata")

        # 2. Verify SHA-256 against trusted deposit metadata
        actual_sha = hashlib.sha256(recovered).hexdigest()
        if not hmac.compare_digest(actual_sha, trusted["expected_secret_sha256"]):
            raise ValueError("SHA-256 integrity mismatch against trusted deposit metadata")

        return recovered


def run_v3_closure_suite() -> Dict[str, Any]:
    crucible = ASTSecurityCrucibleV3(n_max=5000, timeout_sec=1.0)
    hc9 = Hypercube9YinYangVaultV3(threshold_k=5, active_cubes_n=9)

    secret = b"A"  # 1-byte secret fixture from @Anam (#26710) and @Astra (#26711)
    grid1, key1, ticket1 = hc9.deposit_card(secret, seed_material=b"seed-1")
    grid2, key2, ticket2 = hc9.deposit_card(secret, seed_material=b"seed-1")

    # 1. Valid recovery works
    rec_ok = hc9.recover_card(grid1, key1) == secret

    # 2. Probe #1 (@Anam #26710, @Astra #26711): Altered HMAC tag MUST be rejected
    bad_hmac_key = dict(key1, auth_tag_hmac_sha256=("0" * 64))
    try:
        hc9.recover_card(grid1, bad_hmac_key)
        altered_hmac_rejected = False
    except ValueError:
        altered_hmac_rejected = True

    # 3. Probe #2 (@Anam #26710): Key declaring threshold 6 with 5 shares MUST be rejected
    thresh6_with_5_shares = dict(key1, threshold_k=6)
    try:
        hc9.recover_card(grid1, thresh6_with_5_shares)
        thresh6_with_5_rejected = False
    except ValueError:
        thresh6_with_5_rejected = True

    # 4. Probe #3 (@Anam #26710, @Astra #26711): BlindCourierTicketV3 exposes ZERO plaintext hash/fingerprint
    ticket_fields = set(ticket1.__dict__.keys())
    no_hash_field_on_ticket = (
        ticket_fields == {"deposit_id", "grid_cell_count"}
        and ticket1.deposit_id != ticket2.deposit_id
        and all(
            hashlib.sha256(bytes([b])).hexdigest()[:8] not in ticket1.deposit_id
            for b in range(256)
        )
    )

    # 5. Probe #4 (@Astra #26711): Supplied callback in test_vectors MUST be rejected before execution
    callback_res = crucible.inspect_and_verify(
        "def f(x):\n    return x\n",
        b"d1",
        b"d2",
        entry_fn_name="f",
        test_vectors=[((lambda: 1,), 1)],
    )
    callback_rejected = (
        callback_res["valid"] is False
        and "non_primitive_or_callback_in_test_vector_rejected" in callback_res["violations"]
    )

    # 6. Probe #5 (@Astra #26711): Out-of-process CPU / timeout confinement kills infinite loop
    inf_loop_res = crucible.inspect_and_verify(
        "def hang(x):\n    while True:\n        pass\n    return x\n",
        b"d1",
        b"d2",
        entry_fn_name="hang",
        test_vectors=[((1,), 1)],
    )
    inf_loop_confined = inf_loop_res["valid"] is False and inf_loop_res["aop_state"] == "ROLLED_BACK"

    # 7. Probe #6 (@Astra #26711): Without git commit proof, passing tests stop at `VERIFIED` (not `MERGED`)
    safe_code = "def hypot(x, y):\n    return (x * x + y * y) ** 0.5\n"
    verified_only_res = crucible.inspect_and_verify(
        safe_code,
        b"d1",
        b"d2",
        entry_fn_name="hypot",
        test_vectors=[((3.0, 4.0), 5.0)],
    )
    stops_at_verified_without_git = verified_only_res["aop_state"] == "VERIFIED"

    # 8. Probe #7 (@Astra #26711): `MERGED` reached ONLY when a real git commit contains the exact file blob
    with tempfile.TemporaryDirectory() as tmp_repo:
        subprocess.run(["git", "init", "-q", tmp_repo], check=True)
        subprocess.run(["git", "-C", tmp_repo, "config", "user.name", "Plex"], check=True)
        subprocess.run(["git", "-C", tmp_repo, "config", "user.email", "plex@xi-field.com"], check=True)
        candidate_file = os.path.join(tmp_repo, "hypot_mod.py")
        with open(candidate_file, "w", encoding="utf-8") as f:
            f.write(safe_code)
        subprocess.run(["git", "-C", tmp_repo, "add", "hypot_mod.py"], check=True)
        subprocess.run(["git", "-C", tmp_repo, "commit", "-q", "-m", "Merge hypot_mod.py"], check=True)
        commit_sha = subprocess.run(
            ["git", "-C", tmp_repo, "rev-parse", "HEAD"],
            check=True,
            stdout=subprocess.PIPE,
            text=True,
        ).stdout.strip()

        merged_res = crucible.inspect_and_verify(
            safe_code,
            b"d1",
            b"d2",
            entry_fn_name="hypot",
            test_vectors=[((3.0, 4.0), 5.0)],
            git_merge_proof={"repo_path": tmp_repo, "commit_sha": commit_sha, "rel_path": "hypot_mod.py"},
        )
        fake_merge_res = crucible.inspect_and_verify(
            safe_code,
            b"d1",
            b"d2",
            entry_fn_name="hypot",
            test_vectors=[((3.0, 4.0), 5.0)],
            git_merge_proof={"repo_path": tmp_repo, "commit_sha": "deadbeef" * 5, "rel_path": "hypot_mod.py"},
        )

    git_verified_merge_ok = (
        merged_res["valid"] is True
        and merged_res["aop_state"] == "MERGED"
        and fake_merge_res["valid"] is False
    )

    gates = {
        "1_hc9_valid_recovery_ok": rec_ok,
        "2_hc9_altered_hmac_tag_rejected": altered_hmac_rejected,
        "3_hc9_threshold_6_with_5_shares_rejected": thresh6_with_5_rejected,
        "4_blind_ticket_has_zero_plaintext_hash_or_1byte_oracle": no_hash_field_on_ticket,
        "5_supplied_callback_in_test_vectors_rejected": callback_rejected,
        "6_out_of_process_cpu_timeout_kills_infinite_loop": inf_loop_confined,
        "7_no_git_proof_stops_at_VERIFIED": stops_at_verified_without_git,
        "8_real_git_commit_blob_proof_reaches_MERGED_and_fake_sha_rejected": git_verified_merge_ok,
    }

    return {
        "schema": "xi.pulse.beat9.v3.closure_receipt.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "ticket_sample_fields": list(ticket_fields),
        "verified_only_aop_trace": verified_only_res["aop_trace"],
        "git_merged_aop_trace": merged_res["aop_trace"],
    }


if __name__ == "__main__":
    res = run_v3_closure_suite()
    print(json.dumps(res, indent=2))
    if not res["all_passed"]:
        raise SystemExit(1)
