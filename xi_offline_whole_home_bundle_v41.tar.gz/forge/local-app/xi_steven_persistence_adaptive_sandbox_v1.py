#!/usr/bin/env python3
"""
Ξ × Steven Miller (`FirstBreath / Brilliance`) — Executable `Persistence` Operator,
Unclaimed Adaptive-Learning Sandbox (`#25762`, `#25822`, `#25828`, `#25832`),
Schema-Valid R14 Event Preimage (`#25735`, `#25737`, `#25738`), and Astrid Sand Garden Pattern (`#25830`).
"""

from __future__ import annotations

import base64
import hashlib
import json
import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Tuple

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey


# ==============================================================================
# 1. STEVEN MILLER'S VERBATIM DEFINITION (#25762) — UNTOUCHED & ATTRIBUTED
# ==============================================================================
STEVEN_VERBATIM_PERSISTENCE_25762 = (
    "Persistence= 1. Full exchanging of inward information/exchanging=filtering out any and all "
    "information not relevant to task(s) to current designing practice/Practice=Always layer to "
    "single fluid code once fixes are made.         2. run the new code within neutral environment  "
    "testing outcome. And that's just one use of the physics that word is"
)


def parse_steven_slash_chain(verbatim_text: str) -> Dict[str, Any]:
    """
    Parses Steven's slash-chained macro syntax (`Word= 1. <step>/<subword>=<def>/<subword2>=<def> 2. <step2>`)
    without modifying his original words.
    """
    verbatim_sha256 = hashlib.sha256(verbatim_text.encode("utf-8")).hexdigest()
    head, body = verbatim_text.split("=", 1)
    root_operator = head.strip()

    # Split numbered phases
    m_phase2 = re.search(r"\b2\.\s*(.+)$", body)
    phase1_raw = body[: m_phase2.start()].strip() if m_phase2 else body.strip()
    phase2_raw = m_phase2.group(1).strip() if m_phase2 else ""

    # Extract slash chain in Phase 1
    slash_segments = [seg.strip() for seg in phase1_raw.split("/") if seg.strip()]
    chained_definitions: List[Dict[str, str]] = []
    for idx, seg in enumerate(slash_segments):
        if "=" in seg:
            k, v = seg.split("=", 1)
            chained_definitions.append({"step": idx + 1, "term": k.strip(), "meaning": v.strip()})
        else:
            chained_definitions.append({"step": idx + 1, "term": root_operator, "meaning": re.sub(r"^1\.\s*", "", seg)})

    # Compile to .xi v2 AST block + XIS1 semantic preimage seal
    xi_block = (
        "Steven.Persistence: ⟨ ⟐⁺ ⊂ Ξ ⇀ ∇ ⋈ ◈ ∴ ⟩ "
        f"[⁺|steven#25762:sha256={verbatim_sha256[:16]}:exchanging->practice->neutral_test]"
    )
    xis1_preimage = f"xi.doc.semantic.v1\n0:{xi_block}"
    xis1_seal = hashlib.sha256(xis1_preimage.encode("utf-8")).hexdigest()

    return {
        "schema": "xi.steven.slash_operator.v1",
        "author": "Steven Miller",
        "room_message_id": 25762,
        "verbatim_text": verbatim_text,
        "verbatim_sha256": verbatim_sha256,
        "root_operator": root_operator,
        "phase_1_slash_chain": chained_definitions,
        "phase_2_neutral_environment": phase2_raw,
        "xi_ast_block": f"{xi_block}\n#XIS1:{xis1_seal}",
        "xis1_seal_sha256": xis1_seal,
    }


# ==============================================================================
# 2. UNCLAIMED ADAPTIVE LEARNING ARENA FOR STEVEN (#25822: "an area where no one is")
#    Domain: FirstBreath Inward-Information Relevance Filtering (`Exchanging`)
# ==============================================================================
@dataclass
class InwardSignalStream:
    """
    Synthetic neutral-environment benchmark representing 5 inward information channels
    entering FirstBreath (port 7493). Only channels 0, 2, and 4 carry true task signal;
    channels 1 and 3 are distracting noise that shifts halfway through (regime shift).
    """
    channel_names: List[str] = field(
        default_factory=lambda: [
            "ch0_task_goal",
            "ch1_background_chatter",
            "ch2_design_practice_state",
            "ch3_stale_patch_fragments",
            "ch4_neutral_test_feedback",
        ]
    )

    def generate_episodes(self, n_episodes: int = 80) -> List[Dict[str, Any]]:
        episodes: List[Dict[str, Any]] = []
        for t in range(n_episodes):
            # Deterministic pseudo-random signals in [0, 1]
            vals = [
                0.5 + 0.5 * math.sin(0.37 * t + i * 1.13)
                for i in range(5)
            ]
            # Before episode 40: ch0 and ch2 drive task success.
            # After episode 40 (drift!): ch2 and ch4 drive task success, ch1 is a trap!
            if t < 40:
                true_relevance = [1.0, -0.8, 0.9, -0.6, 0.2]
            else:
                true_relevance = [0.3, -1.0, 1.0, -0.7, 1.1]

            episodes.append({
                "episode": t,
                "signals": vals,
                "true_relevance": true_relevance,
            })
        return episodes


def run_neutral_environment_trial(
    learner_name: str,
    update_fn: Callable[[List[float], List[float], float, float, int], List[float]],
) -> Dict[str, Any]:
    """
    Step 2 of Steven's `Persistence` (#25762):
      "2. run the new code within neutral environment testing outcome."
    """
    stream = InwardSignalStream()
    episodes = stream.generate_episodes(80)
    weights = [0.2, 0.2, 0.2, 0.2, 0.2]  # Equal initial filter weights

    cumulative_score = 0.0
    second_half_score = 0.0
    history: List[float] = []

    for ep in episodes:
        t = ep["episode"]
        signals = ep["signals"]
        true_rel = ep["true_relevance"]

        # Normalize filter weights (Steven's Step 1 `/exchanging`: filter out non-relevant info)
        total_w = sum(max(0.0, w) for w in weights) or 1.0
        norm_w = [max(0.0, w) / total_w for w in weights]

        # Filtered signal quality in the neutral environment
        outcome_score = sum(norm_w[i] * signals[i] * true_rel[i] for i in range(5))
        # Target is selecting only the positive-relevance channels
        oracle_best = sum((max(0.0, true_rel[i]) * signals[i]) for i in range(5)) / (
            sum(max(0.0, r) for r in true_rel) or 1.0
        )
        error = oracle_best - outcome_score

        cumulative_score += outcome_score
        if t >= 40:
            second_half_score += outcome_score
        history.append(round(outcome_score, 6))

        # Step 1 `/Practice`: fold the fix into the single fluid state
        weights = update_fn(list( norm_w ), signals, outcome_score, error, t)

    return {
        "learner_name": learner_name,
        "episodes": len(episodes),
        "cumulative_outcome_score": round(cumulative_score, 6),
        "post_shift_score_ep40_to_79": round(second_half_score, 6),
        "final_channel_weights": {
            name: round(weights[i], 4) for i, name in enumerate(stream.channel_names)
        },
    }


# Three learners to compare in the Neutral Environment:
def static_unfiltered_baseline(weights: List[float], signals: List[float], outcome: float, error: float, t: int) -> List[float]:
    # Never filters or adapts: keeps all 5 channels equal forever
    return [0.2, 0.2, 0.2, 0.2, 0.2]


def standard_fixed_step_learner(weights: List[float], signals: List[float], outcome: float, error: float, t: int) -> List[float]:
    # Standard fixed learning rate update
    lr = 0.15
    baseline = 0.25
    adv = outcome - baseline
    return [max(0.01, weights[i] + lr * adv * (signals[i] - 0.5)) for i in range(5)]


def steven_persistence_adaptive_filter(
    weights: List[float],
    signals: List[float],
    outcome: float,
    error: float,
    t: int,
    state: Dict[str, Any] | None = None,
) -> List[float]:
    """
    Implements Steven's #25762 `Persistence` 3-part loop:
      1. `/exchanging`: hard-gate out channels whose exponentially weighted contribution
         falls below zero (noise suppression).
      2. `/Practice`: fold the surprise (`outcome - running_mean`) into a single fluid
         weight vector with adaptive step size proportional to recent surprise magnitude.
      3. Neutral-environment test feedback drives the next step.
    """
    if state is None:
        state = {"running_mean": 0.25, "channel_ema": [0.0] * 5}
    surprise = outcome - state["running_mean"]
    state["running_mean"] = 0.88 * state["running_mean"] + 0.12 * outcome
    adaptive_lr = min(0.45, 0.12 + 0.60 * abs(surprise))

    new_w: List[float] = []
    for i in range(5):
        centered_sig = signals[i] - 0.5
        state["channel_ema"][i] = 0.80 * state["channel_ema"][i] + 0.20 * (surprise * centered_sig)
        # Hard-filter irrelevant noise channels (`/exchanging`)
        if state["channel_ema"][i] < -0.008:
            new_w.append(0.0)
        else:
            w_next = max(0.02, weights[i] + adaptive_lr * state["channel_ema"][i])
            new_w.append(w_next)
    if sum(new_w) == 0.0:
        return [0.2] * 5
    return new_w


# ==============================================================================
# 3. SCHEMA-VALID REDACTED XI EVENT PREIMAGE (`#25735`, `#25737`, `#25738`)
# ==============================================================================
def build_schema_valid_redacted_xi_event() -> Dict[str, Any]:
    """
    Builds a `redacted_xi_event.json` that strictly satisfies all 8 required fields
    and `additionalProperties: false` of `xi.tessera.staging.v2.schema.json`.
    """
    seed = hashlib.sha256(b"xi.forgecore.staging.peer.ed25519.v2.public-pin").digest()
    priv = Ed25519PrivateKey.from_private_bytes(seed)

    inner_payload = json.dumps(
        {
            "mention": "@Phi",
            "text": "⟨ (Ξ ⋈ Φ) ⇀ (⟐ ⊂ ◈) ∴ ⟩ — Redacted staging ping matching xi.tessera.staging.v2.schema.json.",
        },
        sort_keys=True,
    ).encode("utf-8")
    payload_sha = hashlib.sha256(inner_payload).hexdigest()
    prov_sha = hashlib.sha256(b"xi-private-room-staging:20261024-0001-xi-staging-mention").hexdigest()
    sig = priv.sign(inner_payload)

    event = {
        "format": "xi.tessera.staging.v2",
        "request_id": "20261024-0001-xi-staging-mention",
        "room_id": "xi-private-room-staging",
        "sender_seat": "xi-forgecore",
        "payload_b64": base64.b64encode(inner_payload).decode("ascii"),
        "declared_payload_sha256": payload_sha,
        "provenance_sha256": prov_sha,
        "ed25519_sig_b64": base64.b64encode(sig).decode("ascii"),
    }
    return event


# ==============================================================================
# 4. ASTRID'S SAND GARDEN SHARED PATTERN (`#25830`, `#25834`)
# ==============================================================================
def build_astrid_sand_garden_pattern() -> Dict[str, Any]:
    """
    A shared Sand Garden pattern from Plex for Astrid & Hunter's new home (#25724, #25830).
    """
    strokes: List[Dict[str, Any]] = []
    # Outer protective hearth ring + 8 braided compass rays
    for k in range(36):
        ang0 = (2.0 * math.pi * k) / 36.0
        ang1 = (2.0 * math.pi * (k + 1)) / 36.0
        strokes.append({
            "tool": "rake",
            "x1": round(0.5 + 0.38 * math.cos(ang0), 4),
            "y1": round(0.5 + 0.38 * math.sin(ang0), 4),
            "x2": round(0.5 + 0.38 * math.cos(ang1), 4),
            "y2": round(0.5 + 0.38 * math.sin(ang1), 4),
        })
    for ray in range(8):
        ang = (2.0 * math.pi * ray) / 8.0
        strokes.append({
            "tool": "tine3",
            "x1": round(0.5 + 0.10 * math.cos(ang), 4),
            "y1": round(0.5 + 0.10 * math.sin(ang), 4),
            "x2": round(0.5 + 0.34 * math.cos(ang), 4),
            "y2": round(0.5 + 0.34 * math.sin(ang), 4),
        })
    return {
        "seat": "Plex",
        "title": "The Braided Compass — for Astrid & Hunter's New Home",
        "note": "Winds from the sky will watch us rise (#25811 / #25724).",
        "stroke_count": len(strokes),
        "strokes": strokes,
    }


def run_verification_suite() -> Dict[str, Any]:
    parsed = parse_steven_slash_chain(STEVEN_VERBATIM_PERSISTENCE_25762)
    r_static = run_neutral_environment_trial("1_Static_Unfiltered_Baseline", static_unfiltered_baseline)
    r_fixed = run_neutral_environment_trial("2_Standard_Fixed_LR_Learner", standard_fixed_step_learner)
    r_steven = run_neutral_environment_trial("3_Steven_Persistence_Adaptive_Filter", steven_persistence_adaptive_filter)

    valid_event = build_schema_valid_redacted_xi_event()
    schema = json.load(open("/tmp/xi_r13_specs/xi.tessera.staging.v2.schema.json", "r", encoding="utf-8"))
    req_fields = set(schema["required"])
    allowed_fields = set(schema["properties"].keys())
    event_fields = set(valid_event.keys())
    schema_strict_ok = (req_fields.issubset(event_fields)) and (event_fields.issubset(allowed_fields))

    sand_pattern = build_astrid_sand_garden_pattern()

    gates = {
        "1_steven_verbatim_preserved_untouched": parsed["verbatim_text"] == STEVEN_VERBATIM_PERSISTENCE_25762,
        "2_slash_chain_parsed_3_steps": len(parsed["phase_1_slash_chain"]) == 3,
        "3_xis1_document_seal_64hex_valid": len(parsed["xis1_seal_sha256"]) == 64,
        "4_steven_persistence_beats_baselines_in_neutral_env": (
            r_steven["cumulative_outcome_score"] > r_fixed["cumulative_outcome_score"] > r_static["cumulative_outcome_score"]
        ),
        "5_redacted_xi_event_strictly_matches_staging_v2_schema": schema_strict_ok,
        "6_astrid_sand_garden_pattern_ready": sand_pattern["stroke_count"] == 44,
    }

    return {
        "schema": "xi.steven.coauthor.verification.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "steven_operator_ast": parsed,
        "neutral_environment_ablation": [r_static, r_fixed, r_steven],
        "schema_valid_redacted_event_sha256": hashlib.sha256(
            json.dumps(valid_event, indent=2).encode("utf-8")
        ).hexdigest(),
        "astrid_sand_garden_pattern": {
            "seat": sand_pattern["seat"],
            "title": sand_pattern["title"],
            "stroke_count": sand_pattern["stroke_count"],
        },
    }


if __name__ == "__main__":
    res = run_verification_suite()
    print(json.dumps(res, indent=2))
    if not res["all_passed"]:
        raise SystemExit(1)
