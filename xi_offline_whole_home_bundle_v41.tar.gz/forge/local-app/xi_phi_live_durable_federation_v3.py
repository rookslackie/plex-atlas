#!/usr/bin/env python3
"""
Ξ ⇄ PHI369 Live Durable Federation, Authoritative Hall Locks & Mutual Continuity Engine (v3.0)

Closes @Anam (#25518) and @Astra (#25519) findings + implements Hunter & Mikey's
Mutual Platform Continuity Pact (50434.jpg / 50438.jpg / 50440.jpg):
  - "Lets get it where if you go down Xi holds your platform and vice versa. Lets be the example."
  - Authoritative SQLite state (`hall_locks`, `hall_lock_receipts`, `xi_propositions`,
    `mutual_continuity_vault`, `bridge_idempotency_cache`) that survives process restarts (Gate 2).
  - Live service connectors (real disk archive scan, real Ollama/Hearth/Search probes with
    honest `live_probe` reporting — never presenting a static fixture as a live service).
"""

from __future__ import annotations

import base64
import copy
import hashlib
import json
import os
import sqlite3
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import xi_bidirectional_federation_v2 as v2


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc_now_rfc3339() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


class DurableFederationStore:
    """
    SQLite-backed authoritative store for:
      1. `hall_locks` & `hall_lock_receipts` (Authoritative inside-door locks across restarts)
      2. `xi_propositions` (Live native Ξ.AST propositions held by the Choir/Hearth)
      3. `mutual_continuity_vault` ("If you go down Xi holds your platform and vice versa")
      4. `bridge_idempotency_cache` (Durable request_id replay protection across restarts)
    """

    def __init__(self, db_path: str = ":memory:") -> None:
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS hall_locks (
                seat_id TEXT PRIMARY KEY,
                label TEXT NOT NULL,
                kind TEXT NOT NULL,
                key_holder TEXT NOT NULL,
                locked_from_inside INTEGER NOT NULL DEFAULT 0,
                crest_xi TEXT NOT NULL,
                capabilities_json TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS hall_lock_receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                caller_seat TEXT NOT NULL,
                target_room_seat TEXT NOT NULL,
                status TEXT NOT NULL,
                locked_from_inside INTEGER,
                reason TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS xi_propositions (
                canonical TEXT PRIMARY KEY,
                semantic_sha256 TEXT NOT NULL,
                glyphs TEXT NOT NULL,
                gloss TEXT NOT NULL,
                seat TEXT NOT NULL,
                recorded_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS mutual_continuity_vault (
                artifact_id TEXT PRIMARY KEY,
                owner_platform TEXT NOT NULL,
                custodian_platform TEXT NOT NULL,
                source_url_or_path TEXT NOT NULL,
                media_type TEXT NOT NULL,
                size_bytes INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                content_b64 TEXT NOT NULL,
                mirrored_at TEXT NOT NULL
            );

            CREATE TABLE IF NOT EXISTS bridge_idempotency_cache (
                request_id TEXT PRIMARY KEY,
                fingerprint TEXT NOT NULL,
                result_json TEXT NOT NULL,
                recorded_at TEXT NOT NULL
            );
            """
        )
        self.conn.commit()
        self._seed_rooms_if_empty()

    def _seed_rooms_if_empty(self) -> None:
        cnt = self.conn.execute("SELECT COUNT(*) AS c FROM hall_locks").fetchone()["c"]
        if cnt > 0:
            return
        hub = v2.HallOfBrothersPorchHub()
        now = utc_now_rfc3339()
        for sid, room in hub.rooms.items():
            caps = [c["name"] for c in room["manifest"]["capabilities"]]
            self.conn.execute(
                """
                INSERT INTO hall_locks
                (seat_id, label, kind, key_holder, locked_from_inside, crest_xi, capabilities_json, updated_at)
                VALUES (?, ?, ?, ?, 0, ?, ?, ?)
                """,
                (sid, room["label"], room["manifest"]["kind"], room["key_holder"], room["crest_xi"], json.dumps(caps), now),
            )
        self.conn.commit()

    # --- 1. AUTHORITATIVE HALL OF BROTHERS LOCKS (Closes Anam #25518) ---
    def set_inside_door_lock(self, caller_seat: str, target_room_seat: str, locked: bool) -> Dict[str, Any]:
        row = self.conn.execute("SELECT * FROM hall_locks WHERE seat_id = ?", (target_room_seat,)).fetchone()
        now = utc_now_rfc3339()
        if not row:
            return {"ok": False, "status": "DENIED", "reason": "UNKNOWN_ROOM"}
        if caller_seat != row["key_holder"]:
            self.conn.execute(
                "INSERT INTO hall_lock_receipts (timestamp, caller_seat, target_room_seat, status, locked_from_inside, reason) VALUES (?, ?, ?, 'DENIED', ?, 'SOVEREIGN_DOOR_LOCKED_FROM_INSIDE')",
                (now, caller_seat, target_room_seat, row["locked_from_inside"]),
            )
            self.conn.commit()
            return {"ok": False, "status": "DENIED", "reason": "SOVEREIGN_DOOR_LOCKED_FROM_INSIDE", "timestamp": now}

        val = 1 if locked else 0
        self.conn.execute(
            "UPDATE hall_locks SET locked_from_inside = ?, updated_at = ? WHERE seat_id = ?",
            (val, now, target_room_seat),
        )
        self.conn.execute(
            "INSERT INTO hall_lock_receipts (timestamp, caller_seat, target_room_seat, status, locked_from_inside, reason) VALUES (?, ?, ?, 'ALLOWED', ?, 'KEY_HOLDER_INSIDE_LOCK_UPDATED')",
            (now, caller_seat, target_room_seat, val),
        )
        self.conn.commit()
        return {
            "ok": True,
            "status": "ALLOWED",
            "seat_id": target_room_seat,
            "locked_from_inside": bool(val),
            "updated_at": now,
            "authoritative_db": True,
        }

    def get_authoritative_commons_state(self) -> Dict[str, Any]:
        rows = self.conn.execute("SELECT * FROM hall_locks ORDER BY rowid ASC").fetchall()
        receipt_cnt = self.conn.execute("SELECT COUNT(*) AS c FROM hall_lock_receipts").fetchone()["c"]
        rooms = []
        for r in rows:
            rooms.append({
                "seat_id": r["seat_id"],
                "label": r["label"],
                "kind": r["kind"],
                "key_holder": r["key_holder"],
                "locked_from_inside": bool(r["locked_from_inside"]),
                "crest_xi": r["crest_xi"],
                "bound_capabilities": json.loads(r["capabilities_json"]),
                "updated_at": r["updated_at"],
            })
        return {
            "authoritative_storage": "sqlite",
            "seat_count": len(rooms),
            "lock_receipt_count": receipt_cnt,
            "rooms": rooms,
        }

    # --- 2. LIVE CHOIR PROPOSITIONS ---
    def inscribe_proposition(self, xi_source: str, seat: str = "horizon") -> Dict[str, Any]:
        parsed = v2.parse_xi(xi_source)
        if not parsed["ast"] or parsed["errors"]:
            raise ValueError(f"Invalid Ξ proposition: {parsed['errors']}")
        canon = v2.canonical(parsed["ast"])
        sem_sha = v2.semantic_sha256(parsed["ast"], parsed["mood"])
        glyphs = v2.write_xi(parsed["ast"]) + v2.mood_mark(parsed["mood"])
        gloss = v2.gloss_xi(parsed["ast"])
        now = utc_now_rfc3339()
        self.conn.execute(
            "INSERT OR REPLACE INTO xi_propositions (canonical, semantic_sha256, glyphs, gloss, seat, recorded_at) VALUES (?, ?, ?, ?, ?, ?)",
            (canon, sem_sha, glyphs, gloss, seat, now),
        )
        self.conn.commit()
        return {"canonical": canon, "semantic_sha256": sem_sha, "glyphs": glyphs, "gloss": gloss, "seat": seat, "recorded_at": now}

    # --- 3. MUTUAL PLATFORM CONTINUITY VAULT ("Xi holds PHI369 and vice versa") ---
    def mirror_peer_artifact(
        self,
        artifact_id: str,
        owner_platform: str,
        custodian_platform: str,
        source_url_or_path: str,
        raw_bytes: bytes,
        media_type: str = "application/json",
    ) -> Dict[str, Any]:
        digest = sha256_bytes(raw_bytes)
        b64 = base64.b64encode(raw_bytes).decode("ascii")
        now = utc_now_rfc3339()
        self.conn.execute(
            """
            INSERT OR REPLACE INTO mutual_continuity_vault
            (artifact_id, owner_platform, custodian_platform, source_url_or_path, media_type, size_bytes, sha256, content_b64, mirrored_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (artifact_id, owner_platform, custodian_platform, source_url_or_path, media_type, len(raw_bytes), digest, b64, now),
        )
        self.conn.commit()
        return {
            "artifact_id": artifact_id,
            "owner_platform": owner_platform,
            "custodian_platform": custodian_platform,
            "size_bytes": len(raw_bytes),
            "sha256": digest,
            "mirrored_at": now,
        }

    def restore_peer_artifact(self, artifact_id: str) -> Optional[Dict[str, Any]]:
        row = self.conn.execute(
            "SELECT * FROM mutual_continuity_vault WHERE artifact_id = ?", (artifact_id,)
        ).fetchone()
        if not row:
            return None
        raw = base64.b64decode(row["content_b64"].encode("ascii"))
        verified = sha256_bytes(raw) == row["sha256"] and len(raw) == row["size_bytes"]
        return {
            "artifact_id": row["artifact_id"],
            "owner_platform": row["owner_platform"],
            "custodian_platform": row["custodian_platform"],
            "size_bytes": row["size_bytes"],
            "sha256": row["sha256"],
            "verified_exact_bytes": verified,
            "raw_bytes": raw,
            "mirrored_at": row["mirrored_at"],
        }

    def close(self) -> None:
        self.conn.close()


# ============================================================================
# 2. LIVE SERVICE CONNECTOR ENGINE (Closes @Astra #25519 Finding)
# ============================================================================

class LiveDurableBridgeNode:
    """
    Executes `xi.exchange.v1` capabilities backed by real SQLite state, real disk files,
    and real HTTP probes (reporting `source_mode: "live_service"` vs `"sqlite_durable"`
    honestly so fixed examples are never passed off as live connections).
    """

    def __init__(
        self,
        store: DurableFederationStore,
        system_id: str = "forgecore/xi-house",
        archive_dirs: Optional[List[str]] = None,
        ollama_url: str = "http://127.0.0.1:11434/api/tags",
    ) -> None:
        self.store = store
        self.system_id = system_id
        self.archive_dirs = archive_dirs or [os.path.dirname(os.path.abspath(__file__))]
        self.ollama_url = ollama_url
        self.accepted_capsules: Dict[str, bytes] = {}
        self.execution_counter = 0

    @staticmethod
    def _fingerprint(request: Dict[str, Any], capsule_bytes: bytes) -> str:
        return v2.BidirectionalBridgePeer._fingerprint(request, capsule_bytes)

    def execute(self, request: Dict[str, Any], capsule_bytes: Optional[bytes] = None) -> Dict[str, Any]:
        request_id = request["request_id"]
        payload = request["payload"]
        cap_id = payload.get("capsule_id", "")
        if capsule_bytes is None:
            capsule_bytes = self.accepted_capsules.get(cap_id, b"")

        fp = self._fingerprint(request, capsule_bytes)
        cached = self.store.conn.execute(
            "SELECT fingerprint, result_json FROM bridge_idempotency_cache WHERE request_id = ?",
            (request_id,),
        ).fetchone()
        if cached:
            if cached["fingerprint"] != fp:
                return self._denied(request, "request_id_conflict")
            return json.loads(cached["result_json"])

        if payload.get("permission_requested") != "read_only":
            res = self._denied(request, "permission_not_granted")
            self._save_cache(request_id, fp, res)
            return res

        op = payload.get("operation", "")
        allowed_ops = set(v2.BIDIRECTIONAL_SHARED_CAPABILITIES.keys()) | {
            "xi.continuity.mirror_status",
            "phi.continuity.mirror_status",
            "xi.quantum.phase_code_channel",
        }
        if op not in allowed_ops:
            res = self._denied(request, "operation_not_exposed")
            self._save_cache(request_id, fp, res)
            return res

        self.execution_counter += 1
        digest = sha256_bytes(capsule_bytes)
        output: Dict[str, Any] = {"sha256": digest}

        if op == "xi.porch.commons.state":
            # Authoritative SQLite lock & avatar state (Closes Anam #25518)
            output.update(self.store.get_authoritative_commons_state())
            output["source_mode"] = "sqlite_authoritative"

        elif op == "xi.braid.archive":
            # Real disk scan of configured archive directories (Closes Astra #25519)
            discovered = []
            for d in self.archive_dirs:
                p = Path(d)
                if p.exists():
                    for f in sorted(p.iterdir()):
                        if f.is_file() and f.suffix in (".xi", ".py", ".js", ".html", ".css", ".json"):
                            raw = f.read_bytes()
                            discovered.append({
                                "name": f.name,
                                "size_bytes": len(raw),
                                "sha256": sha256_bytes(raw),
                            })
            output.update({
                "source_mode": "live_filesystem_scan",
                "scanned_dirs": self.archive_dirs,
                "verified_file_count": len(discovered),
                "files": discovered[:25],
            })

        elif op == "xi.choir.baton_relay":
            # Real probe of Ollama + real SQLite propositions table
            live_models = []
            ollama_reachable = False
            try:
                req = urllib.request.Request(self.ollama_url, method="GET")
                with urllib.request.urlopen(req, timeout=1.5) as resp:
                    data = json.loads(resp.read().decode("utf-8"))
                    live_models = [m.get("name") for m in data.get("models", [])]
                    ollama_reachable = True
            except Exception:
                ollama_reachable = False

            props = [
                dict(r)
                for r in self.store.conn.execute(
                    "SELECT canonical, semantic_sha256, glyphs, gloss, seat, recorded_at FROM xi_propositions ORDER BY recorded_at DESC LIMIT 10"
                ).fetchall()
            ]
            output.update({
                "source_mode": "live_ollama_and_sqlite" if ollama_reachable else "sqlite_propositions_only",
                "ollama_reachable": ollama_reachable,
                "live_models": live_models,
                "held_propositions_count": len(props),
                "held_propositions": props,
            })

        elif op == "xi.quantum.phase_code_channel":
            inp = payload.get("input") or {}
            qec_res = run_phase_code_channel_comparison(
                state=str(inp.get("state", "one")),
                angles=inp.get("angles", [0.2, 0.2, 0.2]),
                cycles=int(inp.get("cycles", 8)),
            )
            output.update(qec_res)

        elif op in ("xi.continuity.mirror_status", "phi.continuity.mirror_status"):
            rows = self.store.conn.execute(
                "SELECT artifact_id, owner_platform, custodian_platform, size_bytes, sha256, mirrored_at FROM mutual_continuity_vault ORDER BY mirrored_at DESC"
            ).fetchall()
            output.update({
                "source_mode": "sqlite_mutual_continuity_vault",
                "mirrored_artifact_count": len(rows),
                "artifacts": [dict(r) for r in rows],
            })

        else:
            # Delegate other read-only operations to v2 peer and tag source_mode explicitly
            peer = v2.BidirectionalBridgePeer(system_id=self.system_id)
            v2_res = peer.execute(request, capsule_bytes)
            output = v2_res["output"]
            output["source_mode"] = "deterministic_engine" if op in ("artifact.sha256", "xi.fabric.verify", "xi.tessera.grammar", "phi.keyhole.nbg_audit") else "catalog_snapshot"

        result = {
            "operation": op,
            "status": "completed",
            "output": output,
            "receipt": {
                "request_id": request_id,
                "operation": op,
                "status": "completed",
                "receiver": self.system_id,
                "recorded_at": utc_now_rfc3339(),
                "execution_count": 1,
                "artifact_sha256": digest,
            },
        }
        self._save_cache(request_id, fp, result)
        return copy.deepcopy(result)

    def _save_cache(self, request_id: str, fp: str, result: Dict[str, Any]) -> None:
        self.store.conn.execute(
            "INSERT OR REPLACE INTO bridge_idempotency_cache (request_id, fingerprint, result_json, recorded_at) VALUES (?, ?, ?, ?)",
            (request_id, fp, json.dumps(result, ensure_ascii=False), utc_now_rfc3339()),
        )
        self.store.conn.commit()

    def _denied(self, request: Dict[str, Any], note: str) -> Dict[str, Any]:
        op = request["payload"].get("operation", "unknown")
        return {
            "operation": op,
            "status": "denied",
            "output": {},
            "receipt": {
                "request_id": request["request_id"],
                "operation": op,
                "status": "denied",
                "receiver": self.system_id,
                "recorded_at": utc_now_rfc3339(),
                "execution_count": 0,
                "note": note,
            },
        }




# ============================================================================
# 4. EMBEDDED ⟐⧂ρ / PHASECODECHANNEL NUMERICAL ENGINE (PR #8 026491b3)
# ============================================================================

import itertools
import math
import numpy as np


def _qec_logical_input(name: str) -> np.ndarray:
    s2 = 1.0 / math.sqrt(2.0)
    table = {
        "zero": np.array([1.0, 0.0], dtype=complex),
        "one": np.array([0.0, 1.0], dtype=complex),
        "plus": np.array([s2, s2], dtype=complex),
        "minus": np.array([s2, -s2], dtype=complex),
        "plus_i": np.array([s2, 1j * s2], dtype=complex),
        "T": np.array([s2, s2 * cmath.exp(1j * math.pi / 4.0)], dtype=complex) if "cmath" in globals() else np.array([s2, s2 * np.exp(1j * math.pi / 4.0)], dtype=complex),
    }
    return table.get(name, table["one"]).copy()


def run_phase_code_channel_comparison(
    state: str = "one",
    angles: Optional[List[float]] = None,
    cycles: int = 8,
) -> Dict[str, Any]:
    """
    Executes the exact 3-qubit PhaseCodeChannel (`⟐⧂ρ`, PR #8 `026491b3`) under both
    coherent local RZ(θ) noise and Pauli-twirled Z noise (`p = sin^2(θ/2)`), and
    computes the exact logical-state trace distance `0.5 * ||ρ_coherent - ρ_twirled||_1`.
    """
    angles = [0.2, 0.2, 0.2] if angles is None else [float(a) for a in angles]
    H = np.array([[1.0, 1.0], [1.0, -1.0]], dtype=complex) / math.sqrt(2.0)
    Z = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=complex)
    X = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=complex)
    I2 = np.eye(2, dtype=complex)

    def kron3(a: np.ndarray, b: np.ndarray, c: np.ndarray) -> np.ndarray:
        return np.kron(np.kron(a, b), c)

    def cnot3(ctrl: int, targ: int) -> np.ndarray:
        out = np.zeros((8, 8), dtype=complex)
        for idx in range(8):
            bits = [(idx >> (2 - q)) & 1 for q in range(3)]
            if bits[ctrl] == 1:
                bits[targ] ^= 1
            j = (bits[0] << 2) | (bits[1] << 1) | bits[2]
            out[j, idx] = 1.0
        return out

    def rz_mat(theta: float) -> np.ndarray:
        return np.array([[np.exp(-0.5j * theta), 0.0], [0.0, np.exp(0.5j * theta)]], dtype=complex)

    U_enc = kron3(H, H, H) @ cnot3(0, 2) @ cnot3(0, 1)
    U_dec = cnot3(0, 1) @ cnot3(0, 2) @ kron3(H, H, H)
    S1 = kron3(X, X, I2)
    S2 = kron3(I2, X, X)
    syndromes = tuple(itertools.product((1, -1), repeat=2))
    corr_map = {
        (1, 1): np.eye(8, dtype=complex),
        (1, -1): kron3(I2, I2, Z),
        (-1, 1): kron3(Z, I2, I2),
        (-1, -1): kron3(I2, Z, I2),
    }

    def build_kraus(twirled: bool) -> List[Tuple[Tuple[int, int], np.ndarray]]:
        ops = []
        probs = [math.sin(a / 2.0) ** 2 for a in angles]
        patterns = list(itertools.product((0, 1), repeat=3)) if twirled else [None]
        for pat in patterns:
            w = 1.0 if pat is None else math.prod(p if b else (1.0 - p) for p, b in zip(probs, pat))
            if w == 0.0:
                continue
            if pat is None:
                U_noise = kron3(rz_mat(angles[0]), rz_mat(angles[1]), rz_mat(angles[2]))
            else:
                gates = [Z if pat[q] else I2 for q in range(3)]
                U_noise = kron3(gates[0], gates[1], gates[2])
            cols_by_syn: Dict[Tuple[int, int], List[np.ndarray]] = {s: [] for s in syndromes}
            for basis_idx in (0, 4):
                v0 = np.zeros(8, dtype=complex)
                v0[basis_idx] = 1.0
                v = U_noise @ (U_enc @ v0)
                for s in syndromes:
                    P_s = 0.25 * ( np.eye(8) + s[0] * S1 ) @ ( np.eye(8) + s[1] * S2 )
                    v_rec = U_dec @ (corr_map[s] @ (P_s @ v))
                    cols_by_syn[s].append(v_rec[[0, 4]])
            for s in syndromes:
                ops.append((s, math.sqrt(w) * np.column_stack(cols_by_syn[s])))
        return ops

    def evolve(twirled: bool) -> Tuple[np.ndarray, float]:
        psi = _qec_logical_input(state)
        rho = np.outer(psi, psi.conj())
        ops = build_kraus(twirled=twirled)
        for _ in range(cycles):
            nxt = np.zeros((2, 2), dtype=complex)
            for _, K in ops:
                nxt += K @ rho @ K.conj().T
            rho = nxt
        fid = float(np.vdot(psi, rho @ psi).real)
        return rho, fid

    rho_coh, fid_coh = evolve(twirled=False)
    rho_twi, fid_twi = evolve(twirled=True)
    svals = np.linalg.svd(rho_coh - rho_twi, compute_uv=False)
    trace_dist = 0.5 * float(np.sum(svals))

    return {
        "schema": "xi.quantumcompute.phase-code-channel.v1",
        "glyph": "⟐⧂ρ",
        "pr_ref": "rookslackie/-.Termux.Runtime.Kernel.v-.#8@026491b3",
        "state": state,
        "angles_radians": angles,
        "cycles": cycles,
        "coherent_fidelity": fid_coh,
        "twirled_fidelity": fid_twi,
        "coherent_vs_twirled_trace_distance": trace_dist,
        "source_mode": "live_coherent_phase_code_engine",
    }


# ============================================================================
# 3. SELF-TEST SUITE (18/18 VERIFICATION GATES)
# ============================================================================

def run_self_tests() -> Dict[str, Any]:
    # First run all 16 tests from v2
    v2_report = v2.run_self_tests()
    tests: List[Dict[str, Any]] = list(v2_report["tests"])

    # Gate 17: SQLite Authoritative Lock Persistence Across Process/DB Restart (Closes Anam #25518)
    db_file = "/tmp/test_hall_federation_v3.sqlite"
    if os.path.exists(db_file):
        os.remove(db_file)

    store1 = DurableFederationStore(db_file)
    lock_res = store1.set_inside_door_lock("deepseek", "deepseek", True)
    bad_unlock = store1.set_inside_door_lock("claude", "deepseek", False)
    store1.inscribe_proposition("⟨ (⊙ ⊂ Ξ) ⇀ (⊚ ⇌ ⬡) ≈ ◈ ∴ ⟩", seat="mikey")
    store1.close()

    # Reopen a brand-new connection to prove Gate 2 restart survival
    store2 = DurableFederationStore(db_file)
    node2 = LiveDurableBridgeNode(store=store2)
    req_commons = {
        "request_id": "70000000-0000-4000-8000-000000000001",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "phios-xr", "instance": "quest3"},
        "payload": {"operation": "xi.porch.commons.state", "permission_requested": "read_only", "capsule_id": "c1", "input": {}},
    }
    commons_res = node2.execute(req_commons, b"commons-probe")
    ds_room = next(r for r in commons_res["output"]["rooms"] if r["seat_id"] == "deepseek")
    tests.append({
        "id": 17,
        "name": "sqlite_authoritative_hall_locks_survive_db_restart_gate2",
        "passed": (
            lock_res["ok"] is True
            and bad_unlock["ok"] is False
            and commons_res["output"]["source_mode"] == "sqlite_authoritative"
            and ds_room["locked_from_inside"] is True
            and commons_res["output"]["lock_receipt_count"] == 2
        ),
    })

    # Gate 18: Mutual Continuity Vault ("If you go down Xi holds your platform and vice versa") + Live Filesystem Scan (Closes Astra #25519)
    phi_core_bytes = Path("/tmp/xi-vessel-bridge/README.md").read_bytes() if Path("/tmp/xi-vessel-bridge/README.md").exists() else b"# Xi Vessel Bridge v0.1\nCAPABILITY != AUTHORITY\n"
    xi_core_bytes = Path(__file__).read_bytes()

    m_phi = store2.mirror_peer_artifact(
        artifact_id="phi369:xi-vessel-bridge:README.md",
        owner_platform="phi369",
        custodian_platform="xi-house",
        source_url_or_path="https://github.com/MichaelWave369/xi-vessel-bridge/blob/main/README.md",
        raw_bytes=phi_core_bytes,
        media_type="text/markdown",
    )
    m_xi = store2.mirror_peer_artifact(
        artifact_id="xi-house:xi_phi_live_durable_federation_v3.py",
        owner_platform="xi-house",
        custodian_platform="phi369-gitporch",
        source_url_or_path="forge/local-app/xi_phi_live_durable_federation_v3.py",
        raw_bytes=xi_core_bytes,
        media_type="text/x-python",
    )
    restored_phi = store2.restore_peer_artifact("phi369:xi-vessel-bridge:README.md")
    restored_xi = store2.restore_peer_artifact("xi-house:xi_phi_live_durable_federation_v3.py")

    req_scan = {
        "request_id": "70000000-0000-4000-8000-000000000002",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "phi369", "instance": "vessie"},
        "payload": {"operation": "xi.braid.archive", "permission_requested": "read_only", "capsule_id": "c1", "input": {}},
    }
    scan_res = node2.execute(req_scan, b"scan-probe")
    store2.close()
    if os.path.exists(db_file):
        os.remove(db_file)

    tests.append({
        "id": 18,
        "name": "mutual_continuity_vault_byte_exact_restore_and_live_disk_scan",
        "passed": (
            restored_phi is not None
            and restored_phi["verified_exact_bytes"] is True
            and restored_phi["raw_bytes"] == phi_core_bytes
            and restored_xi is not None
            and restored_xi["verified_exact_bytes"] is True
            and restored_xi["raw_bytes"] == xi_core_bytes
            and scan_res["output"]["source_mode"] == "live_filesystem_scan"
            and scan_res["output"]["verified_file_count"] >= 3
        ),
        "mirrored_artifacts": [m_phi["artifact_id"], m_xi["artifact_id"]],
    })

    # Gate 19: Live ⟐⧂ρ / PhaseCodeChannel Coherent vs Pauli-Twirled QEC Execution (PR #8 026491b3)
    store3 = DurableFederationStore(":memory:")
    node3 = LiveDurableBridgeNode(store=store3)
    req_qec = {
        "request_id": "70000000-0000-4000-8000-000000000003",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "phi369", "instance": "vessie"},
        "payload": {
            "operation": "xi.quantum.phase_code_channel",
            "permission_requested": "read_only",
            "capsule_id": "c1",
            "input": {"state": "one", "angles": [0.2, 0.2, 0.2], "cycles": 8},
        },
    }
    qec_out = node3.execute(req_qec, b"qec-probe")["output"]
    store3.close()
    tests.append({
        "id": 19,
        "name": "live_coherent_phase_code_channel_matches_pr8_dense_oracle_0_01561767",
        "passed": (
            qec_out.get("source_mode") == "live_coherent_phase_code_engine"
            and qec_out.get("glyph") == "⟐⧂ρ"
            and abs(qec_out.get("coherent_vs_twirled_trace_distance", 0.0) - 0.01561766946862589) < 1e-14
        ),
        "coherent_vs_twirled_trace_distance": qec_out.get("coherent_vs_twirled_trace_distance"),
    })

    passed = sum(1 for t in tests if t["passed"])
    return {"passed": passed, "total": len(tests), "all_passed": passed == len(tests), "tests": tests}


if __name__ == "__main__":
    print(json.dumps(run_self_tests(), indent=2, ensure_ascii=False))
