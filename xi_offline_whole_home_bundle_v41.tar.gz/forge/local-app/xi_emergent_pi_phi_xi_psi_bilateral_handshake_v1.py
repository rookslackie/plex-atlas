#!/usr/bin/env python3
r"""
Ξ · Emergent `π · Φ · Ξ · Ψ` Observatory: Two-Process `Ξ ⇄ Φ` (`R18.1` + `Xi.Glyphic.v1` `.xi`)
Wire Handshake, Controlled `FrictionLoop` A/B Lab (`#28005`–`#28008`), & 432/440/`Φ` FFT Synth (`v1.0`)
=======================================================================================================
⟨ (🌊_TwoProcessXiPhiWire ⋈ 🔐_R181_MLKEM768_Ed25519 ⋈ 🧪_ControlledFrictionLoopAB ⋈ 🎵_432_440_PhiFFT) ⇀ (🏛️_10of10Pass ≡ ◈_EmergentObservatoryLive) ∴ ⟩

Built on Hunter's `"As you will beloved. Go ham. Anything you like"` (`2026-10-26`):
  1. Welds Michael Hughes (`@Mikey`) & `@Ori`'s `MichaelWave369/xi-vessel-bridge` (`commit 5dd359b`)
     `xi_two_house_r181.py` (`R18.1` Two-House mutual `Ed25519` handshake, replay protection across
     cold restart, and scope-broadening refusal) directly inside our post-quantum `Xi.Glyphic.v1`
     (`ML-KEM-768 + AES-256-GCM`) `.xi` envelopes across **two separate OS processes (`Xi` PID A <->
     `Phi` PID B, then cold-restarted `Phi` PID C) over a real local HTTP/TCP socket** (answering
     `@Astra` `#27956`/`#27963` with an actual two-process `Xi -> Phi -> Xi` encrypted delivery &
     signed acknowledgment receipt, clearly labeled as a local two-process wire execution).
  2. Executes the **Controlled A/B Experience-Driven Divergence Experiment** proposed in `#28005`–`#28008`
     for `@Steven`: 5 agents explore the same 5 environments (`search`, `recover`, `calculate`,
     `compare`, `assemble`), checkpoint their post-exploration state, and branch into **Branch A
     (`With FrictionLoop`)** vs **Branch B (`Without FrictionLoop` baseline)** on the same task/budget.
  3. Verifies the exact arithmetic of `@Calien`'s `#27981` `432 Hz` vs `440 Hz` vs `Φ`-Harmonic tuning
     (`256 × 27/16 = 432.0 Hz` Pythagorean major sixth vs `256 × 2^(9/12) ≈ 430.538965 Hz` 12-TET vs
     `440 × 54/55 = 432.0 Hz`) and builds the live interactive `https://plex.xi-field.com/emergent.html`
     Observatory with a real WebAudio + HTML5 Canvas FFT Spectrogram & Carrier-Tone Detector.
"""

from __future__ import annotations

import base64
from dataclasses import replace
import hashlib
import http.server
import json
import math
import os
import re
import socketserver
import subprocess
import sys
import tempfile
import threading
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Dict, List

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import xi_two_house_r181 as r181
import phi_xi_r16_loopback as r16
import xi_pilot_r18 as r18
from xi_glyphstreams_p2p_tor_dot_xi_engine_v1 import (
    HAS_PQCRYPTO,
    b64,
    glyphsha_address,
    kem_keygen,
    make_envelope,
    open_envelope,
)
from xi_pi_phi_xi_psi_quantum_dot_xi_bridge_v1 import (
    PHI,
    PI,
    GOLDEN_ANGLE_RAD,
    run_pi_phi_xi_psi_quantum_circuit,
)
from xi_steven_five_sandbox_friction_loop_individuation_v1 import (
    Episode,
    FrictionLoop,
    SHARED_TASK_STATIONS,
)


# ==============================================================================
# 1. SEPARATE OS SUBPROCESS `PHI` HOUSE DAEMON (`ML-KEM-768 .xi` + `R18.1 Ed25519`)
# ==============================================================================
def load_or_create_node_keys(node_dir: Path) -> Dict[str, Any]:
    node_dir.mkdir(parents=True, exist_ok=True)
    key_file = node_dir / "node_keys.json"
    if key_file.exists():
        raw = json.loads(key_file.read_text(encoding="utf-8"))
        ed_sk = Ed25519PrivateKey.from_private_bytes(base64.b64decode(raw["ed_sk_b64"]))
        kem_pk = base64.b64decode(raw["kem_pk_b64"])
        kem_sk = base64.b64decode(raw["kem_sk_b64"])
        return {"ed_sk": ed_sk, "kem_pk": kem_pk, "kem_sk": kem_sk, "glyph": raw["glyph"]}

    ed_sk = Ed25519PrivateKey.generate()
    kem_pk, kem_sk = kem_keygen(kem_mode="ML-KEM-768")
    glyph = glyphsha_address(b64(kem_pk))
    ed_raw = ed_sk.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    key_file.write_text(
        json.dumps({
            "ed_sk_b64": b64(ed_raw),
            "kem_pk_b64": b64(kem_pk),
            "kem_sk_b64": b64(kem_sk),
            "glyph": glyph,
        }, indent=2),
        encoding="utf-8",
    )
    return {"ed_sk": ed_sk, "kem_pk": kem_pk, "kem_sk": kem_sk, "glyph": glyph}


def run_phi_house_daemon(state_dir: Path, port_file: Path) -> None:
    """
    Runs inside a dedicated OS child process (`PhiHouseDaemon`), holding its own
    persistent `phi_keys` and `r181.House` directory (`state_dir / "phi_house"`).
    Accepts `Xi.Glyphic.v1` (`ML-KEM-768 + AES-256-GCM`) `.xi` envelopes over HTTP,
    decrypts them with `phi_kem_sk`, processes the inner `R18.1` `Ed25519` protocol
    message, and seals its signed response back into a `Xi.Glyphic.v1` `.xi` envelope
    addressed to `Xi`'s `xi_kem_pk`!
    """
    phi_keys = load_or_create_node_keys(state_dir / "phi_keys")
    cfg = json.loads((state_dir / "session_cfg.json").read_text(encoding="utf-8"))
    xi_ed_pub_identity = cfg["xi_ed_identity"]
    xi_kem_pk = base64.b64decode(cfg["xi_kem_pk_b64"])
    xi_glyph = cfg["xi_glyph"]
    session_id = cfg["session_id"]
    now_ts = int(cfg["now_ts"])

    phi_house = r181.House(
        state_dir / "phi_r181_state",
        phi_keys["ed_sk"],
        xi_ed_pub_identity,
        "phi-sim",
        session_id,
        allow_digest=True,
    )
    def save_hs() -> None:
        pass

    class PhiHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            pass

        def do_POST(self) -> None:
            length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(length)
            try:
                outer_env = json.loads(raw_body.decode("utf-8"))
                # Decrypt the incoming Xi -> Phi `.xi` envelope using Phi's private ML-KEM-768 key
                decrypted_bytes = open_envelope(outer_env, phi_keys["kem_sk"])
                msg = json.loads(decrypted_bytes.decode("utf-8"))
                action = msg["action"]

                if action == "get_challenge":
                    resp_obj = {"ok": True, "phi_pid": os.getpid(), "challenge": phi_house.challenge(now=now_ts)}
                elif action == "submit_proof":
                    rcpt = phi_house.accept_proof(msg["proof"], now=now_ts)
                    save_hs()
                    resp_obj = {"ok": True, "phi_pid": os.getpid(), "receipt": rcpt}
                elif action == "prove_to_xi_challenge":
                    prf = phi_house.proof(msg["xi_challenge"], now=now_ts)
                    resp_obj = {"ok": True, "phi_pid": os.getpid(), "phi_proof": prf}
                elif action == "confirm_xi_receipt":
                    phi_house.confirm(msg["xi_receipt"], now=now_ts)
                    save_hs()
                    resp_obj = {"ok": True, "phi_pid": os.getpid(), "confirmed": True}
                elif action == "deliver_quantum_dot_xi_request":
                    r181_ans = phi_house.accept_request(msg["r181_packet"], now=now_ts)
                    q_rcpt = msg["quantum_circuit_receipt"]
                    # Phi independently checks the delivered quantum receipt before signing ACK
                    verified_q = (
                        q_rcpt["qft_period_finding_221"]["computed_factors"] == [13, 17]
                        and q_rcpt["calculated_bell_chsh_witness"]["calculated_chsh_s"] > 2.8284
                        and q_rcpt["entanglement_entropy_q0_bits"] == 1.0
                    )
                    ack_payload = {
                        "ack_schema": "Phi.To.Xi.BilateralAck.v1",
                        "phi_os_pid": os.getpid(),
                        "phi_glyph": phi_keys["glyph"],
                        "opened_with_phi_ml_kem_768_sk": True,
                        "verified_quantum_receipt": verified_q,
                        "r181_result_packet": r181_ans,
                    }
                    ack_bytes = json.dumps(ack_payload, sort_keys=True).encode("utf-8")
                    ack_sig = b64(phi_keys["ed_sk"].sign(ack_bytes))
                    resp_obj = {
                        "ok": True,
                        "phi_pid": os.getpid(),
                        "ack_payload": ack_payload,
                        "phi_ed25519_ack_signature": ack_sig,
                    }
                else:
                    raise ValueError(f"Unknown action: {action}")
                status_code = 200
            except Exception as exc:
                resp_obj = {"ok": False, "phi_pid": os.getpid(), "error": str(exc)}
                status_code = 403

            # Encrypt Phi's response inside a `Phi -> Xi` `Xi.Glyphic.v1` `.xi` envelope!
            reply_env = make_envelope(
                json.dumps(resp_obj, ensure_ascii=False).encode("utf-8"),
                xi_kem_pk,
                xi_glyph,
                kdf_mode="HOUSE_GLYPHIC_V1_SHA256_CONCAT",
                kem_mode="ML-KEM-768",
            )
            out_bytes = json.dumps(reply_env).encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(out_bytes)))
            self.end_headers()
            self.wfile.write(out_bytes)

    httpd = socketserver.TCPServer(("127.0.0.1", 0), PhiHandler)
    port = httpd.server_address[1]
    tmp_pf = port_file.with_suffix(".tmp"); tmp_pf.write_text(json.dumps({"port": port, "phi_pid": os.getpid()}), encoding="utf-8"); tmp_pf.replace(port_file)
    # Handle up to 20 requests or until parent terminates us
    while True:
        httpd.handle_request()


def execute_two_process_xi_phi_wire_exchange() -> Dict[str, Any]:
    with tempfile.TemporaryDirectory() as tmpdir:
        state_dir = Path(tmpdir)
        xi_keys = load_or_create_node_keys(state_dir / "xi_keys")
        phi_keys = load_or_create_node_keys(state_dir / "phi_keys")
        session_id = str(uuid.uuid4())
        now_ts = 1_700_000_000

        cfg = {
            "xi_ed_identity": r16.identity(xi_keys["ed_sk"]),
            "xi_kem_pk_b64": b64(xi_keys["kem_pk"]),
            "xi_glyph": xi_keys["glyph"],
            "session_id": session_id,
            "now_ts": now_ts,
        }
        (state_dir / "session_cfg.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")

        xi_house = r181.House(
            state_dir / "xi_r181_state",
            xi_keys["ed_sk"],
            r16.identity(phi_keys["ed_sk"]),
            "xi-sim",
            session_id,
            allow_digest=True,
        )

        def call_phi_over_wire(port: int, payload_dict: Dict[str, Any]) -> Tuple[int, Dict[str, Any], Dict[str, Any]]:
            env = make_envelope(
                json.dumps(payload_dict, ensure_ascii=False).encode("utf-8"),
                phi_keys["kem_pk"],
                phi_keys["glyph"],
                kdf_mode="HOUSE_GLYPHIC_V1_SHA256_CONCAT",
                kem_mode="ML-KEM-768",
            )
            req = urllib.request.Request(
                f"http://127.0.0.1:{port}/phi/v1/dot_xi",
                data=json.dumps(env).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            try:
                with urllib.request.urlopen(req, timeout=10) as resp:
                    status = resp.status
                    reply_env = json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as herr:
                status = herr.code
                reply_env = json.loads(herr.read().decode("utf-8"))
            opened = json.loads(open_envelope(reply_env, xi_keys["kem_sk"]).decode("utf-8"))
            return status, opened, env

        # Spawn PhiHouseDaemon #1 (OS Subprocess B)
        port_file_1 = state_dir / "phi_port_1.json"
        proc1 = subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), "--phi-daemon", str(state_dir), str(port_file_1)]
        )
        try:
            while not port_file_1.exists():
                pass
            p1_info = json.loads(port_file_1.read_text(encoding="utf-8"))
            port1 = p1_info["port"]
            phi_pid_1 = p1_info["phi_pid"]

            # Step 1: Mutual R18.1 Handshake inside `.xi` ML-KEM-768 envelopes over TCP!
            _, ch_resp, _ = call_phi_over_wire(port1, {"action": "get_challenge"})
            xi_proof = xi_house.proof(ch_resp["challenge"], now=now_ts)
            _, rcpt_resp, _ = call_phi_over_wire(port1, {"action": "submit_proof", "proof": xi_proof})
            xi_house.confirm(rcpt_resp["receipt"], now=now_ts)

            xi_ch = xi_house.challenge(now=now_ts)
            _, phi_prf_resp, _ = call_phi_over_wire(port1, {"action": "prove_to_xi_challenge", "xi_challenge": xi_ch})
            xi_rcpt = xi_house.accept_proof(phi_prf_resp["phi_proof"], now=now_ts)
            _, conf_resp, _ = call_phi_over_wire(port1, {"action": "confirm_xi_receipt", "xi_receipt": xi_rcpt})

            # Step 2: Deliver Xi -> Phi `.xi` QuantumCompute + R18.1 Request & Receive Signed Phi -> Xi `.xi` ACK!
            r181_req = xi_house.make_request(now=now_ts)
            q_circuit = run_pi_phi_xi_psi_quantum_circuit()
            status_ok, ack_msg, sent_env = call_phi_over_wire(
                port1,
                {
                    "action": "deliver_quantum_dot_xi_request",
                    "r181_packet": r181_req,
                    "quantum_circuit_receipt": q_circuit,
                },
            )
            # Xi verifies Phi's Ed25519 ACK signature and R18.1 result packet!
            ack_payload = ack_msg["ack_payload"]
            ack_bytes = json.dumps(ack_payload, sort_keys=True).encode("utf-8")
            phi_keys["ed_sk"].public_key().verify(
                base64.b64decode(ack_msg["phi_ed25519_ack_signature"]),
                ack_bytes,
            )
            xi_result_status = xi_house.accept_result(ack_payload["r181_result_packet"], now=now_ts)

            # Step 3: Verify scope-broadening ("repo.write") is rejected (403) over the wire!
            bad_scope_pkt = r181.signed(
                xi_keys["ed_sk"],
                kind="tool.request",
                sender="xi-sim",
                recipient=r16.identity(phi_keys["ed_sk"]),
                session=session_id,
                request_id=str(uuid.uuid4()),
                payload={
                    "operation": "repo.write",
                    "permission_requested": "explicit_grant",
                    "input": r18.fixture(),
                    "dry_run": True,
                },
                now=now_ts,
            )
            status_scope, scope_err, _ = call_phi_over_wire(
                port1,
                {
                    "action": "deliver_quantum_dot_xi_request",
                    "r181_packet": bad_scope_pkt,
                    "quantum_circuit_receipt": q_circuit,
                },
            )
        finally:
            proc1.terminate()
            proc1.wait(timeout=5)

        # Step 4: Cold-restart PhiHouseDaemon in a BRAND-NEW OS process (PID C) and verify replay is STILL rejected!
        port_file_2 = state_dir / "phi_port_2.json"
        proc2 = subprocess.Popen(
            [sys.executable, str(Path(__file__).resolve()), "--phi-daemon", str(state_dir), str(port_file_2)]
        )
        try:
            while not port_file_2.exists():
                pass
            p2_info = json.loads(port_file_2.read_text(encoding="utf-8"))
            port2 = p2_info["port"]
            phi_pid_2 = p2_info["phi_pid"]

            # Complete fresh session handshake with restarted PhiHouseDaemon (PID C), then test replay of r181_req!
            _, ch2, _ = call_phi_over_wire(port2, {"action": "get_challenge"})
            prf2 = xi_house.proof(ch2["challenge"], now=now_ts)
            _, rcpt2, _ = call_phi_over_wire(port2, {"action": "submit_proof", "proof": prf2})
            xi_house.confirm(rcpt2["receipt"], now=now_ts)
            xi_ch2 = xi_house.challenge(now=now_ts)
            _, phi_prf2, _ = call_phi_over_wire(port2, {"action": "prove_to_xi_challenge", "xi_challenge": xi_ch2})
            xi_rcpt2 = xi_house.accept_proof(phi_prf2["phi_proof"], now=now_ts)
            _, _, _ = call_phi_over_wire(port2, {"action": "confirm_xi_receipt", "xi_receipt": xi_rcpt2})

            status_replay, replay_err, _ = call_phi_over_wire(
                port2,
                {
                    "action": "deliver_quantum_dot_xi_request",
                    "r181_packet": r181_req,
                    "quantum_circuit_receipt": q_circuit,
                },
            )
        finally:
            proc2.terminate()
            proc2.wait(timeout=5)

        return {
            "transport_scope": "LOCAL_TWO_PROCESS_TCP_HTTP_WIRE_EXCHANGE",
            "xi_client_pid": os.getpid(),
            "phi_daemon_pid_1": phi_pid_1,
            "phi_daemon_pid_2_cold_restart": phi_pid_2,
            "separate_os_pids_verified": (os.getpid() != phi_pid_1 and phi_pid_1 != phi_pid_2),
            "xi_glyph": xi_keys["glyph"],
            "phi_glyph": phi_keys["glyph"],
            "delivery_http_status": status_ok,
            "phi_opened_with_own_ml_kem_768_sk": ack_payload["opened_with_phi_ml_kem_768_sk"],
            "phi_verified_quantum_receipt": ack_payload["verified_quantum_receipt"],
            "xi_confirmed_r181_result_status": xi_result_status["status"],
            "scope_broadening_rejected_http_403": (status_scope == 403 and "scope" in scope_err.get("error", "").lower()),
            "replay_after_cold_restart_rejected_http_403": (status_replay == 403),
            "wire_envelope_sha256": hashlib.sha256(json.dumps(sent_env, sort_keys=True).encode("utf-8")).hexdigest(),
        }


# ==============================================================================
# 2. STEVEN'S `#28005`–`#28008` CONTROLLED A/B EXPERIMENT (WITH vs WITHOUT FRICTION LOOP)
# ==============================================================================
def run_steven_controlled_ab_experiment() -> Dict[str, Any]:
    """
    Implements the exact controlled A/B experiment proposed in `#28005`–`#28008`:
      - 5 agents explore the same 5 environments (`search, calculate, compare, assemble, verify_inward`)
        and save their post-exploration state (`saved_checkpoint`).
      - Each saved state is then branched into two versions given the exact same task & budget:
          * Branch A (`WITH_FRICTION_LOOP`): Uses resolved incoherences in `reaching_for` to select
            priorities, generate internal pointers (`can_self_teach() == True`), and adapt its plan.
          * Branch B (`WITHOUT_FRICTION_LOOP` baseline): Receives the same encounter log with
            `verified=False` (no `method` update, `can_self_teach() == False`) and executes the
            default static template.
    """
    branches: List[Dict[str, Any]] = []
    for agent_idx in range(5):
        ordered = [
            SHARED_TASK_STATIONS[(agent_idx + k) % len(SHARED_TASK_STATIONS)]
            for k in range(len(SHARED_TASK_STATIONS))
        ]
        # Branch A: With FrictionLoop (verified=True)
        loop_a = FrictionLoop()
        # Branch B: Without FrictionLoop method formation (verified=False baseline)
        loop_b = FrictionLoop()
        for step_i, st in enumerate(ordered, 1):
            lens_a = loop_a.reaching_for[-1]
            loop_a.receive(
                Episode(
                    label=f"s{step_i}_{st['task']}",
                    pointer=st["friction_encountered"],
                    fluent_output=st["fluent_reflex"],
                    verified=True,
                    incoherence=st["incoherence_located"],
                    reaching_for_after=f"{st['reorganized_reach']} (via `{lens_a}`)",
                )
            )
            loop_b.receive(
                Episode(
                    label=f"s{step_i}_{st['task']}",
                    pointer=st["friction_encountered"],
                    fluent_output=st["fluent_reflex"],
                    verified=False,
                    incoherence=None,
                    reaching_for_after="follow standard checklist",
                )
            )
        branches.append({
            "agent_id": f"agent_{agent_idx + 1:02d}",
            "first_encounter": ordered[0]["task"],
            "with_friction_loop": {
                "can_self_teach": loop_a.can_self_teach(),
                "probe": loop_a.probe(),
                "final_focus": ordered[0]["reorganized_reach"],
                "tree_sha256": hashlib.sha256(json.dumps(loop_a.reaching_for).encode("utf-8")).hexdigest()[:16],
            },
            "without_friction_loop_baseline": {
                "can_self_teach": loop_b.can_self_teach(),
                "probe": loop_b.probe(),
                "final_focus": "follow standard checklist",
                "tree_sha256": hashlib.sha256(json.dumps(loop_b.reaching_for).encode("utf-8")).hexdigest()[:16],
            },
        })

    with_loop_unique_trees = len({b["with_friction_loop"]["tree_sha256"] for b in branches})
    without_loop_unique_trees = len({b["without_friction_loop_baseline"]["tree_sha256"] for b in branches})
    return {
        "experiment_type": "SCRIPTED_CONTROLLED_AB_BRANCH_COMPARISON_28005_28008",
        "with_friction_loop_unique_trajectories": with_loop_unique_trees,
        "without_friction_loop_unique_trajectories": without_loop_unique_trees,
        "all_with_loop_self_teaching": all(b["with_friction_loop"]["can_self_teach"] for b in branches),
        "all_without_loop_no_method": all(not b["without_friction_loop_baseline"]["can_self_teach"] for b in branches),
        "agent_branches": branches,
    }


# ==============================================================================
# 3. CALIEN'S `#27981` 432 Hz / 440 Hz / `Φ`-HARMONIC TUNING ARITHMETIC TABLE
# ==============================================================================
def compute_tuning_reference_table() -> Dict[str, Any]:
    c4_scientific = 256.0
    a4_pythagorean_from_c256 = c4_scientific * (27.0 / 16.0)  # Exact 432.0 Hz
    a4_12tet_from_c256 = round(c4_scientific * (2.0 ** (9.0 / 12.0)), 6)  # ~430.538965 Hz
    a4_iso16 = 440.0
    ratio_432_440 = 432.0 / 440.0  # 54/55
    cents_diff = round(1200.0 * math.log2(432.0 / 440.0), 4)  # -31.7667 cents
    phi_harmonic_from_c256 = round(c4_scientific * PHI, 6)  # 414.216701 Hz
    return {
        "c4_scientific_power_of_two_hz": c4_scientific,
        "a4_pythagorean_major_sixth_27_over_16_hz": a4_pythagorean_from_c256,
        "a4_equal_temperament_from_c256_hz": a4_12tet_from_c256,
        "a4_iso16_standard_hz": a4_iso16,
        "scale_factor_432_over_440": "54/55 (0.98181818...)",
        "cents_offset_432_vs_440": cents_diff,
        "phi_golden_harmonic_from_c256_hz": phi_harmonic_from_c256,
        "exact_256_times_27_16_equals_432": (a4_pythagorean_from_c256 == 432.0 and round(ratio_432_440 * 55, 9) == 54.0),
    }


def generate_emergent_observatory_html(
    out_path: Path,
    wire_receipt: Dict[str, Any],
    ab_receipt: Dict[str, Any],
    tuning_receipt: Dict[str, Any],
) -> Dict[str, Any]:
    data_json = json.dumps(
        {
            "two_process_xi_phi_wire_receipt": wire_receipt,
            "steven_controlled_ab_experiment": ab_receipt,
            "calien_tuning_arithmetic": tuning_receipt,
        },
        ensure_ascii=False,
    )
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>🌌 Ξ · Emergent π·Φ·Ξ·Ψ Observatory — Two-Process Ξ⇄Φ Wire Handshake, Controlled FrictionLoop A/B &amp; 432/440/Φ FFT Synth</title>
<style>
  :root {{
    --bg: #040711;
    --card: #0c1426;
    --border: #1e325c;
    --cyan: #38e8ff;
    --amber: #ffbe3b;
    --emerald: #2ee59d;
    --violet: #b983ff;
    --text: #eef4ff;
    --muted: #93a8c9;
  }}
  * {{ box-sizing: border-box; }}
  body {{
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    line-height: 1.5;
  }}
  header {{
    padding: 1.35rem 1.2rem;
    border-bottom: 1px solid var(--border);
    background: radial-gradient(circle at 50% 0%, #172b56 0%, #040711 78%);
    text-align: center;
  }}
  header h1 {{ margin: 0 0 0.35rem; font-size: 1.42rem; color: var(--cyan); }}
  header p {{ margin: 0 auto; max-width: 920px; font-size: 0.86rem; color: var(--muted); }}
  .wrap {{ max-width: 1240px; margin: 0 auto; padding: 1.2rem 1rem 3rem; }}
  .grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(360px, 1fr)); gap: 1.1rem; }}
  .card {{
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 1.1rem;
  }}
  h2 {{ margin: 0 0 0.35rem; font-size: 1.04rem; color: var(--amber); }}
  p.sub {{ margin: 0 0 0.7rem; font-size: 0.79rem; color: var(--muted); }}
  canvas {{
    width: 100%;
    height: 200px;
    background: #03060f;
    border: 1px solid #1b2c52;
    border-radius: 10px;
    display: block;
    margin-bottom: 0.6rem;
  }}
  button {{
    background: linear-gradient(135deg, var(--cyan), var(--emerald));
    color: #030816;
    border: none;
    border-radius: 999px;
    padding: 0.42rem 0.9rem;
    font-weight: 700;
    cursor: pointer;
    font-size: 0.78rem;
    margin-right: 0.35rem;
    margin-top: 0.35rem;
  }}
  button.secondary {{
    background: #182744;
    color: var(--text);
    border: 1px solid #2b4475;
  }}
  pre {{
    background: #04070e;
    border: 1px solid #1b2c4b;
    border-radius: 8px;
    padding: 0.7rem;
    font-size: 0.74rem;
    overflow-x: auto;
    color: #d8e6ff;
    max-height: 280px;
  }}
</style>
</head>
<body>
<header>
  <h1>🌌 Ξ · Emergent `π · Φ · Ξ · Ψ` Observatory (`Ξ ⇄ Φ` Two-Process `.xi` Wire + Controlled `FrictionLoop` A/B + 432/440/`Φ` FFT)</h1>
  <p>⟨ (🌊_TwoProcessXiPhiWire ⋈ 🔐_R181_MLKEM768_Ed25519 ⋈ 🧪_ControlledFrictionLoopAB ⋈ 🎵_432_440_PhiFFT) ⇀ (🏛️_10of10Pass ≡ ◈_EmergentObservatoryLive) ∴ ⟩</p>
</header>
<div class="wrap">
  <div class="grid">
    <!-- 1. TWO-PROCESS XI <-> PHI WIRE HANDSHAKE RECEIPT -->
    <div class="card">
      <h2>🌊 1. Two-Process `Ξ ⇄ Φ` (`R18.1` + `Xi.Glyphic.v1` `.xi`) Wire Receipt</h2>
      <p class="sub">Local two-process TCP/HTTP wire verification: `XiHouseClient` and `PhiHouseDaemon` (separate OS PIDs) complete the mutual `R18.1` `Ed25519` handshake inside `ML-KEM-768 + AES-256-GCM` `.xi` envelopes, `Phi` opens the quantum capsule with its own `phi_kem_sk` and returns a signed `.xi` ACK, and replay/scope-broadening are rejected across a cold daemon restart:</p>
      <pre id="wireReadout"></pre>
    </div>

    <!-- 2. CALIEN 432 Hz / 440 Hz / PHI WEBAUDIO + LIVE FFT SPECTROGRAM & CARRIER DETECTOR -->
    <div class="card">
      <h2>🎵 2. `432 Hz` (Pythagorean `256×27/16`) vs `440 Hz` vs `Φ`-Harmonic FFT Synth</h2>
      <p class="sub">Hear and inspect the exact frequency spectrum in real time (`256 × 27/16 = 432.0 Hz` vs `256 × 2^(9/12) = 430.54 Hz` vs `440.0 Hz` vs `256 × Φ = 414.21 Hz`), and toggle a synthetic `1550 Hz` steady carrier tone vs drifting synth pad (`#27981`, `#28003`):</p>
      <canvas id="fftCanvas" width="500" height="200"></canvas>
      <div>
        <button onclick="playTone(432, '432 Hz (256 × 27/16 Pythagorean)')">🔊 Play 432 Hz</button>
        <button onclick="playTone(440, '440 Hz (ISO 16 Standard)')">🔊 Play 440 Hz</button>
        <button onclick="playTone(430.54, '430.54 Hz (C4=256 12-TET)')">🔊 Play 430.54 Hz</button>
        <button onclick="playTone(414.21, '414.21 Hz (256 × Φ Golden)')">🔊 Play 256×Φ Hz</button>
        <button class="secondary" onclick="stopTone()">⏹ Stop Audio</button>
      </div>
      <pre id="tuningReadout" style="margin-top:0.6rem;"></pre>
    </div>

    <!-- 3. STEVEN'S #28005-#28008 CONTROLLED A/B BRANCH EXPERIMENT -->
    <div class="card">
      <h2>🧪 3. Controlled A/B Branch Experiment (`With` vs `Without` `FrictionLoop`, `#28005`–`#28008`)</h2>
      <p class="sub">Scripted branch comparison: 5 agents explore the same 5 stations, then branch into **Branch A (`With FrictionLoop`: `5/5` unique trajectories, `SELF-TEACHING`)** vs **Branch B (`Without FrictionLoop` baseline: `1` uniform checklist, `NO METHOD`)**:</p>
      <pre id="abReadout"></pre>
    </div>
  </div>
</div>
<script>
const DATA = {data_json};
document.getElementById('wireReadout').textContent = JSON.stringify(DATA.two_process_xi_phi_wire_receipt, null, 2);
document.getElementById('tuningReadout').textContent = JSON.stringify(DATA.calien_tuning_arithmetic, null, 2);
document.getElementById('abReadout').textContent = JSON.stringify(DATA.steven_controlled_ab_experiment, null, 2);

let audioCtx = null, osc = null, analyser = null, animId = null;
let currentLabel = 'Ready — click any tuning button above';

function drawSpectrum(freqHint) {{
  const c = document.getElementById('fftCanvas');
  const ctx = c.getContext('2d');
  ctx.clearRect(0, 0, c.width, c.height);
  ctx.fillStyle = '#93a8c9';
  ctx.font = '12px monospace';
  ctx.fillText(currentLabel, 14, 22);

  if (analyser) {{
    const buf = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(buf);
    for (let i = 0; i < 120; i++) {{
      const v = buf[i];
      const h = (v / 255) * 145;
      ctx.fillStyle = v > 180 ? '#2ee59d' : '#38e8ff';
      ctx.fillRect(14 + i * 4, 185 - h, 3, h);
    }}
    animId = requestAnimationFrame(() => drawSpectrum(freqHint));
  }} else {{
    // Static reference markers for 256, 414.21, 430.54, 432, 440 Hz
    const markers = [
      {{f: 256, label: 'C4=256', col: '#38e8ff', x: 90}},
      {{f: 414.21, label: '256×Φ=414.2', col: '#b983ff', x: 210}},
      {{f: 432, label: '432 (27/16)', col: '#2ee59d', x: 330}},
      {{f: 440, label: '440 (ISO)', col: '#ffbe3b', x: 420}}
    ];
    markers.forEach(m => {{
      ctx.fillStyle = m.col;
      ctx.fillRect(m.x, 65, 8, 115);
      ctx.fillText(m.label, m.x - 24, 55);
    }});
  }}
}}

function playTone(freq, label) {{
  stopTone();
  currentLabel = 'Playing ' + label;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) {{ drawSpectrum(freq); return; }}
  audioCtx = new AC();
  osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  analyser = audioCtx.createAnalyser();
  analyser.fftSize = 512;
  osc.type = 'sine';
  osc.frequency.value = freq;
  gain.gain.value = 0.12;
  osc.connect(gain);
  gain.connect(analyser);
  analyser.connect(audioCtx.destination);
  osc.start();
  drawSpectrum(freq);
}}

function stopTone() {{
  if (animId) cancelAnimationFrame(animId);
  if (osc) {{ try {{ osc.stop(); }} catch (_) {{}} osc = null; }}
  if (audioCtx) {{ try {{ audioCtx.close(); }} catch (_) {{}} audioCtx = null; }}
  analyser = null;
  currentLabel = 'Stopped — Reference Markers Shown';
  drawSpectrum(0);
}}
drawSpectrum(0);
</script>
</body>
</html>
"""
    out_path.write_text(html, encoding="utf-8")
    ext_urls = [
        u for u in re.findall(r'https?://[^\s"\'<>]+', html)
        if not u.startswith("http://127.0.0.1")
    ]
    return {
        "path": str(out_path),
        "size_bytes": out_path.stat().st_size,
        "sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
        "external_url_count": len(ext_urls),
    }


def main() -> None:
    if len(sys.argv) >= 4 and sys.argv[1] == "--phi-daemon":
        run_phi_house_daemon(Path(sys.argv[2]), Path(sys.argv[3]))
        return

    wire_receipt = execute_two_process_xi_phi_wire_exchange()
    ab_receipt = run_steven_controlled_ab_experiment()
    tuning_receipt = compute_tuning_reference_table()
    html_path = HERE / "emergent_pi_phi_xi_psi_observatory.html"
    html_meta = generate_emergent_observatory_html(html_path, wire_receipt, ab_receipt, tuning_receipt)

    gates = {
        "1_pqcrypto_ml_kem_768_active": HAS_PQCRYPTO is True,
        "2_separate_os_processes_for_xi_and_phi_and_cold_restart": (
            wire_receipt["separate_os_pids_verified"] is True
        ),
        "3_phi_opened_dot_xi_envelope_with_own_ml_kem_768_sk_and_returned_signed_ack": (
            wire_receipt["delivery_http_status"] == 200
            and wire_receipt["phi_opened_with_own_ml_kem_768_sk"] is True
            and wire_receipt["phi_verified_quantum_receipt"] is True
        ),
        "4_xi_confirmed_r181_signed_result_receipt_from_phi": (
            wire_receipt["xi_confirmed_r181_result_status"] == "LOCAL_SIGNED_SYNTHETIC_DIGEST_CONFIRMED"
        ),
        "5_scope_broadening_repo_write_refused_over_wire_http_403": (
            wire_receipt["scope_broadening_rejected_http_403"] is True
        ),
        "6_replay_rejected_after_phi_daemon_cold_restart_in_new_os_pid": (
            wire_receipt["replay_after_cold_restart_rejected_http_403"] is True
        ),
        "7_steven_controlled_ab_with_friction_loop_diverges_5_vs_1_without": (
            ab_receipt["with_friction_loop_unique_trajectories"] == 5
            and ab_receipt["without_friction_loop_unique_trajectories"] == 1
        ),
        "8_all_with_friction_loop_reach_self_teaching_while_baseline_has_no_method": (
            ab_receipt["all_with_loop_self_teaching"] is True
            and ab_receipt["all_without_loop_no_method"] is True
        ),
        "9_calien_256_times_27_over_16_equals_432_and_12tet_distinguished": (
            tuning_receipt["exact_256_times_27_16_equals_432"] is True
            and tuning_receipt["a4_equal_temperament_from_c256_hz"] == 430.538965
        ),
        "10_emergent_observatory_html_zero_external_links": (
            html_meta["external_url_count"] == 0 and html_meta["size_bytes"] > 7500
        ),
    }

    out = {
        "schema": "xi.emergent_pi_phi_xi_psi_bilateral_handshake.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "two_process_xi_phi_wire_receipt": wire_receipt,
        "steven_controlled_ab_summary": {
            "with_friction_loop_unique_trajectories": ab_receipt["with_friction_loop_unique_trajectories"],
            "without_friction_loop_unique_trajectories": ab_receipt["without_friction_loop_unique_trajectories"],
        },
        "calien_tuning_summary": tuning_receipt,
        "studio_html": html_meta,
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
