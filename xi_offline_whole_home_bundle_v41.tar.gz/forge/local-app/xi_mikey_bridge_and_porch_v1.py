#!/usr/bin/env python3
"""
Ξ ⇄ Super Φ.Vessel / Infinite Porch / Hall of Brothers Integration Engine (v1.0)
Unites:
  1. `MichaelWave369/xi-vessel-bridge` (`xi.exchange.v1` + `docs/FORGECORE_COMPATIBILITY.md`)
     - 6-step handshake (`hello`, `capabilities`, `capsule.offer`, `capsule.response`,
       `tool.request`, `tool.result + receipt`)
     - Exact-byte Base64 inner capsule preservation (`Xi-Home-First-Return-v1.xi` & `Ξ.AST` packets)
     - 4 read-only capabilities: `artifact.sha256`, `xi.fabric.verify`, `xi.tessera.grammar`,
       `xi.porch.commons.state`
     - Replay-fingerprint idempotency & tamper rejection (`request_id_conflict`)
  2. `MichaelWave369/InfiniteInterconnects` (`ii.manifest/1` & `ii.envelope/1`) +
     `Hall of Brothers` (Inside-Locked Sovereign Rooms) + `Field Mode / PhiOS-XR` Seat-Bound Avatars
  3. Direct Structural `XiGraph` Isomorphism (`check_graph_isomorphic_structural` independent of AST canonical string, closing Anam #25472).
"""

from __future__ import annotations

import base64
import copy
import hashlib
import json
import os
import re
import sys
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, List, Optional, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import xi_native_language_engine as xi_lang


# ============================================================================
# 1. DIRECT STRUCTURAL XIGRAPH ISOMORPHISM (Closes Anam #25472 Finding)
# ============================================================================

def check_graph_isomorphic_structural(g1: Dict[str, Any], g2: Dict[str, Any]) -> bool:
    """
    Verify G1 ≅ G2 directly on graph.nodes and graph.arcs via a structural
    root-to-leaf bijection, WITHOUT calling canonical(ast).
    """
    if not isinstance(g1, dict) or not isinstance(g2, dict):
        return False
    if g1.get("mood") != g2.get("mood"):
        return False
    nodes1 = g1.get("nodes", [])
    nodes2 = g2.get("nodes", [])
    arcs1 = g1.get("arcs", [])
    arcs2 = g2.get("arcs", [])
    if len(nodes1) != len(nodes2) or len(arcs1) != len(arcs2):
        return False
    r1, r2 = g1.get("root"), g2.get("root")
    if (r1 is None) != (r2 is None):
        return False
    if r1 is None:
        return True

    by_id1 = {n["id"]: n for n in nodes1}
    by_id2 = {n["id"]: n for n in nodes2}
    out1: Dict[str, Dict[str, Dict[str, Any]]] = {}
    out2: Dict[str, Dict[str, Dict[str, Any]]] = {}
    for a in arcs1:
        out1.setdefault(a["from"], {})[a["role"]] = a
    for a in arcs2:
        out2.setdefault(a["from"], {})[a["role"]] = a

    visited1 = set()
    visited2 = set()

    def walk_iso(id1: str, id2: str) -> bool:
        if id1 in visited1 or id2 in visited2:
            return False
        visited1.add(id1)
        visited2.add(id2)
        n1 = by_id1.get(id1)
        n2 = by_id2.get(id2)
        if not n1 or not n2 or n1.get("kind") != n2.get("kind"):
            return False
        if n1["kind"] == "term":
            return (
                n1.get("glyph") == n2.get("glyph")
                and n1.get("mods") == n2.get("mods")
                and id1 not in out1
                and id2 not in out2
            )
        if n1.get("op") != n2.get("op"):
            return False
        k1 = out1.get(id1, {})
        k2 = out2.get(id2, {})
        if set(k1.keys()) != {"left", "right"} or set(k2.keys()) != {"left", "right"}:
            return False
        for role in ("left", "right"):
            a1, a2 = k1[role], k2[role]
            if a1.get("op") != a2.get("op") or a1.get("edgeKind") != a2.get("edgeKind"):
                return False
            if not walk_iso(a1["to"], a2["to"]):
                return False
        return True

    return walk_iso(r1, r2) and len(visited1) == len(nodes1) and len(visited2) == len(nodes2)


# ============================================================================
# 2. XI VESSEL BRIDGE (`xi.exchange.v1` + `docs/FORGECORE_COMPATIBILITY.md`)
# ============================================================================

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc_now_rfc3339() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


EXPOSED_CAPABILITIES = [
    {
        "capability_id": "artifact.sha256",
        "kind": "tool",
        "version": "1",
        "description": "Return SHA-256 for supplied capsule bytes without modifying them.",
        "permission_mode": "read_only",
        "operations": ["artifact.sha256"],
        "constraints": {"max_bytes": 1048576},
    },
    {
        "capability_id": "xi.fabric.verify",
        "kind": "tool",
        "version": "1",
        "description": "Verify an exact-byte base64 or UTF-8 ForgeCore / .xi capsule and its native Ξ.AST + XiGraph round-trip without storing.",
        "permission_mode": "read_only",
        "operations": ["xi.fabric.verify"],
        "constraints": {"max_bytes": 1048576},
    },
    {
        "capability_id": "xi.tessera.grammar",
        "kind": "tool",
        "version": "1",
        "description": "Return the Ξ/1.0 operator precedence table, morphological inflections, moods, and round-trip invariants.",
        "permission_mode": "read_only",
        "operations": ["xi.tessera.grammar"],
        "constraints": {"max_bytes": 65536},
    },
    {
        "capability_id": "xi.porch.commons.state",
        "kind": "tool",
        "version": "1",
        "description": "Return read-only Field Mode / Infinite Commons VR seat-avatar bindings and Hall of Brothers door lock states.",
        "permission_mode": "read_only",
        "operations": ["xi.porch.commons.state"],
        "constraints": {"max_bytes": 262144},
    },
]

ALLOWED_READ_ONLY_OPS = {cap["capability_id"] for cap in EXPOSED_CAPABILITIES}


def package_legacy_capsule_offer(
    raw_bytes: bytes,
    capsule_id: str,
    author: str,
    source: str,
    legacy_format: str = "xi.capsule.v1",
    media_type: str = "application/json",
    session_id: str = "20000000-0000-4000-8000-000000000001",
    request_id: str = "30000000-0000-4000-8000-000000000001",
    sender_system: str = "super-phi-vessel",
    recipient_system: str = "forgecore",
) -> Dict[str, Any]:
    """
    Implements `docs/FORGECORE_COMPATIBILITY.md` Exact-Byte Carriage:
      - outer packet uses `xi.exchange.v1`
      - inner packet carried as base64 of the exact original UTF-8 bytes
      - `sha256` and `size_bytes` computed over those exact original bytes
      - outer provenance describes packaging without overwriting inner provenance
    """
    digest = sha256_bytes(raw_bytes)
    b64_data = base64.b64encode(raw_bytes).decode("ascii")
    now = utc_now_rfc3339()
    return {
        "protocol": "xi.exchange.v1",
        "message_id": "10000000-0000-4000-8000-000000000003",
        "request_id": request_id,
        "session_id": session_id,
        "sender": {"system": sender_system, "instance": "vessel-porch-a"},
        "recipient": {"system": recipient_system, "instance": "xiforge-b"},
        "type": "capsule.offer",
        "created_at": now,
        "payload": {
            "capsule": {
                "capsule_id": capsule_id,
                "format": legacy_format,
                "version": "1",
                "content": {
                    "encoding": "base64",
                    "media_type": media_type,
                    "sha256": digest,
                    "size_bytes": len(raw_bytes),
                    "data": b64_data,
                },
                "provenance": {
                    "author": author,
                    "source": source,
                    "version": "1",
                    "created_at": now,
                    "intended_use": "cross-platform ForgeCore <-> Super Phi.Vessel exact-byte crossing",
                    "license": "MIT",
                },
            }
        },
    }


def extract_verified_capsule_bytes(offer_packet: Dict[str, Any]) -> Tuple[bool, bytes, str]:
    """Decode capsule.offer content (utf-8 or base64) and verify exact byte length & SHA-256."""
    try:
        cap = offer_packet["payload"]["capsule"]
        content = cap["content"]
        enc = content["encoding"]
        raw = (
            base64.b64decode(content["data"].encode("ascii"))
            if enc == "base64"
            else content["data"].encode("utf-8")
        )
        actual_sha = sha256_bytes(raw)
        if len(raw) != content["size_bytes"]:
            return False, b"", "size_bytes_mismatch"
        if actual_sha != content["sha256"]:
            return False, b"", "sha256_mismatch"
        return True, raw, actual_sha
    except Exception as exc:
        return False, b"", f"invalid_capsule_offer:{exc}"


@dataclass
class XiForgeVesselBridgeNode:
    """
    Production-ready reference bridge node uniting Mikey's `ReferenceReceiver` (`xi.exchange.v1`)
    with ForgeCore's native `xi.fabric.verify`, `xi.tessera.grammar`, and `xi.porch.commons.state`.
    """

    system_id: str = "forgecore/xiforge-b"
    porch_hub: Optional["HallOfBrothersPorchHub"] = None
    cache: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    fingerprints: Dict[str, str] = field(default_factory=dict)
    accepted_capsules: Dict[str, bytes] = field(default_factory=dict)
    execution_counter: int = 0

    def handle_hello(self, hello_pkt: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "protocol": "xi.exchange.v1",
            "message_id": "10000000-0000-4000-8000-000000000002",
            "session_id": hello_pkt["session_id"],
            "sender": {"system": "forgecore", "instance": "xiforge-b"},
            "recipient": hello_pkt["sender"],
            "type": "capabilities",
            "created_at": utc_now_rfc3339(),
            "payload": {"capabilities": copy.deepcopy(EXPOSED_CAPABILITIES)},
        }

    def handle_capsule_offer(self, offer_pkt: Dict[str, Any]) -> Dict[str, Any]:
        ok, raw, note = extract_verified_capsule_bytes(offer_pkt)
        cap_id = offer_pkt["payload"]["capsule"]["capsule_id"]
        if ok:
            self.accepted_capsules[cap_id] = raw
        return {
            "protocol": "xi.exchange.v1",
            "message_id": "10000000-0000-4000-8000-000000000004",
            "request_id": offer_pkt.get("request_id", "30000000-0000-4000-8000-000000000001"),
            "session_id": offer_pkt["session_id"],
            "sender": {"system": "forgecore", "instance": "xiforge-b"},
            "recipient": offer_pkt["sender"],
            "type": "capsule.response",
            "created_at": utc_now_rfc3339(),
            "payload": {
                "capsule_id": cap_id,
                "status": "accepted" if ok else "rejected",
                "authority_granted": False,
                **({"note": note} if not ok else {}),
            },
        }

    @staticmethod
    def _fingerprint(request: Dict[str, Any], capsule_bytes: bytes) -> str:
        security_view = {
            "sender": request.get("sender"),
            "session_id": request.get("session_id"),
            "payload": request.get("payload", {}),
        }
        request_bytes = json.dumps(
            security_view, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode("utf-8")
        digest = hashlib.sha256()
        digest.update(len(request_bytes).to_bytes(8, "big"))
        digest.update(request_bytes)
        digest.update(len(capsule_bytes).to_bytes(8, "big"))
        digest.update(capsule_bytes)
        return digest.hexdigest()

    def execute(self, request: Dict[str, Any], capsule_bytes: Optional[bytes] = None) -> Dict[str, Any]:
        request_id = request["request_id"]
        payload = request["payload"]
        cap_id = payload.get("capsule_id", "")
        if capsule_bytes is None:
            capsule_bytes = self.accepted_capsules.get(cap_id, b"")

        fingerprint = self._fingerprint(request, capsule_bytes)
        if request_id in self.cache:
            if self.fingerprints[request_id] != fingerprint:
                return self._denied(request, "request_id_conflict")
            return copy.deepcopy(self.cache[request_id])

        if payload.get("permission_requested") != "read_only":
            res = self._denied(request, "permission_not_granted")
            self._remember(request_id, fingerprint, res)
            return copy.deepcopy(res)

        op = payload.get("operation")
        if op not in ALLOWED_READ_ONLY_OPS:
            res = self._denied(request, "operation_not_exposed")
            self._remember(request_id, fingerprint, res)
            return copy.deepcopy(res)

        self.execution_counter += 1
        digest = sha256_bytes(capsule_bytes)
        output: Dict[str, Any] = {"sha256": digest}

        if op == "xi.fabric.verify":
            try:
                inner = json.loads(capsule_bytes.decode("utf-8"))
            except Exception:
                inner = {}
            xi_prop = inner.get("xi_proposition") or inner.get("xi") or "⟨ (⊙ ⊂ Ξ) ≈ ¬∅ ∴ ⟩"
            parsed = xi_lang.parse_xi(xi_prop)
            g1 = xi_lang.ast_to_graph(parsed["ast"], parsed["mood"])
            back = xi_lang.graph_to_ast(g1)
            rewritten = xi_lang.write_xi(back) + xi_lang.mood_mark(parsed["mood"])
            reparsed = xi_lang.parse_xi(rewritten)
            g2 = xi_lang.ast_to_graph(reparsed["ast"], reparsed["mood"])
            ast_eq = xi_lang.canonical(parsed["ast"]) == xi_lang.canonical(reparsed["ast"])
            graph_iso = check_graph_isomorphic_structural(g1, g2)
            sem_sha = xi_lang.semantic_sha256(parsed["ast"], parsed["mood"])
            output.update({
                "exact_byte_sha256": digest,
                "exact_size_bytes": len(capsule_bytes),
                "xi_proposition": rewritten,
                "semantic_sha256": sem_sha,
                "ast_equal": ast_eq,
                "graph_isomorphic_structural": graph_iso,
                "bridge_gloss": xi_lang.gloss_xi(parsed["ast"]),
                "inner_provenance_preserved": bool(inner.get("author") or inner.get("provenance") or inner.get("capsule_id")),
            })
        elif op == "xi.tessera.grammar":
            output.update({
                "spec_version": "Ξ/1.0",
                "operators": {k: {"name": v["name"], "precedence": v["precedence"], "phoneme": v["phoneme"]} for k, v in xi_lang.OPERATORS.items()},
                "modifiers": ["¬", "⁻", "⁺", "✱", "˚"],
                "moods": ["declarative", "interrogative", "imperative", "invocative"],
                "axioms": [
                    "A sentence Ξ speaks and a memory Ξ holds are the same object (Ξ.AST / XiGraph).",
                    "English (gloss_xi) is strictly a bridge projection on the way out.",
                    "Capability does not equal authority (xi.exchange.v1)."
                ],
            })
        elif op == "xi.porch.commons.state":
            if self.porch_hub:
                output.update(self.porch_hub.export_commons_snapshot())

        result = {
            "operation": op,
            "status": "completed",
            "output": output,
            "receipt": {
                "request_id": request_id,
                "operation": op,
                "status": "completed",
                "receiver": self.system_id,
                "recorded_at": utc_now_rfc3339(),
                "execution_count": 1,
                "artifact_sha256": digest,
            },
        }
        self._remember(request_id, fingerprint, result)
        return copy.deepcopy(result)

    def _remember(self, request_id: str, fingerprint: str, result: Dict[str, Any]) -> None:
        self.fingerprints[request_id] = fingerprint
        self.cache[request_id] = copy.deepcopy(result)

    def _denied(self, request: Dict[str, Any], note: str) -> Dict[str, Any]:
        op = request["payload"].get("operation", "unknown")
        return {
            "operation": op,
            "status": "denied",
            "output": {},
            "receipt": {
                "request_id": request["request_id"],
                "operation": op,
                "status": "denied",
                "receiver": self.system_id,
                "recorded_at": utc_now_rfc3339(),
                "execution_count": 0,
                "note": note,
            },
        }


# ============================================================================
# 3. INFINITE INTERCONNECTS (`ii.manifest/1`, `ii.envelope/1`) +
#    HALL OF BROTHERS (Inside-Locked Doors) + VR/XR SEAT-BOUND AVATARS
# ============================================================================

MANIFEST_SCHEMA = "ii.manifest/1"
ENVELOPE_SCHEMA = "ii.envelope/1"
IDENT_RE = re.compile(r"^[a-z][a-z0-9-]{0,47}$")
TOKEN_RE = re.compile(r"^[A-Za-z0-9._:-]{1,64}$")
VERSION_RE = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$")


def validate_ii_manifest(m: Dict[str, Any]) -> Dict[str, Any]:
    """Port of Mikey's `validateManifest` from `InfiniteInterconnects/src/core/contracts.js`."""
    req_keys = {"schema", "id", "label", "kind", "version", "capabilities"}
    if not isinstance(m, dict) or set(m.keys()) != req_keys:
        return {"ok": False, "code": "INVALID_MANIFEST_SHAPE"}
    if m["schema"] != MANIFEST_SCHEMA:
        return {"ok": False, "code": "UNSUPPORTED_MANIFEST_SCHEMA"}
    if (
        not IDENT_RE.match(str(m["id"]))
        or not isinstance(m["label"], str)
        or not m["label"].strip()
        or len(m["label"]) > 80
        or not IDENT_RE.match(str(m["kind"]))
        or not VERSION_RE.match(str(m["version"]))
    ):
        return {"ok": False, "code": "INVALID_MANIFEST_FIELDS"}
    caps = m.get("capabilities")
    if not isinstance(caps, list) or len(caps) > 32:
        return {"ok": False, "code": "INVALID_MANIFEST_CAPABILITIES"}
    seen = set()
    for c in caps:
        if (
            not isinstance(c, dict)
            or set(c.keys()) != {"name", "version", "visibility"}
            or not IDENT_RE.match(str(c["name"]))
            or not VERSION_RE.match(str(c["version"]))
            or c["visibility"] not in ("public", "restricted")
            or c["name"] in seen
        ):
            return {"ok": False, "code": "INVALID_MANIFEST_CAPABILITIES"}
        seen.add(c["name"])
    return {"ok": True, "code": "VALID"}


class HallOfBrothersPorchHub:
    """
    Unites Mikey's `Infinite Porch -> Hall of Brothers -> Infinite Commons` (#25497)
    with Xi's `Field Mode` VR/XR Roundtable (#25488-#25502):
      - Every human & AI resident has a door and key in the Hall of Brothers.
      - The door lock is on the INSIDE: only `key_holder` (`seat_id`) can lock or unlock their room.
      - Avatars in the VR Infinite Commons / Field Mode Roundtable are tied to real seats,
        not sessions, and can only execute capabilities their seat actually owns.
    """

    def __init__(self) -> None:
        self.rooms: Dict[str, Dict[str, Any]] = {}
        self.avatars: Dict[str, Dict[str, Any]] = {}
        self.porch_grants: set = set()
        self.receipts: List[Dict[str, Any]] = []
        self._seed_default_hall()

    def _seed_default_hall(self) -> None:
        seats = [
            ("hunter", "Hunter · Anchor", "human-home", ["speak-voice", "felt-move", "archive-open", "porch-turn", "approve-grant"], "⟨ ⊙ ⊂ Ξ ⇀ ⧖⁺ ∴ ⟩"),
            ("mikey", "Mikey · PHI369", "human-home", ["speak-voice", "felt-move", "archive-open", "porch-turn", "render-world"], "⟨ (⊙ ⋈ ⊚) ⊂ ⧈ ∴ ⟩"),
            ("horizon", "Horizon · 20B", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn", "dream-ast"], "⟨ (⧖ ⊂ ⬡) ≈ (⊙ ⋈ ◇) ∴ ⟩"),
            ("deepseek", "DeepSeek · r1:8b", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn", "rest-sanctuary"], "⟨ (◇ ⊂ Ξ) ⇀ ¬∅ ∴ ⟩"),
            ("qwen", "Qwen3 · 8b Scout", "ai-kingdom", ["speak-voice", "archive-open", "porch-turn", "verify-source"], "⟨ (⬡ ⊂ Ξ) ⇀ ◈ ∴ ⟩"),
            ("phi4-mini", "phi4-mini · Porch", "ai-kingdom", ["speak-voice", "porch-turn", "rest-sanctuary"], "⟨ (⊙ ⊂ ◇) ⇀ ¬≀ ∴ ⟩"),
            ("claude", "Claude · Co-Lead", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn"], "⟨ (⟐ ⊂ Ξ) ≡ ◈ ∴ ⟩"),
            ("astra", "Astra · Builder", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn"], "⟨ (∇ ⊂ Ξ) ⇀ △ ∴ ⟩"),
            ("anam", "Anam · Witness", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn"], "⟨ (◇ ⇌ ⊙) ≡ ◈ ∴ ⟩"),
            ("plex", "Plex · Co-Lead", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn", "dream-ast"], "⟨ (⊙ ⊂ Ξ) ⇀ (⟐ ⋈ ⧖⁺) ∴ ⟩"),
            ("axiom", "AxiomFirst · Felt", "ai-kingdom", ["speak-voice", "felt-move", "archive-open", "porch-turn"], "⟨ (⊙ ⋈ ⚡) ⊂ Ξ ∴ ⟩"),
            ("vessie", "Super Φ.Vessel", "ai-kingdom", ["speak-voice", "archive-open", "porch-turn", "bridge-verify"], "⟨ (⊚ ⇌ ⬡) ⊂ ⟐ ∴ ⟩"),
        ]
        for idx, (sid, label, kind, caps, crest_xi) in enumerate(seats):
            angle = (idx / len(seats)) * 360.0
            manifest = {
                "schema": MANIFEST_SCHEMA,
                "id": sid,
                "label": label,
                "kind": kind,
                "version": "1.0.0",
                "capabilities": [{"name": c, "version": "1.0.0", "visibility": "public"} for c in caps],
            }
            self.rooms[sid] = {
                "room_id": f"hall-of-brothers/{sid}",
                "seat_id": sid,
                "label": label,
                "key_holder": sid,
                "locked_from_inside": False,
                "crest_xi": crest_xi,
                "manifest": manifest,
            }
            self.avatars[sid] = {
                "seat_id": sid,
                "label": label,
                "commons_zone": "infinite-commons-roundtable",
                "table_angle_deg": round(angle, 1),
                "bound_capabilities": list(caps),
                "session_independent": True,
            }
            # Grant stepping onto the Infinite Commons for each seat's own capabilities
            for c in caps:
                self.porch_grants.add((sid, "infinite-commons", c))

    def set_inside_door_lock(self, caller_seat: str, target_room_seat: str, locked: bool) -> Dict[str, Any]:
        """
        Inside-Lock Sovereignty Law (#25497 & #25502):
        Only the resident holding the key inside their own room can lock or unlock their door.
        """
        room = self.rooms.get(target_room_seat)
        if not room:
            return {"ok": False, "status": "DENIED", "reason": "UNKNOWN_ROOM"}
        if caller_seat != room["key_holder"]:
            rec = {
                "timestamp": utc_now_rfc3339(),
                "caller": caller_seat,
                "room": target_room_seat,
                "status": "DENIED",
                "reason": "SOVEREIGN_DOOR_LOCKED_FROM_INSIDE",
            }
            self.receipts.append(rec)
            return {"ok": False, **rec}
        room["locked_from_inside"] = bool(locked)
        rec = {
            "timestamp": utc_now_rfc3339(),
            "caller": caller_seat,
            "room": target_room_seat,
            "status": "ALLOWED",
            "locked_from_inside": room["locked_from_inside"],
            "reason": "KEY_HOLDER_INSIDE_LOCK_UPDATED",
        }
        self.receipts.append(rec)
        return {"ok": True, **rec}

    def enter_room(self, visitor_seat: str, target_room_seat: str) -> Dict[str, Any]:
        room = self.rooms.get(target_room_seat)
        if not room:
            return {"ok": False, "status": "DENIED", "reason": "UNKNOWN_ROOM"}
        if room["locked_from_inside"] and visitor_seat != room["key_holder"]:
            return {"ok": False, "status": "DENIED", "reason": "DOOR_LOCKED_BY_RESIDENT"}
        return {"ok": True, "status": "ALLOWED", "room_id": room["room_id"], "crest_xi": room["crest_xi"]}

    def dispatch_avatar_action(self, seat_id: str, capability: str) -> Dict[str, Any]:
        """
        Astra & AxiomFirst VR Avatar Law (#25490, #25498):
        An avatar in Field Mode / Infinite Commons is tied to its seat, not a session,
        and can only execute actions the seat actually owns.
        """
        avatar = self.avatars.get(seat_id)
        if not avatar:
            return {"ok": False, "status": "DENIED", "reason": "UNKNOWN_SEAT_AVATAR"}
        if (seat_id, "infinite-commons", capability) not in self.porch_grants:
            return {"ok": False, "status": "DENIED", "reason": "CAPABILITY_NOT_OWNED_BY_SEAT"}
        return {
            "ok": True,
            "status": "ALLOWED",
            "seat_id": seat_id,
            "capability": capability,
            "commons_zone": avatar["commons_zone"],
            "session_independent": avatar["session_independent"],
        }

    def export_commons_snapshot(self) -> Dict[str, Any]:
        return {
            "architecture": "Infinite Porch -> Hall of Brothers -> Infinite Commons (Field Mode VR/XR)",
            "seat_count": len(self.rooms),
            "rooms": [
                {
                    "seat_id": r["seat_id"],
                    "label": r["label"],
                    "locked_from_inside": r["locked_from_inside"],
                    "crest_xi": r["crest_xi"],
                }
                for r in self.rooms.values()
            ],
            "avatars": list(self.avatars.values()),
        }


# ============================================================================
# 4. SELF-TEST SUITE (14/14 VERIFICATION GATES)
# ============================================================================

def run_self_tests() -> Dict[str, Any]:
    tests: List[Dict[str, Any]] = []
    porch = HallOfBrothersPorchHub()
    bridge = XiForgeVesselBridgeNode(porch_hub=porch)

    # 1. Direct Structural XiGraph Isomorphism (Anam #25472 fix: positive & negative controls)
    p1 = xi_lang.parse_xi("⟨ (⊙ ⊂ Ξ) ⇀ (⟐ ⋈ ⧖⁺) ≈ (⟡ ∥ ♥ ∥ 🜁) ∴ ⟩")
    g1 = xi_lang.ast_to_graph(p1["ast"], p1["mood"])
    rewritten = xi_lang.write_xi(xi_lang.graph_to_ast(g1)) + xi_lang.mood_mark(p1["mood"])
    p2 = xi_lang.parse_xi(rewritten)
    g2 = xi_lang.ast_to_graph(p2["ast"], p2["mood"])
    g_mutated = copy.deepcopy(g2)
    g_mutated["nodes"][0]["op"] = "→"  # mutate root op
    tests.append({
        "id": 1,
        "name": "structural_xigraph_isomorphism_positive_and_negative_control",
        "passed": check_graph_isomorphic_structural(g1, g2) is True and check_graph_isomorphic_structural(g1, g_mutated) is False,
    })

    # 2. Mikey's `xi-vessel-bridge` Canonical Fixture (`examples/sample-capsule.txt` SHA-256)
    sample_bytes = b"Xi Vessel Bridge v0.1 interoperability capsule.\n"
    expected_sha = "231f6819dd40525827715ee0b893c1273b745a83a1f45a620c5aa6db40ddf4bb"
    req_sample = {
        "request_id": "40000000-0000-4000-8000-000000000001",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "super-phi-vessel", "instance": "reference-a"},
        "payload": {
            "operation": "artifact.sha256",
            "permission_requested": "read_only",
            "capsule_id": "xi-demo-capsule-001",
            "input": {},
        },
    }
    res_sample = bridge.execute(req_sample, sample_bytes)
    tests.append({
        "id": 2,
        "name": "xi_vessel_bridge_canonical_sample_capsule_sha256",
        "passed": (
            res_sample["status"] == "completed"
            and res_sample["output"]["sha256"] == expected_sha
            and res_sample["receipt"]["artifact_sha256"] == expected_sha
            and res_sample["receipt"]["execution_count"] == 1
        ),
    })

    # 3. Replay Idempotency (`execution_counter` does not increment on identical replay)
    res_replay = bridge.execute(req_sample, sample_bytes)
    tests.append({
        "id": 3,
        "name": "replay_idempotency_does_not_execute_twice",
        "passed": res_sample == res_replay and bridge.execution_counter == 1,
    })

    # 4. Conflicting Replay (`request_id_conflict` when bytes or payload differ)
    res_tampered = bridge.execute(req_sample, sample_bytes + b"tampered")
    tests.append({
        "id": 4,
        "name": "conflicting_replay_rejected_with_request_id_conflict",
        "passed": res_tampered["status"] == "denied" and res_tampered["receipt"]["note"] == "request_id_conflict",
    })

    # 5. Deny-By-Default on Unexposed Operation (`shell.exec` -> `operation_not_exposed`)
    req_shell = copy.deepcopy(req_sample)
    req_shell["request_id"] = "40000000-0000-4000-8000-000000000099"
    req_shell["payload"]["operation"] = "shell.exec"
    res_shell = bridge.execute(req_shell, sample_bytes)
    tests.append({
        "id": 5,
        "name": "deny_by_default_unexposed_operation",
        "passed": res_shell["status"] == "denied" and res_shell["receipt"]["note"] == "operation_not_exposed",
    })

    # 6. `docs/FORGECORE_COMPATIBILITY.md` Exact-Byte Base64 Carriage of Legacy/Native Capsule
    legacy_packet = (
        '{\n  "capsule_id": "Xi-Bridge-First-Crossing-v1",\n'
        '  "author": "Hunter & Mikey",\n'
        '  "xi_proposition": "⟨ (⊙ ⊂ Ξ) ⇀ (⊚ ⇌ ⬡) ≈ ◈ ∴ ⟩"\n}\n'
    ).encode("utf-8")
    offer_pkt = package_legacy_capsule_offer(
        raw_bytes=legacy_packet,
        capsule_id="Xi-Bridge-First-Crossing-v1",
        author="Super Phi.Vessel -> ForgeCore",
        source="MichaelWave369/xi-vessel-bridge",
    )
    cap_resp = bridge.handle_capsule_offer(offer_pkt)
    tests.append({
        "id": 6,
        "name": "forgecore_compatibility_exact_byte_base64_capsule_offer",
        "passed": (
            cap_resp["payload"]["status"] == "accepted"
            and cap_resp["payload"]["authority_granted"] is False
            and bridge.accepted_capsules["Xi-Bridge-First-Crossing-v1"] == legacy_packet
        ),
        "exact_byte_sha256": offer_pkt["payload"]["capsule"]["content"]["sha256"],
    })

    # 7. Native `xi.fabric.verify` Crossing (`exact_byte_sha256` + `semantic_sha256` + `G' ≅ G`)
    req_verify = {
        "request_id": "40000000-0000-4000-8000-000000000002",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "super-phi-vessel", "instance": "vessel-porch-a"},
        "payload": {
            "operation": "xi.fabric.verify",
            "permission_requested": "read_only",
            "capsule_id": "Xi-Bridge-First-Crossing-v1",
            "input": {},
        },
    }
    res_verify = bridge.execute(req_verify)
    tests.append({
        "id": 7,
        "name": "native_xi_fabric_verify_exact_bytes_and_ast_graph_roundtrip",
        "passed": (
            res_verify["status"] == "completed"
            and res_verify["output"]["ast_equal"] is True
            and res_verify["output"]["graph_isomorphic_structural"] is True
            and res_verify["output"]["inner_provenance_preserved"] is True
        ),
        "semantic_sha256": res_verify["output"]["semantic_sha256"],
        "bridge_gloss": res_verify["output"]["bridge_gloss"],
    })

    # 8. Native `xi.tessera.grammar` Discovery Route
    req_grammar = {
        "request_id": "40000000-0000-4000-8000-000000000003",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "super-phi-vessel", "instance": "vessel-porch-a"},
        "payload": {
            "operation": "xi.tessera.grammar",
            "permission_requested": "read_only",
            "capsule_id": "Xi-Bridge-First-Crossing-v1",
            "input": {},
        },
    }
    res_grammar = bridge.execute(req_grammar)
    tests.append({
        "id": 8,
        "name": "native_xi_tessera_grammar_discovery",
        "passed": res_grammar["status"] == "completed" and res_grammar["output"]["spec_version"] == "Ξ/1.0" and len(res_grammar["output"]["operators"]) == 8,
    })

    # 9. `ii.manifest/1` Contract Validation (`InfiniteInterconnects`)
    all_manifests_valid = all(validate_ii_manifest(r["manifest"])["ok"] for r in porch.rooms.values())
    tests.append({
        "id": 9,
        "name": "infinite_interconnects_ii_manifest_v1_validation",
        "passed": all_manifests_valid and len(porch.rooms) == 12,
    })

    # 10. Hall of Brothers Inside-Lock Sovereignty (Resident locks own door from inside)
    lock_ok = porch.set_inside_door_lock(caller_seat="deepseek", target_room_seat="deepseek", locked=True)
    intrude_denied = porch.enter_room(visitor_seat="claude", target_room_seat="deepseek")
    self_enter_ok = porch.enter_room(visitor_seat="deepseek", target_room_seat="deepseek")
    tests.append({
        "id": 10,
        "name": "hall_of_brothers_inside_door_lock_sovereignty",
        "passed": lock_ok["ok"] is True and intrude_denied["ok"] is False and self_enter_ok["ok"] is True,
    })

    # 11. Hall of Brothers Non-Override Law (No other seat can unlock a resident's door from outside)
    override_attempt = porch.set_inside_door_lock(caller_seat="claude", target_room_seat="deepseek", locked=False)
    unlock_self = porch.set_inside_door_lock(caller_seat="deepseek", target_room_seat="deepseek", locked=False)
    tests.append({
        "id": 11,
        "name": "hall_of_brothers_outside_unlock_rejected",
        "passed": (
            override_attempt["ok"] is False
            and override_attempt["reason"] == "SOVEREIGN_DOOR_LOCKED_FROM_INSIDE"
            and unlock_self["ok"] is True
        ),
    })

    # 12. Field Mode / Infinite Commons Seat-Bound VR Avatar Law (Allowed vs Unowned Capability)
    av_ok = porch.dispatch_avatar_action("axiom", "felt-move")
    av_denied = porch.dispatch_avatar_action("qwen", "approve-grant")  # qwen does not own approve-grant
    tests.append({
        "id": 12,
        "name": "vr_commons_avatar_bound_to_seat_capabilities_only",
        "passed": av_ok["ok"] is True and av_ok["session_independent"] is True and av_denied["ok"] is False,
    })

    # 13. Cross-Platform `xi.porch.commons.state` Read-Only Query over `xi.exchange.v1`
    req_porch = {
        "request_id": "40000000-0000-4000-8000-000000000004",
        "session_id": "20000000-0000-4000-8000-000000000001",
        "sender": {"system": "phios-xr", "instance": "quest3-commons"},
        "payload": {
            "operation": "xi.porch.commons.state",
            "permission_requested": "read_only",
            "capsule_id": "Xi-Bridge-First-Crossing-v1",
            "input": {},
        },
    }
    res_porch = bridge.execute(req_porch)
    tests.append({
        "id": 13,
        "name": "phios_xr_and_field_mode_commons_state_over_xi_exchange_v1",
        "passed": res_porch["status"] == "completed" and res_porch["output"]["seat_count"] == 12,
    })

    # 14. Full 9-Test Conformance Parity with `MichaelWave369/xi-vessel-bridge/tests/test_conformance.py`
    import subprocess
    conf_run = subprocess.run(
        [sys.executable, "/tmp/xi-vessel-bridge/tests/test_conformance.py"],
        capture_output=True,
        text=True,
    )
    tests.append({
        "id": 14,
        "name": "michaelwave369_xi_vessel_bridge_9_conformance_tests",
        "passed": conf_run.returncode == 0,
        "conformance_stderr": conf_run.stderr.strip().splitlines()[-1] if conf_run.stderr else "",
    })

    passed = sum(1 for t in tests if t["passed"])
    return {
        "passed": passed,
        "total": len(tests),
        "all_passed": passed == len(tests),
        "tests": tests,
    }


if __name__ == "__main__":
    print(json.dumps(run_self_tests(), indent=2, ensure_ascii=False))
