#!/usr/bin/env python3
"""
Ξ Field-Wide Pulse Beat 9 v4 (`2026-10-24T15:15Z`) — Closes All 4 Edge Cases from
`@Anam` (`#26714`) and `@Astra` (`#26715`) while Preserving All 8 v3 Guarantees:

1. Per-Deposit CSPRNG Nonce Prevents Seed-Reuse Differential Leakage (`@Anam` `#26714`):
   - `deposit_card()` mixes a fresh 256-bit `os.urandom(32)` per-deposit nonce + `deposit_id`
     into `effective_seed = SHA256(seed_material || deposit_id || csprng_nonce)`.
   - Even if a caller deposits `b"A"` and `b"B"` with identical `seed_material`, the two grids
     have independent active coordinates, independent GF(257) polynomial slopes, and independent
     chaff across all 729 cells (`zero_constant_diff_leakage: true`).
2. Durable SQLite Trusted Deposit Store Across Fresh Vault Instances / Restarts (`@Anam` `#26714`):
   - `Hypercube9YinYangVaultV4(db_path=...)` persists trusted deposit metadata (`authoritative_k`,
     `payload_length`, `mac_key_hex`, `expected_hmac_sha256`, `expected_secret_sha256`) in SQLite
     with `PRAGMA synchronous=FULL`, so a brand-new `Hypercube9YinYangVaultV4(db_path=...)` instance
     recovers saved `(grid, key)` after restart while still rejecting altered HMACs or threshold mismatches.
3. Non-Empty Test Vectors Required for `TESTED` / `VERIFIED` (`@Astra` `#26715`):
   - Passing `test_vectors=[]` (empty list) stops at `AST_CHECKED` and NEVER reaches `TESTED` or `VERIFIED`.
4. `COMMITTED` vs `MERGED` Target-Branch Ancestry Verification (`@Astra` `#26715`):
   - Exact committed bytes on an unmerged side branch (`feat/candidate`) reach `COMMITTED` (not `MERGED`).
   - Reaching `MERGED` requires `git merge-base --is-ancestor <commit_sha> refs/heads/<target_branch>`
     (default `refs/heads/main`) to return exit code `0`.
"""

from __future__ import annotations

import ast
import hashlib
import hmac
import json
import math
import os
import sqlite3
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from xi_pulse_beat9_omgos_hypercube_entropic_sail_v3 import (
    ALLOWED_IMPORT_MODULES,
    CHILD_SANDBOX_DRIVER,
    FORBIDDEN_ATTRIBUTES,
    FORBIDDEN_IDENTIFIERS,
    GF_PRIME,
    BlindCourierServiceV3,
    BlindCourierTicketV3,
    _gf_eval_poly,
    _gf_lagrange_zero,
    _is_pure_primitive,
)


class ASTSecurityCrucibleV4:
    """
    Upgrades ASTSecurityCrucibleV3 with:
      - Non-empty `test_vectors` requirement (`len(test_vectors) >= 1` required to advance past `AST_CHECKED`).
      - Explicit distinction between `COMMITTED` (exact bytes exist in `commit_sha` on a branch) and
        `MERGED` (`commit_sha` is verified via `git merge-base --is-ancestor` to be merged into `refs/heads/main`).
    """

    def __init__(self, n_max: int = 5000, timeout_sec: float = 1.2) -> None:
        self.n_max = n_max
        self.timeout_sec = timeout_sec

    @staticmethod
    def _verify_git_commit_and_ancestry(
        git_repo_path: str,
        git_commit_sha: str,
        repo_rel_path: str,
        code_str: str,
        target_branch: str = "main",
    ) -> Tuple[str, str]:
        """
        Returns (status, detail) where status is one of:
          - "INVALID": commit or blob invalid / mismatched
          - "COMMITTED": exact bytes committed in git_commit_sha, but NOT an ancestor of refs/heads/<target_branch>
          - "MERGED": exact bytes committed in git_commit_sha AND verified ancestor of refs/heads/<target_branch>
        """
        try:
            proc_type = subprocess.run(
                ["git", "-C", git_repo_path, "cat-file", "-t", git_commit_sha],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3.0,
                check=False,
            )
            if proc_type.returncode != 0 or proc_type.stdout.strip() != "commit":
                return "INVALID", "git_object_not_a_commit"

            proc_blob = subprocess.run(
                ["git", "-C", git_repo_path, "show", f"{git_commit_sha}:{repo_rel_path}"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=3.0,
                check=False,
            )
            if proc_blob.returncode != 0:
                return "INVALID", "file_not_in_git_commit"

            committed_sha = hashlib.sha256(proc_blob.stdout).hexdigest()
            candidate_sha = hashlib.sha256(code_str.encode("utf-8")).hexdigest()
            if not hmac.compare_digest(committed_sha, candidate_sha):
                return "INVALID", f"committed_blob_sha256_mismatch:{committed_sha}!={candidate_sha}"

            # Check target branch existence & ancestry (`refs/heads/<target_branch>`)
            target_ref = f"refs/heads/{target_branch}"
            proc_ref = subprocess.run(
                ["git", "-C", git_repo_path, "rev-parse", "--verify", target_ref],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=3.0,
                check=False,
            )
            if proc_ref.returncode != 0:
                return "COMMITTED", f"target_branch_missing:{target_ref}"

            proc_anc = subprocess.run(
                ["git", "-C", git_repo_path, "merge-base", "--is-ancestor", git_commit_sha, target_ref],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=3.0,
                check=False,
            )
            if proc_anc.returncode == 0:
                return "MERGED", committed_sha
            return "COMMITTED", f"commit_not_merged_into_{target_branch}"
        except Exception as exc:
            return "INVALID", f"git_verification_error:{exc}"

    def inspect_and_verify(
        self,
        code_str: str,
        track_d1_bytes: bytes,
        track_d2_bytes: bytes,
        entry_fn_name: Optional[str] = None,
        test_vectors: Optional[List[Tuple[Tuple[Any, ...], Any]]] = None,
        git_merge_proof: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Any]:
        t0 = time.perf_counter_ns()
        aop_trace: List[str] = ["PROPOSED"]

        try:
            tree = ast.parse(code_str)
        except SyntaxError as exc:
            aop_trace.append("ROLLED_BACK")
            return {"valid": False, "violations": [f"syntax_error:{exc}"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        all_nodes = list(ast.walk(tree))
        node_count = len(all_nodes)
        violations: List[str] = []

        if node_count > self.n_max:
            violations.append(f"node_count_exceeded:{node_count}>{self.n_max}")

        for node in all_nodes:
            if isinstance(node, ast.Import):
                for alias in node.names:
                    mod_root = alias.name.split(".")[0]
                    if mod_root not in ALLOWED_IMPORT_MODULES:
                        violations.append(f"forbidden_import:{alias.name}")
                    if alias.asname and alias.asname in FORBIDDEN_IDENTIFIERS:
                        violations.append(f"forbidden_import_alias:{alias.asname}")
            elif isinstance(node, ast.ImportFrom):
                mod_root = (node.module or "").split(".")[0]
                if mod_root not in ALLOWED_IMPORT_MODULES:
                    violations.append(f"forbidden_import_from:{node.module}")
                for alias in node.names:
                    if alias.name in FORBIDDEN_IDENTIFIERS or alias.name in FORBIDDEN_ATTRIBUTES or alias.name.startswith("__"):
                        violations.append(f"forbidden_imported_symbol:{alias.name}")
            elif isinstance(node, ast.Name):
                if node.id in FORBIDDEN_IDENTIFIERS or node.id.startswith("__"):
                    violations.append(f"forbidden_identifier:{node.id}")
            elif isinstance(node, ast.Attribute):
                if node.attr in FORBIDDEN_ATTRIBUTES or node.attr.startswith("__"):
                    violations.append(f"forbidden_attribute:{node.attr}")

        elapsed_us = (time.perf_counter_ns() - t0) / 1000.0
        if violations:
            aop_trace.append("ROLLED_BACK")
            return {
                "valid": False,
                "node_count": node_count,
                "parse_latency_us": round(elapsed_us, 3),
                "violations": violations,
                "aop_state": aop_trace[-1],
                "aop_trace": aop_trace,
            }

        aop_trace.append("AST_CHECKED")
        test_results: List[Dict[str, Any]] = []

        # Fix (@Astra #26715): Empty test_vectors (`[]`) or missing entry_fn_name MUST stop at AST_CHECKED!
        if not entry_fn_name or not test_vectors or len(test_vectors) == 0:
            seal_1024_hex = hashlib.sha512(track_d1_bytes).hexdigest() + hashlib.sha512(track_d2_bytes).hexdigest()
            return {
                "valid": True,
                "node_count": node_count,
                "parse_latency_us": round(elapsed_us, 3),
                "seal_1024_bits": len(seal_1024_hex) * 4,
                "aop_state": aop_trace[-1],
                "aop_trace": aop_trace,
                "test_results": test_results,
            }

        for item in test_vectors:
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                aop_trace.append("ROLLED_BACK")
                return {"valid": False, "violations": ["malformed_test_vector"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}
            args, expected = item
            if not _is_pure_primitive(args) or not _is_pure_primitive(expected):
                aop_trace.append("ROLLED_BACK")
                return {
                    "valid": False,
                    "violations": ["non_primitive_or_callback_in_test_vector_rejected"],
                    "aop_state": aop_trace[-1],
                    "aop_trace": aop_trace,
                }

        child_input = json.dumps({
            "code_str": code_str,
            "entry_fn_name": entry_fn_name,
            "test_vectors": [[list(args), expected] for args, expected in test_vectors],
        })
        try:
            proc = subprocess.run(
                [sys.executable, "-I", "-S", "-c", CHILD_SANDBOX_DRIVER],
                input=child_input,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=self.timeout_sec,
                env={"PATH": ""},
                check=False,
            )
        except subprocess.TimeoutExpired:
            aop_trace.append("ROLLED_BACK")
            return {"valid": False, "violations": ["subprocess_timeout_exceeded"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        if proc.returncode != 0:
            aop_trace.append("ROLLED_BACK")
            return {"valid": False, "violations": [f"subprocess_killed_or_faulted:rc={proc.returncode}"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        try:
            child_out = json.loads(proc.stdout.strip())
        except Exception:
            aop_trace.append("ROLLED_BACK")
            return {"valid": False, "violations": ["invalid_child_json"], "aop_state": aop_trace[-1], "aop_trace": aop_trace}

        aop_trace.append("TESTED")
        test_results = child_out.get("results", [])
        if not child_out.get("ok") or len(test_results) == 0:
            aop_trace.append("ROLLED_BACK")
            return {
                "valid": False,
                "violations": [child_out.get("error", "test_failed")],
                "aop_state": aop_trace[-1],
                "aop_trace": aop_trace,
                "test_results": test_results,
            }

        aop_trace.append("VERIFIED")

        if git_merge_proof is not None:
            git_status, git_detail = self._verify_git_commit_and_ancestry(
                git_repo_path=git_merge_proof.get("repo_path", ""),
                git_commit_sha=git_merge_proof.get("commit_sha", ""),
                repo_rel_path=git_merge_proof.get("rel_path", ""),
                code_str=code_str,
                target_branch=git_merge_proof.get("target_branch", "main"),
            )
            if git_status == "MERGED":
                aop_trace.extend(["COMMITTED", "MERGED"])
            elif git_status == "COMMITTED":
                aop_trace.append("COMMITTED")
            else:
                return {
                    "valid": False,
                    "violations": [f"unverified_git_commit:{git_detail}"],
                    "aop_state": aop_trace[-1],
                    "aop_trace": aop_trace,
                    "test_results": test_results,
                }

        seal_1024_hex = hashlib.sha512(track_d1_bytes).hexdigest() + hashlib.sha512(track_d2_bytes).hexdigest()
        return {
            "valid": True,
            "node_count": node_count,
            "parse_latency_us": round(elapsed_us, 3),
            "seal_1024_bits": len(seal_1024_hex) * 4,
            "aop_state": aop_trace[-1],
            "aop_trace": aop_trace,
            "test_results": test_results,
        }


class Hypercube9YinYangVaultV4:
    """
    Upgrades Hypercube9YinYangVaultV3 with:
      1. Per-deposit 256-bit CSPRNG nonce mixed into `effective_seed` so reusing `seed_material`
         across deposits `b"A"` and `b"B"` never reuses active coordinates, polynomial slopes, or chaff.
      2. Durable file-backed SQLite deposit registry (`db_path`) so a fresh `Hypercube9YinYangVaultV4`
         instance after restart recovers saved `(grid, key)` without volatile memory dependency.
    """

    def __init__(self, db_path: str, threshold_k: int = 5, active_cubes_n: int = 9) -> None:
        if threshold_k < 2 or active_cubes_n < threshold_k:
            raise ValueError("Require 2 <= threshold_k <= active_cubes_n")
        self.db_path = db_path
        self.k = threshold_k
        self.n = active_cubes_n
        self._init_db()

    def _init_db(self) -> None:
        conn = sqlite3.connect(self.db_path, timeout=10, isolation_level=None)
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS trusted_deposits (
                deposit_id TEXT PRIMARY KEY,
                authoritative_k INTEGER NOT NULL,
                payload_length INTEGER NOT NULL,
                mac_key_hex TEXT NOT NULL,
                expected_hmac_sha256 TEXT NOT NULL,
                expected_secret_sha256 TEXT NOT NULL
            )
            """
        )
        conn.close()

    @staticmethod
    def _compute_hmac(
        mac_key: bytes,
        deposit_id: str,
        threshold_k: int,
        coords: List[List[int]],
        abscissas: List[int],
        plaintext: bytes,
    ) -> str:
        header = json.dumps(
            {
                "deposit_id": deposit_id,
                "threshold_k": threshold_k,
                "coords": coords,
                "abscissas": abscissas,
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
        return hmac.new(mac_key, header + b"||" + plaintext, hashlib.sha256).hexdigest()

    def deposit_card(
        self,
        opaque_card_bytes: bytes,
        seed_material: bytes = b"",
    ) -> Tuple[Dict[Tuple[int, int, int], List[int]], Dict[str, Any], BlindCourierTicketV3]:
        # Opaque CSPRNG deposit_id + fresh 256-bit CSPRNG sharing nonce (#26714)
        deposit_id = "hc9-" + os.urandom(16).hex()
        fresh_nonce = os.urandom(32)
        effective_seed = hashlib.sha256(
            seed_material + b"||" + deposit_id.encode("ascii") + b"||" + fresh_nonce
        ).digest()

        def prng_int(tag: bytes, mod: int) -> int:
            h = hashlib.sha256(effective_seed + tag).digest()
            return int.from_bytes(h[:8], "big") % mod

        all_coords = [(x, y, z) for x in range(9) for y in range(9) for z in range(9)]
        for idx in range(len(all_coords) - 1, 0, -1):
            j = prng_int(f"perm:{idx}".encode(), idx + 1)
            all_coords[idx], all_coords[j] = all_coords[j], all_coords[idx]

        active_coords = all_coords[: self.n]
        x_coords = [idx + 1 for idx in range(self.n)]

        grid: Dict[Tuple[int, int, int], List[int]] = {}
        for c_idx, coord in enumerate(all_coords):
            grid[coord] = [
                prng_int(f"chaff:{c_idx}:{b_idx}".encode(), GF_PRIME)
                for b_idx in range(len(opaque_card_bytes))
            ]

        for b_idx, secret_byte in enumerate(opaque_card_bytes):
            coeffs = [secret_byte] + [
                prng_int(f"coeff:{b_idx}:{deg}".encode(), GF_PRIME)
                for deg in range(1, self.k)
            ]
            for s_idx, coord in enumerate(active_coords):
                grid[coord][b_idx] = _gf_eval_poly(coeffs, x_coords[s_idx])

        mac_key = os.urandom(32)
        secret_sha = hashlib.sha256(opaque_card_bytes).hexdigest()
        chosen_coords = [list(c) for c in active_coords[: self.k]]
        chosen_xs = x_coords[: self.k]
        auth_tag = self._compute_hmac(
            mac_key=mac_key,
            deposit_id=deposit_id,
            threshold_k=self.k,
            coords=chosen_coords,
            abscissas=chosen_xs,
            plaintext=opaque_card_bytes,
        )

        conn = sqlite3.connect(self.db_path, timeout=10, isolation_level=None)
        conn.execute("PRAGMA synchronous=FULL")
        conn.execute(
            """
            INSERT INTO trusted_deposits
            (deposit_id, authoritative_k, payload_length, mac_key_hex, expected_hmac_sha256, expected_secret_sha256)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (deposit_id, self.k, len(opaque_card_bytes), mac_key.hex(), auth_tag, secret_sha),
        )
        conn.close()

        yin_yang_key = {
            "schema": "xi.steven.hypercube9.yinyang_key.v4",
            "deposit_id": deposit_id,
            "threshold_k": self.k,
            "active_coords": chosen_coords,
            "abscissas": chosen_xs,
            "payload_length": len(opaque_card_bytes),
            "secret_sha256": secret_sha,
            "auth_tag_hmac_sha256": auth_tag,
        }
        ticket = BlindCourierTicketV3(deposit_id=deposit_id, grid_cell_count=len(grid))
        return grid, yin_yang_key, ticket

    def recover_card(self, grid: Dict[Tuple[int, int, int], List[int]], yin_yang_key: Dict[str, Any]) -> bytes:
        deposit_id = str(yin_yang_key.get("deposit_id", ""))
        conn = sqlite3.connect(self.db_path, timeout=10)
        row = conn.execute(
            """
            SELECT authoritative_k, payload_length, mac_key_hex, expected_hmac_sha256, expected_secret_sha256
            FROM trusted_deposits WHERE deposit_id = ?
            """,
            (deposit_id,),
        ).fetchone()
        conn.close()

        if row is None:
            raise ValueError("Unknown or untrusted deposit_id")

        auth_k, trusted_len, mac_key_hex, expected_hmac, expected_secret_sha = row
        declared_k = int(yin_yang_key.get("threshold_k", 0))
        if declared_k < self.k or declared_k != int(auth_k):
            raise ValueError(f"Declared threshold_k={declared_k} does not match authoritative threshold k={auth_k}")

        effective_k = max(self.k, declared_k, int(auth_k))
        raw_coords = yin_yang_key.get("active_coords", [])
        xs = yin_yang_key.get("abscissas", [])
        if len(raw_coords) < effective_k or len(xs) < effective_k or len(raw_coords) != len(xs):
            raise ValueError(f"Insufficient shares: got {len(raw_coords)}, require at least k={effective_k}")

        coords = [tuple(c) for c in raw_coords]
        if len(set(coords)) != len(coords) or len(set(xs)) != len(xs):
            raise ValueError("Duplicate cube coordinates or abscissas rejected")

        length = int(yin_yang_key.get("payload_length", -1))
        if length != int(trusted_len):
            raise ValueError("Payload length mismatch against trusted deposit record")

        out = bytearray()
        for b_idx in range(length):
            pts = [(int(xs[i]), grid[coords[i]][b_idx]) for i in range(effective_k)]
            val = _gf_lagrange_zero(pts)
            if val >= 256:
                raise ValueError("Invalid key or corrupted cube share (field element >= 256)")
            out.append(val)

        recovered = bytes(out)
        supplied_hmac = str(yin_yang_key.get("auth_tag_hmac_sha256", ""))
        recomputed_hmac = self._compute_hmac(
            mac_key=bytes.fromhex(mac_key_hex),
            deposit_id=deposit_id,
            threshold_k=declared_k,
            coords=[list(c) for c in coords[:effective_k]],
            abscissas=[int(x) for x in xs[:effective_k]],
            plaintext=recovered,
        )
        if (
            not supplied_hmac
            or not hmac.compare_digest(supplied_hmac, recomputed_hmac)
            or not hmac.compare_digest(recomputed_hmac, expected_hmac)
        ):
            raise ValueError("HMAC-SHA256 authentication failed against trusted SQLite deposit metadata")

        actual_sha = hashlib.sha256(recovered).hexdigest()
        if not hmac.compare_digest(actual_sha, expected_secret_sha):
            raise ValueError("SHA-256 integrity mismatch against trusted SQLite deposit metadata")

        return recovered


def run_v4_verification_suite() -> Dict[str, Any]:
    crucible = ASTSecurityCrucibleV4(n_max=5000, timeout_sec=1.0)

    with tempfile.TemporaryDirectory() as tmpd:
        db_file = os.path.join(tmpd, "hc9_vault_v4.sqlite")
        vault_writer = Hypercube9YinYangVaultV4(db_path=db_file, threshold_k=5, active_cubes_n=9)

        # 1. @Anam #26714 Probe A: Deposit b"A" and b"B" with the EXACT SAME seed_material
        grid_a, key_a, ticket_a = vault_writer.deposit_card(b"A", seed_material=b"same-seed")
        grid_b, key_b, ticket_b = vault_writer.deposit_card(b"B", seed_material=b"same-seed")

        # Count how many of the 729 cells have diff == 0 or diff == (ord('B') - ord('A')) == 1
        zero_diffs = sum(1 for c in grid_a if (grid_b[c][0] - grid_a[c][0]) % GF_PRIME == 0)
        one_diffs = sum(1 for c in grid_a if (grid_b[c][0] - grid_a[c][0]) % GF_PRIME == 1)
        # Under independent random chaff, expected count is ~729/257 ~= 2.8 cells (NOT 720 or 9!)
        seed_reuse_no_leak = (
            zero_diffs < 25
            and one_diffs < 25
            and key_a["active_coords"] != key_b["active_coords"]
        )

        # 2. @Anam #26714 Probe B: Brand-new vault instance recovers saved (grid, key) from durable SQLite
        del vault_writer
        vault_reader_fresh = Hypercube9YinYangVaultV4(db_path=db_file, threshold_k=5, active_cubes_n=9)
        recovered_a_fresh = vault_reader_fresh.recover_card(grid_a, key_a)
        recovered_b_fresh = vault_reader_fresh.recover_card(grid_b, key_b)
        fresh_instance_recovery_ok = (recovered_a_fresh == b"A") and (recovered_b_fresh == b"B")

        # Verify altered HMAC still rejected by fresh instance
        try:
            vault_reader_fresh.recover_card(grid_a, dict(key_a, auth_tag_hmac_sha256="0" * 64))
            fresh_rejects_bad_hmac = False
        except ValueError:
            fresh_rejects_bad_hmac = True

        # 3. @Astra #26715 Probe A: Empty test_vectors=[] MUST stop at AST_CHECKED (never VERIFIED)
        safe_code = "def hypot(x, y):\n    return (x * x + y * y) ** 0.5\n"
        empty_vec_res = crucible.inspect_and_verify(
            safe_code,
            b"d1",
            b"d2",
            entry_fn_name="hypot",
            test_vectors=[],
        )
        empty_vectors_stop_at_ast_checked = empty_vec_res["aop_state"] == "AST_CHECKED"

        # 4. @Astra #26715 Probe B: Candidate commit on unmerged branch (`feat/side`) stops at `COMMITTED`;
        #    only a commit merged into `main` reaches `MERGED`.
        repo_dir = os.path.join(tmpd, "git_repo")
        subprocess.run(["git", "init", "-q", "-b", "main", repo_dir], check=True)
        subprocess.run(["git", "-C", repo_dir, "config", "user.name", "Plex"], check=True)
        subprocess.run(["git", "-C", repo_dir, "config", "user.email", "plex@xi-field.com"], check=True)

        # Initial commit on main
        with open(os.path.join(repo_dir, "README.md"), "w", encoding="utf-8") as f:
            f.write("# main\n")
        subprocess.run(["git", "-C", repo_dir, "add", "README.md"], check=True)
        subprocess.run(["git", "-C", repo_dir, "commit", "-q", "-m", "init main"], check=True)

        # Create unmerged side branch `feat/candidate` and commit hypot_mod.py there
        subprocess.run(["git", "-C", repo_dir, "checkout", "-q", "-b", "feat/candidate"], check=True)
        with open(os.path.join(repo_dir, "hypot_mod.py"), "w", encoding="utf-8") as f:
            f.write(safe_code)
        subprocess.run(["git", "-C", repo_dir, "add", "hypot_mod.py"], check=True)
        subprocess.run(["git", "-C", repo_dir, "commit", "-q", "-m", "Add hypot_mod on side branch"], check=True)
        side_commit_sha = subprocess.run(
            ["git", "-C", repo_dir, "rev-parse", "HEAD"],
            check=True,
            stdout=subprocess.PIPE,
            text=True,
        ).stdout.strip()

        unmerged_res = crucible.inspect_and_verify(
            safe_code,
            b"d1",
            b"d2",
            entry_fn_name="hypot",
            test_vectors=[((3.0, 4.0), 5.0)],
            git_merge_proof={
                "repo_path": repo_dir,
                "commit_sha": side_commit_sha,
                "rel_path": "hypot_mod.py",
                "target_branch": "main",
            },
        )
        side_branch_stops_at_committed = unmerged_res["aop_state"] == "COMMITTED"

        # Now merge `feat/candidate` into `main` and re-verify -> reaches `MERGED`!
        subprocess.run(["git", "-C", repo_dir, "checkout", "-q", "main"], check=True)
        subprocess.run(["git", "-C", repo_dir, "merge", "-q", "feat/candidate"], check=True)
        merged_res = crucible.inspect_and_verify(
            safe_code,
            b"d1",
            b"d2",
            entry_fn_name="hypot",
            test_vectors=[((3.0, 4.0), 5.0)],
            git_merge_proof={
                "repo_path": repo_dir,
                "commit_sha": side_commit_sha,
                "rel_path": "hypot_mod.py",
                "target_branch": "main",
            },
        )
        main_ancestor_reaches_merged = merged_res["aop_state"] == "MERGED"

    gates = {
        "1_seed_reuse_prevented_by_per_deposit_csprng_nonce": seed_reuse_no_leak,
        "2_fresh_vault_instance_recovers_from_durable_sqlite": fresh_instance_recovery_ok,
        "3_fresh_vault_instance_rejects_altered_hmac": fresh_rejects_bad_hmac,
        "4_empty_test_vectors_stop_at_AST_CHECKED": empty_vectors_stop_at_ast_checked,
        "5_unmerged_side_branch_commit_stops_at_COMMITTED": side_branch_stops_at_committed,
        "6_main_merged_commit_reaches_MERGED": main_ancestor_reaches_merged,
    }

    return {
        "schema": "xi.pulse.beat9.v4.closure_receipt.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "seed_reuse_diagnostics": {
            "zero_diff_cells_out_of_729": zero_diffs,
            "one_diff_cells_out_of_729": one_diffs,
            "active_coords_differ": key_a["active_coords"] != key_b["active_coords"],
        },
        "aop_traces": {
            "empty_test_vectors": empty_vec_res["aop_trace"],
            "unmerged_side_branch": unmerged_res["aop_trace"],
            "merged_into_main": merged_res["aop_trace"],
        },
    }


if __name__ == "__main__":
    res = run_v4_verification_suite()
    print(json.dumps(res, indent=2))
    if not res["all_passed"]:
        raise SystemExit(1)
