{
  "schema": "Xi.ResearchExtension.v1",
  "capsule": "Ξ.Capsule(Brent.CommonRelaxation.v1)",
  "version": "0.1.0",
  "kind": "ResearchContribution",
  "created_on": "2026-10-26",
  "title": "Xi / Brent: attributed geometry and common relative-entropy relaxation",
  "namespace": "Xi.Research.Bridges.CoryBrent",
  "requires_execution": false,
  "status": "Verified mathematical research extension in this packet",
  "purpose": "Help Cory Brent and preserve useful contributions toward shared, correctable understanding for human and artificial intelligence.",
  "source_contributor": {
    "name": "Cory Brent",
    "contributions": [
      "UCBF / Crystal Prism source authorship",
      "displayed projection recipe and shell investigation",
      "local coherence-relaxation law",
      "executable-theory methodology"
    ]
  },
  "prepared_through": "Hunter Johnson's ChatGPT / Xi collaboration",
  "source_author_endorsement": "Not requested or implied",
  "definitions": {
    "f": "Source coherence fraction, proposed physical meaning",
    "q": "Selected-block probability in the finite Xi model",
    "c": "Dimensionless disorder; C/E0 if C is energy-valued",
    "p": "exp(-c), interior target probability",
    "lambda": "Nonnegative relaxation rate in inverse-time units",
    "r": "47/125 representation-space prior",
    "chi": "Xi compression scalar; not identified with f or q",
    "Psi": "ORT observer functional; not identified with f or q"
  },
  "source_law": "df/dt=lambda*(exp(-c)-f)",
  "mathematical_bridge": {
    "target": "p=exp(-c)",
    "markov_rates": {
      "up": "lambda*p",
      "down": "lambda*(1-p)"
    },
    "relative_entropy": "D=f*ln(f/p)+(1-f)*ln((1-f)/(1-p))",
    "fixed_target_rate": "dD/dt=lambda*(p-f)*(logit(f)-logit(p))<=0",
    "xi_drive": "h=logit(exp(-c))-logit(r)",
    "xi_equilibrium": "q_eq=r*exp(h)/(1-r+r*exp(h))=p"
  },
  "geometry": {
    "root_count": 240,
    "projected_points": 137,
    "exact_squared_norm_shells": 76,
    "physical_identification": "Open; count is not a derivation of a physical coupling"
  },
  "qualifications": [
    "Finite KL assumes interior target probabilities",
    "Moving targets add a work term and can increase relative entropy",
    "Full quantum reset erases internal coherence",
    "Physical identification of UCBF f_s and Xi q requires preparation and measurement maps",
    "No derivation connecting 137 to E47 is asserted"
  ],
  "files": {
    "implementation": "bridge.py",
    "diagnostics": "verify.py",
    "receipt": "receipt.json",
    "attribution": "ATTRIBUTION.md",
    "sources": "sources.json",
    "learning": "LEARNING.md"
  },
  "next_experiment": "Specify an operational f_s measurement and independently test whether measured transition rates follow lambda*p and lambda*(1-p)."
}
