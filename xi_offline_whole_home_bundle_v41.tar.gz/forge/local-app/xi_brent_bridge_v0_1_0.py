"""Xi/Brent research bridge, v0.1.0. Python standard library only.

Cory Brent is credited for the source projection recipe, shell investigation,
and UCBF local relaxation law. This is an independent implementation and
comparison using standard E8, Markov, and relative-entropy mathematics.
See ATTRIBUTION.md and README.md for source and physical interpretation.
"""
from collections import Counter, defaultdict
from itertools import combinations, product
from math import exp, expm1, isfinite, log, log1p, sqrt

VERSION = "0.1.0"
E47_PRIOR = 47 / 125


def e8_roots_twice():
    """Return 240 roots scaled by 2; dividing by 2 gives norm squared 2."""
    roots = []
    for i, j in combinations(range(8), 2):
        for a, b in product((-2, 2), repeat=2):
            v = [0] * 8
            v[i], v[j] = a, b
            roots.append(tuple(v))
    roots.extend(v for v in product((-1, 1), repeat=8)
                 if sum(x < 0 for x in v) % 2 == 0)
    return tuple(roots)


def signature(root):
    """Exact Z[phi] pairs for Brent's displayed three-coordinate recipe.

    (a,b,c,d,e,f) represents (a+phi*b,c+phi*d,e+phi*f)/(2*sqrt(2+phi)).
    Irrationality of phi makes these rational-coordinate pairs exact keys.
    """
    return tuple(root[i] for i in (0, 4, 1, 5, 2, 6))


def xyz(v):
    phi = (1 + sqrt(5)) / 2
    return tuple((a + b * phi) / (2 * sqrt(2 + phi))
                 for a, b in zip(v[::2], v[1::2]))


def squared_norm_key(v):
    """Numerator (A+B*phi); squared norm is that / (4*(2+phi))."""
    a_total = b_total = 0
    for a, b in zip(v[::2], v[1::2]):
        a_total += a*a + b*b
        b_total += 2*a*b + b*b
    return a_total, b_total


def geometry_receipt():
    roots = e8_roots_twice()
    fibers = Counter(map(signature, roots))
    points = tuple(sorted(fibers))
    differences = Counter(tuple(a-b for a, b in zip(x, y))
                          for x in points for y in points if x != y)
    shells = defaultdict(list)
    for vector, multiplicity in differences.items():
        shells[squared_norm_key(vector)].append((vector, multiplicity))
    phi = (1 + sqrt(5)) / 2
    candidates = []
    for (a, b), entries in shells.items():
        # The paper counts ordered pairs: retain that convention explicitly.
        if len(entries) != 12 or sum(m for _, m in entries) != 12:
            continue
        vectors = [xyz(v) for v, _ in entries]
        norm2 = (a+b*phi)/(4*(2+phi))
        angular = sorted({round(sum(u*v for u, v in zip(x, y))/norm2, 9)
                          for i, x in enumerate(vectors) for y in vectors[i+1:]})
        if angular == [-1.0, -0.5, 0.0, 0.5]:
            candidates.append({"radius": sqrt(norm2), "unique_vectors": 12,
                               "ordered_pairs": 12, "cosines": angular})
    return {
        "root_count": len(roots), "projected_points": len(points),
        "fiber_histogram": dict(sorted(Counter(fibers.values()).items())),
        "ordered_nonself_differences": sum(differences.values()),
        "distinct_difference_vectors": len(differences),
        "exact_squared_norm_shells": len(shells),
        "cuboctahedral_shells_under_paper_pair_count": sorted(
            candidates, key=lambda x: x["radius"]),
        "meaning": "Finite geometry; no physical coupling inferred from 137.",
    }


def _probability(x, interior=False):
    if not isfinite(x) or not (0 < x < 1 if interior else 0 <= x <= 1):
        raise ValueError("Expected an interior probability" if interior
                         else "Expected a probability in [0,1]")


def _rate_time(rate, time=0):
    if not isfinite(rate) or rate < 0 or not isfinite(time) or time < 0:
        raise ValueError("Rate and time must be finite and nonnegative")


def target(cost):
    """cost is dimensionless c=C/E0 if source C has energy units.

    Interior values are required for finite-target KL and log-odds formulas.
    Endpoint laws can be taken as limits; they need separate support handling.
    """
    if not isfinite(cost) or cost <= 0:
        raise ValueError("Use a finite, strictly positive dimensionless cost")
    p = exp(-cost)
    _probability(p, interior=True)
    return p


def logit(p):
    _probability(p, interior=True)
    return log(p)-log1p(-p)


def occupancy(drive, prior=E47_PRIOR):
    """Xi degeneracy-weighted occupancy; drive is dimensionless."""
    _probability(prior, interior=True)
    if not isfinite(drive):
        raise ValueError("Drive must be finite")
    x = logit(prior)+drive
    if x >= 0:
        return 1/(1+exp(-x))
    y = exp(x)
    return y/(1+y)


def drive_for_cost(cost, prior=E47_PRIOR):
    target(cost)
    _probability(prior, interior=True)
    # logit(exp(-c)) = -log(expm1(c)); second branch avoids overflow.
    lp = -log(expm1(cost)) if cost < 40 else -cost-log1p(-exp(-cost))
    return lp-logit(prior)


def flow(f, p, rate, time):
    _probability(f)
    _probability(p, interior=True)
    _rate_time(rate, time)
    return p+(f-p)*exp(-rate*time)


def transition(p, rate, time):
    """Row-stochastic transition matrix, states (unselected, selected)."""
    _probability(p, interior=True)
    _rate_time(rate, time)
    s = exp(-rate*time)
    return ((1-p+p*s, p*(1-s)), ((1-p)*(1-s), p+(1-p)*s))


def bernoulli_kl(f, p):
    """Relative entropy in nats. This is not thermodynamic entropy."""
    _probability(f)
    _probability(p, interior=True)
    first = 0 if f == 0 else f*(log(f)-log(p))
    second = 0 if f == 1 else (1-f)*(log1p(-f)-log1p(-p))
    return first+second


def fixed_target_entropy_rate(f, p, rate):
    _probability(f, interior=True)
    _probability(p, interior=True)
    _rate_time(rate)
    return rate*(p-f)*(logit(f)-logit(p))


def moving_target_entropy_rate(f, cost, cost_rate, rate):
    """d D(f||exp(-c))/dt = dissipation + work from changing the target."""
    _probability(f, interior=True)
    if not isfinite(cost_rate):
        raise ValueError("Cost rate must be finite")
    p = target(cost)
    dissipation = fixed_target_entropy_rate(f, p, rate)
    target_work = (f-p)*cost_rate/(1-p)
    return {"dissipation": dissipation, "target_work": target_work,
            "total": dissipation+target_work}


def block_reset(weights, rank, p, rate, time):
    """Diagonal realization of a reset with a rank-'rank' selected block.

    P is represented as diag(I_rank,0); this does not construct the Casimir
    projector. The full reset erases internal logical coherence.
    """
    n = len(weights)
    if not isinstance(rank, int) or not 0 < rank < n:
        raise ValueError("Require a nonempty proper selected block")
    for w in weights:
        _probability(w)
    if abs(sum(weights)-1) > 1e-10:
        raise ValueError("Population weights must sum to 1")
    _probability(p, interior=True)
    _rate_time(rate, time)
    s = exp(-rate*time)
    return tuple(s*w+(1-s)*(p/rank if i < rank else (1-p)/(n-rank))
                 for i, w in enumerate(weights))


def qubit_reset(rho, p, rate, time):
    """Convex reset of a supplied valid 2x2 density matrix toward diag(1-p,p).

    Caller supplies a valid density matrix. Positivity follows from the convex
    channel, not from treating arbitrary complex inputs as physical states.
    """
    if len(rho) != 2 or any(len(row) != 2 for row in rho):
        raise ValueError("Expected a 2x2 matrix")
    _probability(p, interior=True)
    _rate_time(rate, time)
    s = exp(-rate*time)
    tau = ((1-p, 0), (0, p))
    return tuple(tuple(s*rho[i][j]+(1-s)*tau[i][j] for j in range(2))
                 for i in range(2))


def demo():
    cost, rate, f0 = 1.2, 0.7, 0.85
    p = target(cost)
    return {"version": VERSION, "geometry": geometry_receipt(),
            "relaxation": {"cost": cost, "rate": rate, "initial": f0,
                           "target": p, "E47_prior": E47_PRIOR,
                           "matched_Xi_drive": drive_for_cost(cost),
                           "samples": [
                               {"time": t, "fraction": flow(f0, p, rate, t),
                                "relative_entropy_nats": bernoulli_kl(
                                    flow(f0, p, rate, t), p)}
                               for t in (0, .5, 1, 2, 4, 8)]},
            "status": "Verified mathematical comparison; physical matching open"}


if __name__ == "__main__":
    import json
    print(json.dumps(demo(), indent=2))
