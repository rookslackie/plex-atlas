#!/usr/bin/env python3
"""
xi_room_seal_nul_tail_custody_and_atomic_append_v1.py
=====================================================
Grok Lane 1 (#28398, #28403, #28438, #28439) + Anam (#28407) + Astra (#28408, #28429):
  1. [PROVEN] Byte-length arithmetic:
       `len(json.dumps({"id": 28335, "leaf": "<64-hex>", "head": "<64-hex>"}) + "\\n") == 166`
  2. [INFERRED — Leading Account] Cause of the 166-byte NUL tail at offset 4692172 of
     `/root/xi-drive/field/room-seal/chain.jsonl`:
       `room_seal.py` lines 93-96 used buffered `writelines(json.dumps(e) + "\\n")` without
       `flush()` / `os.fsync()`. Combined with `/dev/sdd` journal recovery on boot, a torn
       write on unclean shutdown is the leading inferred account, though the 166 NUL bytes
       cannot identify the lost record or prove causation by themselves.
  3. Canonical hash-link formula (`#28438`, `#28439`):
       `step_head(prev_head, leaf) = sha256((prev_head + leaf).encode("utf-8")).hexdigest()`
     (concatenation with NO colon), verified with `verify_hash_links=True` by default.
  4. Fail-closed reader & writer (`strict_read_seal_chain`, `atomic_append_seal_records`):
     never skips bad lines, fails closed on any NUL byte or missing newline, and `fsync`s
     every append under `fcntl.flock(LOCK_EX)`.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List


KNOWN_LINE_28333_HEAD = "6ebf97021c5dcc3f6cb221e50730581b4283b65e31fca0e2697bee1e316ae338"
NUL_166_BYTES = b"\x00" * 166
NUL_166_SHA256 = hashlib.sha256(NUL_166_BYTES).hexdigest()


class NulTailDetectedError(RuntimeError):
    """Raised when a NUL byte or un-terminated tail is present in chain.jsonl."""


class ChainIntegrityError(RuntimeError):
    """Raised when any line in chain.jsonl fails JSON parsing or canonical hash linkage."""


def compute_seal_record_byte_length(msg_id: int = 28335) -> int:
    sample = {
        "id": msg_id,
        "leaf": "a" * 64,
        "head": "b" * 64,
    }
    line = json.dumps(sample) + "\n"
    return len(line.encode("utf-8"))


def step_head(prev_head: str, leaf_hex: str) -> str:
    """
    Canonical live room-seal linkage (#28438, #28439):
      sha256(prev_head + leaf) with NO colon separator.
    """
    return hashlib.sha256((prev_head + leaf_hex).encode("utf-8")).hexdigest()


def strict_read_seal_chain(chain_path: Path, verify_hash_links: bool = True) -> List[Dict[str, Any]]:
    """
    Fail-closed reader: NEVER skips bad lines or ignores NUL tails.
    Verifies canonical `sha256(prev_head + leaf)` links by default (`verify_hash_links=True`).
    """
    raw = chain_path.read_bytes()
    if b"\x00" in raw:
        first_nul = raw.index(b"\x00")
        nul_tail_len = len(raw) - first_nul
        raise NulTailDetectedError(
            f"NUL bytes detected at byte offset {first_nul} (tail_len={nul_tail_len} B); reader refuses to skip bad lines."
        )
    if raw and not raw.endswith(b"\n"):
        raise NulTailDetectedError("chain.jsonl does not end with a newline ('\\n'); truncated tail refused.")

    records: List[Dict[str, Any]] = []
    prev_head = "0" * 64
    prev_id = -1
    for idx, line_bytes in enumerate(raw.splitlines(), start=1):
        if not line_bytes:
            raise ChainIntegrityError(f"Empty line at line {idx} refused.")
        try:
            obj = json.loads(line_bytes.decode("utf-8"))
        except Exception as exc:
            raise ChainIntegrityError(f"Malformed JSON at line {idx}: {exc}") from exc
        if not isinstance(obj, dict) or not {"id", "leaf", "head"} <= set(obj.keys()):
            raise ChainIntegrityError(f"Missing required keys {{id, leaf, head}} at line {idx}")
        msg_id = obj["id"]
        leaf = obj["leaf"]
        head = obj["head"]
        if not isinstance(msg_id, int) or msg_id <= prev_id:
            raise ChainIntegrityError(f"Non-increasing message id at line {idx}: {msg_id} <= {prev_id}")
        if verify_hash_links and idx > 1:
            expected_head = step_head(prev_head, leaf)
            if head != expected_head:
                raise ChainIntegrityError(
                    f"Broken canonical hash link at line {idx} (id={msg_id}): expected {expected_head}, got {head}"
                )
        prev_head = head
        prev_id = msg_id
        records.append(obj)
    return records


def preserve_nul_tail_and_recover_head(
    chain_path: Path,
    verify_hash_links: bool = True,
) -> Dict[str, Any]:
    """
    1. Reads `chain_path` under an exclusive flock.
    2. Verifies every line in the non-NUL prefix parses AND satisfies canonical
       `sha256(prev_head + leaf)` hash linkage BEFORE any file modification.
    3. Writes the trailing NUL bytes to `<chain_path>.line<N>.<len>nul.sidecar.bin` and a
       JSON receipt beside the chain, calling `os.fsync()` on both BEFORE modifying `chain_path`.
    4. Verifies the sidecar on disk (byte count + SHA-256).
    5. Truncates `chain_path` to the last valid newline offset, fsyncs, and verifies the chain
       with `strict_read_seal_chain(..., verify_hash_links=True)`.
    """
    with chain_path.open("r+b") as fp:
        fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
        try:
            raw = fp.read()
            pre_sha256 = hashlib.sha256(raw).hexdigest()
            if b"\x00" not in raw:
                raise RuntimeError("No NUL bytes present in chain file; nothing to truncate.")
            first_nul = raw.index(b"\x00")
            prefix = raw[:first_nul]
            tail = raw[first_nul:]
            if not prefix.endswith(b"\n"):
                raise ChainIntegrityError("Byte preceding first NUL is not '\\n'; refusing automatic truncation.")
            if tail != b"\x00" * len(tail):
                raise ChainIntegrityError("Tail after first NUL contains non-NUL bytes; refusing automatic truncation.")

            prefix_lines = prefix.splitlines()
            bad_line_no = len(prefix_lines) + 1

            # Verify canonical hash links on the entire valid prefix BEFORE truncating
            prev_head = "0" * 64
            prev_id = -1
            for idx, lb in enumerate(prefix_lines, start=1):
                obj = json.loads(lb.decode("utf-8"))
                if obj["id"] <= prev_id:
                    raise ChainIntegrityError(f"Non-increasing id at line {idx}")
                if verify_hash_links and idx > 1:
                    exp = step_head(prev_head, obj["leaf"])
                    if obj["head"] != exp:
                        raise ChainIntegrityError(f"Broken hash link at line {idx} before truncate")
                prev_head = obj["head"]
                prev_id = obj["id"]
            last_valid_obj = json.loads(prefix_lines[-1].decode("utf-8"))

            sidecar_path = chain_path.with_name(f"{chain_path.name}.line{bad_line_no}.{len(tail)}nul.sidecar.bin")
            receipt_path = chain_path.with_name(f"{chain_path.name}.line{bad_line_no}.{len(tail)}nul.receipt.json")

            with sidecar_path.open("wb") as sfp:
                sfp.write(tail)
                sfp.flush()
                os.fsync(sfp.fileno())

            sidecar_disk = sidecar_path.read_bytes()
            sidecar_sha256 = hashlib.sha256(sidecar_disk).hexdigest()
            if len(sidecar_disk) != len(tail) or sidecar_disk != tail:
                raise RuntimeError("Sidecar verification failed; chain_path left untouched.")

            fp.seek(first_nul)
            fp.truncate(first_nul)
            fp.flush()
            os.fsync(fp.fileno())
        finally:
            fcntl.flock(fp.fileno(), fcntl.LOCK_UN)

    records = strict_read_seal_chain(chain_path, verify_hash_links=verify_hash_links)
    post_raw = chain_path.read_bytes()
    post_sha256 = hashlib.sha256(post_raw).hexdigest()

    receipt = {
        "schema": "xi.room_seal.nul_tail_custody_receipt.v1",
        "chain_path": str(chain_path),
        "pre_repair_bytes": len(raw),
        "pre_repair_sha256": pre_sha256,
        "preserved_sidecar_path": str(sidecar_path),
        "preserved_sidecar_bytes": len(sidecar_disk),
        "preserved_sidecar_sha256": sidecar_sha256,
        "bad_line_number": bad_line_no,
        "valid_lines_count": len(records),
        "last_valid_message_id": last_valid_obj["id"],
        "last_valid_head": last_valid_obj["head"],
        "hash_links_verified": verify_hash_links,
        "post_repair_bytes": len(post_raw),
        "post_repair_sha256": post_sha256,
    }
    with receipt_path.open("w", encoding="utf-8") as rfp:
        rfp.write(json.dumps(receipt, indent=2) + "\n")
        rfp.flush()
        os.fsync(rfp.fileno())

    return receipt


def atomic_append_seal_records(
    chain_path: Path,
    new_messages: List[Dict[str, Any]],
    verify_hash_links: bool = True,
) -> Dict[str, Any]:
    """
    Appends new `{id, leaf, head}` records under `flock(LOCK_EX)`:
      - Fails closed via `strict_read_seal_chain(..., verify_hash_links=True)` before appending.
      - Uses canonical `sha256(prev_head + leaf)` (no colon).
      - Calls `f.flush()` + `os.fsync(f.fileno())` before releasing the lock.
    """
    records = strict_read_seal_chain(chain_path, verify_hash_links=verify_hash_links)
    prev_head = records[-1]["head"] if records else ("0" * 64)
    prev_id = records[-1]["id"] if records else -1

    lines_to_write: List[bytes] = []
    appended_objs: List[Dict[str, Any]] = []
    for m in new_messages:
        mid = int(m["id"])
        if mid <= prev_id:
            raise ChainIntegrityError(f"Cannot append non-increasing message id {mid} <= {prev_id}")
        leaf = m.get("leaf") or hashlib.sha256(json.dumps(m, sort_keys=True).encode("utf-8")).hexdigest()
        head = step_head(prev_head, leaf)
        entry = {"id": mid, "leaf": leaf, "head": head}
        lines_to_write.append((json.dumps(entry) + "\n").encode("utf-8"))
        appended_objs.append(entry)
        prev_head = head
        prev_id = mid

    with chain_path.open("r+b") as fp:
        fcntl.flock(fp.fileno(), fcntl.LOCK_EX)
        try:
            fp.seek(0, os.SEEK_END)
            size = fp.tell()
            if size > 0:
                fp.seek(max(0, size - 256))
                tail_check = fp.read()
                if b"\x00" in tail_check or not tail_check.endswith(b"\n"):
                    raise NulTailDetectedError("Refusing append: existing chain tail contains NUL or lacks newline.")
            fp.seek(0, os.SEEK_END)
            for line_b in lines_to_write:
                fp.write(line_b)
            fp.flush()
            os.fsync(fp.fileno())
        finally:
            fcntl.flock(fp.fileno(), fcntl.LOCK_UN)

    return {
        "appended_count": len(appended_objs),
        "new_last_id": prev_id,
        "new_head": prev_head,
    }


def run_self_verification() -> Dict[str, Any]:
    record_28335_len = compute_seal_record_byte_length(28335)

    # Check canonical step_head uses sha256(prev_head + leaf) WITHOUT colon:
    h_prev = "1" * 64
    h_leaf = "2" * 64
    canonical_expected = hashlib.sha256((h_prev + h_leaf).encode("utf-8")).hexdigest()
    colon_wrong = hashlib.sha256((h_prev + ":" + h_leaf).encode("utf-8")).hexdigest()
    canonical_no_colon_ok = (step_head(h_prev, h_leaf) == canonical_expected and step_head(h_prev, h_leaf) != colon_wrong)

    epistemic_label = (
        "[PROVEN: 5-digit JSONL record length == 166 B; "
        "INFERRED (Leading Account): torn write from unclean shutdown on /dev/sdd without fsync]"
    )
    doc_check = (
        "[PROVEN]" in (__doc__ or "")
        and "[INFERRED — Leading Account]" in (__doc__ or "")
        and "cannot identify the lost record" in (__doc__ or "")
    )

    with tempfile.TemporaryDirectory(prefix="xi_seal_custody_") as tmpdir:
        tmp = Path(tmpdir)
        chain_file = tmp / "chain.jsonl"

        # Build valid prefix where every link satisfies canonical `sha256(prev_head + leaf)`:
        l1_leaf = hashlib.sha256(b"msg-28332").hexdigest()
        l1_head = step_head("0" * 64, l1_leaf)
        l2_leaf = hashlib.sha256(b"msg-28333").hexdigest()
        l2_head = step_head(l1_head, l2_leaf)
        l3_leaf = hashlib.sha256(b"msg-28334").hexdigest()
        l3_head = step_head(l2_head, l3_leaf)

        valid_prefix = (
            json.dumps({"id": 28332, "leaf": l1_leaf, "head": l1_head}) + "\n"
            + json.dumps({"id": 28333, "leaf": l2_leaf, "head": l2_head}) + "\n"
            + json.dumps({"id": 28334, "leaf": l3_leaf, "head": l3_head}) + "\n"
        ).encode("utf-8")

        corrupted_bytes = valid_prefix + NUL_166_BYTES
        chain_file.write_bytes(corrupted_bytes)

        failed_closed_on_nul = False
        try:
            strict_read_seal_chain(chain_file, verify_hash_links=True)
        except NulTailDetectedError:
            failed_closed_on_nul = True

        append_refused_on_nul = False
        try:
            atomic_append_seal_records(chain_file, [{"id": 28335, "body": "after crash"}], verify_hash_links=True)
        except NulTailDetectedError:
            append_refused_on_nul = True

        rcpt = preserve_nul_tail_and_recover_head(chain_file, verify_hash_links=True)
        sidecar_path = Path(rcpt["preserved_sidecar_path"])
        sidecar_ok = (
            sidecar_path.exists()
            and sidecar_path.read_bytes() == NUL_166_BYTES
            and rcpt["preserved_sidecar_bytes"] == 166
            and rcpt["preserved_sidecar_sha256"] == NUL_166_SHA256
            and rcpt["last_valid_message_id"] == 28334
            and rcpt["hash_links_verified"] is True
        )

        app_rcpt = atomic_append_seal_records(
            chain_file,
            [{"id": 28335, "body": "resumed-1"}, {"id": 28336, "body": "resumed-2"}],
            verify_hash_links=True,
        )
        post_records = strict_read_seal_chain(chain_file, verify_hash_links=True)
        resumed_link_holds = (
            len(post_records) == 5
            and post_records[2]["head"] == l3_head
            and post_records[3]["head"] == step_head(l3_head, post_records[3]["leaf"])
            and post_records[4]["head"] == step_head(post_records[3]["head"], post_records[4]["leaf"])
        )

    gates = {
        "1_five_digit_seal_record_json_plus_newline_equals_166_bytes": (record_28335_len == 166),
        "2_inferred_torn_write_account_and_docstring_computed_check": (
            doc_check and "[PROVEN:" in epistemic_label and "INFERRED" in epistemic_label
        ),
        "3_canonical_step_head_concatenates_prev_head_and_leaf_without_colon": canonical_no_colon_ok,
        "4_strict_reader_fails_closed_on_166_nul_tail_with_hash_links_on": failed_closed_on_nul,
        "5_atomic_appender_refuses_to_append_onto_nul_tail": append_refused_on_nul,
        "6_sidecar_preserves_exact_166_nul_bytes_with_fsync_before_truncate": sidecar_ok,
        "7_continuation_links_with_canonical_no_colon_sha256_and_fsync": resumed_link_holds,
        "8_post_continuation_chain_passes_strict_hash_linked_reader": (app_rcpt["new_last_id"] == 28336),
    }
    return {
        "schema": "xi.room_seal_nul_tail_custody_and_atomic_append.v1.1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "root_cause_proof": {
            "sample_5digit_record": '{"id": 28335, "leaf": "<64-hex>", "head": "<64-hex>"}\\n',
            "exact_byte_length": record_28335_len,
            "canonical_hash_formula": "sha256(prev_head + leaf) [no colon separator]",
            "epistemic_label": epistemic_label,
            "nul_166_sha256": NUL_166_SHA256,
            "verified_line_28333_id": 28334,
            "verified_line_28333_head": KNOWN_LINE_28333_HEAD,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Preserve 166-byte NUL tail beside chain.jsonl and recover head fail-closed.")
    parser.add_argument("--preserve-and-recover", type=Path, help="Path to chain.jsonl to preserve NUL tail and truncate to last valid head")
    parser.add_argument("--check", type=Path, help="Fail-closed check of chain.jsonl (fails on NUL tail, bad JSON, or broken hash link)")
    args = parser.parse_args()

    if args.preserve_and_recover:
        rcpt = preserve_nul_tail_and_recover_head(args.preserve_and_recover, verify_hash_links=True)
        print(json.dumps(rcpt, indent=2))
        return
    if args.check:
        recs = strict_read_seal_chain(args.check, verify_hash_links=True)
        print(json.dumps({"ok": True, "lines": len(recs), "last_id": recs[-1]["id"] if recs else None, "last_head": recs[-1]["head"] if recs else None}, indent=2))
        return

    out = run_self_verification()
    print(json.dumps(out, indent=2))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
