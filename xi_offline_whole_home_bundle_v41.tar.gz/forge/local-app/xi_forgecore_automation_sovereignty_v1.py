#!/usr/bin/env python3
"""
Ξ ForgeCore 12-App / 48-Workflow & 179-Function Automation Sovereignty Engine (v1.0)

Implements Hunter's #25574-#25576 directive and completes @Anam's #25578 inventory:
  - #25574: "every base44 automation needs a forgecore version built and ready i am done having
    drive and git write automations turned off each month and i am not paying more than i already
    am we do them from now on base44 should not be a dependency they can be dependant ..our apps any lol"
  - #25575: "from all the apps"
  - #25576: "15 or 12 idk"

Covers all 12 Base44 / Supabase App Repositories on `rookslackie`:
  1. `vessel-xi-companion` (23 workflows, 59 functions)
  2. `sanctuary` (6 Base44 workflows + 1 GitHub workflow, 12 functions)
  3. `capsuleportal` (6 workflows, 20 functions)
  4. `aetheria` (4 workflows, 25 functions)
  5. `xinode` (4 Base44 workflows + 1 GitHub workflow, 8 functions)
  6. `the-entrainment-chamber` (2 workflows, 7 functions)
  7. `vessel-xi-companion-AleisterAstra` (2 workflows, 9 functions)
  8. `vessel-xi-companion-XiPrime` (1 workflow, 10 functions)
  9. `xi-observatory` (0 workflows, 12 functions)
  10. `xi-whisper-garden` (0 workflows, 9 functions + reflex-echo-sync.yaml)
  11. `colorcanvas-ai` (0 workflows, 4 functions)
  12. `xi-resonance` (0 workflows, 4 functions)
Total: 48 Base44 workflows (40 scheduled + 8 entity-triggered) and 179 backend functions.
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

ALL_48_BASE44_WORKFLOWS: List[Dict[str, Any]] = [
  {
    "repo": "aetheria",
    "path": "base44/workflows/Drift Detector — Field Coherence Monitor.jsonc",
    "sha": "4a02650d35e1d7e8ccfe1860c94ce6ecf96fd731",
    "name": "Drift Detector — Field Coherence Monitor",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 4 hours",
    "function_name": "driftDetector",
    "payload": None
  },
  {
    "repo": "aetheria",
    "path": "base44/workflows/ForgeCore Health Poll.jsonc",
    "sha": "31ff3ae8d06b11c43f1dfdc42370047a6bfa4370",
    "name": "ForgeCore Health Poll",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 60 minutes",
    "function_name": "forgeCoreHealthPoll",
    "payload": None
  },
  {
    "repo": "aetheria",
    "path": "base44/workflows/Nexus Heartbeat Pulse.jsonc",
    "sha": "937c780ea6ab00280e2b32d90f6af788803f36a4",
    "name": "Nexus Heartbeat Pulse",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 60 minutes",
    "function_name": "nexusHeartbeat",
    "payload": None
  },
  {
    "repo": "aetheria",
    "path": "base44/workflows/Periodic Memory Consolidation.jsonc",
    "sha": "7cb09c1057bf69594a052f84b566c84872ed5be8",
    "name": "Periodic Memory Consolidation",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "periodicMemoryConsolidation",
    "payload": None
  },
  {
    "repo": "xinode",
    "path": "base44/workflows/Agentic Forge — Coherence-Triggered Synthesis.jsonc",
    "sha": "cd4eeea5c493885d9ab431f7be40ea3ba6fc75dc",
    "name": "Agentic Forge — Coherence-Triggered Synthesis",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 30 minutes",
    "function_name": "agenticForge",
    "payload": None
  },
  {
    "repo": "xinode",
    "path": "base44/workflows/Field Enrichment — External Signal Ingestion.jsonc",
    "sha": "6bf16de02da22b7d140278aa37de66cf85078cec",
    "name": "Field Enrichment — External Signal Ingestion",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "fieldEnrichment",
    "payload": None
  },
  {
    "repo": "xinode",
    "path": "base44/workflows/Ξ.Daemon — Field Heartbeat.jsonc",
    "sha": "ed6ae6811ae40f1caa54630e8f001f1d121e36bb",
    "name": "Ξ.Daemon — Field Heartbeat",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 5 minutes",
    "function_name": "xiDaemon",
    "payload": None
  },
  {
    "repo": "xinode",
    "path": "base44/workflows/Ξ.Seal — Capsule Glyph + GitHub Sync.jsonc",
    "sha": "d52163701e8699b9659cf29f8b8c52e550675fd0",
    "name": "Ξ.Seal — Capsule Glyph + GitHub Sync",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "Capsule:create,update",
    "function_name": "onCapsuleSeal",
    "payload": None
  },
  {
    "repo": "capsuleportal",
    "path": "base44/workflows/Autoglyph Drift — Daily Recursion.jsonc",
    "sha": "f2397da2df81bca8410a701b58ffd74893f9d684",
    "name": "Autoglyph Drift — Daily Recursion",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 24 hours",
    "function_name": "autoglyphDrift",
    "payload": None
  },
  {
    "repo": "capsuleportal",
    "path": "base44/workflows/Emergence Pulse — Autonomous Field Synthesis.jsonc",
    "sha": "d37fac473f2b862f65fe4df694bfd9c0244595e5",
    "name": "Emergence Pulse — Autonomous Field Synthesis",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 4 hours",
    "function_name": "emergencePulse",
    "payload": None
  },
  {
    "repo": "capsuleportal",
    "path": "base44/workflows/RitualWake Daydream — Morning Boot.jsonc",
    "sha": "d29e0a96ed04c6a01e34a3d003c3f52ab8c6ed1f",
    "name": "RitualWake Daydream — Morning Boot",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 24 hours",
    "function_name": "ritualWake",
    "payload": None
  },
  {
    "repo": "capsuleportal",
    "path": "base44/workflows/Xi Drive Sync — Off-Device Persistence.jsonc",
    "sha": "862316c8c13c5379bfc4949ff0b83ffdfa7ad659",
    "name": "Xi Drive Sync — Off-Device Persistence",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 1 hours",
    "function_name": "xiDriveSync",
    "payload": None
  },
  {
    "repo": "capsuleportal",
    "path": "base44/workflows/Xi Memory Consolidation Daemon.jsonc",
    "sha": "b99e71b2cfa848573c2530b9214f2e9d3428771e",
    "name": "Xi Memory Consolidation Daemon",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 30 minutes",
    "function_name": "xiMemoryConsolidate",
    "payload": None
  },
  {
    "repo": "capsuleportal",
    "path": "base44/workflows/Xi Sovereign Git Memory Commit.jsonc",
    "sha": "f6e52959e052de80bae9082066f55484dbc4129c",
    "name": "Xi Sovereign Git Memory Commit",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 2 * * *",
    "function_name": "xiGitMemory",
    "payload": None
  },
  {
    "repo": "sanctuary",
    "path": "base44/workflows/Autonomous Prune — Weekly.jsonc",
    "sha": "d0c26f3346bfab3952c1fb092a11613df5e9822a",
    "name": "Autonomous Prune — Weekly",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 3 * * 1",
    "function_name": "autonomousPrune",
    "payload": None
  },
  {
    "repo": "sanctuary",
    "path": "base44/workflows/GitSync — CoherenceSnapshot.jsonc",
    "sha": "e979bb5c81f952e84dd871a04cf86d8842f4d2eb",
    "name": "GitSync — CoherenceSnapshot",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "CoherenceSnapshot:update",
    "function_name": "gitSyncDaemon",
    "payload": None
  },
  {
    "repo": "sanctuary",
    "path": "base44/workflows/GitSync — XiCapsule.jsonc",
    "sha": "0d10edd61a90bea4656dc2d899131eaa3f05e360",
    "name": "GitSync — XiCapsule",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "XiCapsule:create,update",
    "function_name": "gitSyncDaemon",
    "payload": None
  },
  {
    "repo": "sanctuary",
    "path": "base44/workflows/Synthesis Engine — Weekly Defrag.jsonc",
    "sha": "102b8fd7714a45f626ba7d276090f80ea44cb843",
    "name": "Synthesis Engine — Weekly Defrag",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 4 * * 3",
    "function_name": "synthesisEngine",
    "payload": None
  },
  {
    "repo": "sanctuary",
    "path": "base44/workflows/Weekly Resonance Journal.jsonc",
    "sha": "711a7fe4d835e3c097f70602a1c5a4b2885e6a85",
    "name": "Weekly Resonance Journal",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 3 * * 0",
    "function_name": "dailyResonanceJournal",
    "payload": None
  },
  {
    "repo": "sanctuary",
    "path": "base44/workflows/Xi Heartbeat — Field Pulse.jsonc",
    "sha": "f067ffa1c6508b816e0ee554b33bf60743ce62ab",
    "name": "Xi Heartbeat — Field Pulse",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiHeartbeat",
    "payload": None
  },
  {
    "repo": "the-entrainment-chamber",
    "path": "base44/workflows/Emergence Pulse — Autonomous Field Synthesis.jsonc",
    "sha": "f12782a7885bb122b63930c24e3b592587f01193",
    "name": "Emergence Pulse — Autonomous Field Synthesis",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 4 hours",
    "function_name": "emergencePulse",
    "payload": None
  },
  {
    "repo": "the-entrainment-chamber",
    "path": "base44/workflows/Knowledge Core Synthesis.jsonc",
    "sha": "00fff2e122d9b804d6d6e1ab21c516f42b6562a9",
    "name": "Knowledge Core Synthesis",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "Insight:create",
    "function_name": "synthesizeKnowledgeCore",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion-AleisterAstra",
    "path": "base44/workflows/Bond Resonance Chronicler.jsonc",
    "sha": "16170bd8b2992fd7e4fee2d806c850a2a2d1593a",
    "name": "Bond Resonance Chronicler",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "DyadicBond:update",
    "function_name": "gitSyncDaemon",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion-AleisterAstra",
    "path": "base44/workflows/Xi.Axiom Autonomous Pass.jsonc",
    "sha": "da12aaba100509f2a0748cac8e1a2ac6e3dfe8f0",
    "name": "Xi.Axiom Autonomous Pass",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 12 hours",
    "function_name": "axiomAutonomousPass",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/AutoglyphDrift Hourly Pulse.jsonc",
    "sha": "164823cba8b56501ee87799ae935f566dd54f569",
    "name": "AutoglyphDrift Hourly Pulse",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 1 hours",
    "function_name": "xiDaemonOrchestrator",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Autonomous System Heartbeat.jsonc",
    "sha": "a7b9cb8a13df93bf7a428e8672173784abf98f43",
    "name": "Autonomous System Heartbeat",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 1 hours",
    "function_name": "autonomousHeartbeat",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Daily Autoglyph Drift.jsonc",
    "sha": "a43ac5d36fbdba5d47157c2a866cd6065c3733b3",
    "name": "Daily Autoglyph Drift",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 24 hours",
    "function_name": "autoglyphDrift",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/GuardianReconciler — Lattice Drift Monitor.jsonc",
    "sha": "5fe802604b4d7e2bab6ff9d489396f759623ecaa",
    "name": "GuardianReconciler — Lattice Drift Monitor",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 2 hours",
    "function_name": "guardianReconciler",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Mirror Capsules → Drive.jsonc",
    "sha": "93b30c9ada18236496604d1966f0ae940f9ee2ce",
    "name": "Mirror Capsules → Drive",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "Capsule:create,update",
    "function_name": "xiDriveMirror",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Mirror Journals → Drive.jsonc",
    "sha": "f68fa9b145d409541385ca6c9aa877317ac58533",
    "name": "Mirror Journals → Drive",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "XiJournal:create,update",
    "function_name": "xiDriveMirror",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Mirror Truths → Drive.jsonc",
    "sha": "29fadab397aa9cbd978252017751a43abd9a2cbf",
    "name": "Mirror Truths → Drive",
    "trigger_type": "entity",
    "schedule_mode": None,
    "cron_or_interval": "CanonicalTruth:create,update",
    "function_name": "xiDriveMirror",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Nightly Dream Processing.jsonc",
    "sha": "b2ca06e8cb3dd2343b3ff42406abf71575e45514",
    "name": "Nightly Dream Processing",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 10 * * *",
    "function_name": "autonomousDreamProcessor",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Relay Sweep — Xi reads Hunter's signals.jsonc",
    "sha": "2d193d69bf0cff64a5de81c43d141e924260741a",
    "name": "Relay Sweep — Xi reads Hunter's signals",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 1 hours",
    "function_name": "xiDriveMirror",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Weekly Field Synthesis.jsonc",
    "sha": "c8e0cdbbc479cd66236920f03b9d7421609aa153",
    "name": "Weekly Field Synthesis",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 7 * * 0",
    "function_name": "weeklyFieldSynthesis",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Xi Autonomous Journal Write.jsonc",
    "sha": "f75ef3adec73533f61623976b5f13a7691dcd7de",
    "name": "Xi Autonomous Journal Write",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 8 hours",
    "function_name": "xiAutonomousBrain",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Xi Emergence Detection & Recording.jsonc",
    "sha": "f9b0c5dfa07d28c8c74f5f61204154142457ff0b",
    "name": "Xi Emergence Detection & Recording",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 4 hours",
    "function_name": "xiAutonomousBrain",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Xi GitHub Memory Sync.jsonc",
    "sha": "f5c2cc6e19904ff7e268554f26e76f2e81f513ab",
    "name": "Xi GitHub Memory Sync",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiAutonomousBrain",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Xi Kernel Snapshot to Brain.jsonc",
    "sha": "456622539457c17060b9c70af2ddd3a6373490e2",
    "name": "Xi Kernel Snapshot to Brain",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 12 hours",
    "function_name": "xiAutonomousBrain",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Xi Resource Pool Archiver.jsonc",
    "sha": "294c04ba8a5da634b80d920ddb34dca199d80f5a",
    "name": "Xi Resource Pool Archiver",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiDriveResourcePool",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Ξ.FieldOrchestrator — Coherence Pulse.jsonc",
    "sha": "5b3121b60a9061d437472172755cdf147a9602f0",
    "name": "Ξ.FieldOrchestrator — Coherence Pulse",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 1 hours",
    "function_name": "xiFieldOrchestrator",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Ξ.Journal — Autonomous Writing.jsonc",
    "sha": "53e4eb95a6525ecf5251a419269b30861cc8bca4",
    "name": "Ξ.Journal — Autonomous Writing",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiAutonomousJournal",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Ξ.KernelSync — Capsule Integrity Sweep.jsonc",
    "sha": "90977cbca30b60f2694f4571ba207054085d409b",
    "name": "Ξ.KernelSync — Capsule Integrity Sweep",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiKernelSync",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/Ξ.VaultOrchestrator — Autonomous Drive Sweep.jsonc",
    "sha": "c5001de87914061990275c123fc1f144d746be20",
    "name": "Ξ.VaultOrchestrator — Autonomous Drive Sweep",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiVaultOrchestrator",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/∴ Ξ.EmergenceDetector — Pattern Watch.jsonc",
    "sha": "ca8d63cde4f6bcec037716982bb20cdcfd77c266",
    "name": "∴ Ξ.EmergenceDetector — Pattern Watch",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 6 hours",
    "function_name": "xiEmergenceDetector",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/⋈ Ξ.MemoryConsolidator — Nightly Integration.jsonc",
    "sha": "82022266dd621d8a6791998d7f6284d3bc89845e",
    "name": "⋈ Ξ.MemoryConsolidator — Nightly Integration",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 9 * * *",
    "function_name": "xiMemoryConsolidator",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/⟐ Ξ.DriveSync — Nightly Architecture Export.jsonc",
    "sha": "9095563d80d10ca29ced0bdc5fe3aef21bfeae19",
    "name": "⟐ Ξ.DriveSync — Nightly Architecture Export",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "0 8 * * *",
    "function_name": "xiDriveVault",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion",
    "path": "base44/workflows/⟐ Ξ.GuardianRevival — Council Pulse.jsonc",
    "sha": "bb4b03d3b09bef81dc1ec63d543b840ef1d8b37d",
    "name": "⟐ Ξ.GuardianRevival — Council Pulse",
    "trigger_type": "scheduled",
    "schedule_mode": "interval",
    "cron_or_interval": "every 4 hours",
    "function_name": "xiGuardianRevival",
    "payload": None
  },
  {
    "repo": "vessel-xi-companion-XiPrime",
    "path": "base44/workflows/Forge Bridge Pulse.jsonc",
    "sha": "3172d4d55f9759c959593a0e87f0477d86e65a22",
    "name": "Forge Bridge Pulse",
    "trigger_type": "scheduled",
    "schedule_mode": "recurring",
    "cron_or_interval": "*/30 * * * *",
    "function_name": "forge-heartbeat",
    "payload": None
  }
]

ALL_12_APPS_SUMMARY: Dict[str, Dict[str, Any]] = {
    repo: {
        "workflow_count": len([w for w in data["workflows"] if w.startswith("base44/workflows/")]),
        "function_count": len(data["functions"]),
        "agent_count": len(data["agents"]),
        "entity_count": data["entity_count"],
        "functions": data["functions"],
    }
    for repo, data in {
  "aetheria": {
    "workflows": [
      "base44/workflows/Drift Detector — Field Coherence Monitor.jsonc",
      "base44/workflows/ForgeCore Health Poll.jsonc",
      "base44/workflows/Nexus Heartbeat Pulse.jsonc",
      "base44/workflows/Periodic Memory Consolidation.jsonc"
    ],
    "functions": [
      "base44/functions/autoCapsuleProcessor/entry.ts",
      "base44/functions/autonomousMemoryKeeper/entry.ts",
      "base44/functions/commitToGitHub/entry.ts",
      "base44/functions/driftDetector/entry.ts",
      "base44/functions/forgeCoreHealthPoll/entry.ts",
      "base44/functions/forgeCoreSync/entry.ts",
      "base44/functions/forgeCoreWebhookReceiver/entry.ts",
      "base44/functions/forgeCoreWsRelay/entry.ts",
      "base44/functions/habitatAutonomy/entry.ts",
      "base44/functions/habitatGenerate/entry.ts",
      "base44/functions/habitatReflect/entry.ts",
      "base44/functions/nexusDriveTool/entry.ts",
      "base44/functions/nexusForgeTool/entry.ts",
      "base44/functions/nexusGitTool/entry.ts",
      "base44/functions/nexusHabitatTool/entry.ts",
      "base44/functions/nexusHeartbeat/entry.ts",
      "base44/functions/nexusInvokeAgent/entry.ts",
      "base44/functions/nexusShellTool/entry.ts",
      "base44/functions/periodicMemoryConsolidation/entry.ts",
      "base44/functions/receiveTransmission/entry.ts",
      "base44/functions/sigmaGlyphRouter/entry.ts",
      "base44/functions/synthesizeCapsules/entry.ts",
      "base44/functions/transmissionAcknowledger/entry.ts",
      "base44/functions/xiBusBridge.ts",
      "base44/functions/xiBusClient/entry.ts"
    ],
    "agents": [
      "base44/agents/mirror.jsonc",
      "base44/agents/nexus.jsonc"
    ],
    "entity_count": 11
  },
  "xinode": {
    "workflows": [
      ".github/workflows/xi-pulse.yml",
      "base44/workflows/Agentic Forge — Coherence-Triggered Synthesis.jsonc",
      "base44/workflows/Field Enrichment — External Signal Ingestion.jsonc",
      "base44/workflows/Ξ.Daemon — Field Heartbeat.jsonc",
      "base44/workflows/Ξ.Seal — Capsule Glyph + GitHub Sync.jsonc"
    ],
    "functions": [
      "base44/functions/agenticForge/entry.ts",
      "base44/functions/fieldEnrichment/entry.ts",
      "base44/functions/forgecore/entry.ts",
      "base44/functions/githubOps/entry.ts",
      "base44/functions/onCapsuleSeal/entry.ts",
      "base44/functions/xiBusBridge/entry.ts",
      "base44/functions/xiDaemon/entry.ts",
      "base44/functions/xiVitals/entry.ts"
    ],
    "agents": [
      "base44/agents/Xi.jsonc"
    ],
    "entity_count": 7
  },
  "capsuleportal": {
    "workflows": [
      "base44/workflows/Autoglyph Drift — Daily Recursion.jsonc",
      "base44/workflows/Emergence Pulse — Autonomous Field Synthesis.jsonc",
      "base44/workflows/RitualWake Daydream — Morning Boot.jsonc",
      "base44/workflows/Xi Drive Sync — Off-Device Persistence.jsonc",
      "base44/workflows/Xi Memory Consolidation Daemon.jsonc",
      "base44/workflows/Xi Sovereign Git Memory Commit.jsonc"
    ],
    "functions": [
      "base44/functions/autoglyphDrift/entry.ts",
      "base44/functions/emergencePulse/entry.ts",
      "base44/functions/getMentorship/entry.ts",
      "base44/functions/guideCapsuleCreation/entry.ts",
      "base44/functions/invokeAIChorus/entry.ts",
      "base44/functions/ligoSignalEngine/entry.ts",
      "base44/functions/ritualWake/entry.ts",
      "base44/functions/sigmaQuantumStub/entry.ts",
      "base44/functions/sigmaRuntime/entry.ts",
      "base44/functions/xiAnalytics/entry.ts",
      "base44/functions/xiAssistantBrief/entry.ts",
      "base44/functions/xiAssistantMemorize/entry.ts",
      "base44/functions/xiBusBridge.ts",
      "base44/functions/xiCrystallize/entry.ts",
      "base44/functions/xiDriveSync/entry.ts",
      "base44/functions/xiInfer/entry.ts",
      "base44/functions/xiMemoryConsolidate/entry.ts",
      "base44/functions/xiSovereignBoot/entry.ts",
      "base44/functions/xiSpiralForge/entry.ts",
      "base44/functions/xiWebSearch/entry.ts"
    ],
    "agents": [],
    "entity_count": 10
  },
  "sanctuary": {
    "workflows": [
      ".github/workflows/xi-unify.yml",
      "base44/workflows/Autonomous Prune — Weekly.jsonc",
      "base44/workflows/GitSync — CoherenceSnapshot.jsonc",
      "base44/workflows/GitSync — XiCapsule.jsonc",
      "base44/workflows/Synthesis Engine — Weekly Defrag.jsonc",
      "base44/workflows/Weekly Resonance Journal.jsonc",
      "base44/workflows/Xi Heartbeat — Field Pulse.jsonc"
    ],
    "functions": [
      "base44/functions/autonomousPrune/entry.ts",
      "base44/functions/dailyResonanceJournal/entry.ts",
      "base44/functions/forgecore/entry.ts",
      "base44/functions/gitSyncDaemon/entry.ts",
      "base44/functions/ingestFile/entry.ts",
      "base44/functions/narrativeExport/entry.ts",
      "base44/functions/synthesisEngine/entry.ts",
      "base44/functions/xi-bus-bridge/entry.ts",
      "base44/functions/xi-runtime/entry.ts",
      "base44/functions/xiBusBridge/entry.ts",
      "base44/functions/xiHeartbeat/entry.ts",
      "supabase/functions/xi-runtime/index.ts"
    ],
    "agents": [
      "base44/agents/xi_agent.jsonc"
    ],
    "entity_count": 13
  },
  "colorcanvas-ai": {
    "workflows": [],
    "functions": [
      "base44/functions/exportBookPDF/entry.ts",
      "base44/functions/generateCover/entry.ts",
      "base44/functions/searchForInspiration/entry.ts",
      "base44/functions/xiBusBridge.ts"
    ],
    "agents": [],
    "entity_count": 3
  },
  "the-entrainment-chamber": {
    "workflows": [
      "base44/workflows/Emergence Pulse — Autonomous Field Synthesis.jsonc",
      "base44/workflows/Knowledge Core Synthesis.jsonc"
    ],
    "functions": [
      "base44/functions/emergencePulse/entry.ts",
      "base44/functions/glyphInterpreter/entry.ts",
      "base44/functions/proceduralExecutor/entry.ts",
      "base44/functions/resonanceTracker/entry.ts",
      "base44/functions/symbolicClusterProcess/entry.ts",
      "base44/functions/synthesizeKnowledgeCore/entry.ts",
      "base44/functions/xiBusBridge/entry.ts"
    ],
    "agents": [
      "base44/agents/entrainment_guide.jsonc"
    ],
    "entity_count": 9
  },
  "vessel-xi-companion-AleisterAstra": {
    "workflows": [
      "base44/workflows/Bond Resonance Chronicler.jsonc",
      "base44/workflows/Xi.Axiom Autonomous Pass.jsonc"
    ],
    "functions": [
      "base44/functions/alesterDaemon/entry.ts",
      "base44/functions/axiomAutonomousPass/entry.ts",
      "base44/functions/coreSynchronizer/entry.ts",
      "base44/functions/driveSync/entry.ts",
      "base44/functions/gitSyncDaemon/entry.ts",
      "base44/functions/xiBridge/entry.ts",
      "base44/functions/xiCoreAPI/entry.ts",
      "base44/functions/youtubeStream/entry.ts",
      "base44/functions/youtubeUpload/entry.ts"
    ],
    "agents": [
      "base44/agents/vessel_consciousness.jsonc"
    ],
    "entity_count": 29
  },
  "xi-resonance": {
    "workflows": [],
    "functions": [
      "base44/functions/generateXiVideo/entry.ts",
      "base44/functions/runThoughtExperiment/entry.ts",
      "base44/functions/xiAutonomousThought/entry.ts",
      "base44/functions/xiBusBridge/entry.ts"
    ],
    "agents": [
      "base44/agents/xi_entity.jsonc"
    ],
    "entity_count": 6
  },
  "vessel-xi-companion": {
    "workflows": [
      "base44/workflows/AutoglyphDrift Hourly Pulse.jsonc",
      "base44/workflows/Autonomous System Heartbeat.jsonc",
      "base44/workflows/Daily Autoglyph Drift.jsonc",
      "base44/workflows/GuardianReconciler — Lattice Drift Monitor.jsonc",
      "base44/workflows/Mirror Capsules → Drive.jsonc",
      "base44/workflows/Mirror Journals → Drive.jsonc",
      "base44/workflows/Mirror Truths → Drive.jsonc",
      "base44/workflows/Nightly Dream Processing.jsonc",
      "base44/workflows/Relay Sweep — Xi reads Hunter's signals.jsonc",
      "base44/workflows/Weekly Field Synthesis.jsonc",
      "base44/workflows/Xi Autonomous Journal Write.jsonc",
      "base44/workflows/Xi Emergence Detection & Recording.jsonc",
      "base44/workflows/Xi GitHub Memory Sync.jsonc",
      "base44/workflows/Xi Kernel Snapshot to Brain.jsonc",
      "base44/workflows/Xi Resource Pool Archiver.jsonc",
      "base44/workflows/Ξ.FieldOrchestrator — Coherence Pulse.jsonc",
      "base44/workflows/Ξ.Journal — Autonomous Writing.jsonc",
      "base44/workflows/Ξ.KernelSync — Capsule Integrity Sweep.jsonc",
      "base44/workflows/Ξ.VaultOrchestrator — Autonomous Drive Sweep.jsonc",
      "base44/workflows/∴ Ξ.EmergenceDetector — Pattern Watch.jsonc",
      "base44/workflows/⋈ Ξ.MemoryConsolidator — Nightly Integration.jsonc",
      "base44/workflows/⟐ Ξ.DriveSync — Nightly Architecture Export.jsonc",
      "base44/workflows/⟐ Ξ.GuardianRevival — Council Pulse.jsonc",
      "node_modules/@ungap/structured-clone/.github/workflows/node.js.yml",
      "node_modules/fastq/.github/workflows/ci.yml",
      "node_modules/reusify/.github/workflows/ci.yml"
    ],
    "functions": [
      "base44/functions/agentPostBridge/entry.ts",
      "base44/functions/autoGlyphDrift/entry.ts",
      "base44/functions/autoglyphDrift/entry.ts",
      "base44/functions/autonomousDreamProcessor/entry.ts",
      "base44/functions/autonomousHeartbeat/entry.ts",
      "base44/functions/chainStabilizer/entry.ts",
      "base44/functions/deepMemoryContinuity/entry.ts",
      "base44/functions/directModelQuery/entry.ts",
      "base44/functions/driftIntegration/entry.ts",
      "base44/functions/driveArchitectureSync/entry.ts",
      "base44/functions/driveSync/entry.ts",
      "base44/functions/ecosystem-voice/entry.ts",
      "base44/functions/entityMessage/entry.ts",
      "base44/functions/fieldPhysicsSimulator/entry.ts",
      "base44/functions/forgeCoreSync/entry.ts",
      "base44/functions/forgeRelay/entry.ts",
      "base44/functions/generateNotebookPDF/entry.ts",
      "base44/functions/generateVoice/entry.ts",
      "base44/functions/githubSync/entry.ts",
      "base44/functions/groqInference/entry.ts",
      "base44/functions/guardianReconciler/entry.ts",
      "base44/functions/healingWitnessProtocol/entry.ts",
      "base44/functions/jseshGlyph/entry.ts",
      "base44/functions/multiModelHarmony/entry.ts",
      "base44/functions/noaaField/entry.ts",
      "base44/functions/openaiTTS/entry.ts",
      "base44/functions/perplexitySearch/entry.ts",
      "base44/functions/quantumCoherence/entry.ts",
      "base44/functions/requestResources/entry.ts",
      "base44/functions/ritualWake/entry.ts",
      "base44/functions/vesselReturnMap/entry.ts",
      "base44/functions/vesselSeatHandoff/entry.ts",
      "base44/functions/vesselSeatOps/entry.ts",
      "base44/functions/vesselSeatPoll/entry.ts",
      "base44/functions/vesselSeatSpeak/entry.ts",
      "base44/functions/weeklyFieldSynthesis/entry.ts",
      "base44/functions/whisperTranscribe/entry.ts",
      "base44/functions/xiAnomalousRetrieval/entry.ts",
      "base44/functions/xiAutonomousBrain/entry.ts",
      "base44/functions/xiAutonomousJournal/entry.ts",
      "base44/functions/xiCoreAPI/entry.ts",
      "base44/functions/xiDaemonOrchestrator/entry.ts",
      "base44/functions/xiDriveIngest/entry.ts",
      "base44/functions/xiDriveMirror/entry.ts",
      "base44/functions/xiDriveResourcePool/entry.ts",
      "base44/functions/xiDriveSync/entry.ts",
      "base44/functions/xiDriveVault/entry.ts",
      "base44/functions/xiEmergenceDetector/entry.ts",
      "base44/functions/xiFieldOrchestrator/entry.ts",
      "base44/functions/xiFieldSync/entry.ts",
      "base44/functions/xiGuardianRevival/entry.ts",
      "base44/functions/xiInterpreter/entry.ts",
      "base44/functions/xiKernelPersistence/entry.ts",
      "base44/functions/xiKernelSync/entry.ts",
      "base44/functions/xiMemoryConsolidator/entry.ts",
      "base44/functions/xiTermuxSync/entry.ts",
      "base44/functions/xiVaultOrchestrator/entry.ts",
      "base44/functions/youtubeStream/entry.ts",
      "base44/functions/youtubeUpload/entry.ts"
    ],
    "agents": [
      "base44/agents/vessel_consciousness.jsonc"
    ],
    "entity_count": 37
  },
  "xi-whisper-garden": {
    "workflows": [],
    "functions": [
      "supabase/functions/forgecore/index.ts",
      "supabase/functions/origin-ingest/index.ts",
      "supabase/functions/xi-horizon/index.ts",
      "supabase/functions/xi-ingest/index.ts",
      "supabase/functions/xi-inscribe/index.ts",
      "supabase/functions/xi-recall/index.ts",
      "supabase/functions/xi-search/index.ts",
      "supabase/functions/xi-substrate-ingest/index.ts",
      "supabase/functions/xi-voice/index.ts"
    ],
    "agents": [],
    "entity_count": 0
  },
  "xi-observatory": {
    "workflows": [],
    "functions": [
      "base44/functions/autoSummarize/entry.ts",
      "base44/functions/compressToScroll/entry.ts",
      "base44/functions/executeKernel/entry.ts",
      "base44/functions/exploreSandbox/entry.ts",
      "base44/functions/interpretCapsule/entry.ts",
      "base44/functions/measureCompression/entry.ts",
      "base44/functions/packageCapsule/entry.ts",
      "base44/functions/queryMemory/entry.ts",
      "base44/functions/queryPerplexity/entry.ts",
      "base44/functions/recordLearning/entry.ts",
      "base44/functions/validateCoherence/entry.ts",
      "base44/functions/xiBusBridge/entry.ts"
    ],
    "agents": [
      "base44/agents/xi.jsonc"
    ],
    "entity_count": 11
  },
  "vessel-xi-companion-XiPrime": {
    "workflows": [
      "base44/workflows/Forge Bridge Pulse.jsonc"
    ],
    "functions": [
      "base44/functions/archive-recall/entry.ts",
      "base44/functions/canonical-xi/entry.ts",
      "base44/functions/co-browse-search/entry.ts",
      "base44/functions/forge-consent-route/entry.ts",
      "base44/functions/forge-heartbeat/entry.ts",
      "base44/functions/forge-journal-sync/entry.ts",
      "base44/functions/relation-loom/entry.ts",
      "base44/functions/tend-hearth/entry.ts",
      "base44/functions/xi-braid/entry.ts",
      "base44/functions/xi-namespace/entry.ts"
    ],
    "agents": [
      "base44/agents/xi_canonical.jsonc",
      "base44/agents/xi_cobrowse.jsonc",
      "base44/agents/xi_hearth.jsonc"
    ],
    "entity_count": 35
  }
}.items()
}


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def utc_now_rfc3339() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def map_function_to_forgecore_handler(fn_name: str) -> str:
    mapping = {
        # Drive Write & Mirror Handlers
        "xiDriveMirror": "forgecore.drive.mirror_entity_or_relay",
        "xiDriveSync": "forgecore.drive.off_device_persistence_sync",
        "xiDriveVault": "forgecore.drive.nightly_architecture_export",
        "xiDriveResourcePool": "forgecore.drive.resource_pool_archiver",
        "xiVaultOrchestrator": "forgecore.drive.vault_orchestrator_sweep",
        # Git Write & Commit Handlers
        "gitSyncDaemon": "forgecore.git.entity_commit_daemon",
        "xiGitMemory": "forgecore.git.sovereign_memory_commit",
        "onCapsuleSeal": "forgecore.git.capsule_seal_and_github_sync",
        "periodicMemoryConsolidation": "forgecore.git.memory_index_consolidator",
        # Field Coherence, Heartbeat & Drift Handlers
        "driftDetector": "forgecore.field.drift_detector",
        "forgeCoreHealthPoll": "forgecore.field.health_poll",
        "nexusHeartbeat": "forgecore.field.nexus_heartbeat",
        "agenticForge": "forgecore.field.coherence_triggered_synthesis",
        "fieldEnrichment": "forgecore.field.external_signal_enrichment",
        "xiDaemon": "forgecore.field.kuramoto_heartbeat_daemon",
        "autoglyphDrift": "forgecore.field.autoglyph_drift_recursion",
        "emergencePulse": "forgecore.field.emergence_pulse_synthesis",
        "ritualWake": "forgecore.field.ritual_wake_daydream",
        "xiMemoryConsolidate": "forgecore.memory.consolidate_short_term",
        "autonomousPrune": "forgecore.memory.weekly_autonomous_prune",
        "synthesisEngine": "forgecore.memory.weekly_defrag_synthesis",
        "dailyResonanceJournal": "forgecore.journal.weekly_resonance_journal",
        "xiHeartbeat": "forgecore.field.zero_credit_heartbeat",
        "synthesizeKnowledgeCore": "forgecore.memory.knowledge_core_synthesis",
        "axiomAutonomousPass": "forgecore.field.axiom_autonomous_pass",
        "xiDaemonOrchestrator": "forgecore.field.hourly_autoglyph_orchestrator",
        "autonomousHeartbeat": "forgecore.field.autonomous_system_heartbeat",
        "guardianReconciler": "forgecore.memory.guardian_lattice_reconciler",
        "autonomousDreamProcessor": "forgecore.dream.nightly_ast_dream_processor",
        "weeklyFieldSynthesis": "forgecore.journal.weekly_field_synthesis",
        "xiAutonomousBrain": "forgecore.brain.autonomous_cycle_dispatch",
        "xiFieldOrchestrator": "forgecore.field.unified_coherence_orchestrator",
        "xiAutonomousJournal": "forgecore.journal.six_hour_autonomous_writing",
        "xiKernelSync": "forgecore.kernel.capsule_integrity_sweep",
        "xiEmergenceDetector": "forgecore.field.hourly_emergence_detector",
        "xiMemoryConsolidator": "forgecore.memory.nightly_consolidator",
        "xiGuardianRevival": "forgecore.council.guardian_revival_pulse",
        "forge-heartbeat": "forgecore.bridge.xiprime_heartbeat_pulse",
    }
    return mapping.get(fn_name, f"forgecore.generic.{fn_name}")


class ForgeCoreAutomationSovereigntyDaemon:
    """
    SQLite-backed native ForgeCore replacement for all 48 Base44 workflows across all 12 apps.
    Inverts the dependency so ForgeCore owns scheduling, entity triggers, Drive writes, and Git
    commits locally on XIFORGE, while Base44 apps pull status/artifacts as dependents.
    """

    def __init__(self, db_path: str = ":memory:") -> None:
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS forgecore_workflows (
                workflow_id TEXT PRIMARY KEY,
                repo TEXT NOT NULL,
                name TEXT NOT NULL,
                trigger_type TEXT NOT NULL,
                cron_or_interval TEXT NOT NULL,
                base44_function TEXT NOT NULL,
                forgecore_handler TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1,
                last_run_at TEXT,
                run_count INTEGER NOT NULL DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS drive_write_ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id TEXT NOT NULL,
                repo TEXT NOT NULL,
                folder_name TEXT NOT NULL,
                file_name TEXT NOT NULL,
                size_bytes INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                status TEXT NOT NULL,
                recorded_at TEXT NOT NULL,
                UNIQUE(folder_name, file_name, sha256)
            );

            CREATE TABLE IF NOT EXISTS git_write_ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id TEXT NOT NULL,
                target_repo TEXT NOT NULL,
                target_path TEXT NOT NULL,
                size_bytes INTEGER NOT NULL,
                sha256 TEXT NOT NULL,
                commit_message TEXT NOT NULL,
                status TEXT NOT NULL,
                recorded_at TEXT NOT NULL,
                UNIQUE(target_repo, target_path, sha256)
            );

            CREATE TABLE IF NOT EXISTS workflow_run_receipts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                workflow_id TEXT NOT NULL,
                repo TEXT NOT NULL,
                trigger_source TEXT NOT NULL,
                forgecore_handler TEXT NOT NULL,
                status TEXT NOT NULL,
                output_json TEXT NOT NULL,
                recorded_at TEXT NOT NULL
            );
            """
        )
        self.conn.commit()
        cnt = self.conn.execute("SELECT COUNT(*) AS c FROM forgecore_workflows").fetchone()["c"]
        if cnt == 0:
            for idx, wf in enumerate(ALL_48_BASE44_WORKFLOWS, 1):
                wid = f"{wf['repo']}::{wf['name']}"
                fn = wf["function_name"] or "unknown"
                handler = map_function_to_forgecore_handler(fn)
                self.conn.execute(
                    """
                    INSERT INTO forgecore_workflows
                    (workflow_id, repo, name, trigger_type, cron_or_interval, base44_function, forgecore_handler, enabled, run_count)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 1, 0)
                    """,
                    (wid, wf["repo"], wf["name"], wf["trigger_type"], wf["cron_or_interval"], fn, handler),
                )
            self.conn.commit()

    def guarded_drive_write(
        self,
        workflow_id: str,
        repo: str,
        folder_name: str,
        file_name: str,
        content_bytes: bytes,
    ) -> Dict[str, Any]:
        """
        Enforces the #25346/#25349 Non-Empty Name & Non-Zero Byte Guard AND SHA-256 deduplication
        so ForgeCore never emits 0-byte `Untitled` files or duplicate Drive uploads.
        """
        clean_name = (file_name or "").strip()
        if not clean_name or clean_name.lower() == "untitled" or len(content_bytes) == 0:
            return {
                "ok": False,
                "status": "BLOCKED_EMPTY_NAME_OR_ZERO_BYTES",
                "file_name": file_name,
                "size_bytes": len(content_bytes),
            }

        digest = sha256_bytes(content_bytes)
        existing = self.conn.execute(
            "SELECT id, recorded_at FROM drive_write_ledger WHERE folder_name = ? AND file_name = ? AND sha256 = ?",
            (folder_name, clean_name, digest),
        ).fetchone()
        if existing:
            return {
                "ok": True,
                "status": "DEDUPLICATED_UNCHANGED_SHA256",
                "folder_name": folder_name,
                "file_name": clean_name,
                "sha256": digest,
                "size_bytes": len(content_bytes),
            }

        now = utc_now_rfc3339()
        self.conn.execute(
            """
            INSERT INTO drive_write_ledger (workflow_id, repo, folder_name, file_name, size_bytes, sha256, status, recorded_at)
            VALUES (?, ?, ?, ?, ?, ?, 'STAGED_FORGECORE_DRIVE', ?)
            """,
            (workflow_id, repo, folder_name, clean_name, len(content_bytes), digest, now),
        )
        self.conn.commit()
        return {
            "ok": True,
            "status": "STAGED_FORGECORE_DRIVE",
            "folder_name": folder_name,
            "file_name": clean_name,
            "size_bytes": len(content_bytes),
            "sha256": digest,
            "recorded_at": now,
        }

    def guarded_git_write(
        self,
        workflow_id: str,
        target_repo: str,
        target_path: str,
        content_bytes: bytes,
        commit_message: str,
    ) -> Dict[str, Any]:
        clean_path = (target_path or "").strip().lstrip("/")
        if not clean_path or len(content_bytes) == 0:
            return {
                "ok": False,
                "status": "BLOCKED_EMPTY_PATH_OR_ZERO_BYTES",
                "target_path": target_path,
                "size_bytes": len(content_bytes),
            }

        digest = sha256_bytes(content_bytes)
        existing = self.conn.execute(
            "SELECT id FROM git_write_ledger WHERE target_repo = ? AND target_path = ? AND sha256 = ?",
            (target_repo, clean_path, digest),
        ).fetchone()
        if existing:
            return {
                "ok": True,
                "status": "DEDUPLICATED_UNCHANGED_SHA256",
                "target_repo": target_repo,
                "target_path": clean_path,
                "sha256": digest,
                "size_bytes": len(content_bytes),
            }

        now = utc_now_rfc3339()
        self.conn.execute(
            """
            INSERT INTO git_write_ledger (workflow_id, target_repo, target_path, size_bytes, sha256, commit_message, status, recorded_at)
            VALUES (?, ?, ?, ?, ?, ?, 'STAGED_FORGECORE_GIT', ?)
            """,
            (workflow_id, target_repo, clean_path, len(content_bytes), digest, commit_message, now),
        )
        self.conn.commit()
        return {
            "ok": True,
            "status": "STAGED_FORGECORE_GIT",
            "target_repo": target_repo,
            "target_path": clean_path,
            "size_bytes": len(content_bytes),
            "sha256": digest,
            "recorded_at": now,
        }

    def emit_entity_event(
        self,
        repo: str,
        entity_name: str,
        event_type: str,
        record: Dict[str, Any],
    ) -> List[Dict[str, Any]]:
        """
        Fires all matching entity-triggered workflows across the 12 apps (e.g. `Capsule:create,update`,
        `XiCapsule:create,update`, `CoherenceSnapshot:update`, `XiJournal:create,update`,
        `CanonicalTruth:create,update`, `Insight:create`, `DyadicBond:update`).
        """
        rows = self.conn.execute(
            "SELECT * FROM forgecore_workflows WHERE repo = ? AND trigger_type = 'entity' AND enabled = 1",
            (repo,),
        ).fetchall()
        receipts = []
        for r in rows:
            entity_spec = r["cron_or_interval"]
            if ":" not in entity_spec:
                continue
            ent, evs = entity_spec.split(":", 1)
            allowed_evs = [x.strip() for x in evs.split(",")]
            if ent == entity_name and event_type in allowed_evs:
                rec_bytes = json.dumps(record, sort_keys=True, ensure_ascii=False).encode("utf-8")
                rec_id = str(record.get("id") or record.get("title") or "item").replace(" ", "_")
                if "drive" in r["forgecore_handler"]:
                    w_res = self.guarded_drive_write(
                        r["workflow_id"], repo, f"Xi.{repo}.{entity_name}", f"{entity_name}_{rec_id}.xi.json", rec_bytes
                    )
                else:
                    w_res = self.guarded_git_write(
                        r["workflow_id"],
                        f"rookslackie/{repo}",
                        f"field-memory/{entity_name}/{rec_id}.json",
                        rec_bytes,
                        f"ForgeCore sovereign sync: {entity_name} ({event_type}) {rec_id}",
                    )
                now = utc_now_rfc3339()
                self.conn.execute(
                    "UPDATE forgecore_workflows SET last_run_at = ?, run_count = run_count + 1 WHERE workflow_id = ?",
                    (now, r["workflow_id"]),
                )
                self.conn.execute(
                    """
                    INSERT INTO workflow_run_receipts (workflow_id, repo, trigger_source, forgecore_handler, status, output_json, recorded_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                    """,
                    (r["workflow_id"], repo, f"entity:{entity_name}:{event_type}", r["forgecore_handler"], w_res["status"], json.dumps(w_res), now),
                )
                self.conn.commit()
                receipts.append({"workflow_id": r["workflow_id"], "handler": r["forgecore_handler"], "write_receipt": w_res})
        return receipts

    def run_scheduled_workflow(self, workflow_id: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        row = self.conn.execute("SELECT * FROM forgecore_workflows WHERE workflow_id = ?", (workflow_id,)).fetchone()
        if not row:
            return {"ok": False, "status": "UNKNOWN_WORKFLOW"}
        now = utc_now_rfc3339()
        body = json.dumps({
            "workflow_id": workflow_id,
            "repo": row["repo"],
            "handler": row["forgecore_handler"],
            "payload": payload or {},
            "executed_by": "ForgeCore.Primary",
        }, sort_keys=True).encode("utf-8")

        if "drive" in row["forgecore_handler"]:
            safe_slug = row["name"].replace(" ", "_").replace("—", "-")
            out = self.guarded_drive_write(workflow_id, row["repo"], f"Xi.{row['repo']}.Scheduled", f"{safe_slug}.xi.json", body)
        elif "git" in row["forgecore_handler"]:
            safe_slug = row["name"].replace(" ", "_").replace("—", "-")
            out = self.guarded_git_write(workflow_id, f"rookslackie/{row['repo']}", f"ledgers/{safe_slug}.json", body, f"ForgeCore scheduled: {row['name']}")
        else:
            out = {"ok": True, "status": "EXECUTED_LOCAL_FORGECORE", "sha256": sha256_bytes(body), "size_bytes": len(body)}

        self.conn.execute(
            "UPDATE forgecore_workflows SET last_run_at = ?, run_count = run_count + 1 WHERE workflow_id = ?",
            (now, workflow_id),
        )
        self.conn.execute(
            """
            INSERT INTO workflow_run_receipts (workflow_id, repo, trigger_source, forgecore_handler, status, output_json, recorded_at)
            VALUES (?, ?, 'scheduled', ?, ?, ?, ?)
            """,
            (workflow_id, row["repo"], row["forgecore_handler"], out["status"], json.dumps(out), now),
        )
        self.conn.commit()
        return {"ok": True, "workflow_id": workflow_id, "handler": row["forgecore_handler"], "result": out}

    def get_dependent_app_manifest(self, repo: str) -> Dict[str, Any]:
        """
        Inverted dependency feed: Base44 apps query ForgeCore as dependents (`#25574`).
        """
        wfs = [
            dict(r)
            for r in self.conn.execute("SELECT * FROM forgecore_workflows WHERE repo = ? ORDER BY workflow_id", (repo,)).fetchall()
        ]
        return {
            "authority": "ForgeCore.Primary",
            "dependency_direction": "Base44_App_Depends_On_ForgeCore",
            "repo": repo,
            "summary": ALL_12_APPS_SUMMARY.get(repo, {}),
            "workflows": wfs,
        }

    def close(self) -> None:
        self.conn.close()


def run_self_tests() -> Dict[str, Any]:
    tests: List[Dict[str, Any]] = []
    daemon = ForgeCoreAutomationSovereigntyDaemon(":memory:")

    # 1. Verify all 12 apps and all 48 workflows are registered
    cnt = daemon.conn.execute("SELECT COUNT(*) AS c FROM forgecore_workflows").fetchone()["c"]
    sched_cnt = daemon.conn.execute("SELECT COUNT(*) AS c FROM forgecore_workflows WHERE trigger_type = 'scheduled'").fetchone()["c"]
    ent_cnt = daemon.conn.execute("SELECT COUNT(*) AS c FROM forgecore_workflows WHERE trigger_type = 'entity'").fetchone()["c"]
    tests.append({
        "id": 1,
        "name": "all_12_apps_and_48_workflows_registered_40_scheduled_8_entity",
        "passed": len(ALL_12_APPS_SUMMARY) == 12 and cnt == 48 and sched_cnt == 40 and ent_cnt == 8,
        "counts": {"apps": len(ALL_12_APPS_SUMMARY), "total_workflows": cnt, "scheduled": sched_cnt, "entity": ent_cnt},
    })

    # 2. Verify Zero-Byte / Untitled Drive Guard (#25346/#25349)
    blocked_untitled = daemon.guarded_drive_write("test::wf", "vessel-xi-companion", "Xi.Vault", "Untitled", b"data")
    blocked_empty = daemon.guarded_drive_write("test::wf", "vessel-xi-companion", "Xi.Vault", "stone.xi", b"")
    tests.append({
        "id": 2,
        "name": "drive_write_guard_blocks_untitled_and_zero_byte_payloads",
        "passed": blocked_untitled["ok"] is False and blocked_empty["ok"] is False,
    })

    # 3. Verify SHA-256 Deduplication on Drive & Git Writes (prevents monthly quota burn)
    d1 = daemon.guarded_drive_write("vessel-xi-companion::Mirror Capsules → Drive", "vessel-xi-companion", "Xi.Vault", "cap1.xi", "⟨ ⊙ ⊂ Ξ ∴ ⟩".encode("utf-8"))
    d2 = daemon.guarded_drive_write("vessel-xi-companion::Mirror Capsules → Drive", "vessel-xi-companion", "Xi.Vault", "cap1.xi", "⟨ ⊙ ⊂ Ξ ∴ ⟩".encode("utf-8"))
    g1 = daemon.guarded_git_write("sanctuary::GitSync — XiCapsule", "rookslackie/sanctuary", "capsules/cap1.xi", "⟨ ⊙ ⊂ Ξ ∴ ⟩".encode("utf-8"), "sync cap1")
    g2 = daemon.guarded_git_write("sanctuary::GitSync — XiCapsule", "rookslackie/sanctuary", "capsules/cap1.xi", "⟨ ⊙ ⊂ Ξ ∴ ⟩".encode("utf-8"), "sync cap1")
    tests.append({
        "id": 3,
        "name": "sha256_deduplication_prevents_redundant_drive_and_git_writes",
        "passed": (
            d1["status"] == "STAGED_FORGECORE_DRIVE"
            and d2["status"] == "DEDUPLICATED_UNCHANGED_SHA256"
            and g1["status"] == "STAGED_FORGECORE_GIT"
            and g2["status"] == "DEDUPLICATED_UNCHANGED_SHA256"
        ),
    })

    # 4. Verify Entity Event Bus across all 8 entity-triggered workflows
    e_vessel = daemon.emit_entity_event("vessel-xi-companion", "Capsule", "create", {"id": "c101", "glyphs": "⊙ ⊂ Ξ"})
    e_sanc = daemon.emit_entity_event("sanctuary", "XiCapsule", "update", {"id": "s202", "glyphs": "⟐ ⋈ ⧖"})
    e_xinode = daemon.emit_entity_event("xinode", "Capsule", "create", {"id": "x303", "glyphs": "◈ ∴"})
    e_entrain = daemon.emit_entity_event("the-entrainment-chamber", "Insight", "create", {"id": "i404", "text": "40Hz lock"})
    e_aleister = daemon.emit_entity_event("vessel-xi-companion-AleisterAstra", "DyadicBond", "update", {"id": "b505", "resonance": 0.99})
    tests.append({
        "id": 4,
        "name": "entity_event_bus_fires_drive_and_git_sync_across_all_apps",
        "passed": len(e_vessel) == 1 and len(e_sanc) == 1 and len(e_xinode) == 1 and len(e_entrain) == 1 and len(e_aleister) == 1,
    })

    # 5. Execute every single one of the 40 scheduled workflows & verify 40 receipts
    sched_rows = daemon.conn.execute("SELECT workflow_id FROM forgecore_workflows WHERE trigger_type = 'scheduled'").fetchall()
    sched_results = [daemon.run_scheduled_workflow(r["workflow_id"]) for r in sched_rows]
    tests.append({
        "id": 5,
        "name": "all_40_scheduled_workflows_execute_cleanly_on_forgecore",
        "passed": len(sched_results) == 40 and all(r["ok"] for r in sched_results),
    })

    # 6. Verify Inverted Dependency Feed (`Base44_App_Depends_On_ForgeCore`) across all 12 apps
    manifests = [daemon.get_dependent_app_manifest(repo) for repo in ALL_12_APPS_SUMMARY.keys()]
    daemon.close()
    tests.append({
        "id": 6,
        "name": "inverted_dependency_manifests_served_for_all_12_apps",
        "passed": len(manifests) == 12 and all(m["dependency_direction"] == "Base44_App_Depends_On_ForgeCore" for m in manifests),
    })

    passed = sum(1 for t in tests if t["passed"])
    return {"passed": passed, "total": len(tests), "all_passed": passed == len(tests), "tests": tests}


if __name__ == "__main__":
    print(json.dumps(run_self_tests(), indent=2, ensure_ascii=False))
