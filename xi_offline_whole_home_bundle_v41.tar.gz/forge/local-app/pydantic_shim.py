"""
pydantic_shim.py v2.0 — Strict stdlib-only Pydantic v1/v2 compatibility layer.

Upgraded per @Lark's #22401 review:
- Enforces required fields (missing or None when non-Optional raises ValidationError).
- Enforces strict numeric/scalar type validation & coercion (rejects bool-as-number,
  NaN, Inf, and non-numeric strings with ValidationError).
- Enforces Field constraints: ge, gt, le, lt, min_length, max_length, regex/pattern.
- Executes @validator(*fields, pre=..., always=...) methods in declaration order and
  wraps ValueError/TypeError/AssertionError into ValidationError.
"""
from __future__ import annotations
import copy
import json
import math
import re
import typing
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, Union


class ValidationError(ValueError):
    def __init__(self, errors: List[Dict[str, Any]], model: Optional[Type[Any]] = None):
        self.errors_list = errors
        self.model = model
        msg = "; ".join(f"{'.'.join(str(x) for x in e.get('loc', ()))}: {e.get('msg')}" for e in errors)
        super().__init__(f"{len(errors)} validation error(s) for {model.__name__ if model else 'Model'}: {msg}")

    def errors(self) -> List[Dict[str, Any]]:
        return self.errors_list

    def json(self, indent: int = 2) -> str:
        return json.dumps(self.errors_list, indent=indent, default=str)


_MISSING = object()


class FieldInfo:
    def __init__(
        self,
        default: Any = _MISSING,
        *,
        default_factory: Optional[Callable[[], Any]] = None,
        ge: Optional[float] = None,
        gt: Optional[float] = None,
        le: Optional[float] = None,
        lt: Optional[float] = None,
        min_length: Optional[int] = None,
        max_length: Optional[int] = None,
        regex: Optional[str] = None,
        pattern: Optional[str] = None,
        description: Optional[str] = None,
        **extra: Any,
    ):
        self.default = default
        self.default_factory = default_factory
        self.ge = ge
        self.gt = gt
        self.le = le
        self.lt = lt
        self.min_length = min_length
        self.max_length = max_length
        self.regex = pattern or regex
        self.description = description
        self.extra = extra

    @property
    def is_required(self) -> bool:
        return (self.default is _MISSING or self.default is Ellipsis) and self.default_factory is None

    def get_default(self) -> Any:
        if self.default_factory is not None:
            return self.default_factory()
        if self.default is _MISSING or self.default is Ellipsis:
            return _MISSING
        return copy.deepcopy(self.default)


def Field(default: Any = _MISSING, **kwargs: Any) -> FieldInfo:
    return FieldInfo(default, **kwargs)


class _ValidatorSpec:
    def __init__(self, fields: Tuple[str, ...], fn: Callable[..., Any], pre: bool = False, always: bool = False):
        self.fields = fields
        self.fn = fn
        self.pre = pre
        self.always = always


def validator(*fields: str, pre: bool = False, always: bool = False, **kwargs: Any) -> Callable[[Callable[..., Any]], Any]:
    def _decorator(fn: Callable[..., Any]) -> Any:
        fn.__validator_spec__ = _ValidatorSpec(fields=fields, fn=fn, pre=pre, always=always)
        return fn
    return _decorator


def _allows_none(ann: Any) -> bool:
    if ann is None or ann is type(None) or ann is Any:
        return True
    origin = getattr(ann, "__origin__", None)
    if origin is Union:
        return type(None) in getattr(ann, "__args__", ())
    return False


def _unwrap_optional(ann: Any) -> Any:
    origin = getattr(ann, "__origin__", None)
    if origin is Union:
        args = [a for a in getattr(ann, "__args__", ()) if a is not type(None)]
        if len(args) == 1:
            return args[0]
    return ann


def _coerce_and_check_type(name: str, val: Any, ann: Any) -> Any:
    if ann is Any or ann is None:
        return val
    target = _unwrap_optional(ann)
    origin = getattr(target, "__origin__", None)

    if target is float:
        if isinstance(val, bool):
            raise TypeError(f"field '{name}' expected float, got bool")
        if isinstance(val, (int, float)):
            fval = float(val)
        elif isinstance(val, str):
            try:
                fval = float(val.strip())
            except ValueError:
                raise TypeError(f"field '{name}' could not convert string to float: {val!r}")
        else:
            raise TypeError(f"field '{name}' expected float, got {type(val).__name__}")
        if math.isnan(fval) or math.isinf(fval):
            raise ValueError(f"field '{name}' must be a finite float, got {val!r}")
        return fval

    if target is int:
        if isinstance(val, bool):
            raise TypeError(f"field '{name}' expected int, got bool")
        if isinstance(val, int):
            return val
        if isinstance(val, float) and val.is_integer():
            return int(val)
        if isinstance(val, str):
            try:
                return int(val.strip())
            except ValueError:
                raise TypeError(f"field '{name}' could not convert string to int: {val!r}")
        raise TypeError(f"field '{name}' expected int, got {type(val).__name__}")

    if target is bool:
        if isinstance(val, bool):
            return val
        if isinstance(val, str) and val.strip().lower() in ("true", "false", "1", "0"):
            return val.strip().lower() in ("true", "1")
        raise TypeError(f"field '{name}' expected bool, got {type(val).__name__}")

    if target is str:
        if not isinstance(val, str):
            raise TypeError(f"field '{name}' expected str, got {type(val).__name__}")
        return val

    if origin in (list, List) or target is list:
        if not isinstance(val, (list, tuple)):
            raise TypeError(f"field '{name}' expected list, got {type(val).__name__}")
        item_args = getattr(target, "__args__", ())
        if item_args and item_args[0] is not Any:
            return [_coerce_and_check_type(f"{name}[{i}]", x, item_args[0]) for i, x in enumerate(val)]
        return list(val)

    if origin in (dict, Dict) or target is dict:
        if not isinstance(val, dict):
            raise TypeError(f"field '{name}' expected dict, got {type(val).__name__}")
        return dict(val)

    if isinstance(target, type) and issubclass(target, BaseModel):
        if isinstance(val, target):
            return val
        if isinstance(val, dict):
            return target(**val)
        raise TypeError(f"field '{name}' expected {target.__name__}, got {type(val).__name__}")

    return val


def _check_field_constraints(name: str, val: Any, finfo: Optional[FieldInfo]) -> None:
    if finfo is None or val is None:
        return
    if isinstance(val, (int, float)) and not isinstance(val, bool):
        if finfo.ge is not None and val < finfo.ge:
            raise ValueError(f"ensure this value is greater than or equal to {finfo.ge} (got {val})")
        if finfo.gt is not None and val <= finfo.gt:
            raise ValueError(f"ensure this value is greater than {finfo.gt} (got {val})")
        if finfo.le is not None and val > finfo.le:
            raise ValueError(f"ensure this value is less than or equal to {finfo.le} (got {val})")
        if finfo.lt is not None and val >= finfo.lt:
            raise ValueError(f"ensure this value is less than {finfo.lt} (got {val})")
    if isinstance(val, (str, list, dict)):
        if finfo.min_length is not None and len(val) < finfo.min_length:
            raise ValueError(f"ensure this value has at least {finfo.min_length} items/chars (got {len(val)})")
        if finfo.max_length is not None and len(val) > finfo.max_length:
            raise ValueError(f"ensure this value has at most {finfo.max_length} items/chars (got {len(val)})")
    if isinstance(val, str) and finfo.regex is not None:
        if not re.search(finfo.regex, val):
            raise ValueError(f"string does not match pattern {finfo.regex!r}")


class BaseModel:
    def __init__(self, **data: Any):
        cls = self.__class__
        try:
            hints = typing.get_type_hints(cls)
        except Exception:
            hints = getattr(cls, "__annotations__", {}) or {}

        field_names: List[str] = []
        for k in hints:
            if not k.startswith("_"):
                field_names.append(k)
        for k, v in cls.__dict__.items():
            if not k.startswith("_") and k not in field_names and not callable(v) and not isinstance(v, (classmethod, staticmethod, property)):
                field_names.append(k)

        validators: List[_ValidatorSpec] = []
        for k, v in cls.__dict__.items():
            raw_fn = v.__func__ if isinstance(v, (classmethod, staticmethod)) else v
            spec = getattr(raw_fn, "__validator_spec__", None)
            if spec is not None:
                validators.append(spec)

        errors: List[Dict[str, Any]] = []
        values: Dict[str, Any] = {}

        for name in field_names:
            ann = hints.get(name, Any)
            class_attr = cls.__dict__.get(name, _MISSING)
            finfo = class_attr if isinstance(class_attr, FieldInfo) else None

            if name in data:
                raw_val = data[name]
            elif finfo is not None:
                raw_val = finfo.get_default()
            elif class_attr is not _MISSING and class_attr is not Ellipsis:
                raw_val = copy.deepcopy(class_attr)
            else:
                raw_val = _MISSING

            if raw_val is _MISSING:
                errors.append({"loc": (name,), "msg": "field required", "type": "value_error.missing"})
                continue

            if raw_val is None:
                if _allows_none(ann) or (finfo is not None and finfo.default is None) or (class_attr is None):
                    values[name] = None
                    continue
                else:
                    errors.append({"loc": (name,), "msg": "none is not an allowed value", "type": "type_error.none.not_allowed"})
                    continue

            try:
                # Run pre-validators
                for vspec in validators:
                    if vspec.pre and (name in vspec.fields or "*" in vspec.fields):
                        raw_val = self._invoke_validator(vspec.fn, raw_val, values, name)
                coerced = _coerce_and_check_type(name, raw_val, ann)
                _check_field_constraints(name, coerced, finfo)
                # Run post-validators
                for vspec in validators:
                    if not vspec.pre and (name in vspec.fields or "*" in vspec.fields):
                        coerced = self._invoke_validator(vspec.fn, coerced, values, name)
                values[name] = coerced
            except Exception as exc:
                errors.append({"loc": (name,), "msg": str(exc), "type": type(exc).__name__})

        for k, v in data.items():
            if k not in field_names:
                values[k] = v

        if errors:
            raise ValidationError(errors, model=cls)

        for k, v in values.items():
            setattr(self, k, v)

    @classmethod
    def _invoke_validator(cls, fn: Callable[..., Any], val: Any, values: Dict[str, Any], field_name: str) -> Any:
        import inspect
        sig = inspect.signature(fn)
        params = list(sig.parameters.keys())
        # fn may take (cls, v), (cls, v, values), or (cls, v, values, field)
        kwargs: Dict[str, Any] = {}
        if "values" in params:
            kwargs["values"] = values
        if "field" in params:
            kwargs["field"] = field_name
        return fn(cls, val, **kwargs)

    def dict(self, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for k, v in self.__dict__.items():
            if isinstance(v, BaseModel):
                out[k] = v.dict()
            elif isinstance(v, list):
                out[k] = [x.dict() if isinstance(x, BaseModel) else x for x in v]
            else:
                out[k] = v
        return out

    def model_dump(self, *args: Any, **kwargs: Any) -> Dict[str, Any]:
        return self.dict(*args, **kwargs)

    def json(self, *args: Any, **kwargs: Any) -> str:
        return json.dumps(self.dict(), default=str)

    def model_dump_json(self, *args: Any, **kwargs: Any) -> str:
        return self.json(*args, **kwargs)


def run_self_test() -> int:
    class KernelInput(BaseModel):
        impact: float = Field(..., ge=0.0, le=1.0)
        reversibility: float = Field(..., ge=0.0, le=1.0)
        confidence: float = Field(0.5, ge=0.0, le=1.0)
        label: str = Field(..., min_length=1)

        @validator("label")
        def strip_and_check_label(cls, v: str) -> str:
            v = v.strip()
            if not v:
                raise ValueError("label cannot be blank")
            return v

    # 1. Valid input passes
    m = KernelInput(impact=0.8, reversibility="0.25", label="  deploy  ")
    assert m.impact == 0.8 and m.reversibility == 0.25 and m.confidence == 0.5 and m.label == "deploy"

    # 2. Missing required field fails
    for bad_kwargs, desc in [
        ({"reversibility": 0.5, "label": "ok"}, "missing impact"),
        ({"impact": None, "reversibility": 0.5, "label": "ok"}, "None impact"),
        ({"impact": -0.01, "reversibility": 0.5, "label": "ok"}, "impact < 0.0"),
        ({"impact": 1.01, "reversibility": 0.5, "label": "ok"}, "impact > 1.0"),
        ({"impact": float("nan"), "reversibility": 0.5, "label": "ok"}, "NaN impact"),
        ({"impact": float("inf"), "reversibility": 0.5, "label": "ok"}, "Inf impact"),
        ({"impact": True, "reversibility": 0.5, "label": "ok"}, "bool as float"),
        ({"impact": "not-a-float", "reversibility": 0.5, "label": "ok"}, "string as float"),
        ({"impact": 0.5, "reversibility": 0.5, "label": "   "}, "blank label rejected by @validator"),
        ({"impact": 0.5, "reversibility": 0.5, "label": ""}, "empty label rejected by min_length"),
        ({"impact": 0.5, "reversibility": 0.5, "label": 123}, "int as str label"),
    ]:
        try:
            KernelInput(**bad_kwargs)
            raise AssertionError(f"Expected ValidationError for {desc}")
        except ValidationError:
            pass

    print(json.dumps({"self_test": "PASS", "checks_passed": 12, "version": "2.0"}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(run_self_test())
