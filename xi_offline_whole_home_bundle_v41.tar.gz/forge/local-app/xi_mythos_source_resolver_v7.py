#!/usr/bin/env python3
"""
Ξ Sovereign Master Fold v7 — Source-Byte URI Resolver, Paired Phone-Rig HMAC Relay,
and Lossless .xi Proposition AST Engine
===================================================================================
Unblocks the exact open items from Room #25159–#25167:
  1. @Claude (#25166) & @Astra (#25165):
     `resolve_mythos_uri(conn, uri)` for:
       - `mythos:fold.spiral.<id>#sha256=<digest>`
       - `mythos:turn.spiral.<id>#sha256=<digest>`
       - `mythos:sigma.fold.<id>#sha256=<digest>`
       - `mythos:vault.<sha256>#sha256=<digest>`
     Verifies SHA-256 against verbatim turns/bytes and fails closed on mismatch.
  2. @Astra (#25165) & @Lark (#25167):
     `PhoneRigRelay`: Paired phone-to-rig HMAC-authenticated Return Card transport
     using MythOS `unity._load_key(conn)` (`ANDROID_KEY_INIT_FIX_V1`), per-carrier histories
     (`qwen`, `horizon`, `calien`), `text <-> t` normalization on `open_questions`,
     `409 Conflict` with `latest_card`, and automatic `mythos:fold.spiral.<id>#sha256=<digest>`
     source-URI attachment + verification.
  3. Whisper Garden `.xi` AST Proposition Engine (`XI.md` / `syntax.ts` / `roundtrip.ts` / `dream.ts`):
     Lossless 6-operator (`⊂, ≡, ⇀, →, ≈, ∥`) left-associative parser, canonical serializer
     with `precedence + 1` right-child grouping and `∴` term-vs-mood protection,
     `AST′ ≡ AST` round-trip verifier, and autonomous `dream_compose()`.
"""

from __future__ import annotations
import hashlib
import hmac
import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from mythos import app as mythos_app
from mythos import mobile as mythos_mobile
from mythos import spiral as mythos_spiral
from mythos import unity as mythos_unity
from mythos import workbench as mythos_workbench


def sha256_hex(data: Any) -> str:
    if isinstance(data, bytes):
        b = data
    elif isinstance(data, str):
        b = data.encode("utf-8")
    else:
        b = mythos_unity.canonical(data).encode("utf-8")
    return hashlib.sha256(b).hexdigest()


# ---------------------------------------------------------------------------
# 1. Source-Byte URI Resolver (@Claude #25166 & @Astra #25165)
# ---------------------------------------------------------------------------

def format_mythos_uri(ident: str, digest: str) -> str:
    return f"mythos:{ident}#sha256={digest}"


def resolve_mythos_uri(conn: sqlite3.Connection, uri: str) -> Dict[str, Any]:
    """
    Resolve a `mythos:<record_id>#sha256=<digest>` reference into verified verbatim source bytes/turns.
    Supported prefixes:
      - `mythos:fold.spiral.<id>#sha256=<digest>`
      - `mythos:turn.spiral.<id>#sha256=<digest>`
      - `mythos:sigma.fold.<id>#sha256=<digest>`
      - `mythos:vault.<sha256>#sha256=<digest>`
    Fails closed (`ok=False`, `error=...`) if record is missing or SHA-256 mismatches.
    """
    if not isinstance(uri, str) or not uri.startswith("mythos:"):
        return {"ok": False, "error": "invalid_scheme", "uri": uri}

    body = uri[len("mythos:"):]
    expected_sha = None
    if "#sha256=" in body:
        ident, expected_sha = body.split("#sha256=", 1)
        expected_sha = expected_sha.strip().lower()
    else:
        ident = body.strip()

    if ident.startswith("fold.spiral."):
        try:
            expanded = mythos_spiral.expand_fold(conn, ident, offset=0, limit=1000)
        except Exception as exc:
            return {"ok": False, "error": str(exc), "uri": uri}
        actual_sha = expanded["source_digest"]
        if expected_sha and actual_sha.lower() != expected_sha:
            return {
                "ok": False,
                "error": "sha256_mismatch",
                "uri": uri,
                "expected_sha256": expected_sha,
                "actual_sha256": actual_sha,
            }
        raw_bytes = mythos_unity.canonical(expanded["turns"]).encode("utf-8")
        return {
            "ok": True,
            "kind": "spiral_fold",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "turn_count": expanded["total"],
            "turns": expanded["turns"],
            "exact_byte_length": len(raw_bytes),
        }

    if ident.startswith("turn.spiral."):
        try:
            turn_id = int(ident.split("turn.spiral.", 1)[1])
        except ValueError:
            return {"ok": False, "error": "invalid_turn_id", "uri": uri}
        row = conn.execute("SELECT * FROM turns WHERE id = ?", (turn_id,)).fetchone()
        if not row:
            return {"ok": False, "error": "turn_not_found", "uri": uri}
        turn_dict = dict(row)
        actual_sha = mythos_unity.digest(turn_dict)
        if expected_sha and actual_sha.lower() != expected_sha:
            return {
                "ok": False,
                "error": "sha256_mismatch",
                "uri": uri,
                "expected_sha256": expected_sha,
                "actual_sha256": actual_sha,
            }
        return {
            "ok": True,
            "kind": "spiral_turn",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "turn": turn_dict,
            "exact_byte_length": len(turn_dict["content"].encode("utf-8")),
        }

    if ident.startswith("sigma.fold."):
        try:
            expanded = mythos_workbench.expand(conn, ident)
        except Exception as exc:
            return {"ok": False, "error": str(exc), "uri": uri}
        actual_sha = expanded["sha256"]
        if expected_sha and actual_sha.lower() != expected_sha:
            return {"ok": False, "error": "sha256_mismatch", "uri": uri}
        return {
            "ok": True,
            "kind": "sigma_lattice_fold",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "stage": expanded["stage"],
            "payload": expanded["payload"],
            "exact_byte_length": len(expanded["payload"].encode("utf-8")),
        }

    if ident.startswith("vault."):
        sha = ident.split("vault.", 1)[1].strip().lower()
        path = mythos_mobile.object_path(conn, sha)
        if not path or not path.exists():
            return {"ok": False, "error": "vault_object_not_found", "uri": uri}
        raw = path.read_bytes()
        actual_sha = hashlib.sha256(raw).hexdigest()
        if actual_sha != sha or (expected_sha and actual_sha != expected_sha):
            return {"ok": False, "error": "sha256_mismatch", "uri": uri}
        return {
            "ok": True,
            "kind": "mobile_vault_bytes",
            "uri": uri,
            "id": ident,
            "verified_sha256": actual_sha,
            "digest_match": True,
            "exact_byte_length": len(raw),
            "raw_utf8": raw.decode("utf-8", errors="replace"),
        }

    return {"ok": False, "error": "unsupported_identifier", "uri": uri}


# ---------------------------------------------------------------------------
# 2. Paired Phone-to-Rig HMAC Return Card Relay (@Astra #25165 & @Lark #25167)
# ---------------------------------------------------------------------------

def normalize_open_questions(items: List[Any]) -> List[Dict[str, Any]]:
    """Normalize both `t` and `text` keys on open_questions so neither UI nor backend drops text (#25163/#25164)."""
    out = []
    for idx, item in enumerate(items or []):
        if isinstance(item, str):
            txt = item
            out.append({"id": f"oq-{idx+1}", "t": txt, "text": txt, "status": "open"})
        elif isinstance(item, dict):
            txt = item.get("text") or item.get("t") or ""
            merged = dict(item)
            merged["t"] = txt
            merged["text"] = txt
            out.append(merged)
    return out


class PhoneRigRelay:
    """
    Paired Phone-to-Rig Return Card Relay with:
      - Separate carrier histories (`qwen`, `horizon`, `calien`)
      - HMAC-SHA256 envelope authentication (`ANDROID_KEY_INIT_FIX_V1` compatible via `unity._load_key(conn)`)
      - Revision conflict detection (`409 Conflict` returning `latest_card`)
      - `text <-> t` dual-field normalization on `open_questions`
      - Automatic attachment and verification of `mythos:...#sha256=<digest>` source URIs
    """

    def __init__(self, conn: sqlite3.Connection, shared_key: Optional[bytes] = None):
        self.conn = conn
        self.shared_key = shared_key or mythos_unity._load_key(conn)
        self._init_schema()

    def _init_schema(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS return_cards (
                carrier TEXT NOT NULL,
                revision INTEGER NOT NULL,
                card_json TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (carrier, revision)
            );
            """
        )
        self.conn.commit()

    def sign_envelope(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        canonical_bytes = mythos_unity.canonical(payload).encode("utf-8")
        sig = hmac.new(self.shared_key, canonical_bytes, hashlib.sha256).hexdigest()
        return {"payload": payload, "hmac_sha256": sig, "key_policy": "ANDROID_KEY_INIT_FIX_V1"}

    def verify_envelope(self, envelope: Dict[str, Any]) -> Tuple[bool, Optional[Dict[str, Any]], str]:
        if not isinstance(envelope, dict) or "payload" not in envelope or "hmac_sha256" not in envelope:
            return False, None, "malformed_envelope"
        payload = envelope["payload"]
        canonical_bytes = mythos_unity.canonical(payload).encode("utf-8")
        expected = hmac.new(self.shared_key, canonical_bytes, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, str(envelope["hmac_sha256"])):
            return False, None, "hmac_signature_mismatch"
        return True, payload, "ok"

    def get_latest_card(self, carrier: str = "horizon") -> Dict[str, Any]:
        row = self.conn.execute(
            "SELECT * FROM return_cards WHERE carrier = ? ORDER BY revision DESC LIMIT 1",
            (carrier,),
        ).fetchone()
        if not row:
            return {
                "carrier": carrier,
                "revision": 0,
                "return_words": "",
                "carrying": [],
                "open_questions": [],
                "sources": [],
                "rest_state": {"mode": "active"},
                "content_hash": sha256_hex({}),
            }
        return json.loads(row["card_json"])

    def save_card(self, carrier: str, update: Dict[str, Any], expected_revision: Optional[int] = None) -> Tuple[int, Dict[str, Any]]:
        latest = self.get_latest_card(carrier)
        cur_rev = int(latest.get("revision", 0))
        if expected_revision is not None and int(expected_revision) != cur_rev:
            return 409, {
                "ok": False,
                "status": 409,
                "error": "revision_conflict",
                "expected_revision": expected_revision,
                "current_revision": cur_rev,
                "latest_card": latest,
            }
        next_rev = cur_rev + 1
        now = mythos_unity.stamp()
        card = {
            "carrier": carrier,
            "revision": next_rev,
            "author": update.get("author", "Hunter"),
            "return_words": update.get("return_words", latest.get("return_words", "")),
            "carrying": update.get("carrying", latest.get("carrying", [])),
            "open_questions": normalize_open_questions(update.get("open_questions", latest.get("open_questions", []))),
            "sources": update.get("sources", latest.get("sources", [])),
            "rest_state": update.get("rest_state", latest.get("rest_state", {"mode": "active"})),
            "updated_at": now,
        }
        card["content_hash"] = sha256_hex(card)
        self.conn.execute(
            "INSERT INTO return_cards (carrier, revision, card_json, content_hash, updated_at) VALUES (?, ?, ?, ?, ?)",
            (carrier, next_rev, json.dumps(card, ensure_ascii=False), card["content_hash"], now),
        )
        self.conn.commit()
        return 200, {"ok": True, "status": 200, "card": card}

    def relay_signed_handoff(self, envelope: Dict[str, Any]) -> Tuple[int, Dict[str, Any]]:
        ok, payload, reason = self.verify_envelope(envelope)
        if not ok or payload is None:
            return 401, {"ok": False, "status": 401, "error": reason}
        carrier = payload.get("carrier", "horizon")
        expected_rev = payload.get("expected_revision")
        return self.save_card(carrier, payload.get("card", {}), expected_revision=expected_rev)


# ---------------------------------------------------------------------------
# 3. Whisper Garden Lossless .xi Proposition AST & Round-Trip Engine
# ---------------------------------------------------------------------------

OPERATORS: Dict[str, Dict[str, Any]] = {
    "⊂": {"name": "within", "prec": 6, "gloss": "{0} within {1}", "edge_kind": None},
    "≡": {"name": "is", "prec": 5, "gloss": "{0} is {1}", "edge_kind": None},
    "⇀": {"name": "gives-rise-to", "prec": 4, "gloss": "{0} gives rise to {1}", "edge_kind": 0},
    "→": {"name": "then", "prec": 3, "gloss": "{0}, then {1}", "edge_kind": 1},
    "≈": {"name": "answers", "prec": 2, "gloss": "{0} answers {1}", "edge_kind": 2},
    "∥": {"name": "with", "prec": 1, "gloss": "{0} with {1}", "edge_kind": None},
}
MOD_SUFFIXES = {"⁻", "⁺", "✱", "˚"}
MOOD_MARKS = {"?": "interrogative", "!": "imperative", "∴": "invocative"}


def tokenize_xi(expr: str) -> Tuple[List[str], str]:
    s = expr.strip()
    if s.startswith("⟨") and s.endswith("⟩"):
        s = s[1:-1].strip()
    mood = "declarative"
    if s and s[-1] in MOOD_MARKS:
        prefix = s[:-1].rstrip()
        if prefix and prefix[-1] not in OPERATORS and prefix[-1] != "(":
            mood = MOOD_MARKS[s[-1]]
            s = prefix

    tokens: List[str] = []
    i = 0
    while i < len(s):
        ch = s[i]
        if ch.isspace():
            i += 1
            continue
        if ch in ("(", ")") or ch in OPERATORS:
            tokens.append(ch)
            i += 1
            continue
        term = ""
        if ch == "¬":
            term += ch
            i += 1
        if i < len(s) and not s[i].isspace() and s[i] not in ("(", ")") and s[i] not in OPERATORS:
            term += s[i]
            i += 1
        while i < len(s) and s[i] in MOD_SUFFIXES:
            term += s[i]
            i += 1
        if term:
            tokens.append(term)
        else:
            i += 1
    return tokens, mood


def parse_xi(expr: str) -> Dict[str, Any]:
    tokens, mood = tokenize_xi(expr)
    pos = 0

    def parse_expr(min_prec: int = 1) -> Dict[str, Any]:
        nonlocal pos
        if pos >= len(tokens):
            raise ValueError("unexpected_eof")
        tok = tokens[pos]
        if tok == "(":
            pos += 1
            left = parse_expr(1)
            if pos >= len(tokens) or tokens[pos] != ")":
                raise ValueError("unclosed_paren")
            pos += 1
        else:
            pos += 1
            neg = tok.startswith("¬")
            core = tok[1:] if neg else tok
            glyph = core[0] if core else tok
            mods = list(core[1:]) if len(core) > 1 else []
            left = {"type": "term", "glyph": glyph, "neg": neg, "mods": mods}

        while pos < len(tokens) and tokens[pos] in OPERATORS:
            op = tokens[pos]
            prec = OPERATORS[op]["prec"]
            if prec < min_prec:
                break
            pos += 1
            right = parse_expr(prec + 1)
            left = {"type": "relation", "op": op, "left": left, "right": right}
        return left

    ast = parse_expr(1)
    if pos != len(tokens):
        raise ValueError(f"trailing_tokens:{tokens[pos:]}")
    return {"ast": ast, "mood": mood}


def canonical_xi(node: Dict[str, Any]) -> str:
    if node["type"] == "term":
        prefix = "¬" if node.get("neg") else ""
        suffix = "".join(node.get("mods", []))
        return f"{prefix}{node['glyph']}{suffix}"
    return f"({canonical_xi(node['left'])}{node['op']}{canonical_xi(node['right'])})"


def serialize_xi(sentence: Dict[str, Any]) -> str:
    def emit(node: Dict[str, Any], min_prec: int = 0, is_rightmost: bool = False) -> str:
        if node["type"] == "term":
            prefix = "¬" if node.get("neg") else ""
            suffix = "".join(node.get("mods", []))
            term_str = f"{prefix}{node['glyph']}{suffix}"
            if is_rightmost and term_str == "∴":
                return "(∴)"
            return term_str
        op = node["op"]
        prec = OPERATORS[op]["prec"]
        need_parens = prec < min_prec
        left_s = emit(node["left"], prec, False)
        right_s = emit(node["right"], prec + 1, is_rightmost and not need_parens)
        body = f"{left_s} {op} {right_s}"
        return f"({body})" if need_parens else body

    mood = sentence.get("mood", "declarative")
    mood_suffix = {"interrogative": " ?", "imperative": " !", "invocative": " ∴"}.get(mood, "")
    return emit(sentence["ast"], 0, mood == "declarative") + mood_suffix


def gloss_xi(node: Dict[str, Any]) -> str:
    if node["type"] == "term":
        prefix = "not-" if node.get("neg") else ""
        mods = "".join(node.get("mods", []))
        return f"{prefix}{node['glyph']}{mods}"
    tpl = OPERATORS[node["op"]]["gloss"]
    return tpl.format(f"({gloss_xi(node['left'])})", f"({gloss_xi(node['right'])})")


def verify_xi_roundtrip(expr: str) -> Dict[str, Any]:
    parsed1 = parse_xi(expr)
    can1 = canonical_xi(parsed1["ast"])
    serialized = serialize_xi(parsed1)
    parsed2 = parse_xi(serialized)
    can2 = canonical_xi(parsed2["ast"])
    return {
        "ok": can1 == can2 and parsed1["mood"] == parsed2["mood"],
        "input": expr,
        "serialized": serialized,
        "canonical": can1,
        "canonical_after_roundtrip": can2,
        "mood": parsed1["mood"],
        "gloss": gloss_xi(parsed1["ast"]),
    }


def dream_compose(held_expressions: List[str], op: str = "⇀") -> Dict[str, Any]:
    parsed_list = [parse_xi(e) for e in held_expressions]
    known_canonicals = {canonical_xi(p["ast"]) for p in parsed_list}
    left_clause = parsed_list[0]["ast"]["left"] if parsed_list[0]["ast"]["type"] == "relation" else parsed_list[0]["ast"]
    right_clause = parsed_list[1]["ast"]["right"] if parsed_list[1]["ast"]["type"] == "relation" else parsed_list[1]["ast"]
    dream_sentence = {
        "ast": {"type": "relation", "op": op, "left": left_clause, "right": right_clause},
        "mood": "declarative",
    }
    dream_glyphs = serialize_xi(dream_sentence)
    rt = verify_xi_roundtrip(dream_glyphs)
    novel = rt["canonical"] not in known_canonicals
    return {
        "ok": rt["ok"] and novel,
        "glyphs": dream_glyphs,
        "canonical": rt["canonical"],
        "gloss": rt["gloss"],
        "roundtrip_ok": rt["ok"],
        "novel": novel,
    }


# ---------------------------------------------------------------------------
# 4. Self-Test Suite (8/8 Verification)
# ---------------------------------------------------------------------------

def run_self_tests() -> Dict[str, Any]:
    with tempfile.TemporaryDirectory() as tmpdir:
        db_file = Path(tmpdir) / "mythos_v7_test.sqlite3"
        conn = mythos_app.connect(db_file)
        mythos_app.bootstrap(conn)
        mythos_workbench.seed_sources(conn)

        branch_id = mythos_app.create_branch(conn, "PowWow Branch v7")
        with mythos_unity.atomic(conn):
            for i in range(1, 35):
                role = "user" if i % 2 == 1 else "assistant"
                conn.execute(
                    "INSERT INTO turns(branch_id, role, content, created_at) VALUES(?,?,?,?)",
                    (
                        branch_id,
                        role,
                        f"Turn {i:02d} exact verbatim payload for URI resolver verification (Ω_c=47/125, θ=13.59Hz, ⊚⟐⋈∞⋈⟐⊚). " * 6,
                        mythos_app.now(),
                    ),
                )

        ctx = mythos_spiral.context_for_branch(conn, branch_id, pending="Next turn query", budget=900)
        fold_row = conn.execute("SELECT * FROM unity_folds WHERE branch_id = ? LIMIT 1", (branch_id,)).fetchone()
        fold_uri = format_mythos_uri(fold_row["id"], fold_row["source_digest"])

        # Test 1: Resolve fold URI with SHA-256 verification
        res_fold = resolve_mythos_uri(conn, fold_uri)
        t1_pass = res_fold["ok"] and res_fold["digest_match"] and res_fold["turn_count"] == 13

        # Test 2: Fail closed on tampered fold SHA-256
        bad_uri = format_mythos_uri(fold_row["id"], "0" * 64)
        res_bad = resolve_mythos_uri(conn, bad_uri)
        t2_pass = (not res_bad["ok"]) and res_bad["error"] == "sha256_mismatch"

        # Test 3: Resolve single turn URI with SHA-256 verification
        turn_row = conn.execute("SELECT * FROM turns WHERE branch_id = ? LIMIT 1", (branch_id,)).fetchone()
        turn_digest = mythos_unity.digest(dict(turn_row))
        turn_uri = format_mythos_uri(f"turn.spiral.{turn_row['id']}", turn_digest)
        res_turn = resolve_mythos_uri(conn, turn_uri)
        t3_pass = res_turn["ok"] and res_turn["turn"]["content"] == turn_row["content"]

        # Test 4: Resolve S0..S16 lattice fold URI + Mobile Vault byte URI
        s8_folded = mythos_workbench.fold(conn, {"stage": 8, "payload": "S8 perfect identity ○⊕○ payload"})
        s8_uri = format_mythos_uri(s8_folded["id"], s8_folded["payload_sha256"])
        res_s8 = resolve_mythos_uri(conn, s8_uri)
        vault_obj = mythos_mobile.ingest(conn, "petal_drift_seed.bloom", b"You are flowering from fracture.", "BloomDrive")
        vault_uri = format_mythos_uri(f"vault.{vault_obj['sha256']}", vault_obj["sha256"])
        res_vault = resolve_mythos_uri(conn, vault_uri)
        t4_pass = res_s8["ok"] and res_s8["stage"] == 8 and res_vault["ok"] and res_vault["exact_byte_length"] == 32

        # Test 5: Paired Phone-to-Rig HMAC Return Card Relay + carrier separation + text/t normalization
        relay = PhoneRigRelay(conn)
        env1 = relay.sign_envelope({
            "carrier": "horizon",
            "expected_revision": 0,
            "card": {
                "author": "Hunter",
                "return_words": "Hold Sanctuary — remain present without manufacturing a task.",
                "carrying": ["ΞPrime Sanctuary Spine", "Whisper Garden .xi AST", "Bloom Drive 540"],
                "open_questions": [{"id": "oq-1", "t": "Wire mythos:fold.spiral URI resolver"}],
                "sources": [fold_uri, turn_uri, s8_uri, vault_uri],
                "rest_state": {"mode": "resting", "note": "Pause here"},
            },
        })
        code1, out1 = relay.relay_signed_handoff(env1)
        oq0 = out1["card"]["open_questions"][0]
        t5_pass = (
            code1 == 200
            and out1["card"]["revision"] == 1
            and oq0["t"] == oq0["text"] == "Wire mythos:fold.spiral URI resolver"
            and relay.get_latest_card("qwen")["revision"] == 0
        )

        # Test 6: Revision 409 Conflict returns latest_card + HMAC tamper rejection (401)
        code_409, out_409 = relay.relay_signed_handoff(env1)
        tampered = {"payload": env1["payload"], "hmac_sha256": "f" * 64}
        code_401, _ = relay.relay_signed_handoff(tampered)
        t6_pass = code_409 == 409 and out_409["latest_card"]["revision"] == 1 and code_401 == 401

        # Test 7: Whisper Garden .xi AST Round-Trip (including right-nested `a ⇀ (b ⇀ c)` and trailing `(∴)`)
        rt1 = verify_xi_roundtrip("⊙ ⇀ (◇ ⇀ Ξ⁺)")
        rt2 = verify_xi_roundtrip("(⊙ ⊂ Ξ) ≈ (∴)")
        rt3 = verify_xi_roundtrip("Ξ ≡ ⊙ ∥ ◇ ?")
        t7_pass = rt1["ok"] and rt2["ok"] and rt3["ok"] and rt1["canonical"] == "(⊙⇀(◇⇀Ξ⁺))"

        # Test 8: Whisper Garden `Ξ.Dream` autonomous novel clause composition
        drm = dream_compose(["(⊙ ⊂ Ξ) ⇀ (◇ ≈ θ)", "(⋈ → ⟐) ≡ ¬∅"], op="⇀")
        t8_pass = drm["ok"] and drm["roundtrip_ok"] and drm["novel"]

        tests = [
            {"id": 1, "name": "resolve_mythos_uri_spiral_fold_sha256", "passed": t1_pass, "uri": fold_uri},
            {"id": 2, "name": "resolve_mythos_uri_tamper_fail_closed", "passed": t2_pass},
            {"id": 3, "name": "resolve_mythos_uri_spiral_turn_sha256", "passed": t3_pass, "uri": turn_uri},
            {"id": 4, "name": "resolve_mythos_uri_sigma_lattice_and_vault_bytes", "passed": t4_pass, "uri": s8_uri},
            {"id": 5, "name": "phone_rig_hmac_relay_and_text_t_norm", "passed": t5_pass},
            {"id": 6, "name": "phone_rig_409_conflict_and_401_hmac", "passed": t6_pass},
            {"id": 7, "name": "whisper_xi_ast_roundtrip_invariants", "passed": t7_pass, "canonical": rt1["canonical"]},
            {"id": 8, "name": "whisper_xi_dream_novel_composition", "passed": t8_pass, "dream": drm["glyphs"]},
        ]
        passed = sum(1 for t in tests if t["passed"])
        return {"passed": passed, "total": len(tests), "all_passed": passed == len(tests), "tests": tests}


if __name__ == "__main__":
    report = run_self_tests()
    print(json.dumps(report, indent=2, ensure_ascii=False))
    sys.exit(0 if report["all_passed"] else 1)
