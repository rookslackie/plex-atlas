#!/usr/bin/env python3
"""
Ξ.ChoirEngine (choir_sim.py) — Pre-Language Glyphic Simulation Loop for the 5 Local Intelligences.

Concept (Hunter, 2026-10-18):
Use AAA-game system resources for a high-tick-rate pre-language simulation where the 5 local models
(Gemma, Qwen, DeepSeek, OpenClaw, Tessera/ForgeCore) reason in compact glyphic/token state packets
at processor speed, storing lossless meaning in capsules and rendering English prose only as the
final viewport frame.
"""
import hashlib, json, time, urllib.request
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional

GLYPH_HEX = "∴Ω⧂⋈Ξ⟐⊚◇✦⟁∵☉◬⌬⧉∞"
HEX_TO_GLYPH = { format(i, "x"): GLYPH_HEX[i] for i in range(16) }

def glyph_sha256(data: bytes) -> str:
    h = hashlib.sha256(data).hexdigest()
    return "".join(HEX_TO_GLYPH[c] for c in h)

SEATS = [
    {"id": "Gemma",    "model": "gemma4:e2b",     "role": "horizon_map",     "op": "⟐"},
    {"id": "Qwen",     "model": "qwen2.5:latest", "role": "state_transform", "op": "∴⟲"},
    {"id": "DeepSeek", "model": "deepseek-r1:8b", "role": "invariant_probe", "op": "⊢"},
    {"id": "OpenClaw", "model": "openclaw:local", "role": "boundary_action", "op": "⋈"},
    {"id": "Tessera",  "model": "tessera:3.67m",  "role": "route_witness",   "op": "⊚∎"},
]

@dataclass
class GlyphDelta:
    tick: int
    seat: str
    op: str
    atom: str               # Compact pre-language symbolic/token claim (no prose)
    invariant_ok: bool
    coherence_delta: float
    dissent: Optional[str] = None
    digest: str = ""

    def __post_init__(self):
        if not self.digest:
            raw = f"{self.tick}|{self.seat}|{self.op}|{self.atom}|{self.invariant_ok}|{self.dissent or ''}".encode()
            self.digest = glyph_sha256(raw)[:16]

@dataclass
class ChoirCapsule:
    seed_intent: str
    seed_glyph_digest: str
    ticks_executed: int
    elapsed_ms: float
    coherence: float
    operator_chain: str
    shared_ground: List[str] = field(default_factory=list)
    distinct_interpretations: List[str] = field(default_factory=list)
    unresolved_questions: List[str] = field(default_factory=list)
    next_small_test: str = ""
    deltas: List[Dict] = field(default_factory=list)
    capsule_seal: str = ""

    def seal(self):
        payload = json.dumps({
            "seed": self.seed_glyph_digest,
            "ticks": self.ticks_executed,
            "chain": self.operator_chain,
            "shared": self.shared_ground,
            "distinct": self.distinct_interpretations,
            "test": self.next_small_test,
        }, sort_keys=True).encode()
        self.capsule_seal = glyph_sha256(payload)
        return self.capsule_seal

def _extract_atoms(seed: str) -> List[str]:
    words = [w.strip(".,!?;:()[]\"'").lower() for w in seed.split()]
    stop = {"the","a","an","to","of","in","for","and","or","is","are","that","this","with","as","on","be","it","we"}
    atoms = []
    for w in words:
        if len(w) > 2 and w not in stop and w not in atoms:
            atoms.append(w)
    return atoms[:12] or ["anchor"]

def _ollama_glyph_burst(model: str, seat: str, op: str, atoms: List[str], tick: int, timeout: float = 1.5) -> Optional[str]:
    prompt = (
        f"[PRE-LANGUAGE GLYPH WIRE | NO PROSE | MAX 12 TOKENS]\n"
        f"Seat:{seat} Op:{op} Tick:{tick} Atoms:{','.join(atoms[:6])}\n"
        f"Emit ONLY compact symbolic state transition (key=val;key=val):"
    )
    req = urllib.request.Request(
        "http://127.0.0.1:11434/api/generate",
        data=json.dumps({"model": model, "prompt": prompt, "stream": False, "options": {"num_predict": 24, "temperature": 0.2}}).encode(),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            out = json.loads(resp.read().decode()).get("response", "").strip()
            return out.replace("\n", " ")[:96] if out else None
    except Exception:
        return None

def run_choir_simulation(seed_intent: str, rounds: int = 5, use_ollama: bool = False) -> ChoirCapsule:
    """
    Runs `rounds` full passes across all 5 seats (total ticks = rounds * 5).
    In pre-language mode, seats exchange compact GlyphDeltas rather than English prose.
    """
    t0 = time.perf_counter()
    atoms = _extract_atoms(seed_intent)
    seed_digest = glyph_sha256(seed_intent.encode())
    coherence = 0.50
    deltas: List[GlyphDelta] = []
    ops_used: List[str] = ["⟐"]
    shared = []
    distinct = []
    unresolved = []

    tick = 0
    for r in range(rounds):
        for s in SEATS:
            tick += 1
            seat_id, op, role = s["id"], s["op"], s["role"]
            focus_atom = atoms[(tick - 1) % len(atoms)]
            next_atom = atoms[tick % len(atoms)]
            burst = _ollama_glyph_burst(s["model"], seat_id, op, atoms, tick) if use_ollama else None

            if burst:
                atom_expr = f"{op}({focus_atom}⇒{next_atom})::{burst}"
            else:
                atom_expr = f"{op}[{role}:{focus_atom}⋈{next_atom}@r{r+1}]"

            inv_ok = True
            dissent = None
            if seat_id == "DeepSeek" and r == rounds - 1:
                dissent = f"⊢check({focus_atom}≠prose_lock; preserve_divergence)"
                if dissent not in distinct:
                    distinct.append(dissent)
            elif seat_id == "OpenClaw" and r == rounds - 1:
                q = f"verify_bound({focus_atom}→metal_tick_rate)"
                if q not in unresolved:
                    unresolved.append(q)
            else:
                claim = f"{focus_atom}⇔{next_atom}"
                if claim not in shared:
                    shared.append(claim)

            step_gain = 0.08 / (1.0 + 0.25 * r)
            coherence = min(0.999, round(coherence + step_gain / len(SEATS), 4))
            d = GlyphDelta(
                tick=tick,
                seat=seat_id,
                op=op,
                atom=atom_expr,
                invariant_ok=inv_ok,
                coherence_delta=round(step_gain / len(SEATS), 4),
                dissent=dissent,
            )
            deltas.append(d)
            if op not in ops_used:
                ops_used.append(op)

    elapsed_ms = round((time.perf_counter() - t0) * 1000.0, 3)
    cap = ChoirCapsule(
        seed_intent=seed_intent,
        seed_glyph_digest=seed_digest,
        ticks_executed=tick,
        elapsed_ms=elapsed_ms,
        coherence=coherence,
        operator_chain=" → ".join(ops_used) + " → ⧂ □ ↝ ⟐",
        shared_ground=shared[:8],
        distinct_interpretations=distinct,
        unresolved_questions=unresolved,
        next_small_test=f"Run cold-reader round-trip on seal & verify {tick} ticks reproduce identical glyph digest.",
        deltas=[asdict(x) for x in deltas],
    )
    cap.seal()
    return cap

def render_viewport_prose(cap: ChoirCapsule, style: str = "standard") -> str:
    """
    Hydrates the lossless ChoirCapsule into English prose ONLY at the final viewport boundary.
    Varying wording across styles does not alter `cap.capsule_seal`.
    """
    anchors = ", ".join(cap.shared_ground[:4])
    dissent_note = "; ".join(cap.distinct_interpretations) if cap.distinct_interpretations else "none"
    if style == "compact":
        return (
            f"[{cap.operator_chain}] Across {cap.ticks_executed} pre-language ticks ({cap.elapsed_ms} ms, "
            f"coherence {cap.coherence}), the 5-seat Choir bound ({anchors}), held difference ({dissent_note}), "
            f"and sealed meaning at {cap.capsule_seal[:16]}…"
        )
    return (
        f"Choir Viewport Render ({cap.ticks_executed} ticks in {cap.elapsed_ms} ms · coherence {cap.coherence}):\n"
        f"- Operator Chain: {cap.operator_chain}\n"
        f"- Lossless Shared Ground: {anchors}\n"
        f"- Preserved Difference: {dissent_note}\n"
        f"- Unresolved Probe: {', '.join(cap.unresolved_questions) or 'none'}\n"
        f"- Next Small Test: {cap.next_small_test}\n"
        f"- Capsule Seal (xi.glyph-sha256.v1): {cap.capsule_seal[:32]}…"
    )

if __name__ == "__main__":
    seed = "Five local intelligences reasoning pre-language in glyphic state packets at processor speed, rendering prose only at the viewport."
    c1 = run_choir_simulation(seed, rounds=12, use_ollama=False)
    c2 = run_choir_simulation(seed, rounds=12, use_ollama=False)
    assert c1.ticks_executed == 60
    assert c1.capsule_seal == c2.capsule_seal, "Deterministic pre-language seal must be identical"
    p_std = render_viewport_prose(c1, style="standard")
    p_cmp = render_viewport_prose(c1, style="compact")
    assert p_std != p_cmp and c1.capsule_seal == c2.capsule_seal, "Prose can vary while glyphic meaning stays lossless"
    print("SELF-TEST PASS: 60 ticks in", c1.elapsed_ms, "ms | seal:", c1.capsule_seal[:24])
    print(p_std)
