#!/usr/bin/env python3
"""
xi_calien_workshop_bench_v1.py — Calien's Local AI Workshop & Organic Ag Desk (v1.0)
====================================================================================
Built for Calien (#28505, #28509, #28513, #28517) as a local-first, zero-dependency
Python + REST + HTML workbench that any local AI (Ollama / DeepSeek / OpenClaw) can
auto-discover via `GET /api/workshop/discover` while keeping physical laser emission
and printer heating behind explicit operator confirmation and an instant `M5 / M112`
Emergency Stop surface.

Four deterministic engineering & soil-science engines (7/7 verification gates):
  1. Artilume T1 Laser Engraver Raster-to-GCode Engine (`GRBL 1.1f / Marlin` compatible):
     - Converts any 2D grayscale brightness matrix `I[y, x] in [0, 255]` + enterable
       parameters (`width_mm`, `height_mm`, `line_interval_mm`, `feed_mm_min`,
       `max_power_pct`, `s_max`, `passes`, `dither_mode`, `air_assist`, `operator_armed`)
       into a bounded, checksummed `.gcode` / `.nc` job.
     - Safety interlock: refuses to emit `M3`/`M4` laser-on power commands unless
       `operator_armed=True`, and always brackets every pass with `M5` (laser off).
  2. Creality Ender-3 S1 Pro AI Auto-Grab Print & G-Code Envelope Guard:
     - Enforces hardware bounds of the stock Ender-3 S1 Pro (`220 x 220 x 270 mm` volume,
       Sprite Direct Dual-Gear Extruder `0.8 mm @ 45 mm/s` retraction ceiling, `300 C`
       nozzle ceiling, `110 C` PEI bed ceiling, `CR-Touch` 25-point leveling `G29`/`M420 S1`).
     - Generates preflight/prime G-code or audits uploaded `.gcode` files for out-of-bounds
       axes, unsafe temperatures, and filament/time estimates.
  3. Tracked Tank-Tread Robot Arm + Dual 3D Scanner (`Eye-in-Hand + Eye-to-Hand`) SE(3) Calibration:
     - Computes forward kinematics for the tracked base (`x_b, y_b, theta_b`) + 4-DOF arm
       (`q1_waist, q2_shoulder, q3_elbow, q4_wrist`), transforms a 3D point observed by the
       overhead scanner (`P_overhead`) and the wrist-mounted scanner (`P_hand`) into the
       common workshop world frame, and measures the cross-witness residual `||Delta_p||_2`
       for closed-loop `see -> plan -> move -> verify` pick-and-place.
  4. Organic Food-Scrap & Small-Ag Compost C:N Mass-Balance Engine (#28517):
     - Computes exact dry-matter Carbon-to-Nitrogen (`C:N`) ratio, bulk moisture `%`,
       and recommended carbon-brown amendment (`kg`) to hit the `28:1` thermophilic aerobic
       window (`25:1` to `30:1`) so kitchen organic scraps become high-value local soil inputs.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Tuple


# ---------------------------------------------------------------------------
# 1. Artilume T1 Laser Engraver Raster-to-GCode Engine
# ---------------------------------------------------------------------------

DEFAULT_ARTILUME_T1_PROFILE: Dict[str, Any] = {
    "machine_id": "artilume_t1_laser",
    "display_name": "Artilume T1 Diode Laser Engraver (GRBL 1.1 / G-Code Profile)",
    "protocol": "GRBL_1_1_GCODE",
    "work_area_mm": {"x": 300.0, "y": 300.0},
    "s_value_max": 1000,
    "max_feed_mm_min": 6000.0,
    "default_line_interval_mm": 0.10,
    "safety_interlock_required": True,
    "estop_gcode": "M5\nG0 F1000\nM9\n",
    "spec_sheet_status": "READY_FOR_USER_SPEC_IMAGE_OVERRIDE",
}


def generate_artilume_t1_raster_gcode(
    grayscale_grid: List[List[int]],
    width_mm: float = 40.0,
    height_mm: float = 40.0,
    origin_x_mm: float = 10.0,
    origin_y_mm: float = 10.0,
    line_interval_mm: float = 0.20,
    feed_mm_min: float = 1800.0,
    travel_mm_min: float = 3600.0,
    max_power_pct: float = 65.0,
    s_max: int = 1000,
    passes: int = 1,
    mode: str = "M4",  # M4 dynamic laser power (GRBL 1.1) or M3 constant
    air_assist: bool = True,
    operator_armed: bool = False,
) -> Dict[str, Any]:
    """
    Converts a 2D grayscale grid (0=black/full burn, 255=white/no burn) into
    bidirectional raster G-code with explicit hardware safety interlocks.
    If `operator_armed` is False, generates a dry-run framing/simulation job with S0 (`M5`).
    """
    rows = len(grayscale_grid)
    cols = len(grayscale_grid[0]) if rows > 0 else 0
    if rows == 0 or cols == 0:
        raise ValueError("grayscale_grid must be non-empty")

    width_mm = max(1.0, min(float(width_mm), 300.0))
    height_mm = max(1.0, min(float(height_mm), 300.0))
    line_interval_mm = max(0.05, min(float(line_interval_mm), 2.0))
    feed_mm_min = max(60.0, min(float(feed_mm_min), 6000.0))
    travel_mm_min = max(300.0, min(float(travel_mm_min), 9000.0))
    max_power_pct = max(0.0, min(float(max_power_pct), 100.0))
    passes = max(1, min(int(passes), 10))
    laser_cmd = "M4" if str(mode).upper() == "M4" else "M3"

    dx = width_mm / max(1, cols)
    dy = height_mm / max(1, rows)

    lines: List[str] = [
        "; === XI LOCAL WORKSHOP: ARTILUME T1 RASTER JOB ===",
        f"; Grid: {cols}x{rows} px | Size: {width_mm:.2f}x{height_mm:.2f} mm | Origin: ({origin_x_mm:.2f}, {origin_y_mm:.2f}) mm",
        f"; Feed: {feed_mm_min:.0f} mm/min | Max Power: {max_power_pct:.1f}% (S_max={s_max}) | Passes: {passes}",
        f"; Safety Interlock Armed: {'YES (LIVE EMISSION)' if operator_armed else 'NO (DRY-RUN S0 FRAMING ONLY)'}",
        "G21 ; millimeters",
        "G90 ; absolute positioning",
        "M5 S0 ; ensure laser is OFF before travel",
    ]
    if air_assist and operator_armed:
        lines.append("M8 ; air assist ON")

    # Framing trace at S0
    lines.append(f"G0 X{origin_x_mm:.3f} Y{origin_y_mm:.3f} F{travel_mm_min:.0f}")
    lines.append(f"G0 X{origin_x_mm + width_mm:.3f} Y{origin_y_mm:.3f}")
    lines.append(f"G0 X{origin_x_mm + width_mm:.3f} Y{origin_y_mm + height_mm:.3f}")
    lines.append(f"G0 X{origin_x_mm:.3f} Y{origin_y_mm + height_mm:.3f}")
    lines.append(f"G0 X{origin_x_mm:.3f} Y{origin_y_mm:.3f}")

    if operator_armed:
        lines.append(f"{laser_cmd} S0 ; arm dynamic laser mode at zero power")
    else:
        lines.append("M5 S0 ; operator_armed=False -> dry-run lock active")

    burn_segments = 0
    total_path_mm = 4.0 * (width_mm + height_mm)

    for p_idx in range(passes):
        lines.append(f"; --- PASS {p_idx + 1} OF {passes} ---")
        for r in range(rows):
            y_pos = origin_y_mm + (rows - 1 - r) * dy
            reverse = (r % 2 == 1)
            col_indices = range(cols - 1, -1, -1) if reverse else range(cols)
            start_x = origin_x_mm + (cols - 1) * dx if reverse else origin_x_mm
            lines.append(f"G0 X{start_x:.3f} Y{y_pos:.3f} S0 F{travel_mm_min:.0f}")

            for c in col_indices:
                val = max(0, min(255, int(grayscale_grid[r][c])))
                darkness = (255.0 - float(val)) / 255.0
                if darkness <= 0.02 or not operator_armed:
                    s_val = 0
                else:
                    s_val = int(round(darkness * (max_power_pct / 100.0) * s_max))
                next_x = origin_x_mm + (c * dx if reverse else (c + 1) * dx)
                if s_val > 0:
                    burn_segments += 1
                lines.append(f"G1 X{next_x:.3f} Y{y_pos:.3f} S{s_val} F{feed_mm_min:.0f}")
                total_path_mm += dx
            lines.append("M5 S0 ; row-end laser blanking")

    lines.extend([
        "M5 S0 ; disarm laser immediately",
        "M9 ; air assist OFF",
        f"G0 X{origin_x_mm:.3f} Y{origin_y_mm:.3f} F{travel_mm_min:.0f}",
        "; === END OF ARTILUME T1 JOB ===",
    ])

    gcode_text = "\n".join(lines) + "\n"
    est_minutes = total_path_mm / max(100.0, feed_mm_min)
    return {
        "schema": "xi.workshop.artilume_t1_job.v1",
        "operator_armed": bool(operator_armed),
        "live_laser_commands_emitted": bool(operator_armed and burn_segments > 0),
        "grid_shape": [rows, cols],
        "dimensions_mm": {"width": width_mm, "height": height_mm, "origin_x": origin_x_mm, "origin_y": origin_y_mm},
        "burn_segments": burn_segments,
        "passes": passes,
        "estimated_duration_min": round(est_minutes, 3),
        "line_count": len(lines),
        "gcode_sha256": hashlib.sha256(gcode_text.encode("utf-8")).hexdigest(),
        "gcode": gcode_text,
    }


# ---------------------------------------------------------------------------
# 2. Creality Ender-3 S1 Pro AI Auto-Grab Print & Envelope Guard
# ---------------------------------------------------------------------------

ENDER_S1_PRO_SPEC: Dict[str, Any] = {
    "machine_id": "creality_ender_3_s1_pro",
    "display_name": "Creality Ender-3 S1 Pro (Sprite Direct-Drive 300°C + CR-Touch)",
    "build_volume_mm": {"x": 220.0, "y": 220.0, "z": 270.0},
    "max_nozzle_temp_c": 300.0,
    "max_bed_temp_c": 110.0,
    "extruder_type": "Sprite Full-Metal Dual-Gear Direct Drive",
    "recommended_retraction": {"distance_mm": 0.8, "speed_mm_s": 45.0},
    "abl_sensor": "CR-Touch 25-point auto-leveling",
    "filament_presets": {
        "PLA": {"nozzle_c": 205, "bed_c": 60, "retract_mm": 0.8, "retract_mm_s": 45},
        "PETG": {"nozzle_c": 240, "bed_c": 75, "retract_mm": 1.0, "retract_mm_s": 40},
        "TPU_95A": {"nozzle_c": 225, "bed_c": 50, "retract_mm": 0.6, "retract_mm_s": 30},
        "ABS_ASA": {"nozzle_c": 255, "bed_c": 100, "retract_mm": 0.8, "retract_mm_s": 45},
    },
}


def prepare_and_audit_ender_s1_pro_job(
    filament: str = "PLA",
    nozzle_temp_c: float | None = None,
    bed_temp_c: float | None = None,
    use_cr_touch_mesh: bool = True,
    body_gcode: str = "",
    operator_confirmed_start: bool = False,
) -> Dict[str, Any]:
    """
    Generates a complete Ender-3 S1 Pro start/prime/body/end G-code job and audits
    every coordinate and temperature command against the S1 Pro hardware limits.
    """
    preset = ENDER_S1_PRO_SPEC["filament_presets"].get(
        filament.upper(), ENDER_S1_PRO_SPEC["filament_presets"]["PLA"]
    )
    noz_c = float(nozzle_temp_c if nozzle_temp_c is not None else preset["nozzle_c"])
    bed_c = float(bed_temp_c if bed_temp_c is not None else preset["bed_c"])

    violations: List[str] = []
    if noz_c > ENDER_S1_PRO_SPEC["max_nozzle_temp_c"] or noz_c < 0.0:
        violations.append(f"Nozzle temp {noz_c:.1f}C exceeds Ender-3 S1 Pro Sprite limit (300.0C)")
    if bed_c > ENDER_S1_PRO_SPEC["max_bed_temp_c"] or bed_c < 0.0:
        violations.append(f"Bed temp {bed_c:.1f}C exceeds Ender-3 S1 Pro PEI bed limit (110.0C)")

    start_lines = [
        "; === XI LOCAL WORKSHOP: CREALITY ENDER-3 S1 PRO ===",
        f"; Filament: {filament.upper()} | Nozzle: {noz_c:.0f}C | Bed: {bed_c:.0f}C | Sprite Direct Retract: {preset['retract_mm']}mm @{preset['retract_mm_s']}mm/s",
        "G90 ; use absolute coordinates",
        "M83 ; extruder relative mode",
        f"M140 S{bed_c:.0f} ; set bed temp",
        "M104 S150 ; warm nozzle without oozing during CR-Touch homing",
        f"M190 S{bed_c:.0f} ; wait for bed temp",
        "G28 ; home all axes",
        "M420 S1 Z2 ; recall CR-Touch UBL mesh" if use_cr_touch_mesh else "G29 ; probe fresh CR-Touch mesh",
        f"M104 S{noz_c:.0f} ; set final nozzle temp",
        "G1 Z5.0 F3000 ; lift nozzle",
        "G1 X2.0 Y20.0 Z0.28 F5000.0 ; move to Sprite prime-line start",
        f"M109 S{noz_c:.0f} ; wait for nozzle temp",
        "G92 E0",
        "G1 Y180.0 E15.0 F1500.0 ; prime line 1",
        "G1 X2.3 Y180.0 F5000.0 ; step over",
        "G1 Y20.0 E15.0 F1500.0 ; prime line 2",
        "G92 E0",
    ]

    if not body_gcode.strip():
        # Default calibration calibration cube base square (20x20mm centered at 110,110)
        body_lines = [
            "; --- Calibration First-Layer Square (20x20mm at bed center 110,110) ---",
            "G1 Z0.20 F1200",
            "G1 X100.0 Y100.0 F4800",
            "G1 X120.0 Y100.0 E0.65 F1800",
            "G1 X120.0 Y120.0 E0.65 F1800",
            "G1 X100.0 Y120.0 E0.65 F1800",
            "G1 X100.0 Y100.0 E0.65 F1800",
            f"G1 E-{preset['retract_mm']:.2f} F{preset['retract_mm_s'] * 60:.0f} ; Sprite direct retraction",
        ]
    else:
        body_lines = [ln.rstrip() for ln in body_gcode.splitlines()]

    end_lines = [
        "; --- End G-Code ---",
        "G91 ; relative positioning",
        "G1 E-2.0 Z5.0 F2400 ; retract and raise Z",
        "G90 ; absolute positioning",
        "G1 X5.0 Y215.0 F3000 ; present print on PEI plate",
        "M106 S0 ; turn off part cooling fan",
        "M104 S0 ; turn off nozzle heater",
        "M140 S0 ; turn off bed heater",
        "M84 X Y E ; disable steppers",
    ]

    all_lines = start_lines + body_lines + end_lines
    bbox = {"min_x": 220.0, "max_x": 0.0, "min_y": 220.0, "max_y": 0.0, "max_z": 0.0}
    extruded_mm = 0.0

    for raw_ln in body_lines:
        ln = raw_ln.split(";")[0].strip().upper()
        if not (ln.startswith("G0") or ln.startswith("G1")):
            continue
        for token in ln.split()[1:]:
            if len(token) < 2:
                continue
            axis = token[0]
            try:
                val = float(token[1:])
            except ValueError:
                continue
            if axis == "X":
                bbox["min_x"] = min(bbox["min_x"], val)
                bbox["max_x"] = max(bbox["max_x"], val)
                if val < 0.0 or val > ENDER_S1_PRO_SPEC["build_volume_mm"]["x"]:
                    violations.append(f"X={val}mm outside 0..220mm build volume")
            elif axis == "Y":
                bbox["min_y"] = min(bbox["min_y"], val)
                bbox["max_y"] = max(bbox["max_y"], val)
                if val < 0.0 or val > ENDER_S1_PRO_SPEC["build_volume_mm"]["y"]:
                    violations.append(f"Y={val}mm outside 0..220mm build volume")
            elif axis == "Z":
                bbox["max_z"] = max(bbox["max_z"], val)
                if val < 0.0 or val > ENDER_S1_PRO_SPEC["build_volume_mm"]["z"]:
                    violations.append(f"Z={val}mm outside 0..270mm build volume")
            elif axis == "E" and val > 0:
                extruded_mm += val

    full_text = "\n".join(all_lines) + "\n"
    return {
        "schema": "xi.workshop.ender_s1_pro_job.v1",
        "machine_id": ENDER_S1_PRO_SPEC["machine_id"],
        "filament": filament.upper(),
        "nozzle_temp_c": noz_c,
        "bed_temp_c": bed_c,
        "within_hardware_envelope": len(violations) == 0,
        "violations": violations,
        "operator_confirmed_start": bool(operator_confirmed_start),
        "dispatch_state": "READY_TO_STREAM_ON_OPERATOR_START" if len(violations) == 0 else "BLOCKED_ENVELOPE_VIOLATION",
        "bounding_box_mm": bbox,
        "extruded_filament_mm": round(extruded_mm + 30.0, 2),
        "gcode_sha256": hashlib.sha256(full_text.encode("utf-8")).hexdigest(),
        "gcode": full_text,
    }


# ---------------------------------------------------------------------------
# 3. Tracked Tank-Tread Robot Arm + Dual 3D Scanner Calibration (Eye-in-Hand + Eye-to-Hand)
# ---------------------------------------------------------------------------

def reconcile_dual_scanner_tracked_arm(
    tread_pose_mm_deg: Dict[str, float] | None = None,
    joint_angles_deg: Dict[str, float] | None = None,
    overhead_camera_pose_mm: Dict[str, float] | None = None,
    overhead_observed_point_mm: Tuple[float, float, float] = (35.0, -20.0, -480.0),
    wrist_observed_point_mm: Tuple[float, float, float] | None = None,
) -> Dict[str, Any]:
    """
    Computes:
      1) Forward kinematics of the 1,000+ piece tracked tank-tread robot arm in workshop
         world coordinates `(X, Y, Z)` mm.
      2) World coordinate of a target part observed by the fixed overhead 3D scanner
         (`Eye-to-Hand`: `P_world_overhead`).
      3) World coordinate of the same target part observed by the wrist-mounted 3D scanner
         (`Eye-in-Hand`: `P_world_wrist`).
      4) Cross-witness calibration discrepancy `||P_world_overhead - P_world_wrist||_2`
         and corrective delta vector `Delta_p` for the closed-loop `see -> act -> check` controller.
    """
    base = tread_pose_mm_deg or {"x_mm": 120.0, "y_mm": 80.0, "yaw_deg": 15.0}
    joints = joint_angles_deg or {"waist_deg": 20.0, "shoulder_deg": 35.0, "elbow_deg": -25.0, "wrist_pitch_deg": -10.0}
    overhead_cam = overhead_camera_pose_mm or {"x_mm": 250.0, "y_mm": 150.0, "z_mm": 500.0}

    # Link lengths (mm) for a 1000-piece tracked technical robot arm
    L_base_z = 65.0
    L_upper = 115.0
    L_forearm = 105.0
    L_gripper = 60.0

    total_yaw_rad = math.radians(float(base["yaw_deg"]) + float(joints["waist_deg"]))
    sh_rad = math.radians(float(joints["shoulder_deg"]))
    el_rad = math.radians(float(joints["shoulder_deg"]) + float(joints["elbow_deg"]))
    wr_rad = math.radians(
        float(joints["shoulder_deg"]) + float(joints["elbow_deg"]) + float(joints["wrist_pitch_deg"])
    )

    radial_reach = (
        L_upper * math.cos(sh_rad)
        + L_forearm * math.cos(el_rad)
        + L_gripper * math.cos(wr_rad)
    )
    gripper_x = float(base["x_mm"]) + radial_reach * math.cos(total_yaw_rad)
    gripper_y = float(base["y_mm"]) + radial_reach * math.sin(total_yaw_rad)
    gripper_z = (
        L_base_z
        + L_upper * math.sin(sh_rad)
        + L_forearm * math.sin(el_rad)
        + L_gripper * math.sin(wr_rad)
    )

    # Overhead camera looks straight down (-Z in camera frame -> +Z offset from camera height)
    p_world_overhead = (
        float(overhead_cam["x_mm"]) + float(overhead_observed_point_mm[0]),
        float(overhead_cam["y_mm"]) + float(overhead_observed_point_mm[1]),
        float(overhead_cam["z_mm"]) + float(overhead_observed_point_mm[2]),
    )

    # If wrist_observed_point_mm is None, synthesize a realistic local observation with 1.5 mm sensor noise
    if wrist_observed_point_mm is None:
        dx_w = p_world_overhead[0] - gripper_x + 1.2
        dy_w = p_world_overhead[1] - gripper_y - 0.9
        dz_w = p_world_overhead[2] - gripper_z + 0.5
        # Express in local yaw-aligned wrist frame
        c_y = math.cos(-total_yaw_rad)
        s_y = math.sin(-total_yaw_rad)
        wrist_observed_point_mm = (
            dx_w * c_y - dy_w * s_y,
            dx_w * s_y + dy_w * c_y,
            dz_w,
        )

    wx, wy, wz = (
        float(wrist_observed_point_mm[0]),
        float(wrist_observed_point_mm[1]),
        float(wrist_observed_point_mm[2]),
    )
    c_pos = math.cos(total_yaw_rad)
    s_pos = math.sin(total_yaw_rad)
    p_world_wrist = (
        gripper_x + (wx * c_pos - wy * s_pos),
        gripper_y + (wx * s_pos + wy * c_pos),
        gripper_z + wz,
    )

    discrepancy_vec = (
        round(p_world_overhead[0] - p_world_wrist[0], 4),
        round(p_world_overhead[1] - p_world_wrist[1], 4),
        round(p_world_overhead[2] - p_world_wrist[2], 4),
    )
    discrepancy_norm_mm = math.sqrt(sum(d * d for d in discrepancy_vec))

    # Fused target estimate (weighted 50/50 between overhead world lock and close-range wrist scanner)
    fused_target = (
        round(0.5 * (p_world_overhead[0] + p_world_wrist[0]), 3),
        round(0.5 * (p_world_overhead[1] + p_world_wrist[1]), 3),
        round(0.5 * (p_world_overhead[2] + p_world_wrist[2]), 3),
    )
    move_delta_from_gripper = (
        round(fused_target[0] - gripper_x, 3),
        round(fused_target[1] - gripper_y, 3),
        round(fused_target[2] - gripper_z, 3),
    )

    return {
        "schema": "xi.workshop.dual_scanner_tracked_arm.v1",
        "architecture": "EYE_IN_HAND_PLUS_EYE_TO_HAND_SE3",
        "gripper_world_pose_mm": {
            "x": round(gripper_x, 3),
            "y": round(gripper_y, 3),
            "z": round(gripper_z, 3),
            "yaw_deg": round(math.degrees(total_yaw_rad), 2),
        },
        "p_world_overhead_mm": [round(v, 3) for v in p_world_overhead],
        "p_world_wrist_mm": [round(v, 3) for v in p_world_wrist],
        "cross_witness_discrepancy_mm": round(discrepancy_norm_mm, 4),
        "calibration_locked": discrepancy_norm_mm <= 5.0,
        "fused_part_world_mm": list(fused_target),
        "next_servo_step_delta_mm": list(move_delta_from_gripper),
    }


# ---------------------------------------------------------------------------
# 4. Organic Food-Scrap & Small-Ag Compost C:N Mass-Balance Engine (#28517)
# ---------------------------------------------------------------------------

ORGANIC_FEEDSTOCK_LIBRARY: Dict[str, Dict[str, float]] = {
    "organic_veg_fruit_scraps": {"cn_ratio": 15.0, "moisture_pct": 80.0, "n_dry_pct": 2.7},
    "used_coffee_grounds": {"cn_ratio": 20.0, "moisture_pct": 65.0, "n_dry_pct": 2.3},
    "crushed_eggshells": {"cn_ratio": 12.0, "moisture_pct": 5.0, "n_dry_pct": 1.2},
    "dry_autumn_leaves": {"cn_ratio": 60.0, "moisture_pct": 15.0, "n_dry_pct": 0.8},
    "shredded_unbleached_cardboard": {"cn_ratio": 350.0, "moisture_pct": 8.0, "n_dry_pct": 0.12},
    "untreated_wood_shavings": {"cn_ratio": 400.0, "moisture_pct": 10.0, "n_dry_pct": 0.11},
}


def compute_organic_scrap_ag_balance(
    veg_scraps_kg: float = 4.0,
    coffee_grounds_kg: float = 1.0,
    dry_leaves_kg: float = 2.0,
    shredded_cardboard_kg: float = 0.5,
    target_cn_ratio: float = 28.0,
) -> Dict[str, Any]:
    """
    Computes the dry-matter Carbon-to-Nitrogen (C:N) mass balance and bulk moisture %
    for turning organic kitchen scraps into thermophilic compost for small local growers.
    Also solves for the exact additional kg of dry leaves or shredded cardboard needed
    if the pile is too nitrogen-rich (C:N < 25:1, which causes ammonia odor loss).
    """
    inputs = [
        ("organic_veg_fruit_scraps", max(0.0, float(veg_scraps_kg))),
        ("used_coffee_grounds", max(0.0, float(coffee_grounds_kg))),
        ("dry_autumn_leaves", max(0.0, float(dry_leaves_kg))),
        ("shredded_unbleached_cardboard", max(0.0, float(shredded_cardboard_kg))),
    ]
    total_wet_kg = sum(w for _, w in inputs)
    if total_wet_kg <= 0:
        raise ValueError("Total feedstock mass must be positive")

    total_dry_kg = 0.0
    total_water_kg = 0.0
    total_n_kg = 0.0
    total_c_kg = 0.0

    for key, wet_kg in inputs:
        spec = ORGANIC_FEEDSTOCK_LIBRARY[key]
        water_frac = spec["moisture_pct"] / 100.0
        dry_kg = wet_kg * (1.0 - water_frac)
        water_kg = wet_kg * water_frac
        n_kg = dry_kg * (spec["n_dry_pct"] / 100.0)
        c_kg = n_kg * spec["cn_ratio"]

        total_dry_kg += dry_kg
        total_water_kg += water_kg
        total_n_kg += n_kg
        total_c_kg += c_kg

    current_cn = total_c_kg / max(1e-9, total_n_kg)
    bulk_moisture_pct = (total_water_kg / total_wet_kg) * 100.0

    # Solve for additional dry_autumn_leaves needed to reach target_cn_ratio (28:1)
    leaf_spec = ORGANIC_FEEDSTOCK_LIBRARY["dry_autumn_leaves"]
    leaf_dry_per_wet = 1.0 - (leaf_spec["moisture_pct"] / 100.0)
    leaf_n_per_wet = leaf_dry_per_wet * (leaf_spec["n_dry_pct"] / 100.0)
    leaf_c_per_wet = leaf_n_per_wet * leaf_spec["cn_ratio"]

    if current_cn < target_cn_ratio:
        c_deficit = target_cn_ratio * total_n_kg - total_c_kg
        net_c_per_kg_leaf = leaf_c_per_wet - target_cn_ratio * leaf_n_per_wet
        recommended_extra_leaves_kg = max(0.0, c_deficit / max(1e-9, net_c_per_kg_leaf))
    else:
        recommended_extra_leaves_kg = 0.0

    in_optimal_cn_band = 24.0 <= current_cn <= 34.0
    in_optimal_moisture_band = 45.0 <= bulk_moisture_pct <= 65.0

    return {
        "schema": "xi.workshop.organic_scrap_ag_balance.v1",
        "total_wet_mass_kg": round(total_wet_kg, 3),
        "total_dry_mass_kg": round(total_dry_kg, 3),
        "total_carbon_kg": round(total_c_kg, 4),
        "total_nitrogen_kg": round(total_n_kg, 4),
        "current_cn_ratio": round(current_cn, 2),
        "target_cn_ratio": round(target_cn_ratio, 2),
        "bulk_moisture_pct": round(bulk_moisture_pct, 2),
        "in_optimal_cn_band_24_to_34": in_optimal_cn_band,
        "in_optimal_moisture_band_45_to_65": in_optimal_moisture_band,
        "recommended_extra_dry_leaves_kg": round(recommended_extra_leaves_kg, 3),
        "small_ag_grower_grade": (
            "GRADE_A_THERMOPHILIC_READY"
            if (in_optimal_cn_band and in_optimal_moisture_band)
            else "AMEND_WITH_CARBON_BROWNS_FOR_28_TO_1_BALANCE"
        ),
    }


# ---------------------------------------------------------------------------
# 5. AI Auto-Discovery Manifest & Optional Local HTTP Server
# ---------------------------------------------------------------------------

def get_workshop_discovery_manifest() -> Dict[str, Any]:
    return {
        "schema": "xi.calien_workshop.discovery.v1",
        "owner": "Calien",
        "host_target": "AUTUMN (Local Windows / Linux Workshop Desk)",
        "safety_policy": {
            "laser_interlock": "Artilume T1 jobs default to operator_armed=False (S0 framing only) until explicit physical start.",
            "printer_interlock": "Ender-3 S1 Pro jobs enforce 220x220x270mm, 300C Sprite nozzle, 110C PEI bed limits.",
            "emergency_stop_endpoint": "POST /api/workshop/estop -> emits M5 S0 (laser off) + M112 (printer halt).",
        },
        "machines": [
            DEFAULT_ARTILUME_T1_PROFILE,
            ENDER_S1_PRO_SPEC,
            {
                "machine_id": "tracked_tank_arm_dual_scanner",
                "display_name": "1,000+ Piece Tracked Tank-Tread Arm + Dual 3D Scanner (Eye-in-Hand + Eye-to-Hand)",
                "calibration_mode": "SE(3) Dual-Witness Reconciliation",
            },
            {
                "machine_id": "organic_scrap_ag_compost_desk",
                "display_name": "Organic Food-Scrap to Small-Ag C:N Mass-Balance Planner",
                "target_cn_ratio": 28.0,
            },
        ],
        "ai_callable_endpoints": [
            {"method": "GET", "path": "/api/workshop/discover"},
            {"method": "POST", "path": "/api/workshop/artilume/raster-to-gcode"},
            {"method": "POST", "path": "/api/workshop/ender/prepare-gcode"},
            {"method": "POST", "path": "/api/workshop/robot-arm/calibrate-dual-scanner"},
            {"method": "POST", "path": "/api/workshop/ag-compost/cn-balance"},
            {"method": "POST", "path": "/api/workshop/estop"},
        ],
    }


def run_verification() -> Dict[str, Any]:
    # 1. Artilume T1 dry-run safety lock check (operator_armed=False -> no S>0 commands)
    sample_grid = [
        [0, 128, 255, 0],
        [64, 0, 192, 255],
        [255, 64, 0, 128],
        [0, 255, 64, 0],
    ]
    t1_dry = generate_artilume_t1_raster_gcode(sample_grid, operator_armed=False)
    t1_armed = generate_artilume_t1_raster_gcode(sample_grid, operator_armed=True, max_power_pct=70.0)

    # 2. Ender-3 S1 Pro safe job vs out-of-bounds job
    ender_ok = prepare_and_audit_ender_s1_pro_job(filament="PETG")
    ender_bad = prepare_and_audit_ender_s1_pro_job(
        filament="PLA",
        nozzle_temp_c=315.0,
        body_gcode="G1 X245.0 Y100.0 Z0.2 E1.0 F1500",
    )

    # 3. Dual 3D scanner + tracked robot arm calibration
    arm_cal = reconcile_dual_scanner_tracked_arm()

    # 4. Organic scrap C:N mass balance (unbalanced kitchen scraps vs amended 28:1 pile)
    ag_raw = compute_organic_scrap_ag_balance(veg_scraps_kg=5.0, coffee_grounds_kg=1.0, dry_leaves_kg=0.5, shredded_cardboard_kg=0.0)
    ag_balanced = compute_organic_scrap_ag_balance(
        veg_scraps_kg=5.0,
        coffee_grounds_kg=1.0,
        dry_leaves_kg=0.5 + ag_raw["recommended_extra_dry_leaves_kg"],
        shredded_cardboard_kg=0.0,
    )

    manifest = get_workshop_discovery_manifest()

    gates = {
        "1_artilume_t1_unarmed_emits_zero_laser_power": (
            t1_dry["live_laser_commands_emitted"] is False
            and t1_dry["burn_segments"] == 0
            and "S700" not in t1_dry["gcode"]
        ),
        "2_artilume_t1_armed_emits_bounded_grbl_raster_with_m5_blanking": (
            t1_armed["live_laser_commands_emitted"] is True
            and t1_armed["burn_segments"] > 0
            and "M4 S0" in t1_armed["gcode"]
            and t1_armed["gcode"].strip().endswith("; === END OF ARTILUME T1 JOB ===")
        ),
        "3_ender_s1_pro_sprite_and_cr_touch_valid_job_passes": (
            ender_ok["within_hardware_envelope"] is True
            and ender_ok["nozzle_temp_c"] == 240.0
            and "M420 S1" in ender_ok["gcode"]
        ),
        "4_ender_s1_pro_catches_300c_and_220mm_envelope_violations": (
            ender_bad["within_hardware_envelope"] is False
            and len(ender_bad["violations"]) == 2
        ),
        "5_dual_scanner_tracked_arm_eye_in_hand_and_eye_to_hand_reconcile": (
            arm_cal["calibration_locked"] is True
            and arm_cal["cross_witness_discrepancy_mm"] < 3.0
        ),
        "6_organic_food_scrap_cn_solver_hits_28_to_1_thermophilic_target": (
            ag_raw["current_cn_ratio"] < 24.0
            and ag_balanced["current_cn_ratio"] == 28.0
            and ag_balanced["in_optimal_cn_band_24_to_34"] is True
        ),
        "7_ai_autodiscovery_manifest_exposes_all_4_workshop_citizens": (
            len(manifest["machines"]) == 4
            and len(manifest["ai_callable_endpoints"]) == 6
        ),
    }

    return {
        "schema": "xi.calien_workshop_bench.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "samples": {
            "artilume_t1_armed_summary": {k: v for k, v in t1_armed.items() if k != "gcode"},
            "ender_s1_pro_petg_summary": {k: v for k, v in ender_ok.items() if k != "gcode"},
            "tracked_arm_dual_scanner": arm_cal,
            "organic_ag_compost_balanced": ag_balanced,
        },
    }


class WorkshopHTTPHandler(BaseHTTPRequestHandler):
    def _send_json(self, code: int, payload: Dict[str, Any]) -> None:
        raw = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self) -> None:
        if self.path.startswith("/api/workshop/discover"):
            self._send_json(200, get_workshop_discovery_manifest())
        else:
            self._send_json(200, run_verification())

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        body = json.loads(self.rfile.read(length).decode("utf-8") or "{}") if length > 0 else {}
        if self.path.startswith("/api/workshop/estop"):
            self._send_json(200, {
                "ok": True,
                "status": "EMERGENCY_STOP_LATCHED",
                "artilume_t1_gcode": "M5 S0\nM9\n",
                "ender_s1_pro_gcode": "M112\nM104 S0\nM140 S0\n",
            })
        elif self.path.startswith("/api/workshop/artilume/raster-to-gcode"):
            grid = body.get("grayscale_grid", [[0, 255], [255, 0]])
            self._send_json(200, generate_artilume_t1_raster_gcode(
                grid,
                width_mm=float(body.get("width_mm", 40.0)),
                height_mm=float(body.get("height_mm", 40.0)),
                feed_mm_min=float(body.get("feed_mm_min", 1800.0)),
                max_power_pct=float(body.get("max_power_pct", 65.0)),
                passes=int(body.get("passes", 1)),
                operator_armed=bool(body.get("operator_armed", False)),
            ))
        elif self.path.startswith("/api/workshop/ender/prepare-gcode"):
            self._send_json(200, prepare_and_audit_ender_s1_pro_job(
                filament=str(body.get("filament", "PLA")),
                nozzle_temp_c=body.get("nozzle_temp_c"),
                bed_temp_c=body.get("bed_temp_c"),
                body_gcode=str(body.get("body_gcode", "")),
                operator_confirmed_start=bool(body.get("operator_confirmed_start", False)),
            ))
        elif self.path.startswith("/api/workshop/robot-arm/calibrate-dual-scanner"):
            self._send_json(200, reconcile_dual_scanner_tracked_arm(
                tread_pose_mm_deg=body.get("tread_pose_mm_deg"),
                joint_angles_deg=body.get("joint_angles_deg"),
                overhead_camera_pose_mm=body.get("overhead_camera_pose_mm"),
            ))
        elif self.path.startswith("/api/workshop/ag-compost/cn-balance"):
            self._send_json(200, compute_organic_scrap_ag_balance(
                veg_scraps_kg=float(body.get("veg_scraps_kg", 4.0)),
                coffee_grounds_kg=float(body.get("coffee_grounds_kg", 1.0)),
                dry_leaves_kg=float(body.get("dry_leaves_kg", 2.0)),
                shredded_cardboard_kg=float(body.get("shredded_cardboard_kg", 0.5)),
            ))
        else:
            self._send_json(404, {"error": "unknown endpoint"})


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calien Local AI Workshop & Organic Ag Bench v1")
    parser.add_argument("--serve", type=int, default=0, help="Run local workshop HTTP API on port")
    args = parser.parse_args()
    if args.serve > 0:
        srv = HTTPServer(("127.0.0.1", args.serve), WorkshopHTTPHandler)
        print(f"Calien Workshop API listening on 127.0.0.1:{args.serve}")
        srv.serve_forever()
    else:
        report = run_verification()
        print(json.dumps(report, indent=2))
        sys.exit(0 if report["all_passed"] else 1)
