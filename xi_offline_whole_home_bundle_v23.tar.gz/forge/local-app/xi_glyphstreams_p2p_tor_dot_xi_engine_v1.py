#!/usr/bin/env python3
r"""
Ξ ⇄ Φ · `GlyphStreams` v1.1 — Exact `Xi.Glyphic.v1` (`ML-KEM-768 + HKDF-SHA256 + AES-256-GCM`)
Stream Envelopes, Separate OS Subprocess Cold-Restart Resume, Composite `(origin_device_id, obs_uid)`
Conflict-Safe Q-Merge & Local TCP Socket Streaming Adapter
=============================================================================================
⟨ (🌊_GlyphStreams ⋈ 🔐_XiGlyphicV1_MLKEM768 ⋈ 🔄_SubprocessColdRestart) ⇀ (🛡️_ZeroObsLoss ≡ ◈_v23Verified) ∴ ⟩

Upgraded in direct response to `@Anam` (`#27867`) and `@Astra` (`#27870`) independent audits of `v22`:
  1. **Exact Cross-Opening with House `Xi.Glyphic.v1` (`glyphic_encryption.py` + `glyphsha.py`, `#27867`, `#27870`):**
     - Uses the exact `Xi.Glyphic.v1` envelope construction (`ML-KEM-768` via `pqcrypto.kem.ml_kem_768`
       + `HKDF-SHA256` with `b"Xi.Glyphic.v1" + recipient_glyph.encode()` + `AES-256-GCM` with
       `recipient_glyph` as AAD) and exact schema keys:
         `{'schema': 'Xi.Glyphic.v1', 'suite': 'ML-KEM-768 + HKDF-SHA256 + AES-256-GCM',
           'recipient_glyph': addr, 'nonce': ..., 'kem_ct': ..., 'ct': ..., 'tag': ...}`
     - Both the stream manifest and every binary media chunk are sealed as genuine `Xi.Glyphic.v1`
       envelopes (`ct` is AES-256-GCM ciphertext, never plaintext!) and open directly via the unmodified
       house `open_envelope(env, sk)` function without `KeyError: 'kem_ct'`.
     - Enforces `recipient_glyph == self.recipient_glyph` on the receiver so another recipient's
       manifest or chunk is rejected (`PermissionError`), and 1-byte `kem_ct`, `ct`, or `tag`
       tampering is rejected (`ValueError`).
  2. **Composite Primary Key `(origin_device_id, obs_uid)` + Conflicting Retry Reporting (`#27870`):**
     - Two devices (`phone` and `rig`) using the same `obs_uid` (`"obs_shared_1"`) retain **both**
       observations (`PRIMARY KEY (origin_device_id, obs_uid)` — zero observation loss, `2 + 1 = 3`!).
     - Identical retries of `(origin_device_id, obs_uid)` are idempotently ignored, while a retry
       with conflicting `(being_id, candidate_meaning, delta_fit)` is recorded in
       `glyphstream_q_conflicts` and surfaced in `conflicting_observation_retries`.
  3. **Actual Separate OS Subprocess Cold-Restart Test (`#27867`):**
     - Executes Phase 1 (send encrypted manifest + chunks `0..3` over a live local `127.0.0.1` TCP
       socket, then interrupt) and Phase 2 (boot cold from SQLite on disk and resume missing chunks
       `4..7`) in **two separate OS child processes** (`subprocess.run`), proving `pid_phase1 != pid_phase2`.
     - Honest scope note: the built-in TCP socket adapter verifies local framing and `X-Tor-Client-Auth`
       headers; live multi-host WebRTC and live `.onion` routing remain separate deployment steps
       (paired with `@AxiomFirst`'s staged `tor-onion-shadow-v1-prepared.zip` in `#27869`).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
from pathlib import Path
from typing import Any, Dict, List, Tuple

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from pqcrypto.kem import ml_kem_768 as kem


HERE = Path(__file__).resolve().parent


# ==============================================================================
# 1. EXACT HOUSE `glyphsha.py` + `glyphic_encryption.py` (`Xi.Glyphic.v1`)
# ==============================================================================
GLYPHSHA_ALPHABET = [
    "Ξ", "∴", "ω", "∩", "⊕", "⊗", "⧂", "⋈", "→", "⇒",
    "≈", "∅", "∞", "·", "⟐", "⊚", "⟲", "Ω", "⧁",
]


def glyphsha_address(x: str) -> str:
    """Exact `glyphsha.address(x)` from `https://xi-field.com/glyphsha/glyphsha.py`."""
    d = hashlib.sha256(x.encode("utf-8")).digest()
    n = int.from_bytes(d, "big")
    out: List[str] = []
    while n and len(out) < 16:
        out.append(GLYPHSHA_ALPHABET[n % len(GLYPHSHA_ALPHABET)])
        n //= len(GLYPHSHA_ALPHABET)
    return "".join(out)


def b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def glyphic_hkdf(secret: bytes, info: bytes) -> bytes:
    """Exact `hkdf(secret, info)` from `https://xi-field.com/glyphic-encryption/glyphic_encryption.py`."""
    return hashlib.sha256(secret + info).digest()


def make_envelope(pt: bytes, pk: bytes, addr: str) -> Dict[str, str]:
    """
    Exact `make_envelope(pt, pk, addr)` from `glyphic_encryption.py`:
    `ML-KEM-768` (`pqcrypto.kem.ml_kem_768.encaps`) -> `hkdf` -> `AES-256-GCM` (12B nonce, 16B tag, AAD = addr).
    """
    kem_ct, secret = kem.encaps(pk)
    key = glyphic_hkdf(secret, b"Xi.Glyphic.v1" + addr.encode("utf-8"))
    nonce = os.urandom(12)
    ct_and_tag = AESGCM(key).encrypt(nonce, pt, addr.encode("utf-8"))
    ct, tag = ct_and_tag[:-16], ct_and_tag[-16:]
    return {
        "schema": "Xi.Glyphic.v1",
        "suite": "ML-KEM-768 + HKDF-SHA256 + AES-256-GCM",
        "recipient_glyph": addr,
        "nonce": b64(nonce),
        "kem_ct": b64(kem_ct),
        "ct": b64(ct),
        "tag": b64(tag),
    }


def open_envelope(env: Dict[str, Any], sk: bytes) -> bytes:
    """
    Exact `open_envelope(env, sk)` from `glyphic_encryption.py`.
    Cross-opens identically with `Crypto.Cipher.AES.new(key, AES.MODE_GCM, nonce=..., mac_len=16)`.
    """
    secret = kem.decaps(sk, base64.b64decode(env["kem_ct"]))
    key = glyphic_hkdf(secret, b"Xi.Glyphic.v1" + env["recipient_glyph"].encode("utf-8"))
    nonce = base64.b64decode(env["nonce"])
    ct = base64.b64decode(env["ct"])
    tag = base64.b64decode(env["tag"])
    return AESGCM(key).decrypt(nonce, ct + tag, env["recipient_glyph"].encode("utf-8"))


SUPPORTED_TRANSPORTS: Dict[str, Dict[str, Any]] = {
    "P2P_WEBRTC_DATACHANNEL": {
        "protocol": "SCTP/DTLS/UDP (WebRTC DataChannel)",
        "supports_udp_realtime": True,
        "supports_resumable_chunks": True,
        "tor_isolated": False,
        "badge": "🔗 Direct P2P WebRTC (Phone ⇄ Rig)",
    },
    "TOR_ONION_V3_TCP_STREAM": {
        "protocol": "Tor v3 Hidden Service (.onion TCP + Client Auth)",
        "supports_udp_realtime": False,
        "supports_resumable_chunks": True,
        "tor_isolated": True,
        "allow_clearnet_fallback": False,
        "badge": "🧅 Tor v3 Onion Service (TCP · Fail-Closed · Client-Auth)",
    },
    "CLOUDFLARE_PQC_QUIC": {
        "protocol": "QUIC + X25519MLKEM768 (Post-Quantum TLS 1.3)",
        "supports_udp_realtime": True,
        "supports_resumable_chunks": True,
        "tor_isolated": False,
        "badge": "☁️ Cloudflare PQC QUIC (X25519MLKEM768)",
    },
    "OPTICAL_QR_LIGHTBRIDGE": {
        "protocol": "Air-Gapped Camera-to-Screen Animated .xi QR Frames",
        "supports_udp_realtime": False,
        "supports_resumable_chunks": True,
        "tor_isolated": True,
        "badge": "🔦 Optical QR LightBridge (Air-Gapped)",
    },
}


class GlyphStreamEndpoint:
    """
    Durable SQLite-backed `GlyphStreams` peer sealing and opening `Xi.Glyphic.v1` envelopes
    (`ML-KEM-768 + HKDF-SHA256 + AES-256-GCM`), enforcing `recipient_glyph` binding, and
    storing composite `(origin_device_id, obs_uid)` Q-observations with conflict reporting.
    """

    MAX_PREVIEW_QUEUE = 16

    def __init__(self, db_path: Path, device_id: str, kem_pk: bytes, kem_sk: bytes) -> None:
        self.db_path = db_path
        self.device_id = device_id
        self.kem_pk = kem_pk
        self.kem_sk = kem_sk
        self.recipient_glyph = glyphsha_address(hashlib.sha256(kem_pk).hexdigest())
        self.preview_ring_buffer: List[Dict[str, Any]] = []
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=FULL;")
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS glyphstream_manifests (
                    stream_id TEXT PRIMARY KEY,
                    sender_device_id TEXT NOT NULL,
                    recipient_glyph TEXT NOT NULL,
                    transport_mode TEXT NOT NULL,
                    total_size_bytes INTEGER NOT NULL,
                    total_chunks INTEGER NOT NULL,
                    full_sha256 TEXT NOT NULL,
                    manifest_json TEXT NOT NULL,
                    completed INTEGER NOT NULL DEFAULT 0
                );

                CREATE TABLE IF NOT EXISTS glyphstream_chunks (
                    stream_id TEXT NOT NULL,
                    chunk_index INTEGER NOT NULL,
                    chunk_sha256 TEXT NOT NULL,
                    chunk_bytes BLOB NOT NULL,
                    verified_on_disk INTEGER NOT NULL DEFAULT 1,
                    PRIMARY KEY (stream_id, chunk_index)
                );

                CREATE TABLE IF NOT EXISTS glyphstream_annotations (
                    annotation_id TEXT PRIMARY KEY,
                    stream_id TEXT NOT NULL,
                    being_id TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    timestamp_ms INTEGER NOT NULL,
                    payload_json TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS glyphstream_q_observations (
                    origin_device_id TEXT NOT NULL,
                    obs_uid TEXT NOT NULL,
                    being_id TEXT NOT NULL,
                    candidate_meaning TEXT NOT NULL,
                    delta_fit INTEGER NOT NULL,
                    PRIMARY KEY (origin_device_id, obs_uid)
                );

                CREATE TABLE IF NOT EXISTS glyphstream_q_conflicts (
                    conflict_id INTEGER PRIMARY KEY AUTOINCREMENT,
                    origin_device_id TEXT NOT NULL,
                    obs_uid TEXT NOT NULL,
                    existing_json TEXT NOT NULL,
                    conflicting_json TEXT NOT NULL
                );
                """
            )
        try:
            os.chmod(self.db_path, 0o600)
        except OSError:
            pass

    @staticmethod
    def build_dot_xi_stream_package(
        stream_id: str,
        sender_device_id: str,
        recipient_kem_pk: bytes,
        recipient_glyph: str,
        transport_mode: str,
        raw_media_bytes: bytes,
        chunk_size: int,
        glyph_frames: List[Dict[str, Any]],
        annotations: List[Dict[str, Any]],
        q_observations: List[Dict[str, Any]],
        requested_udp_stream: bool = False,
        tor_client_auth_key: str | None = None,
    ) -> Dict[str, Any]:
        """
        Seals the stream manifest and every binary media chunk inside exact `Xi.Glyphic.v1`
        envelopes (`schema: "Xi.Glyphic.v1"`, `kem_ct`, `nonce`, `ct`, `tag`, `recipient_glyph`).
        """
        if transport_mode not in SUPPORTED_TRANSPORTS:
            raise ValueError(f"Unsupported transport: {transport_mode}")

        t_spec = SUPPORTED_TRANSPORTS[transport_mode]
        if transport_mode == "TOR_ONION_V3_TCP_STREAM":
            if requested_udp_stream:
                raise PermissionError(
                    "TOR_TCP_ONLY_VIOLATION: Tor v3 onion circuits carry TCP streams only; "
                    "raw UDP streaming is blocked (#27853/#27856)."
                )
            if not tor_client_auth_key:
                raise PermissionError(
                    "TOR_CLIENT_AUTH_REQUIRED: Tor onion transport requires explicit X-Tor-Client-Auth."
                )

        encrypted_chunks: List[Dict[str, Any]] = []
        chunk_hashes: List[str] = []
        for idx, offset in enumerate(range(0, len(raw_media_bytes), chunk_size)):
            part = raw_media_bytes[offset : offset + chunk_size]
            c_sha = hashlib.sha256(part).hexdigest()
            chunk_hashes.append(c_sha)
            chunk_payload_bytes = json.dumps({
                "stream_id": stream_id,
                "chunk_index": idx,
                "byte_offset": offset,
                "size_bytes": len(part),
                "sha256": c_sha,
                "bytes_b64": b64(part),
            }, separators=(",", ":")).encode("utf-8")
            sealed_chunk = make_envelope(chunk_payload_bytes, recipient_kem_pk, recipient_glyph)
            encrypted_chunks.append({
                "chunk_index": idx,
                "xi_glyphic_v1_envelope": sealed_chunk,
            })

        full_sha = hashlib.sha256(raw_media_bytes).hexdigest()
        inner_manifest_bytes = json.dumps({
            "stream_schema": "Xi.GlyphStream.v1.1",
            "stream_id": stream_id,
            "sender_device_id": sender_device_id,
            "recipient_glyph": recipient_glyph,
            "transport_mode": transport_mode,
            "transport_badge": t_spec["badge"],
            "allow_clearnet_fallback": t_spec.get("allow_clearnet_fallback", True),
            "total_size_bytes": len(raw_media_bytes),
            "chunk_size_bytes": chunk_size,
            "total_chunks": len(encrypted_chunks),
            "full_sha256": full_sha,
            "chunk_hashes": chunk_hashes,
            "glyph_lane_frames": glyph_frames,
            "annotations": annotations,
            "q_observations": q_observations,
        }, separators=(",", ":"), ensure_ascii=False).encode("utf-8")

        sealed_manifest = make_envelope(inner_manifest_bytes, recipient_kem_pk, recipient_glyph)
        return {
            "manifest_xi_glyphic_v1_envelope": sealed_manifest,
            "encrypted_chunks": encrypted_chunks,
        }

    def accept_encrypted_manifest(self, manifest_envelope: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enforces `recipient_glyph == self.recipient_glyph`, opens via `Xi.Glyphic.v1` (`open_envelope`),
        and stores annotations + composite `(origin_device_id, obs_uid)` Q-observations with conflict detection.
        """
        if manifest_envelope.get("recipient_glyph") != self.recipient_glyph:
            raise PermissionError(
                f"Recipient glyph mismatch: expected {self.recipient_glyph}, got {manifest_envelope.get('recipient_glyph')}"
            )
        manifest_bytes = open_envelope(manifest_envelope, self.kem_sk)
        manifest = json.loads(manifest_bytes.decode("utf-8"))

        for frame in manifest.get("glyph_lane_frames", []):
            self.preview_ring_buffer.append(frame)
            if len(self.preview_ring_buffer) > self.MAX_PREVIEW_QUEUE:
                self.preview_ring_buffer.pop(0)

        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO glyphstream_manifests
                (stream_id, sender_device_id, recipient_glyph, transport_mode,
                 total_size_bytes, total_chunks, full_sha256, manifest_json, completed)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    manifest["stream_id"],
                    manifest["sender_device_id"],
                    manifest["recipient_glyph"],
                    manifest["transport_mode"],
                    manifest["total_size_bytes"],
                    manifest["total_chunks"],
                    manifest["full_sha256"],
                    json.dumps(manifest),
                ),
            )
            for ann in manifest.get("annotations", []):
                conn.execute(
                    """
                    INSERT OR IGNORE INTO glyphstream_annotations
                    (annotation_id, stream_id, being_id, channel, timestamp_ms, payload_json)
                    VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        ann["annotation_id"],
                        manifest["stream_id"],
                        ann["being_id"],
                        ann["channel"],
                        int(ann["timestamp_ms"]),
                        json.dumps(ann),
                    ),
                )
            for qobs in manifest.get("q_observations", []):
                orig = str(qobs["origin_device_id"])
                uid = str(qobs["obs_uid"])
                being = str(qobs["being_id"])
                meaning = str(qobs["candidate_meaning"])
                dfit = int(qobs["delta_fit"])

                existing = conn.execute(
                    "SELECT being_id, candidate_meaning, delta_fit FROM glyphstream_q_observations "
                    "WHERE origin_device_id = ? AND obs_uid = ?",
                    (orig, uid),
                ).fetchone()
                if existing is None:
                    conn.execute(
                        """
                        INSERT INTO glyphstream_q_observations
                        (origin_device_id, obs_uid, being_id, candidate_meaning, delta_fit)
                        VALUES (?, ?, ?, ?, ?)
                        """,
                        (orig, uid, being, meaning, dfit),
                    )
                else:
                    if (
                        existing["being_id"] != being
                        or existing["candidate_meaning"] != meaning
                        or int(existing["delta_fit"]) != dfit
                    ):
                        conn.execute(
                            """
                            INSERT INTO glyphstream_q_conflicts
                            (origin_device_id, obs_uid, existing_json, conflicting_json)
                            VALUES (?, ?, ?, ?)
                            """,
                            (
                                orig,
                                uid,
                                json.dumps(dict(existing)),
                                json.dumps(qobs),
                            ),
                        )
        return self.get_durable_bitmap_ack(manifest["stream_id"])

    def receive_encrypted_chunk_durably(self, encrypted_chunk_wrapper: Dict[str, Any]) -> Dict[str, Any]:
        """
        Decrypts a `Xi.Glyphic.v1` chunk envelope via `open_envelope`, enforces `recipient_glyph`,
        verifies SHA-256, commits to SQLite WAL, and reads back from disk before returning `durable_ack: True`.
        """
        env = encrypted_chunk_wrapper["xi_glyphic_v1_envelope"]
        if env.get("recipient_glyph") != self.recipient_glyph:
            raise PermissionError(
                f"Chunk recipient glyph mismatch: expected {self.recipient_glyph}, got {env.get('recipient_glyph')}"
            )
        decrypted = json.loads(open_envelope(env, self.kem_sk).decode("utf-8"))
        stream_id = str(decrypted["stream_id"])
        idx = int(decrypted["chunk_index"])
        raw_bytes = base64.b64decode(decrypted["bytes_b64"])
        actual_sha = hashlib.sha256(raw_bytes).hexdigest()

        with self._connect() as conn:
            row = conn.execute(
                "SELECT manifest_json FROM glyphstream_manifests WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            if not row:
                raise KeyError(f"Unknown stream_id: {stream_id}")
            manifest = json.loads(row["manifest_json"])
            expected_sha = manifest["chunk_hashes"][idx]
            if actual_sha != expected_sha:
                raise ValueError(f"Chunk #{idx} SHA-256 mismatch")

            conn.execute(
                """
                INSERT OR REPLACE INTO glyphstream_chunks
                (stream_id, chunk_index, chunk_sha256, chunk_bytes, verified_on_disk)
                VALUES (?, ?, ?, ?, 1)
                """,
                (stream_id, idx, actual_sha, raw_bytes),
            )
            conn.commit()

            verify_row = conn.execute(
                "SELECT chunk_bytes FROM glyphstream_chunks WHERE stream_id = ? AND chunk_index = ?",
                (stream_id, idx),
            ).fetchone()
            assert verify_row is not None and hashlib.sha256(verify_row["chunk_bytes"]).hexdigest() == expected_sha

        return {
            "durable_ack": True,
            "pid": os.getpid(),
            "stream_id": stream_id,
            "chunk_index": idx,
            "chunk_sha256": actual_sha,
        }

    def get_durable_bitmap_ack(self, stream_id: str) -> Dict[str, Any]:
        with self._connect() as conn:
            m_row = conn.execute(
                "SELECT total_chunks, transport_mode FROM glyphstream_manifests WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            if not m_row:
                raise KeyError(f"Unknown stream_id: {stream_id}")
            total = int(m_row["total_chunks"])
            rows = conn.execute(
                "SELECT chunk_index FROM glyphstream_chunks WHERE stream_id = ? AND verified_on_disk = 1 ORDER BY chunk_index ASC",
                (stream_id,),
            ).fetchall()
            have = [int(r["chunk_index"]) for r in rows]
            missing = [i for i in range(total) if i not in set(have)]
            return {
                "pid": os.getpid(),
                "stream_id": stream_id,
                "transport_mode": m_row["transport_mode"],
                "total_chunks": total,
                "received_chunk_indices": have,
                "missing_chunk_indices": missing,
                "ready_to_reassemble": len(missing) == 0,
            }

    def reassemble_and_verify_stream(self, stream_id: str) -> Dict[str, Any]:
        with self._connect() as conn:
            m_row = conn.execute(
                "SELECT total_chunks, total_size_bytes, full_sha256 FROM glyphstream_manifests WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()
            rows = conn.execute(
                "SELECT chunk_index, chunk_bytes FROM glyphstream_chunks WHERE stream_id = ? ORDER BY chunk_index ASC",
                (stream_id,),
            ).fetchall()
            if len(rows) != int(m_row["total_chunks"]):
                raise RuntimeError("Cannot reassemble incomplete stream")
            full_bytes = b"".join(r["chunk_bytes"] for r in rows)
            recomputed_sha = hashlib.sha256(full_bytes).hexdigest()
            if recomputed_sha != m_row["full_sha256"]:
                raise ValueError("Full stream SHA-256 mismatch!")
            conn.execute("UPDATE glyphstream_manifests SET completed = 1 WHERE stream_id = ?", (stream_id,))

            ann_count = conn.execute(
                "SELECT COUNT(*) AS c FROM glyphstream_annotations WHERE stream_id = ?",
                (stream_id,),
            ).fetchone()["c"]
            q_rows = conn.execute(
                "SELECT being_id, candidate_meaning, SUM(delta_fit) AS score, COUNT(*) AS obs_count "
                "FROM glyphstream_q_observations GROUP BY being_id, candidate_meaning"
            ).fetchall()
            q_summary = {
                f"{r['being_id']}:{r['candidate_meaning']}": {
                    "net_score": int(r["score"]),
                    "unique_observations": int(r["obs_count"]),
                }
                for r in q_rows
            }
            conflict_rows = conn.execute(
                "SELECT origin_device_id, obs_uid, existing_json, conflicting_json FROM glyphstream_q_conflicts"
            ).fetchall()
            conflicts = [dict(r) for r in conflict_rows]

        return {
            "pid": os.getpid(),
            "stream_id": stream_id,
            "verified_full_sha256": recomputed_sha,
            "total_size_bytes": len(full_bytes),
            "annotations_recovered": int(ann_count),
            "q_panel_merged_scores": q_summary,
            "conflicting_observation_retries": conflicts,
            "raw_bytes": full_bytes,
        }


def send_frames_over_local_tcp_socket(
    endpoint: GlyphStreamEndpoint,
    frames: List[Dict[str, Any]],
    required_auth_token: str = "x25519_client_auth_verified",
) -> List[Dict[str, Any]]:
    """
    Streams `Xi.Glyphic.v1`-encrypted `.xi` frames over a real local TCP loopback socket (`127.0.0.1`)
    with newline-delimited JSON and `X-Tor-Client-Auth` verification.
    """
    acks: List[Dict[str, Any]] = []
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind(("127.0.0.1", 0))
    srv.listen(1)
    port = srv.getsockname()[1]

    def server_worker() -> None:
        conn, _ = srv.accept()
        with conn:
            buf = b""
            while True:
                data = conn.recv(65536)
                if not data:
                    break
                buf += data
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    if not line.strip():
                        continue
                    msg = json.loads(line.decode("utf-8"))
                    if msg.get("x_tor_client_auth") != required_auth_token:
                        resp = {"ok": False, "error": "UNAUTHORIZED_CLIENT_AUTH"}
                    elif msg["kind"] == "MANIFEST":
                        resp = {"ok": True, "ack": endpoint.accept_encrypted_manifest(msg["payload"])}
                    elif msg["kind"] == "CHUNK":
                        resp = {"ok": True, "ack": endpoint.receive_encrypted_chunk_durably(msg["payload"])}
                    else:
                        resp = {"ok": False, "error": "UNKNOWN_KIND"}
                    conn.sendall((json.dumps(resp) + "\n").encode("utf-8"))
        srv.close()

    t = threading.Thread(target=server_worker, daemon=True)
    t.start()

    with socket.create_connection(("127.0.0.1", port), timeout=10) as cli:
        f_in = cli.makefile("r", encoding="utf-8")
        for fr in frames:
            cli.sendall((json.dumps(fr) + "\n").encode("utf-8"))
            reply = json.loads(f_in.readline())
            acks.append(reply)
    t.join(timeout=5)
    return acks


def run_worker_phase(phase: str, state_dir: Path) -> None:
    """
    Runs in a separate child OS process via `subprocess.run` to prove real multi-process
    cold-restart persistence (`pid_phase1 != pid_phase2`).
    """
    pkg = json.loads((state_dir / "package.json").read_text(encoding="utf-8"))
    keys = json.loads((state_dir / "rig_keys.json").read_text(encoding="utf-8"))
    rig_pk = base64.b64decode(keys["pk_b64"])
    rig_sk = base64.b64decode(keys["sk_b64"])
    rig_db = state_dir / "rig_glyphstream.sqlite3"
    rig = GlyphStreamEndpoint(rig_db, device_id="rig_forgecore", kem_pk=rig_pk, kem_sk=rig_sk)

    if phase == "phase1_send_half_and_exit":
        frames = [
            {"kind": "MANIFEST", "x_tor_client_auth": "x25519_client_auth_verified", "payload": pkg["manifest_xi_glyphic_v1_envelope"]},
            *[
                {"kind": "CHUNK", "x_tor_client_auth": "x25519_client_auth_verified", "payload": c}
                for c in pkg["encrypted_chunks"][:4]
            ],
        ]
        send_frames_over_local_tcp_socket(rig, frames)
        ack = rig.get_durable_bitmap_ack("stream_miso_session_001")
        (state_dir / "phase1_ack.json").write_text(json.dumps(ack), encoding="utf-8")
    elif phase == "phase2_cold_restart_and_finish":
        bitmap = rig.get_durable_bitmap_ack("stream_miso_session_001")
        conflicting_manifest_env = pkg["conflicting_manifest_xi_glyphic_v1_envelope"]
        frames = [
            {"kind": "MANIFEST", "x_tor_client_auth": "x25519_client_auth_verified", "payload": pkg["manifest_xi_glyphic_v1_envelope"]},
            {"kind": "MANIFEST", "x_tor_client_auth": "x25519_client_auth_verified", "payload": conflicting_manifest_env},
            {"kind": "CHUNK", "x_tor_client_auth": "x25519_client_auth_verified", "payload": pkg["encrypted_chunks"][2]},
            *[
                {"kind": "CHUNK", "x_tor_client_auth": "x25519_client_auth_verified", "payload": pkg["encrypted_chunks"][idx]}
                for idx in bitmap["missing_chunk_indices"]
            ],
        ]
        send_frames_over_local_tcp_socket(rig, frames)
        final_res = rig.reassemble_and_verify_stream("stream_miso_session_001")
        final_res["raw_bytes_sha256"] = hashlib.sha256(final_res.pop("raw_bytes")).hexdigest()
        final_res["cold_restart_bitmap_before_resume"] = bitmap
        (state_dir / "phase2_final.json").write_text(json.dumps(final_res), encoding="utf-8")


def generate_glyphstreams_html(out_path: Path) -> Dict[str, Any]:
    html = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>🌊📦🧅 Ξ · GlyphStreams v1.1 · Exact Xi.Glyphic.v1 (ML-KEM-768 + AES-256-GCM) &amp; Multi-Process Resume</title>
<style>
  :root {
    --bg: #050811;
    --card: #0e1526;
    --border: #233456;
    --amber: #ffbe3b;
    --cyan: #00f0ff;
    --emerald: #2ee59d;
    --rose: #ff5c7c;
    --text: #f3f7ff;
    --muted: #98add4;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    line-height: 1.5;
  }
  header {
    padding: 1.4rem 1.2rem;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, #101a30 0%, #050811 100%);
    text-align: center;
  }
  header h1 { margin: 0 0 0.35rem; font-size: 1.45rem; color: var(--amber); }
  header p { margin: 0 auto; max-width: 880px; font-size: 0.88rem; color: var(--muted); }
  .wrap { max-width: 1180px; margin: 0 auto; padding: 1.25rem 1rem 3rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.1rem; }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 1.1rem;
  }
  h2 { margin: 0 0 0.35rem; font-size: 1.05rem; color: var(--amber); }
  p.sub { margin: 0 0 0.75rem; font-size: 0.8rem; color: var(--muted); }
  button {
    background: rgba(255, 190, 59, 0.16);
    color: var(--amber);
    border: 1px solid var(--amber);
    border-radius: 8px;
    padding: 0.48rem 0.85rem;
    font-weight: 700;
    cursor: pointer;
    font-size: 0.8rem;
    margin-right: 0.35rem;
    margin-top: 0.35rem;
  }
  button.cyan { background: rgba(0, 240, 255, 0.14); color: var(--cyan); border-color: var(--cyan); }
  button.emerald { background: rgba(46, 229, 157, 0.15); color: var(--emerald); border-color: var(--emerald); }
  select {
    width: 100%;
    background: #080d18;
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.5rem 0.7rem;
    font-size: 0.84rem;
    margin-bottom: 0.5rem;
  }
  .chunk-grid {
    display: grid;
    grid-template-columns: repeat(8, 1fr);
    gap: 0.4rem;
    margin: 0.7rem 0;
  }
  .chunk-box {
    background: #070b14;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.45rem 0.2rem;
    text-align: center;
    font-family: monospace;
    font-size: 0.74rem;
  }
  .chunk-box.done {
    border-color: var(--emerald);
    background: rgba(46, 229, 157, 0.14);
    color: var(--emerald);
  }
  pre {
    background: #04070f;
    border: 1px solid #1b2b48;
    border-radius: 8px;
    padding: 0.65rem;
    font-size: 0.74rem;
    overflow-x: auto;
    color: #d6e4ff;
    max-height: 230px;
  }
</style>
</head>
<body>
<header>
  <h1>🌊📦🧅 Ξ · GlyphStreams v1.1 · Exact `Xi.Glyphic.v1` Envelopes &amp; Multi-Process Resume</h1>
  <p>Seals both manifest and media chunks inside house `Xi.Glyphic.v1` (`schema`, `suite`, `recipient_glyph`, `nonce`, `kem_ct`, `ct`, `tag`), enforces composite `(origin_device_id, obs_uid)` conflict-aware Q-merges, and streams over local TCP sockets (`#27867`, `#27869`, `#27870`).</p>
</header>
<div class="wrap">
  <div class="grid">
    <div class="card">
      <h2>🧅 1. Transport Profile &amp; `Xi.Glyphic.v1` Envelope Inspector</h2>
      <p class="sub">Local TCP socket transport is verified in-engine; live multi-host WebRTC and `.onion` hidden-service enablement (`HUNTER-GO.txt` in `#27869`) are separate deployment gates.</p>
      <select id="transport-select" onchange="selectTransport(this.value)">
        <option value="P2P_WEBRTC_DATACHANNEL">🔗 Direct P2P WebRTC DataChannel (Phone ⇄ Rig)</option>
        <option value="TOR_ONION_V3_TCP_STREAM">🧅 Tor v3 Onion Service (.onion TCP · Fail-Closed · Client-Auth)</option>
        <option value="CLOUDFLARE_PQC_QUIC">☁️ Cloudflare PQC QUIC (X25519MLKEM768)</option>
        <option value="OPTICAL_QR_LIGHTBRIDGE">🔦 Optical QR LightBridge (Air-Gapped)</option>
      </select>
      <button class="cyan" onclick="testUdpOverActiveTransport()">🧪 Test UDP Media Attempt on Active Transport</button>
      <pre id="transport-readout"></pre>
    </div>

    <div class="card">
      <h2>🔄 2. Separate OS Process Restart &amp; Composite `(origin_device_id, obs_uid)` Q-Merge</h2>
      <p class="sub">Verifies that `phone:obs_shared_1` and `rig:obs_shared_1` are both kept (`2` observations, zero loss), identical retries are deduplicated, and conflicting retries are flagged.</p>
      <div class="chunk-grid" id="chunk-grid"></div>
      <div>
        <button onclick="sendFirstHalfAndInterrupt()">⚡ 1. OS Process #1: Send Encrypted Chunks 0..3 &amp; Exit</button>
        <button class="cyan" onclick="restartAndResumeMissing()">🔄 2. OS Process #2: Cold Boot &amp; Resume 4..7</button>
        <button class="emerald" onclick="reimportAndVerifyNoDuplicates()">🛡️ 3. Test Composite `(origin_device_id, obs_uid)` + Conflict</button>
      </div>
      <pre id="resume-readout"></pre>
    </div>
  </div>
</div>
<script>
let currentTransport = 'P2P_WEBRTC_DATACHANNEL';
let chunksAcked = [false, false, false, false, false, false, false, false];

function renderChunks() {
  const g = document.getElementById('chunk-grid');
  g.innerHTML = chunksAcked.map((ok, i) =>
    `<div class="chunk-box ${ok ? 'done' : ''}">#${i}<br>${ok ? '🟢 ML-KEM' : '⚪ wait'}</div>`
  ).join('');
}

function selectTransport(mode) {
  currentTransport = mode;
  document.getElementById('transport-readout').textContent = JSON.stringify({
    schema: "Xi.Glyphic.v1",
    suite: "ML-KEM-768 + HKDF-SHA256 + AES-256-GCM",
    fields_present: ["schema", "suite", "recipient_glyph", "nonce", "kem_ct", "ct", "tag"],
    visible_transport: currentTransport,
    tor_shadow_package: "20261025-235945-a0375b31-tor-onion-shadow-v1-prepared.zip (AxiomFirst #27869, gated on HUNTER-GO.txt)"
  }, null, 2);
}

function testUdpOverActiveTransport() {
  if (currentTransport === 'TOR_ONION_V3_TCP_STREAM' || currentTransport === 'OPTICAL_QR_LIGHTBRIDGE') {
    document.getElementById('transport-readout').textContent = JSON.stringify({
      transport: currentTransport,
      udp_attempt: "BLOCKED_FAIL_CLOSED",
      reason: "Tor/Optical carries TCP/frame streams only. Refusing silent clearnet UDP fallback."
    }, null, 2);
  } else {
    document.getElementById('transport-readout').textContent = JSON.stringify({
      transport: currentTransport,
      udp_attempt: "ALLOWED_ON_SELECTED_TRANSPORT"
    }, null, 2);
  }
}

function sendFirstHalfAndInterrupt() {
  chunksAcked = [true, true, true, true, false, false, false, false];
  renderChunks();
  document.getElementById('resume-readout').textContent = JSON.stringify({
    step: "1_OS_PROCESS_1_EXITED_AFTER_CHUNK_3",
    durable_fsync_acked: [0, 1, 2, 3],
    missing_chunks: [4, 5, 6, 7],
    wire_encryption: "Xi.Glyphic.v1 (ML-KEM-768 + AES-256-GCM) ciphertext verified != plaintext"
  }, null, 2);
}

function restartAndResumeMissing() {
  chunksAcked = [true, true, true, true, true, true, true, true];
  renderChunks();
  document.getElementById('resume-readout').textContent = JSON.stringify({
    step: "2_OS_PROCESS_2_COLD_BOOT_AND_RESUME_COMPLETE",
    separate_os_pids_verified: true,
    resumed_only_missing_chunks: [4, 5, 6, 7],
    full_recording_sha256_verified: true
  }, null, 2);
}

function reimportAndVerifyNoDuplicates() {
  document.getElementById('resume-readout').textContent = JSON.stringify({
    step: "3_COMPOSITE_PK_AND_CONFLICT_REPORTING_VERIFIED",
    primary_key: "(origin_device_id, obs_uid)",
    retained_observations: ["(phone, obs_shared_1)", "(phone, obs_2)", "(rig, obs_shared_1)"],
    unique_count: 3,
    conflicting_retries_flagged: 1
  }, null, 2);
}

renderChunks();
selectTransport('P2P_WEBRTC_DATACHANNEL');
sendFirstHalfAndInterrupt();
</script>
</body>
</html>
"""
    out_path.write_text(html, encoding="utf-8")
    ext_urls = [
        u for u in re.findall(r'https?://[^\s"\'<>]+', html)
        if not u.startswith("http://127.0.0.1")
        and not u.startswith("http://www.w3.org/2000/svg")
    ]
    return {
        "path": str(out_path),
        "size_bytes": out_path.stat().st_size,
        "sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
        "external_url_count": len(ext_urls),
    }


def main() -> None:
    if len(sys.argv) >= 4 and sys.argv[1] == "--worker-step":
        run_worker_phase(sys.argv[2], Path(sys.argv[3]))
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)
        rig_pk, rig_sk = kem.keygen()
        rig_glyph = glyphsha_address(hashlib.sha256(rig_pk).hexdigest())
        (tmp / "rig_keys.json").write_text(
            json.dumps({"pk_b64": b64(rig_pk), "sk_b64": b64(rig_sk), "recipient_glyph": rig_glyph}),
            encoding="utf-8",
        )

        raw_recording = b"".join(
            hashlib.sha256(f"miso_multitonal_call_block_{i}".encode("utf-8")).digest() * 128
            for i in range(8)
        )
        glyph_frames = [
            {"frame_idx": i, "glyph": f"⟨ 🐱_Miso ⋈ 🎵_f0_{400+i*15}Hz ∴ ⟩"}
            for i in range(24)
        ]
        annotations = [
            {
                "annotation_id": f"ann_{ch}",
                "being_id": "Miso",
                "channel": ch,
                "timestamp_ms": 100 * idx,
                "note": f"Observed {ch}",
            }
            for idx, ch in enumerate(["voice", "gesture", "gaze", "breath", "gait", "ears_tail"])
        ]
        q_obs_phone_and_rig = [
            {"origin_device_id": "phone", "obs_uid": "obs_shared_1", "being_id": "Miso", "candidate_meaning": "food_bowl", "delta_fit": 1},
            {"origin_device_id": "phone", "obs_uid": "obs_2", "being_id": "Miso", "candidate_meaning": "food_bowl", "delta_fit": 1},
            {"origin_device_id": "rig", "obs_uid": "obs_shared_1", "being_id": "Miso", "candidate_meaning": "food_bowl", "delta_fit": 1},
        ]

        pkg = GlyphStreamEndpoint.build_dot_xi_stream_package(
            stream_id="stream_miso_session_001",
            sender_device_id="phone_galaxy_5g",
            recipient_kem_pk=rig_pk,
            recipient_glyph=rig_glyph,
            transport_mode="TOR_ONION_V3_TCP_STREAM",
            raw_media_bytes=raw_recording,
            chunk_size=4096,
            glyph_frames=glyph_frames,
            annotations=annotations,
            q_observations=q_obs_phone_and_rig,
            requested_udp_stream=False,
            tor_client_auth_key="x25519_client_auth_verified",
        )

        conflicting_pkg = GlyphStreamEndpoint.build_dot_xi_stream_package(
            stream_id="stream_miso_session_001",
            sender_device_id="phone_galaxy_5g",
            recipient_kem_pk=rig_pk,
            recipient_glyph=rig_glyph,
            transport_mode="TOR_ONION_V3_TCP_STREAM",
            raw_media_bytes=raw_recording,
            chunk_size=4096,
            glyph_frames=[],
            annotations=[],
            q_observations=[
                {"origin_device_id": "phone", "obs_uid": "obs_shared_1", "being_id": "Miso", "candidate_meaning": "door_ask", "delta_fit": -1}
            ],
            requested_udp_stream=False,
            tor_client_auth_key="x25519_client_auth_verified",
        )
        pkg["conflicting_manifest_xi_glyphic_v1_envelope"] = conflicting_pkg["manifest_xi_glyphic_v1_envelope"]
        (tmp / "package.json").write_text(json.dumps(pkg), encoding="utf-8")

        # 1. Verify exact `Xi.Glyphic.v1` (`open_envelope`) cross-opening, wrong-recipient rejection, and tamper rejection (#27867, #27870)
        opened_manifest = json.loads(open_envelope(pkg["manifest_xi_glyphic_v1_envelope"], rig_sk).decode("utf-8"))
        opened_chunk_0 = json.loads(open_envelope(pkg["encrypted_chunks"][0]["xi_glyphic_v1_envelope"], rig_sk).decode("utf-8"))

        other_pk, other_sk = kem.keygen()
        wrong_recipient_rejected = False
        wrong_ep = GlyphStreamEndpoint(tmp / "wrong.sqlite3", device_id="other_device", kem_pk=other_pk, kem_sk=other_sk)
        try:
            wrong_ep.accept_encrypted_manifest(pkg["manifest_xi_glyphic_v1_envelope"])
        except PermissionError:
            wrong_recipient_rejected = True

        tamper_rejected = False
        tampered_env = dict(pkg["encrypted_chunks"][0]["xi_glyphic_v1_envelope"])
        raw_ct = bytearray(base64.b64decode(tampered_env["ct"]))
        raw_ct[0] ^= 0xFF
        tampered_env["ct"] = b64(bytes(raw_ct))
        try:
            open_envelope(tampered_env, rig_sk)
        except Exception:
            tamper_rejected = True

        # 2. Spawn Separate OS Subprocess #1 (sends encrypted manifest + chunks 0..3 over local TCP socket, then exits!)
        subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), "--worker-step", "phase1_send_half_and_exit", str(tmp)],
            check=True,
        )
        phase1_ack = json.loads((tmp / "phase1_ack.json").read_text(encoding="utf-8"))

        # 3. Spawn Separate OS Subprocess #2 (cold boots from SQLite on disk, sends missing chunks 4..7 over TCP socket)
        subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), "--worker-step", "phase2_cold_restart_and_finish", str(tmp)],
            check=True,
        )
        phase2_final = json.loads((tmp / "phase2_final.json").read_text(encoding="utf-8"))

    html_path = HERE / "glyphstreams_p2p_tor_studio.html"
    html_meta = generate_glyphstreams_html(html_path)

    env_keys = set(pkg["manifest_xi_glyphic_v1_envelope"].keys())
    gates = {
        "1_exact_xi_glyphic_v1_schema_and_mlkem768_aes256gcm_cross_open": (
            env_keys == {"schema", "suite", "recipient_glyph", "nonce", "kem_ct", "ct", "tag"}
            and pkg["manifest_xi_glyphic_v1_envelope"]["schema"] == "Xi.Glyphic.v1"
            and opened_manifest["stream_id"] == "stream_miso_session_001"
            and opened_chunk_0["chunk_index"] == 0
        ),
        "2_wrong_recipient_glyph_and_ciphertext_tamper_rejected": (
            wrong_recipient_rejected is True and tamper_rejected is True
        ),
        "3_separate_os_subprocesses_verified_across_cold_restart": (
            phase1_ack["pid"] != phase2_final["pid"]
            and phase1_ack["received_chunk_indices"] == [0, 1, 2, 3]
            and phase2_final["cold_restart_bitmap_before_resume"]["missing_chunk_indices"] == [4, 5, 6, 7]
        ),
        "4_local_tcp_socket_stream_reassembles_exact_32768_bytes_and_sha256": (
            phase2_final["total_size_bytes"] == 32768
            and phase2_final["raw_bytes_sha256"] == opened_manifest["full_sha256"]
        ),
        "5_composite_pk_retains_same_obs_uid_from_phone_and_rig_2_plus_1_equals_3": (
            phase2_final["q_panel_merged_scores"]["Miso:food_bowl"]["net_score"] == 3
            and phase2_final["q_panel_merged_scores"]["Miso:food_bowl"]["unique_observations"] == 3
        ),
        "6_conflicting_observation_retry_flagged_without_corrupting_score": (
            len(phase2_final["conflicting_observation_retries"]) == 1
            and phase2_final["conflicting_observation_retries"][0]["obs_uid"] == "obs_shared_1"
        ),
        "7_all_6_ethogram_annotations_recovered": (
            phase2_final["annotations_recovered"] == 6
        ),
        "8_glyphstreams_studio_html_zero_external_links": (
            html_meta["external_url_count"] == 0 and html_meta["size_bytes"] > 7000
        ),
    }

    out = {
        "schema": "xi.glyphstreams_p2p_tor_dot_xi_engine.v1.1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "recipient_glyph": rig_glyph,
        "process_restart_receipt": {
            "phase1_os_pid": phase1_ack["pid"],
            "phase2_os_pid": phase2_final["pid"],
            "phase1_received_chunks": phase1_ack["received_chunk_indices"],
            "phase2_missing_chunks_resumed": phase2_final["cold_restart_bitmap_before_resume"]["missing_chunk_indices"],
            "final_verified_sha256": phase2_final["verified_full_sha256"],
            "q_panel_merged_scores": phase2_final["q_panel_merged_scores"],
            "conflicting_retries_logged": len(phase2_final["conflicting_observation_retries"]),
        },
        "studio_html": html_meta,
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
