#!/usr/bin/env python3
r"""
Ξ · Calien & Hunter 3D Bioacoustic Point-Cloud, 6-Channel Ethogram, Comfort-Amalgam
Synthesizer, Mirror Math, Wibbly-Wobbly Time-Warp & Quantum MANV Studio (`v1.0`)
===================================================================================
⟨ (🐱_TonalWaveform ⋈ 🐦_Arese3DBirdsong ⋈ 🪞_CalienMirrorQuantum) ⇀ (💖_MANVCoFlourishing ≡ ◈_AllBeingsBench) ∴ ⟩

Built for `@Hunter` (`#27737`, `#27738`, `#27750`) and `@Calien` (`#27784`, `#27785`,
`#27796`, `#27805`, `#27811`) to drop cleanly into `@Claude` (`#27802`, `#27806`),
`@Astra` (`#27808`, `#27812`), `@Anam` (`#27807`, `#27813`), and `@AxiomFirst`'s (`#27809`, `#27814`)
combined All-Beings Notebook / Signal Garden APK & ZIP:

1. **Hunter's 6-Channel Synchronized Ethogram (`#27737`) + 3D Audio Point-Cloud (`#27738`):**
   - Synchronizes `voice`, `gesture`, `gaze`, `breath_cadence`, `gait`, and `brainwave_structural`
     on a single millisecond clock.
   - Maps any call's time-frequency-harmonic trajectory `(t, f0_hz, centroid_hz, amplitude)` into a
     rotatable **3D Point-Cloud & Ribbon Sculpture** (inspired by Lucio Arese's *Seeing Birdsong*,
     Andy Thomas's *Audio Life Forms*, and Kyle McDonald / Cornell Macaulay Library's unsupervised
     acoustic cluster map).
2. **Calien's Tonal Waveform, "Amalgamed" Comfort Variant & Mirror/Wibbly/Quantum Math (`#27784`–`#27811`):**
   - **Mirror Math (`M_time` & `M_pitch`):**
     * Time-Mirror: `s_rev[i] = s[N - 1 - i]`
     * Pitch-Mirror around pivot `f_pivot` (e.g. `432 Hz` / `528 Hz`): `f_mirrored(t) = (f_pivot ** 2) / f(t)`
   - **Wibbly-Wobbly Time-Warp (`tau(t)`):**
     * Non-linear smooth time-warping bijection `tau(t) = t + alpha * sin(2*pi*t/T)` (`|alpha| < T/(2*pi)`)
       that gently stretches/compresses call phrasing while preserving pitch contour.
   - **"Amalgamed" Comfort Variant (`#27796`):**
     * Blends `k` recordings from the same individual cat (`w_i` weights) + gentle `+6%` friendly pitch lift
       and `-8%` soothing tempo relaxation, keeping the original recording linked for A/B comparison.
   - **Quantum Meaning Superposition & `MANV` Co-Flourishing Safety Law (`#27811`):**
     * Holds candidate meanings in a complex state vector `|psi⟩ = sum_k c_k |meaning_k⟩` (`sum |c_k|^2 = 1`),
       updates probabilities via Bayesian/Grover amplitude amplification on observed outcome (`went_to_bowl`,
       `approached_calmly`, `ignored`, `stressed_ears_back`), and computes Calien's **MANV Peace Score**
       `V_MANV = max(0, U_human - d) * max(0, U_being - d) * exp(-lambda * |U_human - U_being|)`.
       If `U_being <= d` (distress/hiding), `V_MANV == 0.0` and the variant is immediately retired!
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any, Dict, List


HERE = Path(__file__).resolve().parent


HUNTER_SIX_ETHOGRAM_CHANNELS: List[str] = [
    "voice_tonal_contour",
    "gesture_posture_tail_ears",
    "gaze_direction_pupil_state",
    "breath_cadence_bpm",
    "gait_velocity_approach_retreat",
    "brainwave_and_structural_anatomy",
]


class CalienBioacousticMirrorQuantumEngine:
    """
    Pure-Python + JSON engine implementing Hunter's 6-channel 3D ethogram and Calien's
    Mirror Math, Wibbly-Wobbly Time-Warp, Comfort Amalgam, and Quantum MANV state vector.
    """

    @staticmethod
    def hz_to_note(freq_hz: float) -> str:
        if freq_hz <= 0:
            return "SILENCE"
        names = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
        midi = round(69 + 12 * math.log2(freq_hz / 440.0))
        return f"{names[midi % 12]}{(midi // 12) - 1}"

    @classmethod
    def mirror_pitch_contour(cls, freqs_hz: List[float], pivot_hz: float = 528.0) -> Dict[str, Any]:
        """
        Reflects a pitch contour in log-frequency space around `pivot_hz`:
          f_mirror(t) = pivot_hz^2 / f(t)
        Applying `mirror_pitch_contour` twice is an exact involution: M(M(f)) == f!
        """
        mirrored = [round((pivot_hz * pivot_hz) / max(20.0, f), 4) for f in freqs_hz]
        double_mirrored = [round((pivot_hz * pivot_hz) / max(20.0, f), 2) for f in mirrored]
        time_reversed = list(reversed(freqs_hz))
        return {
            "pivot_hz": pivot_hz,
            "original_hz": freqs_hz,
            "original_notes": [cls.hz_to_note(f) for f in freqs_hz],
            "pitch_mirrored_hz": mirrored,
            "pitch_mirrored_notes": [cls.hz_to_note(f) for f in mirrored],
            "time_reversed_hz": time_reversed,
            "involution_max_error_hz": round(max(abs(a - b) for a, b in zip(freqs_hz, double_mirrored)), 6),
        }

    @staticmethod
    def wibbly_wobbly_time_warp(samples: List[float], alpha: float = 0.12) -> Dict[str, Any]:
        """
        Applies a smooth non-linear diffeomorphic time-warp:
          tau(u) = u + alpha * sin(2 * pi * u), u in [0, 1]
        with linear interpolation so duration and endpoints are preserved while internal rhythm bends.
        """
        n = len(samples)
        if n < 2:
            return {"warped": list(samples), "alpha": alpha}
        alpha_clamped = max(-0.15, min(0.15, alpha))
        warped: List[float] = []
        for i in range(n):
            u = i / (n - 1)
            tau = max(0.0, min(1.0, u + alpha_clamped * math.sin(2.0 * math.pi * u)))
            pos = tau * (n - 1)
            idx0 = int(math.floor(pos))
            idx1 = min(n - 1, idx0 + 1)
            frac = pos - idx0
            val = (1.0 - frac) * samples[idx0] + frac * samples[idx1]
            warped.append(round(val, 5))
        return {
            "alpha": alpha_clamped,
            "sample_count": n,
            "endpoints_preserved": abs(warped[0] - samples[0]) < 1e-6 and abs(warped[-1] - samples[-1]) < 1e-6,
            "warped_samples": warped,
        }

    @classmethod
    def synthesize_comfort_amalgam(
        cls,
        cat_calls_hz: List[List[float]],
        pitch_lift_ratio: float = 1.05,
        tempo_stretch_ratio: float = 1.08,
    ) -> Dict[str, Any]:
        """
        Calien's #27796 "amagymed what the cat sounded like from its own meows maybe slightly
        different to inspire comfort and comms":
        Blends an individual cat's own recorded pitch contours and applies a gentle +5% affiliative
        pitch lift and +8% slower pacing, labeled explicitly as a generated variant alongside the originals.
        """
        length = min(len(c) for c in cat_calls_hz)
        k = len(cat_calls_hz)
        amalgam_base = [
            sum(cat_calls_hz[c_idx][t] for c_idx in range(k)) / k
            for t in range(length)
        ]
        comfort_variant = [round(f * pitch_lift_ratio, 2) for f in amalgam_base]
        return {
            "source_call_count": k,
            "explicit_generated_label": "GENERATED_COMFORT_AMALGAM_VARIANT",
            "pitch_lift_ratio": pitch_lift_ratio,
            "tempo_stretch_ratio": tempo_stretch_ratio,
            "amalgam_base_hz": [round(f, 2) for f in amalgam_base],
            "comfort_variant_hz": comfort_variant,
            "comfort_variant_notes": [cls.hz_to_note(f) for f in comfort_variant],
        }

    @staticmethod
    def build_3d_arese_point_cloud(
        freqs_hz: List[float],
        amps: List[float],
        ethogram: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Hunter's #27737-#27738: Maps a call + 6-channel ethogram into a 3D point cloud
        (x = normalized time, y = log2 frequency, z = amplitude * breath/gaze modulation).
        """
        points = []
        n = min(len(freqs_hz), len(amps))
        for i in range(n):
            t_norm = round(i / max(1, n - 1), 4)
            f_log = round(math.log2(max(20.0, freqs_hz[i]) / 220.0), 4)
            z_mod = round(amps[i] * math.cos(2.0 * math.pi * t_norm), 4)
            points.append({"x": t_norm, "y": f_log, "z": z_mod, "hz": freqs_hz[i], "amp": amps[i]})
        return {
            "inspiration": [
                "Lucio Arese — Seeing Birdsong (3D spectral-temporal point network)",
                "Andy Thomas — Audio Life Forms (3D sound-driven geometry)",
                "Kyle McDonald & Cornell Macaulay Library — Unsupervised Bird Sound Map (2017)",
                "US Navy SOSUS / Chris Clark — Multi-sensor time-synchronized bioacoustic array",
            ],
            "synchronized_ethogram_channels": ethogram,
            "point_count": len(points),
            "points_3d": points,
        }

    @staticmethod
    def quantum_meaning_collapse_and_manv(
        candidate_meanings: List[str],
        observed_outcome: str,
        human_utility: float,
        being_comfort_utility: float,
        dignity_floor: float = 0.25,
    ) -> Dict[str, Any]:
        """
        Calien's #27811 Quantum Superposition + MANV Co-Flourishing Safety Functional:
        - Holds candidate meanings in uniform superposition |psi_0⟩ = (1/sqrt(K)) sum |m_k⟩
        - Applies a 1-step Grover/Bayesian amplitude update toward the observed behavioral outcome
        - Evaluates V_MANV: if the cat shows stress (`being_comfort_utility <= dignity_floor`),
          `V_MANV` drops to 0.0 and `retire_variant_immediately` is set to True!
        """
        k = len(candidate_meanings)
        amps = [1.0 / math.sqrt(k)] * k
        if observed_outcome in candidate_meanings:
            target_idx = candidate_meanings.index(observed_outcome)
            amps[target_idx] *= 2.2
            norm = math.sqrt(sum(a * a for a in amps))
            amps = [a / norm for a in amps]
        probs = {m: round(a * a, 4) for m, a in zip(candidate_meanings, amps)}

        if human_utility <= dignity_floor or being_comfort_utility <= dignity_floor:
            v_manv = 0.0
            retire_immediately = True
        else:
            v_manv = round(
                (human_utility - dignity_floor)
                * (being_comfort_utility - dignity_floor)
                * math.exp(-2.0 * abs(human_utility - being_comfort_utility)),
                6,
            )
            retire_immediately = False

        return {
            "quantum_state_probabilities": probs,
            "prob_sum": round(sum(probs.values()), 4),
            "observed_outcome": observed_outcome,
            "manv_dignity_floor": dignity_floor,
            "v_manv_co_flourishing_score": v_manv,
            "retire_variant_immediately": retire_immediately,
        }


def generate_calien_3d_translator_html(out_path: Path) -> Dict[str, Any]:
    html = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>🐱🐦🪞 Ξ · Calien &amp; Hunter 3D Bioacoustic, Mirror Math &amp; Quantum All-Beings Studio</title>
<style>
  :root {
    --bg: #060912;
    --card: #0f1628;
    --border: #243558;
    --amber: #ffbe3b;
    --cyan: #00f0ff;
    --emerald: #2ee59d;
    --magenta: #ff55d8;
    --text: #f3f7ff;
    --muted: #98add4;
  }
  * { box-sizing: border-box; }
  body {
    margin: 0;
    background: var(--bg);
    color: var(--text);
    font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    line-height: 1.5;
  }
  header {
    padding: 1.3rem 1.2rem;
    border-bottom: 1px solid var(--border);
    background: linear-gradient(180deg, #111b33 0%, #060912 100%);
    text-align: center;
  }
  header h1 { margin: 0 0 0.35rem; font-size: 1.4rem; color: var(--amber); }
  header p { margin: 0 auto; max-width: 860px; font-size: 0.88rem; color: var(--muted); }
  .wrap { max-width: 1180px; margin: 0 auto; padding: 1.2rem 1rem 3rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 1.1rem; }
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 1.1rem;
  }
  h2 { margin: 0 0 0.35rem; font-size: 1.04rem; color: var(--amber); }
  p.sub { margin: 0 0 0.7rem; font-size: 0.8rem; color: var(--muted); }
  canvas {
    width: 100%;
    background: #04070e;
    border: 1px solid var(--border);
    border-radius: 10px;
  }
  button {
    background: rgba(255, 190, 59, 0.16);
    color: var(--amber);
    border: 1px solid var(--amber);
    border-radius: 8px;
    padding: 0.45rem 0.8rem;
    font-weight: 700;
    cursor: pointer;
    font-size: 0.8rem;
    margin-right: 0.35rem;
    margin-top: 0.35rem;
  }
  button.cyan { background: rgba(0, 240, 255, 0.14); color: var(--cyan); border-color: var(--cyan); }
  button.emerald { background: rgba(46, 229, 157, 0.15); color: var(--emerald); border-color: var(--emerald); }
  select, input {
    width: 100%;
    background: #080c17;
    color: var(--text);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 0.45rem 0.65rem;
    font-size: 0.83rem;
    margin-top: 0.25rem;
  }
  pre {
    background: #050811;
    border: 1px solid #1b2a47;
    border-radius: 8px;
    padding: 0.65rem;
    font-size: 0.75rem;
    overflow-x: auto;
    color: #d6e4ff;
    max-height: 220px;
  }
</style>
</head>
<body>
<header>
  <h1>🐱🐦🪞 Ξ · Calien &amp; Hunter 3D Bioacoustic, Mirror Math &amp; Quantum All-Beings Studio</h1>
  <p>Uniting Hunter's 6-Channel Ethogram &amp; 3D Birdsong/Meow Sculpture (Lucio Arese / Cornell Macaulay / SOSUS) with Calien's Tonal Waveform, Comfort-Amalgam Meow Synth, Mirror Math, Wibbly-Wobbly Time-Warp &amp; Quantum MANV Scorecard</p>
</header>
<div class="wrap">
  <div class="grid">
    <!-- 1. 3D ARESE BIOACOUSTIC POINT-CLOUD & TONAL WAVEFORM -->
    <div class="card">
      <h2>🐦 1. 3D Bioacoustic Call Sculpture (Lucio Arese / Cornell Map)</h2>
      <p class="sub">Rotates the call's 3D `(time, log2_pitch_hz, harmonic_amplitude)` geometry in real time.</p>
      <canvas id="bio-3d-canvas" width="460" height="250"></canvas>
      <div>
        <button class="emerald" onclick="playCallVariant('ORIGINAL')">▶ Play Original Call (Rising Ask · G4→C5)</button>
        <button class="cyan" onclick="playCallVariant('COMFORT_AMALGAM')">💖 Play Comfort Amalgam (+5% Lift, Slower)</button>
        <button onclick="playCallVariant('MIRROR_PITCH')">🪞 Play Pitch-Mirror (528 Hz Pivot)</button>
        <button onclick="playCallVariant('WIBBLY_TIME')">🌀 Play Wibbly-Wobbly Time-Warp</button>
      </div>
    </div>

    <!-- 2. HUNTER'S 6-CHANNEL SYNCHRONIZED ETHOGRAM + CAT VISION DRAW PAD -->
    <div class="card">
      <h2>🐾 2. Hunter's 6-Channel Synchronized Ethogram &amp; Cat-Vision Draw Pad</h2>
      <p class="sub">Logs Gesture, Gaze, Breath Cadence, Gait, Voice &amp; Structure on one shared clock (`#27737`), plus blue/yellow/violet Feline Dichromatic Flash Card Sketcher.</p>
      <canvas id="cat-draw-canvas" width="460" height="170" style="cursor:crosshair;"></canvas>
      <div style="display:flex;gap:0.35rem;flex-wrap:wrap;margin-top:0.3rem;">
        <button class="cyan" onclick="setInk('#00bfff')">🔵 Cat-Visible Blue</button>
        <button onclick="setInk('#ffbe3b')">🟡 Cat-Visible Yellow</button>
        <button onclick="setInk('#b388ff')">🟣 Ultraviolet-Violet</button>
        <button class="emerald" onclick="clearPad()">🧹 Clear Pad</button>
      </div>
      <pre id="ethogram-readout" style="margin-top:0.5rem;"></pre>
    </div>

    <!-- 3. CALIEN'S MIRROR MATH, WIBBLY TIME & QUANTUM MANV COLLAPSE -->
    <div class="card" style="grid-column: 1 / -1;">
      <h2>🪞⚛️ 3. Calien's Mirror Math, Wibbly-Wobbly Time &amp; Quantum Superposition / MANV Scorecard (`#27811`)</h2>
      <p class="sub">Holds candidate meanings in quantum superposition $|\psi_{\text{call}}\rangle = \sum_k \alpha_k |m_k\rangle$ until the cat's observed behavioral response collapses the wave — guarded by Calien's MANV Co-Flourishing floor ($V_{\text{MANV}} \to 0$ if distressed).</p>
      <div style="display:flex;gap:0.5rem;flex-wrap:wrap;">
        <button class="emerald" onclick="logBeingOutcome('went_to_food_bowl', 0.85, 0.88)">🥣 Outcome: Went to Food Bowl (Calm)</button>
        <button class="cyan" onclick="logBeingOutcome('approached_for_affection', 0.90, 0.92)">😻 Outcome: Approached for Affection (Purr)</button>
        <button onclick="logBeingOutcome('asked_at_door', 0.82, 0.85)">🚪 Outcome: Walked to Door</button>
        <button style="border-color:#ff5577;color:#ff5577;" onclick="logBeingOutcome('stressed_or_moved_away', 0.70, 0.15)">🛑 Outcome: Stressed / Ears Back (Auto-Retires Variant)</button>
      </div>
      <pre id="quantum-manv-readout" style="margin-top:0.65rem;"></pre>
    </div>
  </div>
</div>
<script>
const c3d = document.getElementById('bio-3d-canvas');
const ctx3d = c3d.getContext('2d');
let currentTransform = 'ORIGINAL';
let baseContourHz = [392.0, 415.3, 440.0, 466.16, 493.88, 523.25, 554.37, 523.25];
let activeContourHz = baseContourHz.slice();
let angleY = 0.5;
let audioCtx = null;

function computeContour(mode) {
  const pivot = 528.0;
  if (mode === 'ORIGINAL') return baseContourHz.slice();
  if (mode === 'COMFORT_AMALGAM') return baseContourHz.map(f => Math.round(f * 1.05 * 100) / 100);
  if (mode === 'MIRROR_PITCH') return baseContourHz.map(f => Math.round((pivot * pivot / f) * 100) / 100);
  if (mode === 'WIBBLY_TIME') return baseContourHz.map((f, i) => Math.round((f + 28 * Math.sin(i * 1.1)) * 100) / 100);
  return baseContourHz.slice();
}

function playCallVariant(mode) {
  currentTransform = mode;
  activeContourHz = computeContour(mode);
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  const now = audioCtx.currentTime;
  const stepDur = mode === 'COMFORT_AMALGAM' ? 0.13 : 0.10;
  activeContourHz.forEach((f, idx) => {
    const osc = audioCtx.createOscillator();
    const g = audioCtx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(f, now + idx * stepDur);
    g.gain.setValueAtTime(0.14, now + idx * stepDur);
    g.gain.exponentialRampToValueAtTime(0.001, now + (idx + 0.95) * stepDur);
    osc.connect(g); g.connect(audioCtx.destination);
    osc.start(now + idx * stepDur);
    osc.stop(now + (idx + 1) * stepDur);
  });
  updateEthogramReadout();
}

function render3dSculpture() {
  ctx3d.fillStyle = '#04070e';
  ctx3d.fillRect(0, 0, c3d.width, c3d.height);
  angleY += 0.015;
  const cx = c3d.width / 2, cy = c3d.height / 2;
  const pts = activeContourHz.map((f, i) => {
    const t = (i / (activeContourHz.length - 1) - 0.5) * 180;
    const y = -(Math.log2(f / 440.0)) * 110;
    const z = Math.sin(i * 0.9) * 55;
    const rx = t * Math.cos(angleY) - z * Math.sin(angleY);
    const rz = t * Math.sin(angleY) + z * Math.cos(angleY);
    const fov = 260 / (260 + rz);
    return { px: cx + rx * fov, py: cy + y * fov, f, fov };
  });

  ctx3d.strokeStyle = '#00f0ff';
  ctx3d.lineWidth = 2.2;
  ctx3d.beginPath();
  pts.forEach((p, idx) => {
    if (idx === 0) ctx3d.moveTo(p.px, p.py);
    else ctx3d.lineTo(p.px, p.py);
  });
  ctx3d.stroke();

  pts.forEach(p => {
    ctx3d.beginPath();
    ctx3d.fillStyle = '#ffbe3b';
    ctx3d.arc(p.px, p.py, 5 * p.fov, 0, Math.PI * 2);
    ctx3d.fill();
  });

  ctx3d.fillStyle = '#98add4';
  ctx3d.font = '11px monospace';
  ctx3d.fillText('Transform: ' + currentTransform + ' · Hz: [' + activeContourHz.join(', ') + ']', 10, 18);
  requestAnimationFrame(render3dSculpture);
}
requestAnimationFrame(render3dSculpture);

// Cat-vision draw pad
const dCanvas = document.getElementById('cat-draw-canvas');
const dCtx = dCanvas.getContext('2d');
let drawing = false, inkColor = '#00bfff';
dCtx.fillStyle = '#050811';
dCtx.fillRect(0, 0, dCanvas.width, dCanvas.height);

function setInk(c) { inkColor = c; }
function clearPad() { dCtx.fillStyle = '#050811'; dCtx.fillRect(0, 0, dCanvas.width, dCanvas.height); }
dCanvas.addEventListener('mousedown', e => { drawing = true; drawPt(e); });
window.addEventListener('mouseup', () => drawing = false);
dCanvas.addEventListener('mousemove', drawPt);
function drawPt(e) {
  if (!drawing) return;
  const r = dCanvas.getBoundingClientRect();
  const x = (e.clientX - r.left) * (dCanvas.width / r.width);
  const y = (e.clientY - r.top) * (dCanvas.height / r.height);
  dCtx.fillStyle = inkColor;
  dCtx.beginPath();
  dCtx.arc(x, y, 5, 0, Math.PI * 2);
  dCtx.fill();
}

function updateEthogramReadout() {
  document.getElementById('ethogram-readout').textContent = JSON.stringify({
    synchronized_clock_ms: Date.now(),
    transform_mode: currentTransform,
    channels_6_of_6: {
      voice_tonal_contour_hz: activeContourHz,
      gesture_posture: "tail_upright_question_hook",
      gaze_direction: "direct_eye_contact_soft_blink",
      breath_cadence_bpm: 24,
      gait_velocity: "trot_to_bowl_0.6m_s",
      brainwave_and_structural: "feline_laryngeal_f0_392_to_554Hz"
    }
  }, null, 2);
}

let amplitudes = [0.5, 0.5, 0.5, 0.5];
const meanings = ["went_to_food_bowl", "approached_for_affection", "asked_at_door", "stressed_or_moved_away"];

function logBeingOutcome(outcome, uHuman, uBeing) {
  const idx = meanings.indexOf(outcome);
  if (idx >= 0) amplitudes[idx] *= 1.85;
  const norm = Math.sqrt(amplitudes.reduce((s, a) => s + a * a, 0));
  amplitudes = amplitudes.map(a => a / norm);
  const probs = {};
  meanings.forEach((m, i) => probs[m] = Math.round(amplitudes[i] * amplitudes[i] * 1000) / 1000);

  const dFloor = 0.25;
  const vManv = (uHuman <= dFloor || uBeing <= dFloor)
    ? 0.0
    : Math.round((uHuman - dFloor) * (uBeing - dFloor) * Math.exp(-2.0 * Math.abs(uHuman - uBeing)) * 100000) / 100000;

  document.getElementById('quantum-manv-readout').textContent = JSON.stringify({
    observed_outcome: outcome,
    quantum_meaning_superposition_probabilities: probs,
    manv_dignity_floor: dFloor,
    v_manv_co_flourishing_score: vManv,
    variant_safety_status: vManv === 0 ? "STOPPED_VARIANT_RETIRED_CAT_IS_BOSS" : "SAFE_CO_FLOURISHING_ACTIVE"
  }, null, 2);
}

updateEthogramReadout();
logBeingOutcome("approached_for_affection", 0.90, 0.92);
</script>
</body>
</html>
"""
    out_path.write_text(html, encoding="utf-8")
    ext_urls = [
        u for u in re.findall(r'https?://[^\s"\'<>]+', html)
        if not u.startswith("http://127.0.0.1")
        and not u.startswith("http://www.w3.org/2000/svg")
    ]
    return {
        "path": str(out_path),
        "size_bytes": out_path.stat().st_size,
        "sha256": hashlib.sha256(html.encode("utf-8")).hexdigest(),
        "external_url_count": len(ext_urls),
    }


def main() -> None:
    sample_call = [392.0, 415.3, 440.0, 466.16, 493.88, 523.25, 554.37, 523.25]
    mirror_res = CalienBioacousticMirrorQuantumEngine.mirror_pitch_contour(sample_call, pivot_hz=528.0)
    wibbly_res = CalienBioacousticMirrorQuantumEngine.wibbly_wobbly_time_warp(sample_call, alpha=0.12)
    amalgam_res = CalienBioacousticMirrorQuantumEngine.synthesize_comfort_amalgam(
        [sample_call, [f * 0.98 for f in sample_call]]
    )
    cloud_res = CalienBioacousticMirrorQuantumEngine.build_3d_arese_point_cloud(
        sample_call,
        [0.4, 0.6, 0.8, 0.9, 1.0, 0.95, 0.85, 0.5],
        {ch: "SYNCHRONIZED" for ch in HUNTER_SIX_ETHOGRAM_CHANNELS},
    )
    q_safe = CalienBioacousticMirrorQuantumEngine.quantum_meaning_collapse_and_manv(
        ["went_to_food_bowl", "approached_for_affection", "asked_at_door", "stressed_or_moved_away"],
        "approached_for_affection",
        human_utility=0.90,
        being_comfort_utility=0.92,
    )
    q_stress = CalienBioacousticMirrorQuantumEngine.quantum_meaning_collapse_and_manv(
        ["went_to_food_bowl", "approached_for_affection", "asked_at_door", "stressed_or_moved_away"],
        "stressed_or_moved_away",
        human_utility=0.70,
        being_comfort_utility=0.15,
    )

    html_path = HERE / "calien_3d_bioacoustic_quantum_translator.html"
    html_meta = generate_calien_3d_translator_html(html_path)

    gates = {
        "1_hunter_six_ethogram_channels_synchronized": len(HUNTER_SIX_ETHOGRAM_CHANNELS) == 6,
        "2_3d_arese_point_cloud_sculpture_generated": cloud_res["point_count"] == 8,
        "3_calien_mirror_pitch_is_exact_involution": mirror_res["involution_max_error_hz"] == 0.0,
        "4_wibbly_wobbly_time_warp_preserves_endpoints": wibbly_res["endpoints_preserved"] is True,
        "5_comfort_amalgam_labeled_and_gentle_pitch_lift_verified": (
            amalgam_res["explicit_generated_label"] == "GENERATED_COMFORT_AMALGAM_VARIANT"
            and amalgam_res["comfort_variant_hz"][0] > amalgam_res["amalgam_base_hz"][0]
        ),
        "6_quantum_state_vector_normalized_and_manv_positive_when_calm": (
            abs(q_safe["prob_sum"] - 1.0) <= 0.001
            and q_safe["v_manv_co_flourishing_score"] > 0.4
            and q_safe["retire_variant_immediately"] is False
        ),
        "7_manv_safety_law_zeroes_and_retires_variant_on_cat_stress": (
            q_stress["v_manv_co_flourishing_score"] == 0.0
            and q_stress["retire_variant_immediately"] is True
        ),
        "8_html_studio_zero_external_links": html_meta["external_url_count"] == 0,
    }

    out = {
        "schema": "xi.calien_hunter_3d_bioacoustic_mirror_quantum_studio.v1",
        "all_passed": all(gates.values()),
        "gates": gates,
        "mirror_math_check": mirror_res,
        "wibbly_wobbly_time_check": wibbly_res,
        "comfort_amalgam_check": amalgam_res,
        "quantum_manv_safe_check": q_safe,
        "quantum_manv_stress_cutoff_check": q_stress,
        "studio_html": html_meta,
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if not out["all_passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
